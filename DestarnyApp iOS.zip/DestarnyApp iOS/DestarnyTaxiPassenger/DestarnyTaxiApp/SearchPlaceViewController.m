//
//  SearchPlaceViewController.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/16/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "SearchPlaceViewController.h"
#import "SearchBarCell.h"
#import "MBProgressHUD.h"


@interface SearchPlaceViewController ()
{
    NSMutableArray *arrSearchRes;
    NSDictionary *dicSelectedLoc;
    NSString *strSearchedAddress;
    MBProgressHUD *HUD;
    
}
@end

@implementation SearchPlaceViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _searchBar.layer.cornerRadius = 5;
    _searchBar.clipsToBounds = YES;
    
    strSearchedAddress = [[NSString alloc] init];
    dicSelectedLoc = [[NSDictionary alloc] init];
    arrSearchRes = [[NSMutableArray alloc] init];
    
    HUD=[[MBProgressHUD alloc]initWithView:self.view];
    [HUD setLabelText:@"Loading"];
    [self.view addSubview:HUD];
}

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if([_searchBar.text length] == 0 || [_searchBar.text isEqualToString:@""])
    {
        _tblSearchOptions.hidden = YES;
    }
    else
    {
        _tblSearchOptions.hidden = NO;
        NSString *urlSTR=[[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyC6SPQpZxZ_JGnUZNd8AKGeBOR8UkXHJtw",searchText] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
        
        NSURL *url = [NSURL URLWithString:urlSTR];
        
        NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
        NSURLResponse *responce;
        NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
        NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
        if( [[dictionary1 valueForKey:@"status"] isEqualToString:@"OK"])
        {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                arrSearchRes = [dictionary1 valueForKey:@"predictions"];
                [_tblSearchOptions reloadData];
            });
        }
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"selected row : ");
    dicSelectedLoc = [arrSearchRes objectAtIndex:indexPath.row];
    _searchBar.text = strSearchedAddress;
    _tblSearchOptions.hidden = YES;
    strSearchedAddress = [[arrSearchRes objectAtIndex:indexPath.row] valueForKey:@"description"];
    [_delegateServiceType selectedValue:strSearchedAddress];

    [HUD show:YES];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        
        [HUD hide:YES];
        [self.navigationController popViewControllerAnimated:YES];
    });
    
    
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrSearchRes.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"SearchBarCell"; 
    SearchBarCell *cell = [_tblSearchOptions dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if (cell == nil)
    {
        cell = [[SearchBarCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier] ;
    }
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    cell.lblPredAdress.text = [[arrSearchRes objectAtIndex:indexPath.row] valueForKey:@"description"];
//    strSearchedAddress = [[arrSearchRes objectAtIndex:indexPath.row] valueForKey:@"description"];
    
    return cell;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self.searchBar resignFirstResponder];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)SearchBar
{
    [_searchBar resignFirstResponder];
}

@end
