//
//  DatePicker.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 9/14/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import "DatePicker.h"
#import "DatePickerDelegate.h"


//Check screen macros
#define IS_WIDESCREEN (fabs ( (double)[[UIScreen mainScreen] bounds].size.height - (double)568) < DBL_EPSILON)
#define IS_OS_6_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] < 7.0 )
#define IS_OS_7_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)


////Editable macros
//#define TEXT_COLOR [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]
//#define SELECTED_TEXT_COLOR [UIColor blackColor]
//#define LINE_COLOR [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]
//#define SAVE_AREA_COLOR [UIColor colorWithWhite:0.95 alpha:1.0]
//#define BAR_SEL_COLOR [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]
//#define SAVE_BUTTON_COLOR [UIColor colorWithRed:.45 green:.76 blue:.19 alpha:1]

//-- bright yello - 255 203 7

//Editable macros
#define TEXT_COLOR [UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1]
#define SELECTED_TEXT_COLOR [UIColor blackColor]
#define LINE_COLOR [UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1]
#define SAVE_AREA_COLOR [UIColor colorWithWhite:0.95 alpha:1.0]
#define BAR_SEL_COLOR [UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1]
#define SAVE_BUTTON_COLOR [UIColor colorWithRed:.45 green:.76 blue:.19 alpha:1]


//Editable constants
static const float VALUE_HEIGHT1 = 50.0;
static const float SAVE_AREA_HEIGHT1 = 70.0;
static const float SAVE_AREA_MARGIN_TOP1= 20.0;

//Editable values
float PICKER_HEIGHT1 = 600;
NSString *FONT_NAME1 = @"Arial";//@"HelveticaNeue";
NSString *BOLD_FONT_NAME1 = @"Arial";//@"HelveticaNeue-Medium";

NSString *NOW1 = @"Now";

//Static macros and constants
#define SELECTOR_ORIGIN (PICKER_HEIGHT1/2.0-VALUE_HEIGHT1/2.0)
//#define SAVE_AREA_ORIGIN_Y self.bounds.size.height-SAVE_AREA_HEIGHT
#define PICKER_ORIGIN_Y SAVE_AREA_ORIGIN_Y-SAVE_AREA_MARGIN_TOP1-PICKER_HEIGHT1
#define BAR_SEL_ORIGIN_Y PICKER_HEIGHT1/2.0-VALUE_HEIGHT1/2.0


//Custom UIButton
@implementation SBPickerButton1

- (id)initWithFrame1:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setBackgroundColor:SAVE_BUTTON_COLOR];
        [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self setTitleColor:SELECTED_TEXT_COLOR forState:UIControlStateHighlighted];
        [self.titleLabel setFont:[UIFont fontWithName:FONT_NAME1 size:18.0]];
        self.layer.cornerRadius = 8.0f;
        self.clipsToBounds = YES;
        
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGFloat outerMargin = 5.0f;
    CGRect outerRect = CGRectInset(self.bounds, outerMargin, outerMargin);
    CGFloat radius = 6.0;
    
    CGMutablePathRef outerPath = CGPathCreateMutable();
    CGPathMoveToPoint(outerPath, NULL, CGRectGetMidX(outerRect), CGRectGetMinY(outerRect));
    CGPathAddArcToPoint(outerPath, NULL, CGRectGetMaxX(outerRect), CGRectGetMinY(outerRect), CGRectGetMaxX(outerRect), CGRectGetMaxY(outerRect), radius);
    CGPathAddArcToPoint(outerPath, NULL, CGRectGetMaxX(outerRect), CGRectGetMaxY(outerRect), CGRectGetMinX(outerRect), CGRectGetMaxY(outerRect), radius);
    CGPathAddArcToPoint(outerPath, NULL, CGRectGetMinX(outerRect), CGRectGetMaxY(outerRect), CGRectGetMinX(outerRect), CGRectGetMinY(outerRect), radius);
    CGPathAddArcToPoint(outerPath, NULL, CGRectGetMinX(outerRect), CGRectGetMinY(outerRect), CGRectGetMaxX(outerRect), CGRectGetMinY(outerRect), radius);
    CGPathCloseSubpath(outerPath);
    
    CGContextSaveGState(context);
    CGContextSetStrokeColorWithColor(context, (self.state != UIControlStateHighlighted) ? SAVE_BUTTON_COLOR.CGColor : SELECTED_TEXT_COLOR.CGColor);
    CGContextAddPath(context, outerPath);
    CGContextStrokePath(context);
    CGContextRestoreGState(context);
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    [self setNeedsDisplay];
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesEnded:touches withEvent:event];
    [self setNeedsDisplay];
}

-(void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesCancelled:touches withEvent:event];
    [self setNeedsDisplay];
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesMoved:touches withEvent:event];
    [self setNeedsDisplay];
}

@end


//Custom scrollView
@interface SBPickerScrollView1 ()
@property (nonatomic, strong) NSArray *arrValues1;
@property (nonatomic, strong) UIFont *cellFont1;
@property (nonatomic, strong) UIFont *boldCellFont1;
@property (nonatomic, assign, getter = isScrolling) BOOL scrolling1;

@end

@implementation SBPickerScrollView1

//Constants
const float LBL_BORDER_OFFSET1 = 8.0;

//Configure the tableView
- (id)initWithFrame:(CGRect)frame andValues:(NSArray *)arrayValues
      withTextAlign:(NSTextAlignment)align andTextSize:(float)txtSize
{
    
    if(self = [super initWithFrame:frame])
    {
        [self setScrollEnabled:YES];
        [self setShowsVerticalScrollIndicator:NO];
        [self setUserInteractionEnabled:YES];
        [self setBackgroundColor:[UIColor clearColor]];
        [self setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        [self setContentInset:UIEdgeInsetsMake(BAR_SEL_ORIGIN_Y, 0.0, BAR_SEL_ORIGIN_Y, 0.0)];
        
        _cellFont1 = [UIFont fontWithName:FONT_NAME1 size:txtSize];
        _boldCellFont1 = [UIFont fontWithName:BOLD_FONT_NAME1 size:txtSize];
        
        if(arrayValues)
            _arrValues1 = [arrayValues copy];
    }
    return self;
}

//Dehighlight the last cell
- (void)dehighlightLastCell
{
    NSArray *paths = [NSArray arrayWithObjects:[NSIndexPath indexPathForRow:_tagLastSelected1 inSection:0], nil];
    [self setTagLastSelected1:-1];
    [self beginUpdates];
    [self reloadRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationNone];
    [self endUpdates];
}

//Highlight a cell
- (void)highlightCellWithIndexPathRow:(NSUInteger)indexPathRow
{
    [self setTagLastSelected1:indexPathRow];
    NSArray *paths = [NSArray arrayWithObjects:[NSIndexPath indexPathForRow:_tagLastSelected1 inSection:0], nil];
    [self beginUpdates];
    [self reloadRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationNone];
    [self endUpdates];
}

@end

@interface DatePicker ()

@property (nonatomic, strong) NSArray *arrDays1;
@property (nonatomic, strong) NSArray *arrHours1;
@property (nonatomic, strong) NSArray *arrMinutes1;
@property (nonatomic, strong) NSArray *arrMeridians1;
@property (nonatomic, strong) NSArray *arrDates1;

@property (nonatomic, strong) SBPickerScrollView1 *svDays1;
@property (nonatomic, strong) SBPickerScrollView1 *svHours1;
@property (nonatomic, strong) SBPickerScrollView1 *svMins1;
@property (nonatomic, strong) SBPickerScrollView1 *svMeridians1;

@property (nonatomic, strong) UILabel *lblDayMonth1;
@property (nonatomic, strong) UILabel *lblWeekDay1;
@property (nonatomic, strong) UIButton *btPrev1;
@property (nonatomic, strong) UIButton *btNext1;
@property (nonatomic, strong) SBPickerButton1 *saveButton1;

@end


@implementation DatePicker

-(void)drawRect:(CGRect)rect
{
    [self initialize];
    [self buildControl];
}

- (void)initialize
{
    //Set the height of picker if isn't an iPhone 5 or 5s
    [self checkScreenSize];
    
    //intialize # of days in picker. Default is 365
    [self initializeCalendarDays];
    
    //intialize # of minutes in picker. Default is 365
    [self intializeMinutes];
    
    //Create array Meridians
    _arrMeridians1 = @[@"AM", @"PM"];
    
    //Create array Hours
    NSMutableArray *arrHours = [[NSMutableArray alloc] initWithCapacity:12];
    for(int i=1; i<=12; i++)
    {
        [arrHours addObject:[NSString stringWithFormat:@"%@%d",(i<10) ? @"0":@"", i]];
    }
    _arrHours1 = [NSArray arrayWithArray:arrHours];
    
    //Set the acutal date
    _selectedDate1 = [NSDate date];
}

-(void)intializeMinutes
{
    //Create array Minutes
    __block NSMutableArray *arrMinutes = [[NSMutableArray alloc] init];
    
    //Default days is 60
    if(self.minuterange1 == nil)
    {
        for(int i=0; i<60; i++)
        {
            [arrMinutes addObject:[NSString stringWithFormat:@"%@%d",(i<10) ? @"0":@"", i]];
        }
    }
    else
    {
        [self.minuterange1 enumerateIndexesUsingBlock:^(NSUInteger i, BOOL *stop) {
            [arrMinutes addObject:[NSString stringWithFormat:@"%@%lu",(i<10) ? @"0":@"", (unsigned long)i]];
        }];
    }
    _arrMinutes1 = [NSArray arrayWithArray:arrMinutes];
}


//custom intialize based on desired forward/backward days
-(void)initializeCalendarDays
{
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate* current_Date = [NSDate date];
    NSMutableArray* calendarDates = [[NSMutableArray alloc] init];
    NSMutableArray* calendarTexts = [[NSMutableArray alloc] init];
    NSDateComponents *offsetComponents = [NSDateComponents new];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    formatter.dateFormat = self.dayFormat1 != nil ? self.dayFormat1 : @"d MMM YYYY";
    
    //Default days is 365
    if(self.dayRange1 == nil)
    {
        for( int i = 0; i < 3650; i++)
        {
            //Add following year to calendar
            [offsetComponents setDay:i];
            NSDate *newDate = [gregorian dateByAddingComponents:offsetComponents toDate:current_Date options:0];
            
            NSString* dateSTring = [formatter stringFromDate:newDate];
            [calendarTexts addObject:dateSTring];
            [calendarDates addObject:newDate];
        }
    }
    else
    {
        [self.dayRange1 enumerateIndexesUsingBlock:^(NSUInteger i, BOOL *stop) {
            //Add following year to calendar
            [offsetComponents setDay:i];
            NSDate *newDate = [gregorian dateByAddingComponents:offsetComponents toDate:current_Date options:0];
            
            NSString* dateSTring = [formatter stringFromDate:newDate];
            [calendarTexts addObject:dateSTring];
            [calendarDates addObject:newDate];
        }];
    }
    _arrDays1 = calendarTexts;
    _arrDates1 = calendarDates;
}

- (void)buildControl
{
    //Create a view as base of the picker
    UIView *pickerView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, self.frame.size.width, PICKER_HEIGHT1)];
    [pickerView setBackgroundColor:self.backgroundColor];
    
    //Create bar selector
    UIView *barSel = [[UIView alloc] initWithFrame:CGRectMake(0.0, BAR_SEL_ORIGIN_Y, self.frame.size.width, VALUE_HEIGHT1)];
    [barSel setBackgroundColor:BAR_SEL_COLOR];
    
    
    //Create the first column (moments) of the picker
    _svDays1 = [[SBPickerScrollView1 alloc] initWithFrame:CGRectMake(0.0, 0.0, self.frame.size.width, PICKER_HEIGHT1) andValues:_arrDays1 withTextAlign:NSTextAlignmentRight andTextSize:14];
    _svDays1.tag = 0;
    [_svDays1 setDelegate:self];
    [_svDays1 setDataSource:self];
    
    //Create the second column (hours) of the picker
    //    _svHours = [[SBPickerScrollView alloc] initWithFrame:CGRectMake(self.frame.size.width*122/320, 0.0, self.frame.size.width*66/320, PICKER_HEIGHT) andValues:_arrHours withTextAlign:NSTextAlignmentCenter  andTextSize:18];
    //    _svHours.tag = 1;
    //    [_svHours setDelegate:self];
    //    [_svHours setDataSource:self];
    //
    //    //Create the third column (minutes) of the picker
    //    _svMins = [[SBPickerScrollView alloc] initWithFrame:CGRectMake(_svHours.frame.origin.x+self.frame.size.width*66/320, 0.0, self.frame.size.width*66/320, PICKER_HEIGHT) andValues:_arrMinutes withTextAlign:NSTextAlignmentCenter andTextSize:18];
    //    _svMins.tag = 2;
    //    [_svMins setDelegate:self];
    //    [_svMins setDataSource:self];
    //
    //    //Create the fourth column (meridians) of the picker
    //    _svMeridians = [[SBPickerScrollView alloc] initWithFrame:CGRectMake(_svMins.frame.origin.x+self.frame.size.width*66/320, 0.0, self.frame.size.width*66/320, PICKER_HEIGHT) andValues:_arrMeridians withTextAlign:NSTextAlignmentLeft andTextSize:18];
    //    _svMeridians.tag = 3;
    //    [_svMeridians setDelegate:self];
    //    [_svMeridians setDataSource:self];
    //
    
    //Create separators lines
    // UIView *line = [[UIView alloc] initWithFrame:CGRectMake(self.frame.size.width*122/320-1.0, 0.0, 2.0, PICKER_HEIGHT)];
    // [line setBackgroundColor:LINE_COLOR];
    
    //    UIView *line2 = [[UIView alloc] initWithFrame:CGRectMake(_svHours.frame.origin.x+self.frame.size.width*66/320-1.0, 0.0, 2.0, PICKER_HEIGHT)];
    //    [line2 setBackgroundColor:LINE_COLOR];
    //
    //    UIView *line3 = [[UIView alloc] initWithFrame:CGRectMake(_svMins.frame.origin.x+self.frame.size.width*66/320-1.0, 0.0, 2.0, PICKER_HEIGHT)];
    //    [line3 setBackgroundColor:LINE_COLOR];
    
    
    //Layer gradient
    //    CAGradientLayer *gradientLayerTop = [CAGradientLayer layer];
    //    gradientLayerTop.frame = CGRectMake(0.0, 0.0, pickerView.frame.size.width, PICKER_HEIGHT/3.0);
    //    gradientLayerTop.colors = [NSArray arrayWithObjects:(id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor, (id)self.backgroundColor.CGColor, nil];
    //    gradientLayerTop.startPoint = CGPointMake(0.0f, 0.7f);
    //    gradientLayerTop.endPoint = CGPointMake(0.0f, 0.0f);
    //
    //    CAGradientLayer *gradientLayerBottom = [CAGradientLayer layer];
    //    gradientLayerBottom.frame = CGRectMake(0.0, PICKER_HEIGHT/.5, pickerView.frame.size.width, PICKER_HEIGHT/3.0);
    //    gradientLayerBottom.colors = gradientLayerTop.colors;
    //    gradientLayerBottom.startPoint = CGPointMake(0.0f, 0.3f);
    //    gradientLayerBottom.endPoint = CGPointMake(0.0f, 1.0f);
    //
    
    //Create save area
//    UIView *saveArea = [[UIView alloc] initWithFrame:CGRectMake(0.0, SAVE_AREA_HEIGHT1, self.frame.size.width, SAVE_AREA_HEIGHT1)];
//    [saveArea setBackgroundColor:SAVE_AREA_COLOR];
//    
    
    //Create save button
//    _saveButton = [[SBPickerButton1 alloc] initWithFrame:CGRectMake(10.0, 10.0, self.frame.size.width-20.0, SAVE_AREA_HEIGHT1-20.0)];
//    [_saveButton1 setTitle:@"Choose This Date & Time" forState:UIControlStateNormal];
//    [_saveButton addTarget:self action:@selector(saveButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
//    
    
    //Add pickerView
    [self addSubview:pickerView];
    
    //Add separator lines
    // [pickerView addSubview:line];
    //    [pickerView addSubview:line2];
    //    [pickerView addSubview:line3];
    
    //Add the bar selector
    [pickerView addSubview:barSel];
    
    //Add scrollViews
    [pickerView addSubview:_svDays1];
    [pickerView addSubview:_svHours1];
    [pickerView addSubview:_svMins1];
    [pickerView addSubview:_svMeridians1];
    
    //Add gradients
    //    [pickerView.layer addSublayer:gradientLayerTop];
    //    [pickerView.layer addSublayer:gradientLayerBottom];
    
    //Add Savearea
  //  [self addSubview:saveArea];
    
    //Add button save
   // [saveArea addSubview:_saveButton1];
    
    //Set the time to now
    [self setTime:NOW1];
    [self switchToDay:0];
    [_btPrev1 setEnabled:NO];
    
    [self setUserInteractionEnabled:YES];
}

#pragma mark - Other methods

////Save button pressed
//- (void)saveButtonPressed:(id)sender
//{
//    [self setUserInteractionEnabled:NO];
//    
//    //Create date
//    NSDate *date = [self createDateWithFormat:@"dd-MM-yyyy hh:mm:ss a" andDateString:@"%@ %@:%@:00 %@"];
//    
//    //Send the date to the delegate
//    if([_delegate respondsToSelector:@selector(flatDatePicker:saveDate:)])
//        [_delegate flatDatePicker:self saveDate:date];
//}

//Center the value in the bar selector
- (void)centerValueForScrollView:(SBPickerScrollView1 *)scrollView
{
    
    //Takes the actual offset
    float offset = scrollView.contentOffset.y;
    
    //Removes the contentInset and calculates the prcise value to center the nearest cell
    offset += scrollView.contentInset.top;
    int mod = (int)offset%(int)VALUE_HEIGHT1;
    float newValue = (mod >= VALUE_HEIGHT1/2.0) ? offset+(VALUE_HEIGHT1-mod) : offset-mod;
    
    //Calculates the indexPath of the cell and set it in the object as property
    NSInteger indexPathRow = (int)(newValue/VALUE_HEIGHT1);
    
    //Center the cell
    [self centerCellWithIndexPathRow:indexPathRow forScrollView:scrollView];
}

//Center phisically the cell
- (void)centerCellWithIndexPathRow:(NSUInteger)indexPathRow forScrollView:(SBPickerScrollView1 *)scrollView
{
    
    if(indexPathRow >= [scrollView.arrValues1 count])
    {
        indexPathRow = [scrollView.arrValues1 count]-1;
    }
    
    float newOffset = indexPathRow*VALUE_HEIGHT1;
    
    //Re-add the contentInset and set the new offset
    newOffset -= BAR_SEL_ORIGIN_Y;
    
    [CATransaction begin];
    
    [CATransaction setCompletionBlock:^{
        
        if (![_svMins1 isScrolling] && ![_svHours1 isScrolling] && ![_svMeridians1 isScrolling]) {
            [_saveButton1 setEnabled:YES];
            [_svDays1 setUserInteractionEnabled:YES];
            [_svDays1 setAlpha:1.0];
        }
        
        //Highlight the cell
        [scrollView highlightCellWithIndexPathRow:indexPathRow];
        
        [scrollView setUserInteractionEnabled:YES];
        [scrollView setAlpha:1.0];
    }];
    
    [scrollView setContentOffset:CGPointMake(0.0, newOffset) animated:YES];
    
    [CATransaction commit];
}

//Return a date from a string
- (NSDate *)createDateWithFormat:(NSString *)format andDateString:(NSString *)dateString
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [formatter setLocale:locale];
    formatter.dateFormat = format;
    return [formatter dateFromString:
            [NSString stringWithFormat:dateString,
             [self stringFromDate:_arrDates1[_svDays1.tagLastSelected1] withFormat:@"dd-MM-yyyy"],
             _arrHours1[_svHours1.tagLastSelected1],
             _arrMinutes1[_svMins1.tagLastSelected1],
             _arrMeridians1[_svMeridians1.tagLastSelected1]]];
} //edit here


//Return a string from a date
- (NSString *)stringFromDate:(NSDate *)date withFormat:(NSString *)format
{
    NSDateFormatter *formatter = [NSDateFormatter new];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [formatter setLocale:locale];
    [formatter setDateFormat:format];
    
    return [formatter stringFromDate:date];
}

//Set the time automatically
- (void)setTime:(NSString *)time
{
    //Get the string
    NSString *strTime;
    if([time isEqualToString:NOW1])
        strTime = [self stringFromDate:[NSDate date] withFormat:@"hh:mm a"];
    else
        strTime = (NSString *)time;
    
    //Split
    NSArray *comp = [strTime componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@" :"]];
    
    //Set the tableViews
    [_svHours1 dehighlightLastCell];
    [_svMins1 dehighlightLastCell];
    [_svMeridians1 dehighlightLastCell];
    
    //Center the other fields
    [self centerCellWithIndexPathRow:([comp[0] intValue]%12)-1 forScrollView:_svHours1];
    [self centerCellWithIndexPathRow:[comp[1] intValue] forScrollView:_svMins1];
    [self centerCellWithIndexPathRow:[_arrMeridians1 indexOfObject:comp[2]] forScrollView:_svMeridians1];
}

//Switch to the previous or next day
- (void)switchToDay:(NSInteger)dayOffset
{
    //Calculate and save the new date
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *offsetComponents = [NSDateComponents new];
    
    //Set the offset
    [offsetComponents setDay:dayOffset];
    
    NSDate *newDate = [gregorian dateByAddingComponents:offsetComponents toDate:_selectedDate1 options:0];
    _selectedDate1 = newDate;
    
    //Show new date format
    _lblDayMonth1.text = self.dayFormat1 != nil ? [self stringFromDate:_selectedDate1 withFormat:self.dayFormat1] : [self stringFromDate:_selectedDate1 withFormat:@"dd LLLL yyyy"];
}

- (void)switchToDayPrev
{
    //Check if the again previous day is a past day and in this case i disable the button
    //Calculate the new date
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *offsetComponents = [NSDateComponents new];
    
    //Set the offset
    [offsetComponents setDay:-2];
    NSDate *newDate = [gregorian dateByAddingComponents:offsetComponents toDate:_selectedDate1 options:0];
    
    //Get just the date and not the time
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"dd-MM-yyyy"];
    newDate = [dateFormatter dateFromString:[self stringFromDate:newDate withFormat:@"dd-MM-yyyy"]];
    NSDate *actDate = [dateFormatter dateFromString:[self stringFromDate:[NSDate date] withFormat:@"dd-MM-yyyy"]];
    
    //If newDate is in the past
    if([newDate compare:actDate] == NSOrderedAscending)
    {
        //Disable button previus day
        [_btPrev1 setEnabled:NO];
    }
    
    [self switchToDay:-1];
}

- (void)switchToDayNext
{
    if(![_btPrev1 isEnabled]) [_btPrev1 setEnabled:YES];
    
    [self switchToDay:1];
}

//Check the screen size
- (void)checkScreenSize
{
    if(IS_WIDESCREEN)
    {
        //1000
        PICKER_HEIGHT1 = (self.frame.size.height);
    }
    else
    {
        PICKER_HEIGHT1 = (self.frame.size.height);
    }
}

- (void)setSelectedDate:(NSDate *)date
{
    _selectedDate1 = date;
    [self switchToDay:0];
    
    NSString *strTime = [self stringFromDate:date withFormat:@"hh:mm a"];
    [self setTime:strTime];
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    [_svDays1 setUserInteractionEnabled:NO];
    [_svDays1 setAlpha:0.5];
    
    if (![scrollView isDragging])
    {
        NSLog(@"didEndDragging");
        [(SBPickerScrollView1 *)scrollView setScrolling1:NO];
        [self centerValueForScrollView:(SBPickerScrollView1 *)scrollView];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSLog(@"didEndDecelerating");
    [(SBPickerScrollView1 *)scrollView setScrolling1:NO];
    [self centerValueForScrollView:(SBPickerScrollView1 *)scrollView];
}
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    
    // [_saveButton setEnabled:NO];
    
    SBPickerScrollView1 *sv = (SBPickerScrollView1 *)scrollView;
    [sv setScrolling1:YES];
    [sv dehighlightLastCell];
}

#pragma - UITableViewDelegate

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    SBPickerScrollView1 *sv = (SBPickerScrollView1 *)tableView;
    return [sv.arrValues1 count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *identifier = @"reusableCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    SBPickerScrollView1 *sv = (SBPickerScrollView1 *)tableView;
    
    if(!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        [cell setBackgroundColor:[UIColor clearColor]];
        [cell.textLabel setFont:sv.cellFont1];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        cell.textLabel.adjustsFontSizeToFitWidth = YES;
    }
    
    [cell.textLabel setFont:(indexPath.row == sv.tagLastSelected1) ? sv.boldCellFont1 : sv.cellFont1];
    [cell.textLabel setTextColor:(indexPath.row == sv.tagLastSelected1) ? SELECTED_TEXT_COLOR : TEXT_COLOR];
    [cell.textLabel setText:sv.arrValues1[indexPath.row]];
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return VALUE_HEIGHT1;
}
@end
