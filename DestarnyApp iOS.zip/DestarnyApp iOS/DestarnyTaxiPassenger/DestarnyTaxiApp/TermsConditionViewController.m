//
//  TermsConditionViewController.m
//  DestarnyTaxiApp
//
//  Created by satyaprakash.n on 5/6/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "TermsConditionViewController.h"
#import "webManager.h"
#import "ALToastView.h"

@interface TermsConditionViewController ()

@end

@implementation TermsConditionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self getTermsCondition];
}
-(IBAction)btnBackTapped1:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}


-(void)getTermsCondition
{
    
    //http://www.destarny.com/api/passenger.php/getptc
    
    //  http://dev12.edreamz3.com/api/driver.php/getdtc
    
    
    [[webManager sharedObject] loginRequest:nil withMethod:@"passenger.php/getptc" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
         NSError *e = nil;
         NSString *strStatus = [response valueForKey:@"status"];
         
         //         if([[response valueForKey:@"status"] boolValue]==1)
         //         {
         //             arrBookings = [response valueForKey:@"items"];
         //             [_tblBookingStatus reloadData];
         //         }
         strTerms = [NSString stringWithFormat:@"%@",[[[response valueForKey:@"items"] valueForKey:@"cms"]objectAtIndex:0]];
         [self flattenHTML:strTerms];

         
     }failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
         [ALToastView toastInView:self.view withText:@"Failed"];
              }];
}
- (NSString *)flattenHTML:(NSString *)html {
    
    NSScanner *theScanner;
    NSString *text = nil;
    theScanner = [NSScanner scannerWithString:html];
    
    while ([theScanner isAtEnd] == NO) {
        
        [theScanner scanUpToString:@"<" intoString:NULL] ;
        
        [theScanner scanUpToString:@">" intoString:&text] ;
        
        html = [html stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@>", text] withString:@""];
    }
    //
    html = [html stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    txtTerms.text = [NSString stringWithFormat:@"%@",html];
    return html;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
