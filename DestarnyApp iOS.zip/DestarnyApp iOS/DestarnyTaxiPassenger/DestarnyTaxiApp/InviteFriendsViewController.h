//
//  InviteFriendsViewController.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 9/5/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideNavigationController.h"

@interface InviteFriendsViewController : UIViewController



//******Property *******//
@property (weak, nonatomic) IBOutlet UITextField *txtEmailId;


@property (weak, nonatomic) IBOutlet UIButton *btnInvite;

@property (weak, nonatomic) IBOutlet UIButton *btnFacebook;


@property (weak, nonatomic) IBOutlet UIButton *btnTwitter;

@property (weak, nonatomic) IBOutlet UIButton *btnWhatsApp;

@property (weak, nonatomic) IBOutlet UIButton *btnEmail;



//***********Action*************//

- (IBAction)btnInviteClicked:(id)sender;

- (IBAction)btnBackClicked:(id)sender;

@end
