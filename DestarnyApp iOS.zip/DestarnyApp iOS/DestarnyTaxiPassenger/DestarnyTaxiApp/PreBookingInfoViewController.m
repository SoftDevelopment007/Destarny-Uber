//
//  PreBookingInfoViewController.m
//  DestarnyTaxiApp
//
//  Created by satyaprakash.n on 5/6/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "PreBookingInfoViewController.h"
#import "PreBookingInfoTableViewCell.h"
#import "webManager.h"
#import "MBProgressHUD.h"
#import "ALToastView.h"

@interface PreBookingInfoViewController ()
{
    NSMutableArray *arrBookingDetails;
    MBProgressHUD *HUD;
}

@end

@implementation PreBookingInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    arrBookingDetails = [[NSMutableArray alloc] init];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    HUD.labelText = @"Loading";
    [self.view addSubview:HUD];
    [HUD show:YES];
    [self getBookingInfo];
}
-(void)getBookingInfo
{
    /*
     
     http://dev12.edreamz3.com/destarny_taxi_app/api/get_passanger_current_booking_status.php
     
     */
    
 //   NSString *savedValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
    
    
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults]valueForKey:@"dicPassengerDetails"];
   NSString *strCid = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
    NSDictionary * param=@{@"cid":strCid};
    
    [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/openbooking/?" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
         [HUD hide:YES];
         /*
          
          {
          Response =     (
          {
          cofexpiry = weqwe;
          "device_type" = ewrew;
          deviceid = 23432;
          "driver_id" = 5;
          "driver_noplate" = 34324;
          emailid = "samrat.p@edreamz.in";
          fname = tews;
          "is_activate" = 1;
          "is_deleted" = 0;
          lat = "122.4055";
          "lic_exp_date" = erewraa;
          "lic_no" = asdsa;
          licencecardexpiry = erer;
          lname = test;
          lng = "37.7908";
          made = ewrew;
          payoption = ere;
          "phone_no" = 7098511747;
          "reg_date" = "2016-02-05 03:22:51";
          regoexpiry = werew;
          taxifleetname = erew;
          tc = sdfds;
          "veh_no" = erwere;
          vtid = 2;
          }
          );
          status = Success;
          }
          */
         
         NSError *e = nil;
         NSString *strStatus = [response valueForKey:@"status"];
         
         //         if([strStatus isEqualToString:@"1"])
         if ([[response valueForKey:@"status"] boolValue]==1)
         {
             arrBookingDetails = [response valueForKey:@"items"];
             [tableBooking reloadData];
         }
         else if ([[response valueForKey:@"status"] boolValue]==0)
         {
             NSString *strMSG=[NSString stringWithFormat:@"%@",[response valueForKey:@"items"]];
             
             [ALToastView toastInView:self.view withText:strMSG];
             
             
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"No Records Found" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             
//             [alert show];
         }
         
     }failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
         [ALToastView toastInView:self.view withText:@"Failed to get current booking status."];
//         UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Failed to get current booking status." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//         
//         [alert show];
         [HUD hide:YES];
     }];
    [HUD hide:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrBookingDetails.count;    //count number of row from counting array hear cataGorry is An Array
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"PreBookingInfoTableViewCell";
    PreBookingInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if (cell == nil)
    {
        cell = [[PreBookingInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
    }
    
    tableBooking.backgroundColor = [UIColor clearColor];
    
    cell.lblFrom.text = [NSString stringWithFormat:@": %@",[[arrBookingDetails objectAtIndex:indexPath.row]valueForKey:@"booking_from"]];
    cell.lblTo.text = [NSString stringWithFormat:@": %@",[[arrBookingDetails objectAtIndex:indexPath.row]valueForKey:@"booking_to"]];
    cell.lblDate.text = [NSString stringWithFormat:@": %@",[[arrBookingDetails objectAtIndex:indexPath.row]valueForKey:@"booking_date"]];
    cell.lblDistance.text = [NSString stringWithFormat:@": %@",[[arrBookingDetails objectAtIndex:indexPath.row]valueForKey:@"appx_distance"]];
    cell.lblDuration.text = [NSString stringWithFormat:@": %@",[[arrBookingDetails objectAtIndex:indexPath.row]valueForKey:@"appx_duration"]];
    cell.lblFareType.text = [NSString stringWithFormat:@": %@",[[arrBookingDetails objectAtIndex:indexPath.row]valueForKey:@"fare_type"]];
    cell.lblNotes.text = [NSString stringWithFormat:@": %@",[[arrBookingDetails objectAtIndex:indexPath.row]valueForKey:@"notes"]];
    cell.lblPassenger.text = [NSString stringWithFormat:@": %@",[[arrBookingDetails objectAtIndex:indexPath.row]valueForKey:@"noofpass"]];
    cell.lblTime.text = [NSString stringWithFormat:@": %@",[[arrBookingDetails objectAtIndex:indexPath.row]valueForKey:@"booking_time"]];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}

- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
