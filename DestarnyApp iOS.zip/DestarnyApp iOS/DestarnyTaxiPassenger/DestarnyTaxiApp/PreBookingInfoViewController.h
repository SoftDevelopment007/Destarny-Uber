//
//  PreBookingInfoViewController.h
//  DestarnyTaxiApp
//
//  Created by satyaprakash.n on 5/6/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreBookingInfoViewController : UIViewController
{
    IBOutlet UITableView *tableBooking;
}
@end
