//
//  InviteFriendsViewController.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 9/5/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import "InviteFriendsViewController.h"

@interface InviteFriendsViewController ()

@end

@implementation InviteFriendsViewController

-(void)viewWillAppear:(BOOL)animated
{
    
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    //changing placeholder's color
  //  UIColor *colour = [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1];
    
    _btnEmail.layer.cornerRadius = _btnEmail.layer.frame.size.height/6;
    _btnFacebook.layer.cornerRadius = _btnFacebook.layer.frame.size.height/6;
    _btnTwitter.layer.cornerRadius = _btnTwitter.layer.frame.size.height/6;
    _btnWhatsApp.layer.cornerRadius = _btnWhatsApp.layer.frame.size.height/6;
    
    
//    NSString *text = @"I am using easyGo, an awesome new taxi booking app! Download the app at http://www.ezygo.co.nz/ to start using it.";
    
    
    NSString *text = @"I am using Destarny TaxiApp";
    
    //  NSURL *url = [NSURL URLWithString:@"http://www.ezygo.co.nz/"];
    // UIImage *image = [UIImage imageNamed:@"roadfire-icon-square-200"];
    
    UIActivityViewController *controller =[[UIActivityViewController alloc] initWithActivityItems:@[text] applicationActivities:nil];
    
    controller.excludedActivityTypes = @[UIActivityTypePostToWeibo,
                                         UIActivityTypePrint,
                                         UIActivityTypeCopyToPasteboard,
                                         UIActivityTypeAssignToContact,
                                         UIActivityTypeSaveToCameraRoll,
                                         UIActivityTypeAddToReadingList,
                                         UIActivityTypePostToFlickr,
                                         UIActivityTypePostToVimeo,
                                         UIActivityTypePostToTencentWeibo,
                                         UIActivityTypeAirDrop];
    
    [self presentViewController:controller animated:YES completion:nil];
    
    [controller setCompletionHandler:^(NSString *activityType, BOOL completed)
     {
         NSLog(@"completed");
         [[SlideNavigationController sharedInstance]popViewControllerAnimated:YES];
     }];

   }

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnInviteClicked:(id)sender
{
//    [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
}
- (IBAction)btnBackClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
    
    
    //[[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
    
//    if([[[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"] isEqualToString:@"Register"])
//    {
//        if([[[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentMethod"] isEqualToString:@"CreditCard"])
//        {
//            [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:4] animated:YES];
//        }
//        else
//        {
//            [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:3] animated:YES];
//        }
//    }
//    else
//    {
//        [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:2] animated:YES];
//    }
    
}
@end
