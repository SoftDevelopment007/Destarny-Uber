//
//  DatePickerDelegate.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 9/14/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import <Foundation/Foundation.h>

@class DatePicker;

@protocol DatePickerDelegate <NSObject>

@optional

- (void)datePicker:(DatePicker *)datePicker saveDate:(NSDate *)date;

@end
