//
//  CreditVC.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreditVC : UIViewController
- (IBAction)btnBackTapped:(id)sender;

@end
