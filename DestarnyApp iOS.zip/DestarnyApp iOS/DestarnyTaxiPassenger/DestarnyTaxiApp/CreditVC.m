//
//  CreditVC.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "CreditVC.h"

@interface CreditVC ()

@end

@implementation CreditVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
