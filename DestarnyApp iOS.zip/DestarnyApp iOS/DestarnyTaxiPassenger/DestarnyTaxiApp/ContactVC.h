//
//  ContactVC.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/5/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactVC : UIViewController
{
    IBOutlet UILabel *lblTitle;
    IBOutlet UILabel *lbl1, *lbl2;

}
- (IBAction)btnBackTapped:(id)sender;
@property(nonatomic, copy)NSString *strType;
@end
