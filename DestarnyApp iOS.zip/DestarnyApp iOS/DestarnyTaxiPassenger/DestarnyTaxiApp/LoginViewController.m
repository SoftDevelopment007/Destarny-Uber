//
//  LoginViewController.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/2/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "LoginViewController.h"
#import "Set_PickUp_Location_ViewController.h"
#import "webManager.h"
#import "MBProgressHUD.h"
#import "ALToastView.h"

@interface LoginViewController ()
{
    MBProgressHUD *HUD;
    BOOL remember;
}
@end

@implementation LoginViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    HUD=[[MBProgressHUD alloc]initWithView:self.view];
    [HUD setLabelText:@"Loading"];
    [self.view addSubview:HUD];
    self.navigationController.navigationBarHidden = YES;
    _btnLogin.layer.cornerRadius = 5;
    _btnLogin.clipsToBounds = YES;
    UIColor *colour = [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1];
    
    
    remember=YES;
    [_btnRemember setImage:[UIImage imageNamed:@"check_on"] forState:UIControlStateNormal];
    NSString *tempUsername = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"TempUsername"]];
    if ([tempUsername isEqualToString:@"(null)"] || [tempUsername isEqualToString:@"<null>"] || [tempUsername length]==0)
    {
        NSString *str = @" Username";
        self.txtUsername.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName:colour}];
    }
    else
    {
        _txtUsername.text = tempUsername;
    }
    
    NSString *tempPassword = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"TempPassword"]];
    if ([tempPassword isEqualToString:@"(null)"] || [tempPassword isEqualToString:@"<null>"] || [tempPassword length]==0)
    {
        NSString *str1 = @" ********";
        self.txtPassword.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str1 attributes:@{NSForegroundColorAttributeName:colour}];
    }
    else
    {
        _txtPassword.text = tempPassword;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - viewWillLayoutSubviews
-(void)viewWillLayoutSubviews
{
    [_myScrollView contentSizeToFit];
    [_myScrollView layoutIfNeeded];
    self.myScrollView.contentSize = self.view1.bounds.size;
}

- (IBAction)btnForgotPasswordTapped:(id)sender
{
    UIAlertView * forgotPassword=[[UIAlertView alloc] initWithTitle:@"Forgot Password" message:@"Please enter your email ID" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil];
    
    forgotPassword.tag =302;
    forgotPassword.alertViewStyle=UIAlertViewStylePlainTextInput;
    [forgotPassword textFieldAtIndex:0].delegate=self;
    
    [forgotPassword textFieldAtIndex:0].keyboardType = UIKeyboardTypeASCIICapable ;
    
    [forgotPassword show];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
- (IBAction)btnLoginTapped:(id)sender
{
    if (remember == YES)
    {
        [[NSUserDefaults standardUserDefaults] setObject:_txtUsername.text forKey:@"TempUsername"];
        [[NSUserDefaults standardUserDefaults] setObject:_txtPassword.text forKey:@"TempPassword"];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"TempUsername"];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"TempPassword"];
    }
    
    if([_txtUsername.text isEqualToString:@""] || [_txtPassword.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Enter userid and password"];
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Enter userid and password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [alert show];
    }
    else
    {
        /*
         h ttp://dev12.edreamz3.com/api/passenger.php/login/?username=raj&password=123
         
         */
        [HUD show:YES];
        NSDictionary * param=@{@"username":_txtUsername.text,
                               @"password":_txtPassword.text};
        
        [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/login/?" successResponce:^(id response)
         {
             
             
             NSLog(@"Responce : %@",response);
       //     NSError *e = nil;
             NSString *strStatus = [[response valueForKey:@"status"] stringValue];
             if([strStatus isEqualToString:@"0"])
             {
                 [HUD hide:YES];
                 [ALToastView toastInView:self.view withText:@"Failed to login."];
//                 [[[UIAlertView alloc] initWithTitle:nil message:@"Failed to login." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
             }
             
             else if([strStatus isEqualToString:@"1"])
             {
                 [HUD hide:YES];
                 //////-----------------------------------------
                 

                 NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                 
                 //--already login
                 
                 [defaults setValue:@"YES" forKey:@"login"];
                 
                 //--- other save to user deafults
                 
                 NSString *strCid = [[[response valueForKey:@"items"] objectAtIndex:0] valueForKey:@"id"];
                 [defaults setValue:strCid forKey:@"passengerID"];
                 
                 NSDictionary *dicUserDetails = [[NSDictionary alloc] init];
                 dicUserDetails = [[response valueForKey:@"items"] objectAtIndex:0];
                 [defaults setValue:dicUserDetails forKey:@"dicPassengerDetails"];
                 
                 //---
                 
                 //////----------------------------------------------
                 
                 NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                 NSLog(@"UDID : %@",uniqueIdentifier);
                 
                 
                 //----- navigate to home screen
                 
                 Set_PickUp_Location_ViewController *splv = [self.storyboard instantiateViewControllerWithIdentifier:@"Set_PickUp_Location_ViewController"];
                 [self.navigationController pushViewController:splv animated:YES];
                 
                 //------------- update token ------------------------
                 
                 /*
                  
                 
                 NSString *savedValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
                 
                 NSDictionary * param=@{@"cid":savedValue,
                                        @"deviceid":uniqueIdentifier,
                                        @"device_type":@"iOS"};
                 
                 [[webManager sharedObject] loginRequest:param withMethod:@"passenger_update_token.php" successResponce:^(id response)
                  {
                      NSLog(@"Responce : %@",response);
                      
                   
                      
                      NSError *e = nil;
                      NSString *strStatus = [response valueForKey:@"status"];
                      
                      if([strStatus isEqualToString:@"Success"])
                      {
                          Set_PickUp_Location_ViewController *splv = [self.storyboard instantiateViewControllerWithIdentifier:@"Set_PickUp_Location_ViewController"];
                          [self.navigationController pushViewController:splv animated:YES];
                      }
                      
                  }failure:^(NSError *error)
                  {
                      NSLog(@"Error : %@",error);
                      UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Login Failed!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                      
                      [alert show];
                  }];
                  
                  */

             }
         }
          failure:^(NSError *error)
         {
             [HUD hide:YES];
             NSLog(@"Error : %@",error);
             [ALToastView toastInView:self.view withText:@"Login Failed!"];
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Login Failed!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             
//             [alert show];
         }];
    }
}

#pragma mark Remember Action

-(IBAction)btnRemember:(id)sender
{
    if (remember==YES)
    {
        remember=NO;
        [_btnRemember setImage:[UIImage imageNamed:@"check_off"] forState:UIControlStateNormal];
    }
    else if (remember==NO)
    {
        remember=YES;
        [_btnRemember setImage:[UIImage imageNamed:@"check_on"] forState:UIControlStateNormal];
    }
}

- (BOOL)validateEmail:(NSString *)emailStr
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+]+@[A-Za-z0-9.]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailStr];
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

#pragma mark - AlertView delegate method
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0)
    {
        if(alertView.tag == 301)
        {
            Set_PickUp_Location_ViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"Set_PickUp_Location_ViewController"];
            [[SlideNavigationController sharedInstance] pushViewController:vc animated:YES];
        }
    }
    
    if(buttonIndex == 1)
    {
        if(alertView.tag == 302)
        {
            UITextField *email=[alertView textFieldAtIndex:0];
            if ([self validateEmail:email.text] == NO)
            {
                [ALToastView toastInView:self.view withText:@"Please enter valid Email Id"];
//                UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please enter valid Email Id" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//                
//                [alert show];
            }
            else
            {
                NSString *strFlag=[NSString stringWithFormat:@"api/passengerforgetpassword/?"];
                NSString *strData=[NSString stringWithFormat:@"%@",email.text];
            

            
            
            
             
//             http://dev12.edreamz3.com/destarny_taxi_app/api/passenger_forgot_password.php
//             Parameter:
//             Passenger Forget Password must be POST method
//             email : <Passenger Email>
             
             
            
            NSDictionary * param = @{@"emailid":strData};
            
            [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/forgetPassword/?" successResponce:^(id response)
             {
                 NSLog(@"Responce : %@",response);
                 NSString *strStatus = [response valueForKey:@"message"];
                 
                 if([strStatus isEqualToString:@"Password Mailed"])
                 {
                     UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"A new password has been sent to your e-mail address. Please check your mail box" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                     
                     [alert show];
                 }
             }
                                            failure:^(NSError *error)
             {
                 NSLog(@"Error : %@",error);
                 [ALToastView toastInView:self.view withText:@"Invalid Email ID Please try again"];
//                 UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Invalid Email ID Please try again" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//                 
//                 [alert show];
             }];
             
             
        }
        }
    }
}

- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if(textField ==_txtUsername )
    {
        [_txtPassword becomeFirstResponder];
        
    }else if(textField ==_txtPassword)
    {
        [_txtPassword resignFirstResponder];

    }
    
    return YES;
}

@end
