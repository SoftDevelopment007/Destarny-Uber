//
//  TaxiBookingForm_TableViewCell1.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 10/3/15.
//  Copyright © 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TaxiBookingForm_TableViewCell1 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblBackground;

@end
