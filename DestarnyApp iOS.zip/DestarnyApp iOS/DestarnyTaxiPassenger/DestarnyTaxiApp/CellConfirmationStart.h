//
//  CellConfirmationStart.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/19/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellConfirmationStart : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lblLocPred;
@property (strong, nonatomic) IBOutlet UIView *viewPredBack;

@end
