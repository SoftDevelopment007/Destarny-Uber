//
//  Constant.h
//  Hookd
//
//  Created by Alok Maxter on 12/12/13.
//  Copyright (c) 2013 Intlfaces LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Utilits.h"
#import "ServiceHelper.h"

typedef enum Filters
{
    NEARBY=1,
    ZIPCODE = 2,
    CITY = 3,
    COUNTRY = 4,
    FRIENDS = 5,
    TOPPOST = 6,
    SHAREAPP =7,
    
} Filters;

typedef enum ViewRequest
{
    BLACKLISTVIEW = 1,
    WHITELISTVIEW = 2,
    CHANNERLLIST =  3
    
} ViewRequest;

typedef enum MenuType
{
    NAVIGATION_MENU = 1,
    CHANNEL_MENU = 2,
 
} MenuType;

#define kNotificaitonRefreshNewItem @"NewItem"
#define LOCATIONSEARCH @"http://gd.geobytes.com/AutoCompleteCity?callback=?&q="
#define GEOLOCATIONAPI @"http://maps.googleapis.com/maps/api/geocode/json?address=%@&sensor=false"

//#define DEBUG_MODE YES
#define DEBUG_MODE NO
#define IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
#define CONVERTOMETER 1609.34
//Prod https://n0wprod.azurewebsites.net
//SAND http://n0wtest.azurewebsites.net
#define serviceURL @"http://myredd.net/leon/redd/api/p_api/pass_get_nearest_driver.php?"
#define BASE @"http://n0wprod.azurewebsites.net/"

#define TERMANDCONDITION @"http://rss-technology.com/terms_of_use.html"
#define FAQ @"http://n0w.mobi/faq/"
#define kNotificationShowMBProgressBar @"showProgress"
#define kNotificationHideMBProgressBar @"hideProgress"

#define TranslateUrl @"https://translate.google.com/#auto/"
//
// kill logger
//#if !(TARGET_IPHONE_SIMULATOR)
//#    define c( ... ) {}
//#    define NSLog(...) {}
//#    define NSLog(...) {}
//#    define DDLogError(...) {}
//#    define DDLogWarn(...) {}
//#    define DDLogInfo(...) {}
//#    define DDLogDebug(...) {}
//#    define DDLogVerbose(...) {}
//#endif

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)
#define IS_IOS8 ((SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"8.0"))?35:0)
#define COLOR_COMPONENT_SCALE_FACTOR 255.0f

#define CELL_SELECTION [UIColor colorWithRed:237 / COLOR_COMPONENT_SCALE_FACTOR green:237 / COLOR_COMPONENT_SCALE_FACTOR blue:237 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f];

#define SEGMENTCOLOR [UIColor colorWithRed:88 / COLOR_COMPONENT_SCALE_FACTOR green:172 / COLOR_COMPONENT_SCALE_FACTOR blue:250 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f];

#define NAVIGATIONCOLOR [UIColor colorWithRed:233 / COLOR_COMPONENT_SCALE_FACTOR green:130 / COLOR_COMPONENT_SCALE_FACTOR blue:44 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f];

#define CIRCLEBORDER [UIColor colorWithRed:172 / COLOR_COMPONENT_SCALE_FACTOR green:230 / COLOR_COMPONENT_SCALE_FACTOR blue:44 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

#define YELLOW_FILTER [UIColor colorWithRed:237 / COLOR_COMPONENT_SCALE_FACTOR green:252 / COLOR_COMPONENT_SCALE_FACTOR blue:125 / COLOR_COMPONENT_SCALE_FACTOR alpha:0.4].CGColor;

#define GREEN_FILTER [UIColor colorWithRed:85 / COLOR_COMPONENT_SCALE_FACTOR green:190 / COLOR_COMPONENT_SCALE_FACTOR blue:171 / COLOR_COMPONENT_SCALE_FACTOR alpha:0.4].CGColor;

#define PINK_FILTER [UIColor colorWithRed:228 / COLOR_COMPONENT_SCALE_FACTOR green:126 / COLOR_COMPONENT_SCALE_FACTOR blue:193 / COLOR_COMPONENT_SCALE_FACTOR alpha:0.4].CGColor;

#define NO_FILTER [UIColor clearColor].CGColor;

#define PLACEHOLDERTEXT [UIColor colorWithRed:21 / COLOR_COMPONENT_SCALE_FACTOR green:76 / COLOR_COMPONENT_SCALE_FACTOR blue:155 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0]

#define SEGMENT_SELECTED_COLOR [UIColor colorWithRed:0 / COLOR_COMPONENT_SCALE_FACTOR green:236 / COLOR_COMPONENT_SCALE_FACTOR blue:205 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0]

#define YELLOW_COLOR [UIColor colorWithRed:237 / COLOR_COMPONENT_SCALE_FACTOR green:252 / COLOR_COMPONENT_SCALE_FACTOR blue:125 / COLOR_COMPONENT_SCALE_FACTOR alpha:0.4]

#define GREEN_COLOR [UIColor colorWithRed:85 / COLOR_COMPONENT_SCALE_FACTOR green:190 / COLOR_COMPONENT_SCALE_FACTOR blue:171 / COLOR_COMPONENT_SCALE_FACTOR alpha:0.4]

#define PINK_COLOR [UIColor colorWithRed:228 / COLOR_COMPONENT_SCALE_FACTOR green:126 / COLOR_COMPONENT_SCALE_FACTOR blue:193 / COLOR_COMPONENT_SCALE_FACTOR alpha:0.4]

#define NAVIGATION_BAR_COLOR [UIColor colorWithRed:2 / COLOR_COMPONENT_SCALE_FACTOR green:244 / COLOR_COMPONENT_SCALE_FACTOR blue:211 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0]

#define NAVIGATION_BORDER_COLOR [UIColor colorWithRed:51 / COLOR_COMPONENT_SCALE_FACTOR green:51 / COLOR_COMPONENT_SCALE_FACTOR blue:60 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0]

//font setups
#define FONT_12 [UIFont fontWithName:@"Kefa" size:12]
#define FONT_13 [UIFont fontWithName:@"Kefa" size:13]
#define FONT_14 [UIFont fontWithName:@"Kefa" size:14]
#define FONT_15 [UIFont fontWithName:@"Kefa" size:15]
#define FONT_16 [UIFont fontWithName:@"Kefa" size:16]
#define FONT_17 [UIFont fontWithName:@"Kefa" size:17]
#define FONT_18 [UIFont fontWithName:@"Kefa" size:18]
#define FONT_19 [UIFont fontWithName:@"Kefa" size:19]
#define FONT_20 [UIFont fontWithName:@"Kefa" size:20]

//Sharing icons circle colors
#define PININTERST_BG_COLOR [UIColor colorWithRed:189 / COLOR_COMPONENT_SCALE_FACTOR green:9 / COLOR_COMPONENT_SCALE_FACTOR blue:30 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f]
#define TWITTER_BG_COLOR [UIColor colorWithRed:41 / COLOR_COMPONENT_SCALE_FACTOR green:154 / COLOR_COMPONENT_SCALE_FACTOR blue:233 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f]
#define FACEBOOK_BG_COLOR [UIColor colorWithRed:45 / COLOR_COMPONENT_SCALE_FACTOR green:68 / COLOR_COMPONENT_SCALE_FACTOR blue:134 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f]
#define INSTAGRAM_BG_COLOR [UIColor colorWithRed:49 / COLOR_COMPONENT_SCALE_FACTOR green:94 / COLOR_COMPONENT_SCALE_FACTOR blue:137 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f]
#define EMAIL_BG_COLOR [UIColor colorWithRed:57 / COLOR_COMPONENT_SCALE_FACTOR green:204 / COLOR_COMPONENT_SCALE_FACTOR blue:251 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f]
#define MESSAGE_BG_COLOR [UIColor colorWithRed:61 / COLOR_COMPONENT_SCALE_FACTOR green:206 / COLOR_COMPONENT_SCALE_FACTOR blue:20 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f]

//Chat user fonts
#define FONT_USER_BOLD [UIFont fontWithName:@"HelveticaNeue-Bold" size:17]
#define FONT_USER_MSG_BOLD [UIFont fontWithName:@"HelveticaNeue-Bold" size:16]

#define FONT_USER_NORMAL [UIFont fontWithName:@"HelveticaNeue-Light" size:17]
#define FONT_USER_MSG_NORMAL [UIFont fontWithName:@"HelveticaNeue-Light" size:16]


//Login BG Colors Codes
#define LOGIN_BG_COLOR [UIColor colorWithRed:0 / COLOR_COMPONENT_SCALE_FACTOR green:244 / COLOR_COMPONENT_SCALE_FACTOR blue:200 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f];

#define YELLOW_TILE_BG_COLOR [UIColor colorWithRed:254 / COLOR_COMPONENT_SCALE_FACTOR green:198 / COLOR_COMPONENT_SCALE_FACTOR blue:0 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

#define GREEN_TILE_BG_COLOR [UIColor colorWithRed:47 / COLOR_COMPONENT_SCALE_FACTOR green:207 / COLOR_COMPONENT_SCALE_FACTOR blue:0 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

#define CIRCLEFILLCOLOR [UIColor colorWithRed:238 / COLOR_COMPONENT_SCALE_FACTOR green:237 / COLOR_COMPONENT_SCALE_FACTOR blue:248 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f];

//Mutual Frieds Tiles
#define MF_TILE_BG_COLOR [UIColor colorWithRed:249 / COLOR_COMPONENT_SCALE_FACTOR green:75 / COLOR_COMPONENT_SCALE_FACTOR blue:37 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

//Educational Tiles
#define EDU_TILE_BG_COLOR [UIColor colorWithRed:47 / COLOR_COMPONENT_SCALE_FACTOR green:151 / COLOR_COMPONENT_SCALE_FACTOR blue:216 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

//Work info Tiles
#define WORK_TILE_BG_COLOR [UIColor colorWithRed:0 / COLOR_COMPONENT_SCALE_FACTOR green:92 / COLOR_COMPONENT_SCALE_FACTOR blue:255 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

//Travel info Tiles
#define TRAVEL_TILE_BG_COLOR [UIColor colorWithRed:251 / COLOR_COMPONENT_SCALE_FACTOR green:133 / COLOR_COMPONENT_SCALE_FACTOR blue:0 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

//Home town Tiles
#define HOME_TOWN_TILE_BG_COLOR [UIColor colorWithRed:163 / COLOR_COMPONENT_SCALE_FACTOR green:129 / COLOR_COMPONENT_SCALE_FACTOR blue:80 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

//Astrological Tiles
#define ASTRO_TILE_BG_COLOR [UIColor colorWithRed:251 / COLOR_COMPONENT_SCALE_FACTOR green:133 / COLOR_COMPONENT_SCALE_FACTOR blue:0 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

//Music info Tiles
#define MUSIC_TILE_BG_COLOR [UIColor colorWithRed:132 / COLOR_COMPONENT_SCALE_FACTOR green:145 / COLOR_COMPONENT_SCALE_FACTOR blue:151 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

//Films info Tiles
#define FILMS_TILE_BG_COLOR [UIColor colorWithRed:57 / COLOR_COMPONENT_SCALE_FACTOR green:57 / COLOR_COMPONENT_SCALE_FACTOR blue:57 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

//BOOKS Tiles
#define BOOKS_TILE_BG_COLOR [UIColor colorWithRed:210 / COLOR_COMPONENT_SCALE_FACTOR green:93 / COLOR_COMPONENT_SCALE_FACTOR blue:49 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;

//Inspirational Tiles
#define INSPIRATIONAL_TILE_BG_COLOR [UIColor colorWithRed:253 / COLOR_COMPONENT_SCALE_FACTOR green:184 / COLOR_COMPONENT_SCALE_FACTOR blue:0 / COLOR_COMPONENT_SCALE_FACTOR alpha:1.0f].CGColor;


@interface Constant : NSObject

@end
