//
//  PreBookingInfoTableViewCell.h
//  DestarnyTaxiApp
//
//  Created by satyaprakash.n on 5/6/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreBookingInfoTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UITextView *lblFrom;
@property (weak, nonatomic) IBOutlet UITextView *lblTo;
@property (weak, nonatomic) IBOutlet UILabel *lblDate;
@property (weak, nonatomic) IBOutlet UILabel *lblTime;
@property (weak, nonatomic) IBOutlet UILabel *lblFareType;
@property (weak, nonatomic) IBOutlet UILabel *lblDistance;
@property (weak, nonatomic) IBOutlet UILabel *lblDuration;
@property (weak, nonatomic) IBOutlet UILabel *lblNotes;
@property (weak, nonatomic) IBOutlet UILabel *lblPassenger;
@end
