//
//  SearchPlaceViewController.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/16/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>



@protocol serviceTypeDelegate <NSObject>
@required
-(void)selectedValue:(NSString *)strKey;
@end





@interface SearchPlaceViewController : UIViewController<UITextFieldDelegate,UISearchBarDelegate>


@property(nonatomic,assign)id <serviceTypeDelegate> delegateServiceType;


@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (strong, nonatomic) IBOutlet UITableView *tblSearchOptions;
- (IBAction)btnBackTapped:(id)sender;




@end
