//
//  ServiceHelper.m
//  n0W
//
//  Created by Lakshaya on 1/28/15.
//  Copyright (c) 2015 Lakshaya. All rights reserved.
//

#import "ServiceHelper.h"
#import "JSON.h"
//#import "AFNetworking.h"
#import "AFHTTPRequestOperationManager.h"
#import "AFURLSessionManager.h"
@implementation ServiceHelper


-(void)postParametersSimple:(NSMutableDictionary *)dictParams withEndPoint:(NSString *)endPoint success:(void (^)(id))successBlock error:(void (^)(NSError *))errorBlock
{
    NSString *myJSONString =[dictParams JSONRepresentation];
    NSData *myJSONData =[myJSONString dataUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"myJSONString :%@", myJSONString);
    NSLog(@"myJSONData :%@", myJSONData);
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:[serviceURL stringByAppendingFormat:@"%@",endPoint]]];
    [request setHTTPBody:myJSONData];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    NSURLConnection *theConnection=[[NSURLConnection alloc] initWithRequest:request delegate:self];
    
   
    
    if (theConnection) {
        NSLog(@"connected");
        receivedData=[[NSMutableData alloc]init];
    } else {
        
        NSLog(@"not connected");
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [receivedData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [receivedData appendData:data];
    NSString* responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"response: %@",responseString);
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // do something with the data
    // receivedData is declared as a method instance elsewhere
    NSLog(@"Succeeded! Received %lu data",(unsigned long)[receivedData length]);
    NSString* responseString = [[NSString alloc] initWithData:receivedData encoding:NSUTF8StringEncoding];
    NSLog(@"response: %@",responseString);
    
    
    
    NSError *myError = nil;
    NSDictionary *res = [NSJSONSerialization JSONObjectWithData:receivedData options:NSJSONReadingMutableLeaves error:&myError];
    
    // show all values
    
    if (myError) {
        
        return;
    }
    for(id key in res) {
        
        id value = [res objectForKey:key];
        
        NSString *keyAsString = (NSString *)key;
        NSString *valueAsString = (NSString *)value;
        
        NSLog(@"key: %@", keyAsString);
        NSLog(@"value: %@", valueAsString);
    }  
}

//Post Parameters with server url
+(void)postParameters:(NSMutableDictionary *)dictParams withEndPoint:(NSString *)endPoint success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    manager.responseSerializer = [AFCompoundResponseSerializer serializer];
   // manager.securityPolicy.allowInvalidCertificates = YES;
    //[manager.requestSerializer setHTTPMethodsEncodingParametersInURI:[NSSet setWithObject:displayJson]];
  
   // manager.requestSerializer = [AFJSONRequestSerializer serializer];
  
    //  [manager.requestSerializer setCachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData];
   
    [manager POST:[serviceURL stringByAppendingFormat:@"%@",endPoint] parameters:dictParams success:^(AFHTTPRequestOperation *operation, id responseObject)
    {
       //  NSLog(@"Response : %@", operation.responseString);
        if (responseObject)
        {
            id object = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            successBlock(object);

        }else
        {
            successBlock(responseObject);
        }
       
    }
   failure:
     ^(AFHTTPRequestOperation *operation, NSError *error) {
         NSLog(@"Error: %@", error);
         NSLog(@"JSON: %@", operation.responseString);
         errorBlock(error);
          //[Utilits ShowAlertMessageWithHeader:@"Alert" Message:error.localizedDescription];
     }];
    
}

//Post Parameters with server url
+(void)postAlertParameters:(NSMutableDictionary *)dictParams withEndPoint:(NSString *)endPoint success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    manager.responseSerializer = [AFCompoundResponseSerializer serializer];
    manager.securityPolicy.allowInvalidCertificates = YES;
    //[manager.requestSerializer setHTTPMethodsEncodingParametersInURI:[NSSet setWithObject:displayJson]];
    
    // manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    //  [manager.requestSerializer setCachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData];
//    
//    [manager POST:serviceURLAlert parameters:dictParams success:^(AFHTTPRequestOperation *operation, id responseObject)
//     {
//         NSLog(@"Response : %@", operation.responseString);
//         if (operation.responseString)
//         {
//             successBlock(operation.responseString);
//         }else
//         {
//             successBlock(responseObject);
//         }
//         
//     }
//          failure:
//     ^(AFHTTPRequestOperation *operation, NSError *error) {
//         NSLog(@"Error: %@", error);
//         NSLog(@"JSON: %@", operation.responseString);
//         errorBlock(error);
//         //[Utilits ShowAlertMessageWithHeader:@"Alert" Message:error.localizedDescription];
//     }];
    
}
+(void)synchronizeMessageWithID:(NSString *)msgId Success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock{

    [self getResponseWithEndPoint:[NSString stringWithFormat:@"Alerts/%@",msgId] success:^(id response){
        
        successBlock(response);
        
    } error:^(NSError *error) {
        errorBlock(error);
    }];
}

//Get Response with server url
+(void)getResponseWithEndPoint:(NSString *)endPoint Parameters:(NSMutableDictionary *)dictParams success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    manager.securityPolicy.allowInvalidCertificates = YES;
    NSString *url = [serviceURL stringByAppendingFormat:@"%@",endPoint];
    [manager GET:url parameters:dictParams success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"Response : %@", operation.responseString);
        if(responseObject)
        {
            id object = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            successBlock(object);
        }else
        {
            successBlock(operation.responseString);
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        NSLog(@"JSON: %@", operation.responseString);
        errorBlock(error);
         //[Utilits ShowAlertMessageWithHeader:@"Alert" Message:@"Internal server error"];
        
    }];
}

//Get Response with server url
+(void)getResponseWithEndPoint:(NSString *)serverUr success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    manager.securityPolicy.allowInvalidCertificates = YES;
    
    NSString *url =([serverUr rangeOfString:@"http"].length>0)?serverUr:[serviceURL stringByAppendingFormat:@"%@",serverUr];
    
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {

        if(responseObject)
        {
            
        id object = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            successBlock(object);
        }else
        {
            successBlock(operation.responseString);
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        NSLog(@"JSON: %@", operation.responseString);
        errorBlock(error);
         //successBlock(url);

    }];
}

+(void)uploadImage:(NSString *)serverUr image:(UIImage *)img success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock
{
    NSData *data = UIImageJPEGRepresentation(img, 80);
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *videoPath = [NSString stringWithFormat:@"%@/upload.png", [paths objectAtIndex:0]];
    
    [[NSFileManager defaultManager] removeItemAtPath:videoPath error:nil];
  
    [data writeToFile:videoPath atomically:YES];
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:videoPath])
    {
        
        NSLog(@"file exist");
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
         manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        manager.securityPolicy.allowInvalidCertificates = YES; 
        //NSDictionary *parameters = @{@"foo": @"bar"};
        NSURL *filePath = [NSURL fileURLWithPath:videoPath];
        NSString *url = [serviceURL stringByAppendingFormat:@"%@",serverUr];
        [manager POST:url parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            [formData appendPartWithFileURL:filePath name:@"uploaded_file" error:nil];
            
        } success:^(AFHTTPRequestOperation *operation, id responseObject)
        {
            NSLog(@"Success: %@", responseObject);
            NSString *resString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            successBlock(resString);
        } failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
            NSLog(@"Error: %@", operation.responseString);
            errorBlock(error);
        }];
   
    }else
    {
        NSLog(@"file not exist");
        
       errorBlock(nil);
    }

   
}

+(void)uploadImageWithParams:(NSMutableDictionary *)params endPoint:(NSString *)end image:(UIImage *)img success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock
{
    NSData *data = UIImageJPEGRepresentation(img, 80);
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *videoPath = [NSString stringWithFormat:@"%@/upload.png", [paths objectAtIndex:0]];
    
    [[NSFileManager defaultManager] removeItemAtPath:videoPath error:nil];
    
    [data writeToFile:videoPath atomically:YES];
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:videoPath])
    {
        
        NSLog(@"file exist");
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFCompoundResponseSerializer serializer];
        
         //manager.securityPolicy.allowInvalidCertificates = YES;
        //NSDictionary *parameters = @{@"foo": @"bar"};
        NSURL *filePath = [NSURL fileURLWithPath:videoPath];
        NSString *url = [serviceURL stringByAppendingFormat:@"%@",end];
        __block NSError *error=nil;
        [manager POST:url parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            [formData appendPartWithFileURL:filePath name:@"file" error:&error];
            
            if (error) {
                NSLog(@"%@",error.localizedDescription);
            }
            
        } success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSLog(@"Success: %@", responseObject);
            NSString *resString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            id object = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            successBlock(object);
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", operation.responseString);
            errorBlock(error);
        }];
        
    }else
    {
        NSLog(@"file not exist");
        
        errorBlock(nil);
    }
    
    
}

+(void)uploadVideoWithParams:(NSMutableDictionary *)params endPoint:(NSString *)end image:(NSData *)data success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock
{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *videoPath = [NSString stringWithFormat:@"%@/upload.mp4", [paths objectAtIndex:0]];
    
    [[NSFileManager defaultManager] removeItemAtPath:videoPath error:nil];
    
    [data writeToFile:videoPath atomically:YES];
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:videoPath])
    {
        
        NSLog(@"file exist");
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFCompoundResponseSerializer serializer];
        
        //manager.securityPolicy.allowInvalidCertificates = YES;
        //NSDictionary *parameters = @{@"foo": @"bar"};
        NSURL *filePath = [NSURL fileURLWithPath:videoPath];
        NSString *url = [serviceURL stringByAppendingFormat:@"%@",end];
        __block NSError *error=nil;
        [manager POST:url parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            [formData appendPartWithFileURL:filePath name:@"file" error:&error];
            
            if (error) {
                NSLog(@"%@",error.localizedDescription);
            }
            
        } success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSLog(@"Success: %@", responseObject);
            NSString *resString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            id object = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            successBlock(object);
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", operation.responseString);
            errorBlock(error);
        }];
        
    }else
    {
        NSLog(@"file not exist");
        
        errorBlock(nil);
    }
    
    
}
@end
