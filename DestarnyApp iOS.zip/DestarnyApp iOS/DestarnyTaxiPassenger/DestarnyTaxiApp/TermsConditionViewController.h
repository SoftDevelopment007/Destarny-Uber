//
//  TermsConditionViewController.h
//  DestarnyTaxiApp
//
//  Created by satyaprakash.n on 5/6/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TermsConditionViewController : UIViewController
{
    IBOutlet UITextView *txtTerms;
    NSString *strTerms;
}
@end
