//
//  webManager.m
//  MarketOfMums
//
//  Created by IsoDev1 on 10/28/15.
//  Copyright © 2015 Neha. All rights reserved.
//

#import "webManager.h"
#import "NetworkManager.h"
@implementation webManager
+(webManager*)sharedObject
{
    static webManager *objWeb = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        objWeb = [[webManager alloc] init];
    });
    return objWeb;
    
}
-(void)loginRequest:(NSDictionary *)parameters withMethod:(NSString *)method successResponce:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    [NetworkManager sendWebRequest:parameters withMethod:method successResponce:^(id response)
     {
         //[USER_DETAIL_INFO initWithData:response];
         
         NSLog(@"login dict %@",response);
         
         success(response);
     } failure:^(NSError *error) {
         failure(error);
     }];
}


-(void)signUp:(NSDictionary*)Parameters withImage:(UIImage*)image andMethod:(NSString*)methodName successResponce:(void (^)(id Responce))success failure:(void (^)(NSError *error))failure
{
    [NetworkManager uploadImage:Parameters withMethod:methodName WithFilePath:image successResponce:^(id response)
    {
        success(response);
    } failure:^(NSError *error) {
        failure(error);
    }];
}

-(void)SellRequest:(NSDictionary *)parameters withArr:(NSMutableArray *)ProductImgArr andMethod :(NSString *)methodName successResponce:(void (^)(id Responce))success failure:(void (^)(NSError *error))failure
{
    [NetworkManager uploadProductImages:parameters withMethod:methodName WithImageArr:ProductImgArr successResponce:^(id response)
     {
         success(response);
       // NSLog(@"%@",response);
    } failure:^(NSError *error)
     {
          failure(error);
       // NSLog(@"%@",error.localizedDescription);
    }];
}

@end
