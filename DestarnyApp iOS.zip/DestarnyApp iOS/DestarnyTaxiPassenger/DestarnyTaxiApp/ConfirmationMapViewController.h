//
//  ConfirmationMapViewController.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/16/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Annotation.h"
#import <CoreLocation/CoreLocation.h>
#import "CustomAnnotation.h"
#import "SourceAnnotation.h"

@interface ConfirmationMapViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,MKMapViewDelegate,CLLocationManagerDelegate,UIGestureRecognizerDelegate,MKAnnotation,UITextFieldDelegate,UIAlertViewDelegate,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *arrDriverLatLong;
    MKPointAnnotation *annotation;
    NSDictionary *dicSelectedDriver;
    IBOutlet UIView *viewDriverInfo;
    IBOutlet UILabel *lblDriverName, *lblMade, *lblModel, *lblDriverContact;
    NSString *strAddressType;
    IBOutlet UIView *viewBookVehicle, *viewSetFare;
    NSString *strFareType;
    NSString *strBookingType;
    NSString *strSetFare;
    IBOutlet UIImageView *imgDest, *imgSetFare, *imgTaximeter, *imgPremium, *imgCash, *imgCard;
    IBOutlet UILabel *lblRegId, *lblRating;
    IBOutlet UIImageView *imgTaxi;
    IBOutlet UILabel *lblSeats;
    NSString *getVLatValue;
    NSString *getVLongValue;
    SourceAnnotation *sourceAnn;
    BOOL updateAnnotation, taxiAnnotation;
    BOOL flag;
}

@property(nonatomic,retain)NSDictionary *dicDriverDetails;
@property (copy, nonatomic) NSString *strVtype;
@property (strong, nonatomic) IBOutlet MKMapView *mapViewRoute;
@property (strong, nonatomic) IBOutlet UIButton *btnDestarnyRate;
@property (strong, nonatomic) IBOutlet UIButton *btnTaxiMeter;
@property (strong, nonatomic) IBOutlet UIButton *btnSetFare;
@property (strong, nonatomic) IBOutlet UIButton *btnPremium;
@property (strong, nonatomic) IBOutlet UIButton *btnCancel;
@property (strong, nonatomic) IBOutlet UIButton *btnBook;
@property (strong, nonatomic) IBOutlet UIButton *btnBookTaxi;
@property (strong, nonatomic) IBOutlet UIButton *btnFare;
@property (strong, nonatomic) IBOutlet UIButton *btnCash;
@property (strong, nonatomic) IBOutlet UIButton *btnCard;
@property (strong, nonatomic) IBOutlet UITextField *txtFare;

- (IBAction)btnFareEstimateTapped:(id)sender;
- (IBAction)btnPaymentMethodTapped:(id)sender;
- (IBAction)btnBookTaxiTapped:(id)sender;

@property (strong, nonatomic) IBOutlet UITextField *txtStartSearch;
@property (strong, nonatomic) IBOutlet UITextField *txtDestAddress;
@property (weak, nonatomic) IBOutlet UIButton *btnFromLoc;
@property (weak, nonatomic) IBOutlet UIButton *btnToLoc;
@property (strong, nonatomic) NSString *strSetCredit;

- (IBAction)btnStartAddTapped:(id)sender;
- (IBAction)btnDestAddTapped:(id)sender;

- (IBAction)btnBackTapped:(id)sender;

//---- data from set_pickup_loc_VC

@property(nonatomic , retain)NSString *strVTid;
@property(nonatomic,retain)NSString *strTypeBooking;
@property(nonatomic,copy)NSString *strSource;


@property (weak, nonatomic) IBOutlet UIView *customListView;
@property (weak, nonatomic) IBOutlet UITableView *tblTaxiList;


@end
