//
//  TaxiBookingForm_TableViewCell1.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 10/3/15.
//  Copyright © 2015 pavan bhandari. All rights reserved.
//

#import "TaxiBookingForm_TableViewCell1.h"

@implementation TaxiBookingForm_TableViewCell1

- (void)awakeFromNib {
    // Initialization code
    _lblBackground.layer.cornerRadius = 5;
    _lblBackground.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
