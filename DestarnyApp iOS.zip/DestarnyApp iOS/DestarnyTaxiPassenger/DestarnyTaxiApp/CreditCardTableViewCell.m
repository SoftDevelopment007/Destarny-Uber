//
//  CreditCardTableViewCell.m
//  DestarnyTaxiApp
//
//  Created by satyaprakash.n on 5/5/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "CreditCardTableViewCell.h"

@implementation CreditCardTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
