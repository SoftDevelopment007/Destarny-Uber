//
//  MenuViewController.h
//  SlideMenu
//
//  Created by Aryan Gh on 4/24/13.
//  Copyright (c) 2013 Aryan Ghassemi. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "SlideNavigationController.h"
#import "LeftMenu_TableViewCell.h"
//#import "AirportFixedPriceBookingForm_ViewController.h"
//#import "Review_ViewController.h"
////#import "Taxi_Invoice_StatementVC.h"
//#import "SignInViewController.h"
//#import "EmergencyViewController.h"
//#import "ProfileViewController.h"
//#import "InviteFriendsViewController.h"
//#import "ShareViewController.h"
//#import "FavouriteViewController.h"
//#import "BillingInfoViewController.h"
//#import "Taxi_Booking_Form_ViewController.h"
////#import "SignIn1ViewController.h"
//
//#import <FBSDKCoreKit/FBSDKCoreKit.h>
//#import <FBSDKLoginKit/FBSDKLoginKit.h>

@interface LeftMenuViewController : UIViewController <UITableViewDelegate, UITableViewDataSource >
{
    BOOL _viewDidAppear;
    BOOL _viewIsVisible;
}




@property (weak, nonatomic) IBOutlet UIScrollView *myScrollView;


@property (nonatomic, strong) IBOutlet UITableView *tableView;
@property (nonatomic, assign) BOOL slideOutAnimationEnabled;


@property(nonatomic,strong) NSArray *items;
@property (nonatomic, retain) NSMutableArray *itemsInTable;


- (IBAction)btnLogoutClicked:(id)sender;

- (IBAction)btnShareClicked:(id)sender;


//@property (weak, nonatomic) IBOutlet FBSDKLoginButton *btnFB;

@property (weak, nonatomic) IBOutlet UIButton *btnLogout;
@property (weak, nonatomic) IBOutlet UIImageView *imgLogout;
@property (weak, nonatomic) IBOutlet UILabel *lblLogout;

@end
