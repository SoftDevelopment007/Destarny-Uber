//
//  LeftMenuTableCell.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "LeftMenuTableCell.h"

@implementation LeftMenuTableCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
