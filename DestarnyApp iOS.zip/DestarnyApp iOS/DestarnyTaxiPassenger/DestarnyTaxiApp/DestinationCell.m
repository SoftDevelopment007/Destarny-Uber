//
//  DestinationCell.m
//  DestarnyTaxiApp
//
//  Created by edreamz on 3/1/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "DestinationCell.h"

@implementation DestinationCell

- (void)awakeFromNib {
    _viewDestCell.layer.cornerRadius = 5;
    _viewDestCell.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end
