   //
//  Set_PickUp_Location_ViewController.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/24/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import "Set_PickUp_Location_ViewController.h"
#import <AddressBook/AddressBook.h>
#import "LeftMenuTableCell.h"
#import "ProfileViewController.h"
#import "BillingInfoViewCotroller.h"
#import "FavouritesViewController.h"
#import "CurrentBookingStatus.h"
#import "CreditVC.h"
#import "Taxi_Booking_Form_ViewController.h"
#import "AirportFixedPriceBookingForm_ViewController.h"
#import "InviteFriendsViewController.h"
#import "ContactVC.h"
#import "webManager.h"
#import "ConfirmationMapViewController.h"
#import "SearchPlaceViewController.h"
#import "AppDelegate.h"
#import "SignInViewController.h"
#import "PreBookingInfoViewController.h"
#import "CustomAnnotation.h"
#import "ALToastView.h"
#import "MBProgressHUD.h"

#define DATA_ARRAY    @[@"Taxi", @"All", @"Premium"]
//#import "MathController.h"

@interface Set_PickUp_Location_ViewController ()
{
    AppDelegate *appDelegate;
    /////------
    
    NSString *strLatA,*strLngA;
    
    ////-----
    
    CLLocation * currLocation;
    
    ///--------
    
    NSMutableArray *arrDriverLat;
    
    NSArray * driverLatLng,*locationsNew;
    
    NSDictionary *dicSelectedDriver;
    
    //  MBProgressHUD * HUD;
    
    NSString * driverId;
    
    NSString * distance;
    
    NSString * currentLocation;
    
    NSMutableArray *arrLeftMenu,*arrMenuImages,*arrDriverCoordinates, *arrDriverID;
    
    NSMutableArray * arrAnnotationImages;
    
    
    CLLocationCoordinate2D currentSelectedLocationCoord;
    
    CLLocationManager *locManagerCurrent;
    
    CLLocationManager *locManager2;
    
    double lat2,long2;
    
    BOOL viewHidden,subMenuHidden,isShownLoc,isFailLoc,isMapZoom;
    
    ///---------
    
    NSString *strCurrentLat,*strCurrentLng;
    
    NSTimer * myTimer, *myTimerRed;
    
    ///-----
    
    CLLocationCoordinate2D selectedLocationCoord;

    NSString *strPassLat,*strPassLng;
    
    BOOL isLocationAvailable;
    
    //--
    NSString * isBookingTypeNearest;
    NSString * strVehicleID;
    MKPointAnnotation *annotation;
    NSString *strLocationType;
    NSString *strDistance;
    CLLocationCoordinate2D coord;
    NSString *annotationImage;
    NSArray * response1;
    int i;
    
    MBProgressHUD *HUD;
    //====================================================================
    BOOL isFirstRunning;
    //====================================================================
}

@property(nonatomic) NSInteger seconds;

@end

@implementation Set_PickUp_Location_ViewController



#pragma mark- viewDidLoad
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    HUD=[[MBProgressHUD alloc]initWithView:self.view];
    [HUD setLabelText:@"Loading"];
    [self.view addSubview:HUD];
    
    count = 0;
    strLatA = [[NSString alloc] init];
    strLngA = [[NSString alloc] init];
    i = 0;
    strVehicleID = @"3";
   
    _imgViewSUV.layer.cornerRadius = 29;
    _imgViewSUV.clipsToBounds = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    ////////---------
    
    arrDriverCoordinates = [[NSMutableArray alloc] init];
    
    ///----------------
    
    // setting timer to call method automatically ______
    
    
    //________ initialize activity indicator _____________
    
    // [self initializeActivityIndicator];
    _filterControl.backgroundColor = [UIColor whiteColor];
    [_filterControl setTitles:DATA_ARRAY];
    
    [self initializeControls];
    
    locManagerCurrent = [[CLLocationManager alloc] init];
    
    //[locManagerCurrent startUpdatingLocation];
    
    [locationManager startUpdatingLocation];
    
    //_________________
    
    _btnNearestTaxi.layer.cornerRadius = 5;
    _btnNearestTaxi.clipsToBounds = YES;
    
    _searchBar.layer.cornerRadius = 5;
    _searchBar.clipsToBounds = YES;
    
    strSearchedAddress = [[NSString alloc] init];
    dicSelectedLoc = [[NSDictionary alloc] init];
 //   arrSearchRes = [[NSMutableArray alloc] init];
    
    locView.layer.borderColor = [UIColor grayColor].CGColor;
    locView.layer.borderWidth = 0.5;
    locView.layer.cornerRadius = 2.0;
    
    searchView.hidden = YES;
    // [self getVehicalId:@"Standard"];
    
 //   annotationView.center = CGPointMake(_mapPassenger.frame.size.width  / 2,
 //                                    _mapPassenger.frame.size.height / 2);
    
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gestureHandlerMethod:)];
    [_mapPassenger addGestureRecognizer:tapRecognizer];
    //  _mapPassenger.tag=2;
    [self callmethod];
    
 /*   [_mapPassenger.userLocation addObserver:self
                            forKeyPath:@"location"
                               options:(NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld)
                               context:NULL];*/
    
    
  //  [_searchBar becomeFirstResponder];
    
    self.mapView.showsUserLocation = YES;
    _mapPassenger.showsUserLocation = YES;
    
    isFirstRunning = YES;
    //====================================================================
    if(isFirstRunning == YES)
    {
        [self filterValueChanged:self];
        isFirstRunning = NO;
        //[self callAfterTwentySecond:arrCord];
        
    }
    //====================================================================
}

-(IBAction)showCurrentLocation:(id)sender
{
    [locationManager startUpdatingLocation];
}
/*-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    [object setTitle:[NSString stringWithFormat:@"%f, %f",_mapPassenger.centerCoordinate.latitude,_mapPassenger.centerCoordinate.longitude]];
    [_mapPassenger selectAnnotation:object animated:YES];
}
*/

-(void)viewDidDisappear:(BOOL)animated
{
    [myTimer invalidate];
    myTimer = nil;
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    [myTimer invalidate];
    myTimer = nil;

  //  _mapPassenger.showsUserLocation = NO;
 //   [_mapPassenger removeAnnotation:annotation];
 //   [self.mapView removeAnnotation:self.mapView.annotations.lastObject];
   // _lblSelectedLocation.text = @"";
//    [myTimer invalidate];
//    myTimer = nil;
  //  [myTimerRed invalidate];
 //   [locManagerCurrent stopUpdatingLocation];
}

//-(void)showCurrentLocation
//{
//    MKCoordinateRegion coordinateRegion;   //Creating a local variable
//    _mapPassenger.showsUserLocation = YES;
//    
//    coordinateRegion.center = myCurrentLocation.coordinate.center;  //See notes below
//    coordinateRegion.span.latitudeDelta = .02;
//    coordinateRegion.span.longitudeDelta = .02;
//    
//    [_mapPassenger setRegion:MKCoordinateRegion animated:YES];
//    
//}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}


#pragma mark - ViewWillAppear
-(void)viewWillAppear:(BOOL)animated
{
    _viewDriverInfo.hidden = YES;
    
    // MODIFICATION MENU PETER MALACZYNSKI START
    
    // arrLeftMenu = [[NSMutableArray alloc] initWithObjects:@"Home",@"Profile",@"Billing Info",@"Past Bookings",@"Current Booking Status",@"Book In Advance",@"Invite Friends",@"Contact", nil];
    // arrMenuImages = [[NSMutableArray alloc] initWithObjects:@"home2.png",@"profile2.png",@"billing-info-2.png",@"favourites-2.png",@"favourites-2.png",@"books-2.png",@"invite-friends-2.png",@"contact-2.png", nil];
    arrLeftMenu = [[NSMutableArray alloc] initWithObjects:@"Home",@"Profile",@"Billing Info",@"Past Bookings",@"Current Booking Status",@"Invite Friends",@"Contact", nil];
    
    arrMenuImages = [[NSMutableArray alloc] initWithObjects:@"home2.png",@"profile2.png",@"billing-info-2.png",@"favourites-2.png",@"books-2.png",@"invite-friends-2.png",@"contact-2.png", nil];
    
    // MODIFICATION MENU PETER MALACZYNSKI END

    _viewLeftMenu.hidden = YES;
    _menuBtn1.hidden = YES;
    viewHidden = YES;
   
    dispatch_async(dispatch_get_main_queue(), ^{
        [_tblLeftMenu reloadData];
 
    });
    
    locManager2=[[CLLocationManager alloc]init];
    locManager2.delegate=self;
    [locManager2 requestWhenInUseAuthorization];
    
    locManager2.distanceFilter = kCLDistanceFilterNone;
    locManager2.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    [locationManager startUpdatingLocation];
    
    
    
    NSString *getLatValue = strLatA;
    NSString *getLongValue = strLngA;
    
    CLLocationCoordinate2D zoomLocation;
    zoomLocation.latitude = [getLatValue doubleValue];
    zoomLocation.longitude= [getLongValue doubleValue];
    
    MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
    point.coordinate = zoomLocation;
    [self.mapPassenger addAnnotation:point];
    [self zoomMapView:zoomLocation];
    _mapPassenger.showsUserLocation = YES;
    
    [self getVehicleDetails];
    self.mapView.delegate = self;
    _mapPassenger.delegate = self;
    self.mapView.showsUserLocation = YES;
    _mapPassenger.showsUserLocation = YES;

}

-(void)getVehicleDetails
{
    //http://dev12.edreamz3.com/api/passenger.php/getvehicletype
    
    
    [[webManager sharedObject] loginRequest:nil withMethod:@"passenger.php/getvehicletype" successResponce:^(id response)
     {
         NSString *strStatus = [[response valueForKey:@"status"] stringValue];
         if([strStatus isEqualToString:@"1"])
         {
             [[NSUserDefaults standardUserDefaults] setObject:response forKey:@"VehicleDetails"];
         }
         
         else if([strStatus isEqualToString:@"0"])
         {
             
         }
     }
    failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
     }];
}

-(void)updateLocation
{
    [locManagerCurrent startUpdatingLocation];
    [locationManager stopUpdatingLocation];
}

-(void)callmethod
{
  //  _lblSelectedLocation.text = @"";
    
    [self getAddressFromLatLng];
    [self.mapView removeAnnotation:self.mapView.annotations.lastObject];
    isShownLoc = NO;
    isFailLoc = NO;
    isMapZoom = NO;
    isLocationAvailable = NO;
    
    //--
    
    arrDriverCoordinates = [[NSMutableArray alloc] init];
    dicSelectedDriver = [[NSDictionary alloc] init];
    strPassLat = [[NSString alloc] init];
    strPassLng = [[NSString alloc] init];
    
    //-------- current location -----------
    
    locManager2=[[CLLocationManager alloc]init];
    locManager2.delegate=self;
    [locManager2 requestWhenInUseAuthorization];
    
    locManager2.distanceFilter = kCLDistanceFilterNone;
    locManager2.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    //[locManager2 startUpdatingLocation];
    
    lat2 = locationManager.location.coordinate.latitude;
    long2 = locationManager.location.coordinate.longitude;
    
    strCurrentLat = [[NSNumber numberWithDouble:lat2] stringValue];
    strCurrentLng = [[NSNumber numberWithDouble:long2] stringValue];

    //-------------------------------------
    
    //----- location manager action --------
    
    locManagerCurrent.delegate = self;
    locManagerCurrent.desiredAccuracy = kCLLocationAccuracyBest;
    ///----------------                   ---------       ------ [locManagerCurrent startUpdatingLocation];
    
    /////------ map view zoom to current location
    
    //--------  [self performSelector:@selector(zoomInToMyLocation) withObject:nil afterDelay:1];
    
    //--
    
    _viewLeftMenu.hidden = YES;
    
    subMenuHidden = YES;
    
    _menuBtn1.hidden = YES;
    
    self.navigationController.navigationBarHidden = YES;
    
    viewHidden = YES;
    
    // MODIFICATION MENU PETER MALACZYNSKI START
    
    //arrLeftMenu = [[NSMutableArray alloc] initWithObjects:@"Home",@"Profile",@"Billing Info",@"Past Bookings",@"Current Booking Status",@"Book In Advance",@"Invite Friends",@"Contact", nil];
    
    //arrMenuImages = [[NSMutableArray alloc] initWithObjects:@"home2.png",@"profile2.png",@"billing-info-2.png",@"favourites-2.png",@"favourites-2.png",@"books-2.png",@"invite-friends-2.png",@"contact-2.png", nil];
    
    arrLeftMenu = [[NSMutableArray alloc] initWithObjects:@"Home",@"Profile",@"Billing Info",@"Past Bookings",@"Current Booking Status",@"Invite Friends",@"Contact", nil];
    
    arrMenuImages = [[NSMutableArray alloc] initWithObjects:@"home2.png",@"profile2.png",@"billing-info-2.png",@"favourites-2.png",@"books-2.png",@"invite-friends-2.png",@"contact-2.png", nil];
    
    // MODIFICATION MENU PETER MALACZYNSKI END
    
    dispatch_async(dispatch_get_main_queue(), ^{
  
    [_tblLeftMenu reloadData];
      });
    
    _viewSearchLoc.layer.borderWidth = 0.5;
    _viewSearchLoc.layer.borderColor = [[UIColor grayColor] CGColor];
    _viewSearchLoc.layer.cornerRadius = 2;
    _viewSearchLoc.clipsToBounds = YES;
    
    NSString *startLocation = [[NSUserDefaults standardUserDefaults] objectForKey:@"SearchedAddress"];
    strVehicleID = @"3";
    
    
    _btnNearestTaxi.hidden = YES;
    
    if([_txtPickUpLocation.text isEqualToString:@""])
    {
        [locManagerCurrent startUpdatingLocation];
    }
    else
    {
        //[locManagerCurrent stopUpdatingLocation];
    } 
}

#pragma mark callAfterTwentySecond
-(void)callAfterTwentySecond:(NSMutableArray *)arrCoord
{
    // ------- API call for nearest drivers ------
   // NSMutableArray * annotationsToRemove;
    
    
    if([strLatA isEqualToString:@""] || [strLngA isEqualToString: @""])
    {
        
    }
    else
    {
        NSArray *existingpoints = _mapPassenger.annotations;
        if ([existingpoints count] > 0)
            [_mapPassenger removeAnnotations:existingpoints];
        NSDictionary *dict = [[NSUserDefaults standardUserDefaults] valueForKey:@"dicPassengerDetails"];
        NSString *cid = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
        dispatch_async(dispatch_get_main_queue(), ^{
        
        NSDictionary * param=@{@"booking_from_lat":strLatA,
                               @"booking_from_lng":strLngA,
                               @"vtid":strVehicleID,
                               @"cid":cid};   //----- hard coded
        
        //http://mysetfare.com/au/sydney/api/passenger.php/getnearbydriversbtvtype/?cid=4&booking_from_lat=18.473436&booking_from_lng=73.819105&vtid=3
        
  //   http://destarny.com/api/passenger.php/getnearbydriversbtvtype/?booking_from_lat=18.473436&booking_from_lng=73.8191593&vtid=3&cid=1
        
        [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/getnearbydriversbtvtype/?" successResponce:^(id response)
         {
             NSString *strStatus = [[response valueForKey:@"status"] stringValue];
            if([strStatus isEqualToString:@"1"])
             {
                 _lblDistance.hidden = NO;
                 btnGo.hidden = NO;
                 //---
                 response1 = [[NSArray alloc] init];
                 response1 = [response valueForKey:@"items"];
                 arrDriverCoordinates = response1;
                 strDistance = [NSString stringWithFormat:@"%@",[[arrDriverCoordinates objectAtIndex:0] valueForKey:@"distance"]];
                 double dist = [strDistance doubleValue];
                 _lblDistance.text = [NSString stringWithFormat:@"%0.1f Km",dist];
                 _lblpickupLocation1.text = [NSString stringWithFormat:@"Set pickup Location"];
                 _btnNearestTaxi.enabled = YES;
            NSMutableArray * annotationsToRemove = [_mapPassenger.annotations mutableCopy];
                 [ annotationsToRemove removeObject:_mapPassenger.userLocation];
                 [ _mapPassenger removeAnnotations:annotationsToRemove];
                 //--------- request nearest taxi ----------
                 _btnNearestTaxi.hidden = NO;
                 //-----------------------------------------
                 arrAnnotationImages = [[NSMutableArray alloc] init];
                 
//                 for (int i=0; i<[response1 count]; i++)
//                 {
//                     NSString *strStatus = [NSString stringWithFormat:@"%@",[[response1 valueForKey:@"accepteddriverst"] objectAtIndex:i]];
//                     [arrDriverID addObject:strStatus];
//                     
//                                        
//                     NSDictionary *dic = [response1 objectAtIndex:i];
//                     if([[dic valueForKey:@"accepteddriverst"] isEqualToNumber:[NSNumber numberWithBool:1]])
//                     {
//                         annotationImage = @"RedTaxi";
//                       //  strLocationType = [NSString stringWithFormat:@"RedTaxi"];
//                     }
//                     else
//                     {
//                         annotationImage = @"Car";
//                       //  strLocationType = [NSString stringWithFormat:@"Car"];
//                     }
//                 
//                     
//                     strLocationType = [NSString stringWithFormat:@"Car"];
//                     CLLocationCoordinate2D zoomLocation;
//                     NSString *getLatValue = [[response1 valueForKey:@"lat"]objectAtIndex:i];
//                     NSString *getLongValue = [[response1 valueForKey:@"lng"]objectAtIndex:i];
//                     zoomLocation.latitude = [getLatValue doubleValue];
//                     zoomLocation.longitude= [getLongValue doubleValue];
//                     
//                     MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
//                     point.coordinate = zoomLocation;
//                     [self.mapPassenger addAnnotation:point];
//
//                 }
                 
                 
                // [self.mapPassenger removeAnnotations:self.mapPassenger.annotations];
                 

                 
                 for (NSDictionary * dic in response1)
                     
                 {
                     
                     CustomAnnotation *custAnnotion=[[CustomAnnotation alloc]init];

                     if([[dic valueForKey:@"accepteddriverst"] isEqualToNumber:[NSNumber numberWithBool:1]])
                         
                     {
                         _viewDriverInfo.hidden = NO;
                         NSString *strType = [NSString stringWithFormat:@"%@",[dic valueForKey:@"vtype"]];
                         _lblDriverName.text = [NSString stringWithFormat:@"Driver: %@ %@",[dic valueForKey:@"fname"], [dic valueForKey:@"lname"]];
                         _lblRego.text = [NSString stringWithFormat:@"Rego: %@",[dic valueForKey:@"driver_noplate"]];
                         _lblModel.text = [NSString stringWithFormat:@"%@", [dic valueForKey:@"modelno"]];
                         _lblETA.text = [NSString stringWithFormat:@"ETA: %@",[dic valueForKey:@"duration_from_driver_to_passenger"]];
                         if ([strType isEqualToString:@"Taxi"])
                         {
                             annotationImage = @"RedTaxi";
                             custAnnotion.title=@"RedTaxi";
                         }
                         else if ([strType isEqualToString:@"Premium"])
                         {
                             annotationImage = @"RedPremium";
                             custAnnotion.title= @"RedPremium";
                         }
                         else if ([strType isEqualToString:@"Private"])
                         {
                             annotationImage = @"RedPrivate";
                             custAnnotion.title= @"RedPrivate";
                         }
                         
                        // strLocationType = [NSString stringWithFormat:@"RedTaxi"];
                        // [arrAnnotationImages addObject:@"RedTaxi"];
                     }
                     else
                     {
                         _viewDriverInfo.hidden = YES;
                         NSString *strType = [NSString stringWithFormat:@"%@",[dic valueForKey:@"vtype"]];
                         if ([strType isEqualToString:@"Taxi"])
                         {
                             annotationImage = @"Car";
                             custAnnotion.title= @"Car";
                         }
                         else if ([strType isEqualToString:@"Premium"])
                         {
                             annotationImage = @"PremiumCar";
                             custAnnotion.title= @"PremiumCar";
                         }
                         else if ([strType isEqualToString:@"Private"])
                         {
                             annotationImage = @"PrivateCar";
                             custAnnotion.title= @"PrivateCar";
                         }
                         
                        // strLocationType = [NSString stringWithFormat:@"Car"];
                        // [arrAnnotationImages addObject:@"Car"];
                     }
                     
                     
                     
                     
                     NSString *strStatus = [NSString stringWithFormat:@"%@",[response1 valueForKey:@"accepteddriverst"]];
                     
                     [arrDriverID addObject:strStatus];
                     
                     CLLocationCoordinate2D zoomLocation;
                     
                     NSString *getLatValue = [dic valueForKey:@"lat"];
                     
                     NSString *getLongValue = [dic valueForKey:@"lng"];
                     
                     zoomLocation.latitude = [getLatValue doubleValue];
                     
                     zoomLocation.longitude= [getLongValue doubleValue];
                     
                     
                     custAnnotion.coordinate=CLLocationCoordinate2DMake( zoomLocation.latitude, zoomLocation.longitude);
                     
                     
                    // MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
                     
                   //  point.coordinate = zoomLocation;
                   
                    // [self.mapPassenger addAnnotation:point];
                     
                     
                     [arrAnnotationImages addObject:custAnnotion];
                 }
                    [self.mapPassenger addAnnotations:arrAnnotationImages];
                }
             
             else if([strStatus isEqualToString:@"0"])
             {
                 NSString *strBool = [NSString stringWithFormat:@"%@",[[response valueForKey:@"logout"]stringValue]];
                 if ([strBool isEqualToString:@"1"] && count<=0)
                 {
                     count++;
                     [[[UIAlertView alloc] initWithTitle:nil message:[response valueForKey:@"items"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
                 }
                 _lblDistance.hidden = YES;
                 btnGo.hidden = YES;
                  _lblDistance.text = [NSString stringWithFormat:@"0 Km"];
                 _lblpickupLocation1.text = [NSString stringWithFormat:@"No nearby vehicle available !"];
                 _btnNearestTaxi.enabled = NO;
              //  [_mapPassenger removeAnnotations:annotationsToRemove] ;
                //[self.mapPassenger removeAnnotation:annotation];
             }
         }
         
         failure:^(NSError *error)
         {
             NSLog(@"Error : %@",error);
         }];
            });
    }
}


//___________________________ getting all nearby Drivers _____________________________

#pragma mark - get nearby Drivers method
-(void)getNearByDriversOfLocation: (CLLocationCoordinate2D)location  VehicalId : (NSString *)vehicalId
{
    //______________________ getting nearby drivers ___________________________________
    
    NSString *strFlag=[NSString stringWithFormat:@"api/getallnearbydrivers/?"];
    
    NSString *strData=[NSString stringWithFormat:@"lat=%f&lng=%f&vtid=%@",location.latitude,location.longitude,vehicalId];
    
    //locationManager.location.coordinate.latitude,locationManager.location.coordinate.longitude,vehicalId];
    
    //    [WebManager postDataOnserver:strFlag Data:strData delegate:self onSuccess:@selector(nearbySuccess:) onFailure:@selector(nearbyFail:)];
    
    //  [HUD show:YES];
    
    for (MKPointAnnotation * an in _mapPassenger.annotations)
    {
        [_mapPassenger removeAnnotation:an];
    }
}

// ----- on selection of annotation ------
-(void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    //-----
    
    annotation=(MKPointAnnotation*)view.annotation;
    double latSel = annotation.coordinate.latitude;
    double lngSel = annotation.coordinate.longitude;
    
    NSString *strLat1 = [[NSNumber numberWithDouble:latSel] stringValue];
    NSString *strLng1 = [[NSNumber numberWithDouble:lngSel] stringValue];
    
    MKMapRect r = [mapView visibleMapRect];
    MKMapPoint pt = MKMapPointForCoordinate([annotation coordinate]);
    r.origin.x = pt.x - r.size.width * 0.5;
    r.origin.y = pt.y - r.size.height * 0.5;
    [mapView setVisibleMapRect:r animated:YES];
    
    //-----
    [self getAddressFromLatLong:latSel :lngSel];
//    NSString * SelectedLat = [NSString stringWithFormat:@"%.02f", latSel];
//    
//    NSString *strLattitudeDriver = [[NSString alloc] init];
//    
//    //---
//    
//    for( int i = 0 ; i < arrDriverCoordinates.count ; i++ )
//    {
//        strLattitudeDriver = [[arrDriverCoordinates objectAtIndex:i] valueForKey:@"lat"];
//        
//        //--- driver lattitude into double ---
//        
//        double doubleDriverLat = [strLattitudeDriver doubleValue];
//        NSString *DriverLat = [NSString stringWithFormat:@"%.02f", doubleDriverLat];
//        
//        //---------------
//        
//        if([DriverLat isEqualToString:SelectedLat])
//        {
//            dicSelectedDriver = [arrDriverCoordinates objectAtIndex:i];
//        }
//    }
//    
//    //----
//    
//    NSLog(@"selected annotation %@ and %@",strLat1,strLng1);
//    NSLog(@"pin0-------");
//    
//    //-----
//   // viewDriverInfo.hidden = NO;
//    ConfirmationMapViewController *cmvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ConfirmationMapViewController"];
//    cmvc.dicDriverDetails = dicSelectedDriver;
//    isBookingTypeNearest = NO;
//    cmvc.strTypeBooking = @"perticular";
//    cmvc.strSource = [NSString stringWithFormat:@"%@",_lblSelectedLocation.text];
//    [self.navigationController pushViewController:cmvc animated:YES];
//    
//    //----
//    
    [_mapPassenger deselectAnnotation:view.annotation animated:YES];
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)aView
{
    
}


#pragma mark - get nearest drivers
-(void)getNearestDriverOfLocation : (CLLocationCoordinate2D)location withVehical: (NSString *)vehicalId
{
    NSString *strFlag=[NSString stringWithFormat:@"api/getnearestdriver/?"];
    
    NSString *strData=[NSString stringWithFormat:@"lat=%f&lng=%f&vtid=%@",location.latitude,location.longitude,vehicalId];//18.5203, 73.8567Passenger_Current_Location,vehiicalId];
    
 //      [webManager postDataOnserver:strFlag Data:strData delegate:self onSuccess:@selector(gettimedistanceSuccess:) onFailure:@selector(gettimedistanceFail:)];
 //   [[webManager sharedObject] loginRequest:strData withMethod:@"getnearestdriver/?" successResponce:^(id response)
    // [HUD show:YES];
}

-(void)gettimedistanceSuccess : (NSDictionary *)dataDic
{
    NSLog( @"Success = %@",dataDic);
    
    _lblDistance.text = [[dataDic valueForKey:@"items"] valueForKey:@"time"];
    driverId = [[dataDic valueForKey:@"items"] valueForKey:@"did"];
    distance = [[dataDic valueForKey:@"items"] valueForKey:@"distance"];
    
    //   [HUD hide:YES];
}

-(void)gettimedistanceFail : (NSDictionary *)dataDic
{
    NSLog(@"%@",dataDic);
    //  [HUD hide:YES];
}


// search location
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if([_searchBar.text length] == 0 || [_searchBar.text isEqualToString:@""])
    {
        _tblSearchOptions.hidden = YES;
    }
    else
    {
        arrSearchRes = [[NSMutableArray alloc] init];
        _tblSearchOptions.hidden = NO;
        NSString *urlSTR=[[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyC6SPQpZxZ_JGnUZNd8AKGeBOR8UkXHJtw",searchText] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
        
        NSURL *url = [NSURL URLWithString:urlSTR];
        
        NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
        NSURLResponse *responce;
        NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
        NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
        if( [[dictionary1 valueForKey:@"status"] isEqualToString:@"OK"])
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                arrSearchRes = [dictionary1 valueForKey:@"predictions"];
                [_tblSearchOptions reloadData];
            });
        }
    }
}

-(void)gestureHandlerMethod:(UITapGestureRecognizer*)sender
{
    _menuBtn1.hidden = YES;
    [self viewSlideInFromRightToLeft:_viewLeftMenu];
    _viewLeftMenu.hidden = YES;
    viewHidden = YES;
}

//-(id)initWithTitle:(NSString*)title rating:(double)rating;

-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    CustomAnnotation *abc=(CustomAnnotation *)annotation;
    MKAnnotationView *pinView = nil;
   
    
//    static NSString *defaultPinID = @"car_black";
//    pinView = (MKAnnotationView *)[_mapView dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
//    if ( pinView == nil )
//    {
//        if(annotation1 != mapView.userLocation)//_mapView
//        {
//            
//            if ( pinViewCustom == nil )
//                pinViewCustom = [[MKAnnotationView alloc]
//                                 initWithAnnotation:annotation1 reuseIdentifier:defaultPinID];
//            
//            //pinView.pinColor = MKPinAnnotationColorGreen;
//            pinViewCustom.canShowCallout = YES;
//            //pinView.animatesDrop = YES;
//            pinViewCustom.image = [UIImage imageNamed:abc.title];//@"car_black"];
//            [pinViewCustom sizeToFit];
//            return pinViewCustom;
//        }
//    }
    
    if(annotation != mapView.userLocation)//_mapView
    {
            static NSString *defaultPinID = @"car_black";
            pinView = (MKAnnotationView *)[_mapView dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
            if ( pinView == nil )
                pinView = [[MKAnnotationView alloc]
                           initWithAnnotation:annotation reuseIdentifier:defaultPinID];
            //pinView.pinColor = MKPinAnnotationColorGreen;
            pinView.canShowCallout = YES;
            //pinView.animatesDrop = YES;
            pinView.image = [UIImage imageNamed:abc.title];//@"car_black"];
            [pinView sizeToFit];
    }
    else
    {
        [_mapView.userLocation setTitle:@""];
    }
   // [_mapPassenger setShowsUserLocation:YES];
    return pinView;
}


/*
# pragma mark - mapView delegates
-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation1
{
//    if ([strLocationType isEqualToString:@"RedTaxi"])
//    {
    
    
    
        MKAnnotationView *pinView = nil;
        if(annotation1 != _mapPassenger.userLocation)
        {
           // if (i<[arrAnnotationImages count])
          //  {
                
            
            static NSString *defaultPinID = @"com.invasivecode.pin";
            pinView = (MKAnnotationView *)[_mapPassenger dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
            UIButton *button = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
            
          //  pinView.image = [UIImage imageNamed:[arrAnnotationImages objectAtIndex:i]];
                
            if (!pinView)
            {
                if ( pinView == nil )
                    pinView = [[MKAnnotationView alloc]
                               initWithAnnotation:annotation1 reuseIdentifier:defaultPinID];
                pinView.canShowCallout = YES;
               
//                NSString *img = [NSString stringWithFormat:@"%@",[arrAnnotationImages objectAtIndex:i]];
//                if ([img isEqualToString:@"RedTaxi"])
//                {
//                     pinView.image = [UIImage imageNamed:@"RedTaxi"];
//                    strLocationType = @"";
//                }
//                else
//                {
//                
//                }
                NSLog(@"index  %d",i);
                NSLog(@"Image Name %@",[arrAnnotationImages objectAtIndex:i]);
                
               // pinView.image = [UIImage imageNamed:[arrAnnotationImages objectAtIndex:i]];
                pinView.image = [UIImage imageNamed:annotation];

                [pinView sizeToFit];
                
                pinView.calloutOffset = CGPointMake(0, 0);
                // UIButton *button = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                pinView.rightCalloutAccessoryView = button;
                //  [button addTarget:self action:@selector(viewDetails) forControlEvents:UIControlEventTouchUpInside];
                pinView.rightCalloutAccessoryView = annotationView;
                pinView.canShowCallout=NO;
                i++;
           // }else{
             //   NSLog(@"%d",i);
             //  NSLog(@"%@",[arrAnnotationImages objectAtIndex:i]);
                 //  i++;
            //}
        }
        else
        {
        }
        }
     //   return pinView;
//    }
//    else
//    {
//    MKAnnotationView *pinView = nil;
//    if(annotation1 != _mapPassenger.userLocation)
//    {
//        static NSString *defaultPinID = @"com.invasivecode.pin1";
//        pinView = (MKAnnotationView *)[_mapPassenger dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
//        UIButton *button = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
//        
//        if (!pinView)
//        {
//            if ( pinView == nil )
//                pinView = [[MKAnnotationView alloc]
//                           initWithAnnotation:annotation reuseIdentifier:defaultPinID];
//            pinView.canShowCallout = YES;
//            pinView.image = [UIImage imageNamed:@"Car"];
//            [pinView sizeToFit];
//            
//            pinView.calloutOffset = CGPointMake(0, 0);
//           // UIButton *button = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
//            pinView.rightCalloutAccessoryView = button;
//          //  [button addTarget:self action:@selector(viewDetails) forControlEvents:UIControlEventTouchUpInside];
//            pinView.rightCalloutAccessoryView = annotationView;
//            pinView.canShowCallout=NO;
//        }
//    }
//    else
//    {
//    }
    return pinView;
    }
//}
    /*    NSLog(@"viewForAnnotation");
    
    if([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
    
    static NSString *annotationIdentifier = @"AnnotationIdentifier";
    
    MKPinAnnotationView *pinView = (MKPinAnnotationView *) [_mapPassenger
                                                            dequeueReusableAnnotationViewWithIdentifier:annotationIdentifier];
    
    if (!pinView)
    {
        pinView = [[MKPinAnnotationView alloc]
                    initWithAnnotation:annotation
                    reuseIdentifier:annotationIdentifier];
        
        [pinView setPinColor:MKPinAnnotationColorGreen];
        pinView.animatesDrop = YES;
        pinView.canShowCallout = YES;
        
        UIImageView *houseIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Car"]];
        pinView.leftCalloutAccessoryView = houseIconView;
        
    }
    else 
    {
        pinView.annotation = annotation;
    }
    
    return pinView;*/




#pragma mark - initialize activity Indicator
-(void)initializeActivityIndicator
{
    
}

#pragma mark - initialize controls
-(void)initializeControls
{
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"Background.png"]]];
    
    //____________________ making search view rounded and setting border ___________________________
    
    _viewSearch.layer.cornerRadius = _lblPickupLocation.layer.frame.size.height/6;
   
    _viewSearch.layer.borderWidth = 1.0f;
    _viewSearch.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]CGColor];
    _viewSearch.layer.masksToBounds = YES;
    
    //  _lblPickupLocation.layer.sublayerTransform = CATransform3DMakeTranslation(60, 0, 0);
    
    //____________________adding tapGesture to label Pickup Location__________________________
    
    UITapGestureRecognizer *tapGesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(lblPickupLocationapped:)];
    tapGesture.numberOfTapsRequired = 1;
    [_lblPickupLocation addGestureRecognizer:tapGesture];
    _lblPickupLocation.userInteractionEnabled = YES;
    
    //_______________________adding gesture recognizer to label set pickup location_________________
    
    UITapGestureRecognizer *tapGesture1=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(lblSetPickupLocationapped:)];
    tapGesture.numberOfTapsRequired = 1;
    [_lblsetPickupLocation addGestureRecognizer:tapGesture1];
    _lblsetPickupLocation.userInteractionEnabled = YES;
    
    //____________________changing color of textField's placeholder______________________________
    
    UIColor *colour = [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1];
    NSString *str = @"    Pickup Location";
    _txtPickUpLocation.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName:colour}];
    
    // _txtPickUpLocation.layer.sublayerTransform = CATransform3DMakeTranslation(0, 0, 0);
    
    
    locationManager = [[CLLocationManager alloc]init];
    
    [locationManager requestWhenInUseAuthorization];
    // [locationManager requestAlwaysAuthorization];
    [locationManager setDelegate:self];
    
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBestForNavigation];
    [locationManager setDistanceFilter:kCLDistanceFilterNone];
    [locationManager startUpdatingLocation];
    
    //_____________________setting border to standard image view________________________________
    
    _imgViewStandard.layer.borderWidth = 2.0;
    _imgViewStandard.layer.borderColor = [[UIColor grayColor]CGColor];
    
    _imgViewStandard.layer.cornerRadius = _imgViewStandard.layer.frame.size.width/2;
    _imgViewStandard.layer.masksToBounds = YES;
    
    //____________________setting border to Premium image view__________________________________
    
    _imgViewPremium.layer.borderWidth = 2.0;
    _imgViewPremium.layer.borderColor = [[UIColor grayColor]CGColor];
    
    _imgViewPremium.layer.cornerRadius = _imgViewPremium.layer.frame.size.width/2;
    _imgViewPremium.layer.masksToBounds = YES;
    
    //____________________setting border to btnSUV image view___________________________________
    
    _btnSUV.layer.borderWidth = 2.0;
    _btnSUV.layer.borderColor = [[UIColor grayColor]CGColor];
    _btnSUV.layer.cornerRadius = _btnSUV.layer.frame.size.width/2;
    
    //_____________________setting border to btnSUV2_____________________________________
    
    _btnSUV2.layer.borderWidth = 2.0;
    _btnSUV2.layer.borderColor = [[UIColor grayColor]CGColor];
    _btnSUV2.layer.cornerRadius = _btnSUV2.layer.frame.size.width/2;
    
    //__________________making rounded label inside popover__________________________
    
    _lblDistance.layer.borderWidth = 1.0;
    _lblDistance.layer.borderColor = [[UIColor whiteColor]CGColor];
    _lblDistance.layer.cornerRadius = _lblDistance.layer.frame.size.width/2;
    
    //___________________setting border to imgViewVan________________________________________
    
    _imgViewVan.layer.borderWidth = 2.0;
    _imgViewVan.layer.borderColor = [[UIColor grayColor]CGColor];
    _imgViewVan.layer.cornerRadius = _imgViewVan.layer.frame.size.width/2;
    _imgViewVan.layer.masksToBounds = YES;
    //--ggggggg _imgViewVan.hidden = YES;
    
    
    UIPanGestureRecognizer  * pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(imagePanned:)];
    [_imgViewSUV addGestureRecognizer:pan];
    [_imgViewSUV setUserInteractionEnabled: YES];
}

#pragma mark - zoom mapView
-(void)zoomMapView : (CLLocationCoordinate2D)coord
{
    MKCoordinateRegion region;
    CLLocationCoordinate2DMake(coord.latitude,coord.longitude);//locationManager.location.coordinate.latitude,locationManager.location.coordinate.longitude);
    region = MKCoordinateRegionMakeWithDistance(coord,500, 500);
    
    [_mapPassenger setRegion:region animated:YES];
    //_mapPassenger.showsUserLocation = YES;
}


-(void)viewDetails
{
    
}

- (BOOL)mapViewRegionDidChangeFromUserInteraction
{
    UIView *view = self.mapView.subviews.firstObject;
    //  Look through gesture recognizers to determine whether this region change is from user interaction
    for(UIGestureRecognizer *recognizer in view.gestureRecognizers)
    {
        if(recognizer.state == UIGestureRecognizerStateBegan || recognizer.state == UIGestureRecognizerStateEnded)
        {
            return YES;
        }
    }
    return NO;
}

static BOOL mapChangedFromUserInteraction = NO;

- (void)mapView:(MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated
{
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
    mapChangedFromUserInteraction = [self mapViewRegionDidChangeFromUserInteraction];
    
    CLLocationCoordinate2D centre = [_mapPassenger centerCoordinate];
    
    double lat = centre.latitude;
    double lng = centre.longitude;
   
    strLatA = [NSString stringWithFormat:@"%f",lat];
    strLngA = [NSString stringWithFormat:@"%f",lng];
    NSMutableArray *arrCoordinates = [[NSMutableArray alloc] initWithObjects:strLatA,strLngA ,nil];
    i = 0;
   // int lat1 = (int)lat;
    int lng1 = (int)lng;
    if (lng1)
    {
     //   dispatch_async(dispatch_get_main_queue(), ^{
     //   });
        [myTimer invalidate];
        myTimer = nil;

        myTimer = [NSTimer scheduledTimerWithTimeInterval:5.0 target: self selector: @selector(callAfterTwentySecond:) userInfo:arrCoordinates repeats: YES];
        
      //  [self callAfterTwentySecond:arrCoordinates];
        [self getAddressFromLatLong:lat :lng];
    }
    
    if (mapChangedFromUserInteraction)
    {
        // user changed map region
        
        MKCoordinateRegion region;
        coord = CLLocationCoordinate2DMake(_mapPassenger.region.center.latitude,_mapPassenger.region.center.longitude);//18.9750, 72.8258);//locationManager.location.coordinate.latitude,locationManager.location.coordinate.longitude);
        //region = MKCoordinateRegionMakeWithDistance(coord, 1000, 1000);
        region = MKCoordinateRegionMakeWithDistance(coord, 500, 500);
        
        [_mapPassenger setRegion:region animated:YES];
        
        //_____________ getting addresss from dragged mapView Location (location after dragging) _________
        
        CLGeocoder *  geocoder = [[CLGeocoder alloc] init];
        CLLocation * newLocation = [[CLLocation alloc]initWithLatitude:_mapPassenger.region.center.latitude longitude:_mapPassenger.region.center.longitude];
        
        [geocoder reverseGeocodeLocation:newLocation
                       completionHandler:^(NSArray *placemarks, NSError *error) {
                           if (error)
                           {
                               NSLog(@"Geocode failed with error: %@", error);
                               return;
                           }
                           
                           CLPlacemark *placemark = [placemarks objectAtIndex:0];
                           
                           NSLog(@"placemark - %@",placemark);
                              
                           NSLog(@"placemark.ISOcountryCode %@",placemark.ISOcountryCode);
                           NSLog(@"%@",placemark.locality);
                           NSLog(@"%@",placemark.subLocality);
                           NSLog(@"%@",placemark.thoroughfare);
                           NSLog(@"%@",placemark.subThoroughfare);
                           NSLog(@"%@",placemark.subAdministrativeArea);
                           NSLog(@"%@",placemark.addressDictionary);
                           NSLog(@"%@",placemark.name);
                           NSLog(@"%@",placemark.postalCode);
                           
                           currentLocationAddress = [[placemark.addressDictionary valueForKey:@"FormattedAddressLines"]componentsJoinedByString:@","];
                           
                           [[NSUserDefaults standardUserDefaults] setObject:currentLocationAddress forKey:@"currentLocation"];
                           NSLog(@"%@",currentLocationAddress);
                       }];
        
        //______________ setting new location on label __________________
        
        [self getNearByDriversOfLocation:coord VehicalId:_selectedVehicle];
        
        //  [self getNearByDrivers:_selectedVehicle];
        
        currentSelectedLocationCoord = coord;
        currentLocation =currentLocationAddress;
        
        _lblPickupLocation.text = [[NSUserDefaults standardUserDefaults]objectForKey:@"currentLocation"];
        
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",_mapPassenger.region.center.latitude] forKey:@"Current_Lat"];
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",_mapPassenger.region.center.longitude] forKey:@"Current_Lng"];
        
        
        self.mapView.showsUserLocation = YES;

    }
}

#pragma mark - TapGesture method
//method for tap gesture
-(void)imageTapped:(UITapGestureRecognizer *)sender
{
    if( ((UIImageView *) sender.view).tag == 101)
    {
        [_imgStandard setImage:[UIImage imageNamed:@"Car-1"]];
        [_imgPremium setImage:[UIImage imageNamed:@""]];
        [_imgViewSUV setImage:[UIImage imageNamed:@""]];
        
        _imgViewStandard.hidden =YES;
        _imgViewPremium.hidden = NO;
        //  _imgViewVan.hidden = NO;
    }
    else if(((UIImageView *) sender.view).tag == 102)
    {
        [_imgStandard setImage:[UIImage imageNamed:@""]];
        [_imgPremium setImage:[UIImage imageNamed:@"Car-1"]];
        [_imgViewSUV setImage:[UIImage imageNamed:@""]];
        _imgViewStandard.hidden = NO;
        _imgViewPremium.hidden = YES;
        //_imgViewVan.hidden = NO;
    }
    else if(((UIImageView *) sender.view).tag == 103)
    {
        [_imgStandard setImage:[UIImage imageNamed:@""]];
        [_imgPremium setImage:[UIImage imageNamed:@""]];
        [_imgViewSUV setImage:[UIImage imageNamed:@"Car-1"]];
        
        _imgViewStandard.hidden = NO;
        _imgViewPremium.hidden = NO;
        //  _imgViewVan.hidden = YES;
    }
    // [_imgViewSUV setImage:[UIImage imageNamed:@""]];
}

#pragma mark - PanGesture Method
//Pan gestur's method For panning an image
-(void)imagePanned:(UIPanGestureRecognizer*)pan
{
    //stateBegan stateEnded stateChagned
    //CGRect originalFrame1 = pan.view.frame;
    static CGRect originalFrame;
    
    if (pan.state == UIGestureRecognizerStateBegan)
    {
        //originalFrame = pan.view.frame;
        originalFrame = pan.view.frame;
        //viewVehiclePan
    }
    
    if (pan.state == UIGestureRecognizerStateChanged)
    {
        CGPoint translatedPoint = [pan translationInView:self.view];
        
        [pan.view setFrame:CGRectMake(originalFrame.origin.x + translatedPoint.x, originalFrame.origin.y + translatedPoint.y, originalFrame.size.width, originalFrame.size.height)];
    }
    
    if(pan.state == UIGestureRecognizerStateEnded)
    {
        if((pan.view.frame.origin.x < originalFrame.origin.x ) && (pan.view.frame.origin.x > _imgStandard.frame.origin.x) && (pan.view.frame.origin.x <_imgViewSUV1.frame.origin.x))
        {
            [pan.view setFrame:_imgStandard.frame];
            _imgViewVan.hidden = NO;
            
            _selectedVehicle = @"Standard";
            
            strVehicleID = @"1";
            
            NSLog(@"selected vehicle : %@ , id : %@",_selectedVehicle,strVehicleID);
            
            //-?  [self getVehicalId:_selectedVehicle];
        }
        else if((pan.view.frame.origin.x > originalFrame.origin.x) &&(pan.view.frame.origin.x <= _imgViewSUV1.frame.origin.x))
        {
            [pan.view setFrame:_imgViewSUV1.frame];
            //--ggggggg     _imgViewVan.hidden = YES;
            
            _selectedVehicle = @"Van";
            
            strVehicleID = @"3";
            
            NSLog(@"selected vehicle : %@ , id : %@",_selectedVehicle,strVehicleID);
            
            //-?   [self getVehicalId:_selectedVehicle];
        }
        else if((pan.view.frame.origin.x > originalFrame.origin.x) && (pan.view.frame.origin.x <= _imgPremium.frame.origin.x))
        {
            [pan.view setFrame:_imgPremium.frame];
            _imgViewVan.hidden = NO;
            
            _selectedVehicle = @"Premium";
            
            strVehicleID = @"2";
            
            NSLog(@"selected vehicle : %@ , id : %@",_selectedVehicle,strVehicleID);
            
            //-?   [self getVehicalId:_selectedVehicle];
        }
        else if((pan.view.frame.origin.x < originalFrame.origin.x) && (pan.view.frame.origin.x >= _imgViewSUV1.frame.origin.x))
        {
            [pan.view setFrame:_imgViewSUV1.frame];
            //--ggggggg   _imgViewVan.hidden = YES;
            
            _selectedVehicle = @"Van";
            
            strVehicleID = @"3";
            
            NSLog(@"selected vehicle : %@ , id : %@",_selectedVehicle,strVehicleID);
            
            //-?   [self getVehicalId:_selectedVehicle];
        }
        else if((pan.view.frame.origin.x > originalFrame.origin.x) && (pan.view.frame.origin.x > _imgViewSUV1.frame.origin.x) && (pan.view.frame.origin.x > _imgPremium.frame.origin.x))
        {
            [pan.view setFrame:_imgPremium.frame];
            _imgViewVan.hidden = NO;
            
            _selectedVehicle = @"Premium";
            
            strVehicleID = @"2";
            
            NSLog(@"selected vehicle : %@ , id : %@",_selectedVehicle,strVehicleID);
            
            //-?   [self getVehicalId:_selectedVehicle];
        }
        else if ((pan.view.frame.origin.x < originalFrame.origin.x ) && (pan.view.frame.origin.x < _imgStandard.frame.origin.x))
        {
            [pan.view setFrame:_imgStandard.frame];
            _imgViewVan.hidden = NO;
            
            _selectedVehicle = @"Standard";
            
            strVehicleID = @"1";
            
            NSLog(@"selected vehicle : %@ , id : %@",_selectedVehicle,strVehicleID);
            
            //-?   [self getVehicalId:_selectedVehicle];
        }
    }
}

#pragma filrerValueChanged

- (IBAction)filterValueChanged:(SEFilterControl *)sender
{
  //  [_filterLabel setText:[NSString stringWithFormat:@"Selected index : %ld", (unsigned long)sender.selectedIndex]];
    
    //    if (sender.selectedIndex == 0)
    //    {
    //        strCarType = [NSString stringWithFormat:@"Standard"];
    //    }
    
    
   // [locationManager startUpdatingLocation]; // Changes by Sachin Daingade
    if (sender.selectedIndex == 0)
    {
        //  strCarType = [NSString stringWithFormat:@"Full Size"];
       // strCarType = [NSString stringWithFormat:@"2"];
        _selectedVehicle = @"Standard";
        strVehicleID = @"2";
    }
    else if (sender.selectedIndex == 1)
    {
        //   strCarType = [NSString stringWithFormat:@"4 x 4"];
      //  strCarType = [NSString stringWithFormat:@"3"];
        _selectedVehicle = @"Van";
        strVehicleID = @"3";
    }
    else if (sender.selectedIndex == 2)
    {
        //  strCarType = [NSString stringWithFormat:@"Mini Van"];
       // strCarType = [NSString stringWithFormat:@"4"];
        _selectedVehicle = @"Premium";
        strVehicleID = @"1";
    }
    ConfirmationMapViewController *cmvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ConfirmationMapViewController"];
    cmvc.strVtype = _selectedVehicle;
    CLLocationCoordinate2D coordinates = [_mapPassenger centerCoordinate];
    double lat1 = coordinates.latitude;
    double lng1 = coordinates.longitude;
    
    NSString *str1 = [NSString stringWithFormat:@"%f",lat1];
    NSString *str2 = [NSString stringWithFormat:@"%f",lng1];
    NSMutableArray *arrCord = [[NSMutableArray alloc]initWithObjects:str1,str2,nil];
    
    if (lng1>0)
    {
      //  dispatch_async(dispatch_get_main_queue(), ^{
            
      //  });
        [self callAfterTwentySecond:arrCord];
    }
}


#pragma marks - lblPickupLocation Tapped method

-(void)lblPickupLocationapped:(UITapGestureRecognizer *)tap
{
    NSString *strFlag = [NSString stringWithFormat:@"api/getaddressbycid/?"];
    NSString * cid = [[[NSUserDefaults standardUserDefaults] objectForKey:@"Cid"] objectAtIndex:0];
    NSString *strData = [NSString stringWithFormat:@"cid=%@",cid];
}

#pragma mark - lblSet pickup location tapped
-(void)lblSetPickupLocationapped:(UITapGestureRecognizer *)tap
{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return YES;
}


#pragma mark - menu button action
- (IBAction)btnMenuClicked:(id)sender
{
    if(viewHidden == YES)
    {
        [self viewSlideInFromLeftToRight:_viewLeftMenu];
        viewHidden = NO;
        _viewLeftMenu.hidden = NO;
        [self performSelector:@selector(HideMenuBtn1) withObject:nil afterDelay:0.07];
    }
    else
    {
        [self viewSlideInFromRightToLeft:_viewLeftMenu];
        _viewLeftMenu.hidden = YES;
        viewHidden = YES;
        _menuBtn1.hidden = YES;
    }
}

-(void)HideMenuBtn1
{
    _menuBtn1.hidden = NO;
    [self viewSlideInFromLeftToRight:_menuBtn1];
}

#pragma mark getLatLong From address
-(CLLocationCoordinate2D )getLatLongFromAddress : (NSString *)address
{
    //http://maps.google.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=false
    CLLocationCoordinate2D coord1;
 //   NSString *urlSTR=[[NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?address=%@&sensor=false",address] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
 
    NSString *urlSTR=[[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/geocode/json?address=%@&sensor=true&key=AIzaSyDAgAd4dSAsdzKTdchuennLl9VDD-F_9_U",address] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
    NSURL *url = [NSURL URLWithString:urlSTR];
    
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
    
    NSURLResponse *responce;
    NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
    NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSArray * resultArray = [dictionary1 valueForKey:@"results"];
    if ([resultArray count]<=0)
    {
        [ALToastView toastInView:self.view withText:@"Unable to show location"];
   //     [[[UIAlertView alloc] initWithTitle:nil message:@"Unable to show location" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }
    else
    {
        NSDictionary * dic = [resultArray objectAtIndex:0];
        NSDictionary * geo = [dic valueForKey:@"geometry"];
        NSDictionary * location = [geo valueForKey:@"location"];
        double lat = [[location valueForKey:@"lat"] doubleValue];
        double lng = [[location valueForKey:@"lng"] doubleValue];
        coord1 = CLLocationCoordinate2DMake(lat,lng);
    }
    
 //   MKCoordinateRegion region = MKCoordinateRegionMake(annotation.coordinate, span);
    
        
  //  [_mapPassenger setRegion:region animated:YES];
   // [self methodAddress];
    return coord1;
}


-(NSString *)getAddressFromLatLong : (double)latitude :(double)longitude
{
    //http://maps.googleapis.com/maps/api/geocode/json?latlng=34.41448,-118.93753&sensor=true
    
    NSString *urlSTR=[[NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/geocode/json?latlng=%f,%f&sensor=true",latitude,longitude] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
    
    NSURL *url = [NSURL URLWithString:urlSTR];
    
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
    
    NSURLResponse *responce;
    NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
    NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSArray * resultArray = [dictionary1 valueForKey:@"results"];
    NSDictionary * dic = [resultArray objectAtIndex:0];
    NSDictionary * geo = [dic valueForKey:@"formatted_address"];
    NSString *strAddress = [NSString stringWithFormat:@"%@",geo];
    _lblSelectedLocation.text = strAddress;
    return nil;
}

- (BOOL) textField: (UITextField *)theTextField shouldChangeCharactersInRange:(NSRange)range replacementString: (NSString *)string
{
    NSUInteger lengthOfString = string.length;
    for (NSInteger index = 0; index < lengthOfString; index++)
    {
        unichar character = [string characterAtIndex:index];
        if (character < 48) return NO; // 48 unichar for 0
        if (character > 57) return NO; // 57 unichar for 9
    }
    // Check for total length
    NSUInteger proposedNewLength = theTextField.text.length - range.length + string.length;
    if (proposedNewLength > 6)
        return YES;
    return YES;
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag==502)
    {
        return [arrSearchRes count];
    }
    else
    return arrLeftMenu.count;    //count number of row from counting array hear cataGorry is An Array
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LeftMenuTableCell *cell;
    if (tableView.tag==502)
    {
        static NSString *MyIdentifier = @"SearchBarCell";
        SearchBarCell *cellSearch = [_tblSearchOptions dequeueReusableCellWithIdentifier:MyIdentifier];
        
        if (cellSearch == nil)
        {
            cellSearch = [[SearchBarCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier] ;
        }
        [cellSearch setSelectionStyle:UITableViewCellSelectionStyleNone];
        cellSearch.lblPredAdress.text = [[arrSearchRes objectAtIndex:indexPath.row] valueForKey:@"description"];
        //    strSearchedAddress = [[arrSearchRes objectAtIndex:indexPath.row] valueForKey:@"description"];
        return cellSearch;
    }
    else
    {
    static NSString *MyIdentifier = @"LeftMenuTableCell";
    cell = [_tblLeftMenu dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if (cell == nil)
    {
        cell = [[LeftMenuTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
    }
    
    //-----
    
    cell.lblBaseLine.hidden = NO;
    
    NSInteger currentRow = indexPath.row;
    
    if(subMenuHidden == NO)
    {
        if(currentRow == 6)
        {
            cell.lblBaseLine.hidden = YES;
        }
    }
    
    cell.lblMenu.text = [arrLeftMenu objectAtIndex:indexPath.row];
    cell.imgMenuIcon.image = [UIImage imageNamed:[arrMenuImages objectAtIndex:indexPath.row]];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger currentRow = indexPath.row;
    
    if (tableView.tag == 502)
    {
        dicSelectedLoc = [arrSearchRes objectAtIndex:indexPath.row];
        _searchBar.text = strSearchedAddress;
        _tblSearchOptions.hidden = YES;
        strSearchedAddress = [[arrSearchRes objectAtIndex:indexPath.row] valueForKey:@"description"];
        [_delegateServiceType selectedValue:strSearchedAddress];
        _lblSelectedLocation.text = [NSString stringWithFormat:@"%@",strSearchedAddress];
        searchView.hidden = YES;
        [_searchBar resignFirstResponder];
        [self selectedValue:strSearchedAddress];
        }
    else
    {
    if(subMenuHidden == YES)
    {
        if(currentRow == 5)
        {//@"Fixed Fare to Airport",
            
            dispatch_async(dispatch_get_main_queue(), ^{
       
            // MODIFICATION MENU PETER MALACZYNSKI START

            
            // Original Start
                
                // arrLeftMenu = [[NSMutableArray alloc] initWithObjects:@"Home",@"Profile",@"Billing Info",@"Past Bookings",@"Current Booking Status",@"Book In Advance",@"Pre booking form",@"Pre Booking Info",@"Invite Friends",@"Contact", nil];
                // arrMenuImages = [[NSMutableArray alloc] initWithObjects:@"home2.png",@"profile2.png",@"billing-info-2.png",@"favourites-2.png",@"favourites-2.png",@"books-2.png",@"",@"",@"invite-friends-2.png",@"contact-2.png", nil];
                
            // Original End
                
            
            // Modified Start
                
                arrLeftMenu = [[NSMutableArray alloc] initWithObjects:@"Home",@"Profile",@"Billing Info",@"Past Bookings",@"Current Booking Status",@"Invite Friends",@"Contact", nil];
                arrMenuImages = [[NSMutableArray alloc] initWithObjects:@"home2.png",@"profile2.png",@"billing-info-2.png",@"favourites-2.png",@"books-2.png",@"invite-friends-2.png",@"contact-2.png", nil];
                
            // Modiefied End
                
                
            // MODIFICATION PETER MALACZYNSKI END
                
            subMenuHidden = NO;
            [_tblLeftMenu reloadData];
                     });
        }
        
        if(currentRow == 0)
        {
            [self viewSlideInFromRightToLeft:_viewLeftMenu];
            _viewLeftMenu.hidden = YES;
            viewHidden = YES;
            _menuBtn1.hidden = YES;
        }
        
        if(currentRow == 1)
        {
            ProfileViewController *pvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
            [self.navigationController pushViewController:pvc animated:YES];
        }
        
        if(currentRow == 2)
        {
            BillingInfoViewCotroller *bivc = [self.storyboard instantiateViewControllerWithIdentifier:@"BillingInfoViewCotroller"];
            [self.navigationController pushViewController:bivc animated:YES];
        }
        
        if(currentRow == 3)
        {
            FavouritesViewController *bivc = [self.storyboard instantiateViewControllerWithIdentifier:@"FavouritesViewController"];
            [self.navigationController pushViewController:bivc animated:YES];
        }
        
        if(currentRow == 4)
        {
            CurrentBookingStatus *bivc = [self.storyboard instantiateViewControllerWithIdentifier:@"CurrentBookingStatus"];
            [self.navigationController pushViewController:bivc animated:YES];
        }
        
//        if(currentRow == 5)
//        {
//            CreditVC *bivc = [self.storyboard instantiateViewControllerWithIdentifier:@"CreditVC"];
//            [self.navigationController pushViewController:bivc animated:YES];
//        }
        
        if(currentRow == 6)
        {
            
            NSString *text = @"I am using Destarny TaxiApp";
            
            //  NSURL *url = [NSURL URLWithString:@"http://www.ezygo.co.nz/"];
            // UIImage *image = [UIImage imageNamed:@"roadfire-icon-square-200"];
            
            UIActivityViewController *controller =[[UIActivityViewController alloc] initWithActivityItems:@[text] applicationActivities:nil];
            
            controller.excludedActivityTypes = @[UIActivityTypePostToWeibo,
                                                 UIActivityTypePrint,
                                                 UIActivityTypeCopyToPasteboard,
                                                 UIActivityTypeSaveToCameraRoll,
                                                 UIActivityTypeAddToReadingList,
                                                 UIActivityTypePostToFlickr,
                                                 UIActivityTypePostToVimeo,
                                                 UIActivityTypePostToTencentWeibo,
                                                 UIActivityTypeAirDrop];
            
            [self presentViewController:controller animated:YES completion:nil];
            
            [controller setCompletionHandler:^(NSString *activityType, BOOL completed)
             {
                 NSLog(@"completed");
                 [[SlideNavigationController sharedInstance]popViewControllerAnimated:YES];
             }];

            
        //    InviteFriendsViewController *ifvc = [self.storyboard instantiateViewControllerWithIdentifier:@"InviteFriendsViewController"];
        //    [self.navigationController pushViewController:ifvc animated:YES];
        }
        
        if(currentRow == 7)
        {
            ContactVC *cvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ContactVC"];
            cvc.strType = [NSString stringWithFormat:@"Contact"];
            [self.navigationController pushViewController:cvc animated:YES];
        }
    }
    else
    {
        subMenuHidden = YES;
        
        if(currentRow == 5)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
           
            // MODIFICATION MENU PETER MALACZYNSKI START (I DISABLED ADVANCED BOOKING IN ADVANCE)
                
            // arrLeftMenu = [[NSMutableArray alloc] initWithObjects:@"Home",@"Profile",@"Billing Info",@"Past Bookings",@"Current Booking Status",@"Book In Advance",@"Invite Friends",@"Contact", nil];
            // arrMenuImages = [[NSMutableArray alloc] initWithObjects:@"home2.png",@"profile2.png",@"billing-info-2.png",@"favourites-2.png",@"favourites-2.png",@"books-2.png",@"invite-friends-2.png",@"contact-2.png", nil];
                
            arrLeftMenu = [[NSMutableArray alloc] initWithObjects:@"Home",@"Profile",@"Billing Info",@"Past Bookings",@"Current Booking Status",@"Invite Friends",@"Contact", nil];
            arrMenuImages = [[NSMutableArray alloc] initWithObjects:@"home2.png",@"profile2.png",@"billing-info-2.png",@"favourites-2.png",@"books-2.png",@"invite-friends-2.png",@"contact-2.png", nil];
                
            // MODIFICATION MENU PETER MALACZYNSKI END
                
            subMenuHidden = YES;
        //    NSRange range = NSMakeRange(0, [self numberOfSectionsInTableView:self.tblLeftMenu]);
        //    NSIndexSet *sections = [NSIndexSet indexSetWithIndexesInRange:range];
        //    [self.tblLeftMenu reloadSections:sections withRowAnimation:UITableViewRowAnimationFade];
            [_tblLeftMenu reloadData];
                 });
        }
        
        if(currentRow == 0)
        {
            [self viewSlideInFromRightToLeft:_viewLeftMenu];
            _viewLeftMenu.hidden = YES;
            viewHidden = YES;
            _menuBtn1.hidden = YES;
        }
        
        if(currentRow == 1)
        {
            ProfileViewController *pvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
            [self.navigationController pushViewController:pvc animated:YES];
        }
        
        if(currentRow == 2)
        {
            BillingInfoViewCotroller *bivc = [self.storyboard instantiateViewControllerWithIdentifier:@"BillingInfoViewCotroller"];
            [self.navigationController pushViewController:bivc animated:YES];
        }
        
        if(currentRow == 3)
        {
            FavouritesViewController *bivc = [self.storyboard instantiateViewControllerWithIdentifier:@"FavouritesViewController"];
            [self.navigationController pushViewController:bivc animated:YES];
        }
        
        if(currentRow == 4)
        {
            CurrentBookingStatus *bivc = [self.storyboard instantiateViewControllerWithIdentifier:@"CurrentBookingStatus"];
            [self.navigationController pushViewController:bivc animated:YES];
        }
        
//        if(currentRow == 5)
//        {
//            CreditVC *bivc = [self.storyboard instantiateViewControllerWithIdentifier:@"CreditVC"];
//            [self.navigationController pushViewController:bivc animated:YES];
//        }
        
        if(currentRow == 6)
        {
            Taxi_Booking_Form_ViewController *bivc = [self.storyboard instantiateViewControllerWithIdentifier:@"Taxi_Booking_Form_ViewController"];
            [self.navigationController pushViewController:bivc animated:YES];
        }
        
//        if(currentRow == 7)
//        {
//            AirportFixedPriceBookingForm_ViewController *afpbvc = [self.storyboard instantiateViewControllerWithIdentifier:@"AirportFixedPriceBookingForm_ViewController"];
//            [self.navigationController pushViewController:afpbvc animated:YES];
//        }
        
        if(currentRow == 7)
        {
            PreBookingInfoViewController *objPre = [self.storyboard instantiateViewControllerWithIdentifier:@"PreBookingInfoViewController"];
            [self.navigationController pushViewController:objPre animated:YES];
        }
        
        if(currentRow == 8)
        {
            ContactVC *cvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ContactVC"];
            cvc.strType = [NSString stringWithFormat:@"Contact"];
            [self.navigationController pushViewController:cvc animated:YES];
        }
    }
    }
}


-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self.searchBar resignFirstResponder];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)SearchBar
{
    [_searchBar resignFirstResponder];
}
//-----------

//table disappears from Left to Right - animate
-(void)viewSlideInFromLeftToRight:(UIView *)views
{
    CATransition *transition = nil;
    transition = [CATransition animation];
    transition.duration = 0.5;//kAnimationDuration
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype =kCATransitionFromLeft;
    transition.delegate = self;
    [views.layer addAnimation:transition forKey:nil];
}

//___________________________________________________________________________________

//table disappears from right to left - animate
-(void)viewSlideInFromRightToLeft:(UIView *)views
{
    CATransition *transition = nil;
    transition = [CATransition animation];
    transition.duration = 0.5;//kAnimationDuration
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype =kCATransitionFromRight;
    transition.delegate = self;
    [views.layer addAnimation:transition forKey:nil];
}


- (IBAction)btnLogoutTapped:(id)sender
{
    [self callLogoutAPI];
}


//--------- location manager delegate ----------
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    isLocationAvailable = NO;
}


/////------ dont remove
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    //------ location available
    
    isLocationAvailable = YES;
    locationsNew = locations;
    
    //-------------
    
    currLocation = [locations objectAtIndex:0];
    
   
    CLGeocoder *geocoder = [[CLGeocoder alloc] init] ;
    [geocoder reverseGeocodeLocation:currLocation
                   completionHandler:^(NSArray* placemarks, NSError* error)
     {
         if (error){
             NSLog(@"Geocode failed with error: %@", error);
             return;
         }
         CLPlacemark *placemark = [placemarks objectAtIndex:0];
         
         //         NSLog(@"placemark.ISOcountryCode %@",placemark.ISOcountryCode);
         //         NSLog(@"locality %@",placemark.locality);
         //         NSLog(@"postalCode %@",placemark.postalCode);
         //         NSLog(@"postalCode %@",placemark.subLocality);
         //         NSLog(@"postalCode %@",placemark.country);
         //         NSLog(@"Detail address %@",[placemark.addressDictionary  valueForKey:@"FormattedAddressLines"]);
         
         NSArray *strDetailedAddress = [placemark.addressDictionary  valueForKey:@"FormattedAddressLines"];
         
         NSString *strAddress = [[NSMutableString alloc] init];
         
         for(int i=0 ; i < strDetailedAddress.count ; i++)
         {
             strAddress = [strAddress stringByAppendingString:[NSString stringWithFormat:@"%@,",[strDetailedAddress objectAtIndex:i]]];
         }
         
         strAddress = [strAddress substringToIndex:[strAddress length] - 1];
         _lblSelectedLocation.text = strAddress;
     }];
    
    
    if (currLocation.horizontalAccuracy > 0 && currLocation.horizontalAccuracy < 100)
        [locationManager stopUpdatingLocation];
    
    NSLog(@"Detected Location : %f, %f", currLocation.coordinate.latitude, currLocation.coordinate.longitude);
    
    double lat = currLocation.coordinate.latitude;
    NSString *strLat = [[NSNumber numberWithDouble:lat] stringValue];
    strCurrentLat = strLat;
    strLatA = strLat; /// -- global lat
    
    double lng = currLocation.coordinate.longitude;
    NSString *strLng = [[NSNumber numberWithDouble:lng] stringValue];
    strCurrentLng = strLng;
    strLngA = strLng; /// -- global lat
    
    NSMutableArray *arrCoord = [[NSMutableArray alloc] initWithObjects:strLat,strLng ,nil];
    
    ////-------- call nearby driver --------
    
    //-------- get near by drivers after every 30 sec ------
    
  //  dispatch_async(dispatch_get_main_queue(), ^{
        
  //  });
  //  myTimer = [NSTimer scheduledTimerWithTimeInterval:30.0 target: self selector: @selector(callAfterTwentySecond:) userInfo:arrCoord repeats: YES];
    [self callAfterTwentySecond:arrCoord];
    
    ///---------------------------
    [self zoomInToMyLocation:locations];
    if(isShownLoc == NO)
    {
        isShownLoc = YES;
    }
    
    if(isMapZoom == NO)
    {
        [self zoomInToMyLocation:locations];
        isMapZoom = YES;
    }
}


//------ zoom mapview to current location --------
-(void)zoomInToMyLocation:(NSArray *)locations
{
    //--
    
    CLLocation * currLocation = [locations objectAtIndex:0];
    if (currLocation.horizontalAccuracy > 0 && currLocation.horizontalAccuracy < 100)
        [locationManager stopUpdatingLocation];
    
    //---
    
    MKCoordinateRegion region = { {0.0, 0.0 }, { 0.0, 0.0 } };
    
    region.center.latitude = currLocation.coordinate.latitude;
    region.center.longitude = currLocation.coordinate.longitude;
    
    region.span.longitudeDelta = 0.02f;
    region.span.latitudeDelta = 0.02f;
    [_mapPassenger setRegion:region animated:YES];
}

- (IBAction)btnCurrentLocationTapped:(id)sender
{
      searchView.hidden = NO;
    [_searchBar becomeFirstResponder];
    
//    SearchPlaceViewController * sbvc = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchPlaceViewController"];
//    sbvc.delegateServiceType = self;
//    
//    [self.navigationController pushViewController:sbvc animated:YES];
}
-(IBAction)btnHideSearchView:(id)sender
{
    searchView.hidden = YES;
    [self.view endEditing:YES];
}


- (IBAction)getNearByDriversTapped:(id)sender
{
    if(isLocationAvailable == YES)
    {
        //-------- get near by drivers after every 10 sec ------

    }
}


-(void)selectedValue:(NSDictionary *)strKey
{
    NSLog(@"strKey : %@",strKey);
    selectedLocationCoord = [self getLatLongFromAddress:strKey];
    NSString *address = [NSString stringWithFormat:@"%@",strKey];
    _lblSelectedLocation.text = address;
    
    double lat = selectedLocationCoord.latitude;
    double lng = selectedLocationCoord.longitude;
    
    NSString *strLatSelected =  [[NSNumber numberWithDouble:lat] stringValue];
    NSString *strLngSelected =  [[NSNumber numberWithDouble:lng] stringValue];
    
    strLatA = strLatSelected;
    strLngA = strLngSelected;
    
   // [locManagerCurrent stopUpdatingLocation];
    locManagerCurrent = nil;
    
    [self zoomInToMyLocationCoord:selectedLocationCoord];
    
    /////------------
    
    isLocationAvailable = YES;
    
    //-------- get near by drivers after every 10 sec ------
    


    NSMutableArray *arrCord = [[NSMutableArray alloc] initWithObjects:strLatSelected,strLatSelected, nil];
    
 //   dispatch_async(dispatch_get_main_queue(), ^{
        
 //   });
    [self callAfterTwentySecond:arrCord];
    ///////----------
}

//---- zoom to coordinates -------
-(void)zoomInToMyLocationCoord:(CLLocationCoordinate2D )locations
{
    MKCoordinateRegion region = { {0.0, 0.0 }, { 0.0, 0.0 } };
    
    region.center.latitude = locations.latitude;
    region.center.longitude = locations.longitude;
    
    region.span.longitudeDelta = 0.02f;
    region.span.latitudeDelta = 0.02f;
    
    [_mapPassenger setRegion:region animated:YES];
}


#pragma mark getLatLong From address
-(CLLocationCoordinate2D )getAddressFromLatLng //: (NSString *)address
{
    CLLocationCoordinate2D coord1 ;
    return coord1;
}



- (IBAction)btnBookNearestTapped:(id)sender
{
    ConfirmationMapViewController *cmvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ConfirmationMapViewController"];
    //isBookingTypeNearest = YES;
    cmvc.dicDriverDetails = dicSelectedDriver;
   // cmvc.strTypeBooking = @"perticular";

    cmvc.strTypeBooking = @"nearest";
    cmvc.strVTid = strVehicleID;
     cmvc.strSource = [NSString stringWithFormat:@"%@",_lblSelectedLocation.text];
    
    
    [HUD show:YES];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        
        [HUD hide:YES];
        [self.navigationController pushViewController:cmvc animated:YES];
    });
    
    
    
}



-(void)callLogoutAPI
{
    
//    //http://dev12.edreamz3.com/api/driver.php/logoutschedule/?id=3&did=3
//    
//    //Note use id – as driverloginid output from login API
//    
//    NSDictionary * dicUserData = [[NSUserDefaults standardUserDefaults] dictionaryForKey:@"dicUserData"];
//    NSString * strDid = [[[dicUserData valueForKey:@"items"] objectAtIndex:0]valueForKey:@"id"];
//    
//    NSDictionary * param=@{@"id":strDid,
//                           @"did":strDid}; //////------ change to driver id
//    
//    [[webManager sharedObject] loginRequest:param withMethod:@"driver.php/logoutschedule/?" successResponce:^(id response)
//     {
//         NSLog(@"Responce : %@",response);
//         
//         NSError *e = nil;
//         
//         NSString *strStatus = [[response valueForKey:@"status"] stringValue];
//         
//         if([strStatus isEqualToString:@"1"])
//         {
             //[self.navigationController popViewControllerAnimated:YES];
             //appDelegate
    
    appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setValue:@"NO" forKey:@"login"];
    
    SignInViewController * main = [self.storyboard instantiateViewControllerWithIdentifier:@"SignInViewController"];
    
    UINavigationController *nav=[[UINavigationController alloc]initWithRootViewController:main];
    
    
    [appDelegate.window setRootViewController:nav];
    [appDelegate.window makeKeyAndVisible];
    
  
    
//         }
//         else if ([strStatus isEqualToString:@"0"])
//         {
//             
//         }
//         
//     }failure:^(NSError *error)
//     {
//         
//     }];
    
}


-(IBAction)btnShare:(id)sender
{
    NSString *text = @"I am using Destarny TaxiApp";
    
  //  NSURL *url = [NSURL URLWithString:@"http://www.ezygo.co.nz/"];
    // UIImage *image = [UIImage imageNamed:@"roadfire-icon-square-200"];
    
    UIActivityViewController *controller =[[UIActivityViewController alloc] initWithActivityItems:@[text] applicationActivities:nil];
    
    controller.excludedActivityTypes = @[UIActivityTypePostToWeibo,
                                         UIActivityTypePrint,
                                         UIActivityTypeCopyToPasteboard,
                                         UIActivityTypeAssignToContact,
                                         UIActivityTypeSaveToCameraRoll,
                                         UIActivityTypeAddToReadingList,
                                         UIActivityTypePostToFlickr,
                                         UIActivityTypePostToVimeo,
                                         UIActivityTypePostToTencentWeibo,
                                         UIActivityTypeAirDrop];
    
    [self presentViewController:controller animated:YES completion:nil];
    
    [controller setCompletionHandler:^(NSString *activityType, BOOL completed)
     {
         NSLog(@"completed");
         [[SlideNavigationController sharedInstance]popViewControllerAnimated:YES];
     }];

}

-(IBAction)btnHelp:(id)sender
{
    ContactVC *cvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ContactVC"];
    //[self.navigationController presentViewController:cvc animated:YES completion:nil];
    cvc.strType = [NSString stringWithFormat:@"Help"];
    [self.navigationController pushViewController:cvc animated:YES];
}











@end
