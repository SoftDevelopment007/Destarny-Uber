//
//  LeftMenu_TableViewCell.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/27/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import "LeftMenu_TableViewCell.h"

@implementation LeftMenu_TableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
