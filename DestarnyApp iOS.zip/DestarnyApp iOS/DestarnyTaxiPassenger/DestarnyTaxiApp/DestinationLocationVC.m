//
//  DestinationLocationVC.m
//  DestarnyTaxiApp
//
//  Created by edreamz on 3/1/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "DestinationLocationVC.h"
#import "Utilits.h"
#import "AppDelegate.h"
#import "ServiceHelper.h"
#import "DestinationCell.h"

@interface DestinationLocationVC ()
{
    NSString *strDestination;
    CLLocationManager *locationManager;
    double CurrentLatitude;
    double CurrentLongitude;
}

@property (nonatomic, retain)NSMutableArray *mArrayLocation;

@end

@implementation DestinationLocationVC
@synthesize delegateDestination;


- (void)viewDidLoad {
    [super viewDidLoad];
    _viewSearchLoc2.layer.cornerRadius = 5;
    _viewSearchLoc2.clipsToBounds = YES;
}

-(void)viewDidAppear:(BOOL)animated
{
    [_txtDest becomeFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [delegateDestination sendDataToA:strDestination];
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (IBAction)TxtDidChange:(id)sender
{
    if ([Utilits Trim:_txtDest.text].length>0)
    {
        [self getLocation];
    }
    else if([_txtDest.text length]==0)
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            self.mArrayLocation=nil;
            [self.tblDestination reloadData];
        });
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^{
       
        
        [self.mArrayLocation removeAllObjects];
        [self.tblDestination reloadData];
             });
    }
}

- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)getLocation
{
    [self getCurrentLocation];
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    //    NSString *endPoint = [[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&lat=%@&longi=%@&radius=%@&sensor=true&key=AIzaSyDJcG4Lnyda7EWbJGmTVgHSsLXVs58jUpU",self.txtSearch.text, [NSString stringWithFormat:@"%.6f", delegate.usercurrentlocation.coordinate.latitude], [NSString stringWithFormat:@"%.6f", delegate.usercurrentlocation.coordinate.longitude],@"5000"]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSString *endPoint = [[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&lat=%f&longi=%f&radius=%@&sensor=true&key=AIzaSyC6SPQpZxZ_JGnUZNd8AKGeBOR8UkXHJtw",self.txtDest.text,CurrentLatitude,CurrentLongitude,@"5000"]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    //    NSLog(@"%@ %@",[NSString stringWithFormat:@"%.6f", delegate.usercurrentlocation.coordinate.latitude], [NSString stringWithFormat:@"%.6f", delegate.usercurrentlocation.coordinate.longitude]);
    
    [ServiceHelper getResponseWithEndPoint:endPoint success:^(id response)
     {
         if (response)
         {
             dispatch_async(dispatch_get_main_queue(), ^{
                 self.mArrayLocation = [[[response valueForKey:@"predictions"] valueForKey:@"description"]mutableCopy];
                 [self.tblDestination reloadData];
             });
                 
         }
     } error:^(NSError *error) {
         
     }];
    
    NSLog(@"mArrayLocation = %@",_mArrayLocation);
}

-(void)getCurrentLocation
{
    //current location latitude and longitude...
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    if ([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)])
    {
        [locationManager requestWhenInUseAuthorization];
    }
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    [locationManager startUpdatingLocation];
    CurrentLatitude = locationManager.location.coordinate.latitude;
    CurrentLongitude = locationManager.location.coordinate.longitude;
    NSLog(@" current location lat = %f & long = %f ",CurrentLatitude,CurrentLongitude);
}

#pragma table view methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _mArrayLocation.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"cell";
    DestinationCell *cell = [_tblDestination dequeueReusableCellWithIdentifier:MyIdentifier];
    if (cell == nil)
    {
        cell = [[DestinationCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
    }
    cell.lblLocation.text = [_mArrayLocation objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _txtDest.text = [_mArrayLocation objectAtIndex:indexPath.row];
    strDestination = _txtDest.text;
    [self.navigationController popViewControllerAnimated:YES];
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
    return YES;
}



@end
