//
//  BillingInfoViewCotroller.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BillingInfoViewCotroller : UIViewController<UITextFieldDelegate>
{
    IBOutlet UITableView *tableCard;
    IBOutlet UIView *addCardView, *viewPaymentMethod;
    IBOutlet UIImageView *imgCard, *imgCash;
    NSString *strSETPAYID;
    NSString *strType;
}
- (IBAction)btnBackTapped:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *txtCardNo;
@property (weak, nonatomic) IBOutlet UITextField *txtCVN;
@property (weak, nonatomic) IBOutlet UITextField *txtMonth;
@property (weak, nonatomic) IBOutlet UITextField *txtYear;
@property (weak, nonatomic) IBOutlet UIButton *btnCancel;
@property (weak, nonatomic) IBOutlet UIButton *btnSubmit;
@property (weak, nonatomic) IBOutlet UIButton *btnDone;
@property (weak, nonatomic) IBOutlet UIButton *btnCard;
@property (weak, nonatomic) IBOutlet UIButton *btnCash;
@property (weak, nonatomic) IBOutlet UILabel *lblAlert;
@end
