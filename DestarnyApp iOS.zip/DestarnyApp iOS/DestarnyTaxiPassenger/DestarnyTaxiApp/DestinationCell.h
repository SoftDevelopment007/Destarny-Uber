//
//  DestinationCell.h
//  DestarnyTaxiApp
//
//  Created by edreamz on 3/1/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DestinationCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIView *viewDestCell;
@property (weak, nonatomic) IBOutlet UILabel *lblLocation;

@end
