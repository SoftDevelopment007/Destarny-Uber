//
//  ConfirmationMapViewController.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/16/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "ConfirmationMapViewController.h"
#import "DrawRoute.h"
#import "ConfirmationStartVC.h"
#import "webManager.h"
#import "DestinationLocationVC.h"
#import "BillingInfoViewCotroller.h"
#import "MBProgressHUD.h"
#import "ALToastView.h"

@interface ConfirmationMapViewController ()
{
    CLLocationCoordinate2D coordSource;
    CLLocationCoordinate2D coordDest;
    NSString *strStartLat,*strStartLng,*strDestLat,*strDestLng,*vtid;
    NSString *strED;
    NSString *strET;
    double res, resDist, resTime;
    NSMutableArray *arrDriverDetails,*arrVan,*arrStandard,*arrPremium,*arrPricePerKM,*arrPricePerMin;
    MBProgressHUD *HUD;
    NSString *estPremium, *estTaxi, *estPrivate;
    NSString *strVehicleImage;
    NSMutableArray *arrAnnotationImg;
    NSString *strFareToSend, *strEDToSend, *strETToSend;
    
    NSMutableArray *arrTaxiList;
    NSArray *arrAllDrivers;
    
}
@end

@implementation ConfirmationMapViewController
@synthesize dicDriverDetails,strVTid,strTypeBooking;

- (void)viewDidLoad
{
    [super viewDidLoad];
}

-(void)gestureHandlerMethod:(UITapGestureRecognizer*)sender
{
    viewDriverInfo.hidden = YES;
    viewBookVehicle.hidden = YES;
    [_txtFare resignFirstResponder];
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    
}
-(void)viewDidDisappear:(BOOL)animated
{
    
  //  [self.mapViewRoute removeAnnotations:self.mapViewRoute.annotations];
    
   // [[self.mapViewRoute viewForAnnotation:self.mapViewRoute.annotations.lastObject] setHidden:YES];
//    NSMutableArray * annotationsToRemove = [_mapViewRoute.annotations mutableCopy];
//    [self.mapViewRoute removeAnnotations:annotationsToRemove];
//    [_mapViewRoute removeAnnotation:annotation];
}

-(void)viewWillDisappear:(BOOL)animated
{
  //  NSMutableArray * annotationsToRemove = [_mapViewRoute.annotations mutableCopy];
//    [annotationsToRemove removeObject:_mapViewRoute.userLocation];
//    [_mapViewRoute removeAnnotations:annotationsToRemove];
  //  [self.mapViewRoute removeAnnotation:annotationsToRemove.lastObject];
}
-(void)viewWillAppear:(BOOL)animated
{
    updateAnnotation = YES;
    taxiAnnotation = YES;
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    HUD.labelText = @"Loading";
    [self.view addSubview:HUD];
    
    
    arrDriverLatLong = [[NSMutableArray alloc] init];
    arrDriverDetails = [[NSMutableArray alloc] init];
    arrPremium = [[NSMutableArray alloc] init];
    arrStandard = [[NSMutableArray alloc] init];
    arrVan = [[NSMutableArray alloc] init];
    arrPricePerKM = [[NSMutableArray alloc] init];
    arrPricePerMin = [[NSMutableArray alloc] init];
    _btnBookTaxi.layer.cornerRadius = 5;
    viewDriverInfo.layer.borderColor = [UIColor blackColor].CGColor;
    viewDriverInfo.layer.borderWidth = 0.5;
    _btnBook.layer.cornerRadius = _btnCancel.layer.cornerRadius = viewBookVehicle.layer.cornerRadius = viewSetFare.layer.cornerRadius = _btnFare.layer.cornerRadius = 2.0;
    viewSetFare.layer.borderColor = [UIColor blackColor].CGColor;
    viewSetFare.layer.borderWidth = 0.5;
    viewBookVehicle.layer.borderColor = [UIColor blackColor].CGColor;
    viewBookVehicle.layer.borderWidth = 0.5;
    viewBookVehicle.hidden = YES;
    _txtStartSearch.layer.borderColor = [UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:0.5].CGColor;
    _txtDestAddress.layer.borderColor = [UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:0.5].CGColor;
    _txtDestAddress.layer.cornerRadius = 5;
    _txtDestAddress.clipsToBounds = YES;
    _txtStartSearch.layer.cornerRadius = 5;
    _txtStartSearch.clipsToBounds = YES;
    _txtStartSearch.layer.borderColor = [UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:0.5].CGColor;
    _txtDestAddress.layer.borderColor = [UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:0.5].CGColor;
    _txtStartSearch.text = [NSString stringWithFormat:@"%@",_strSource];
    
      [self setLocation];
    if ([_txtStartSearch.text length]>0)
    {
        _btnFromLoc.enabled = NO;
        _txtStartSearch.enabled = NO;
    }
  
    
    //[_txtStartSearch setValue:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:0.5] forKeyPath:@"_placeholderLabel.textColor"];
    
    [_txtStartSearch setValue:[UIColor darkGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    
    _txtStartSearch.layer.sublayerTransform = CATransform3DMakeTranslation(15, 0, 0);
    
    //[_txtDestAddress setValue:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:0.5] forKeyPath:@"_placeholderLabel.textColor"];
    
    
    [_txtDestAddress setValue:[UIColor darkGrayColor] forKeyPath:@"_placeholderLabel.textColor"];

    
    _txtDestAddress.layer.sublayerTransform = CATransform3DMakeTranslation(15, 0, 0);
    
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gestureHandlerMethod:)];
    [_mapViewRoute addGestureRecognizer:tapRecognizer];
    
    
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults]valueForKey:@"dicPassengerDetails"];//pay_method" = Cash
    
  //  NSString *strPayment = [NSString stringWithFormat:@"%@",[dict valueForKey:@"pay_method"]];
    
    NSString *strPayment = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentType"]];
    
    if ([strPayment isEqualToString:@"Cash"])
    {
        [imgCard setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
        [imgCash setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
        [_btnCard setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
        [_btnCash setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    else
    {
        [imgCash setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
        [imgCard setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
        [_btnCash setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
        [_btnCard setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }

    
//    [self setLocation];
//    _strSetCredit = [[NSUserDefaults standardUserDefaults] valueForKey:@"TypeCredit"];
//  
//    if ([_strSetCredit isEqualToString:@"NO"]||[_strSetCredit length]==0)
//    {
//       
//    }
//    else
//    {
//        [imgCash setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
//        [imgCard setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
//        
//        [_btnCash setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
//        
//        [_btnCard setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//        NSString *strType = [NSString stringWithFormat:@"CreditCard"];
//        [self updatePaymentType:strType];
//    }

   
   
    if([strTypeBooking isEqualToString:@"perticular"])// @"nearest"; //strTypeBooking = @"perticular";
    {
        
    }
    else
    {
        
    }
    
    NSString *strSourceAdd = _txtStartSearch.text;
    NSString *strDestAdd = _txtDestAddress.text;
    
    
    if([_txtDestAddress.text isEqualToString:@""] || strDestAdd == nil)
    {
        NSLog(@"addesses ");
        coordSource.latitude = 0;
        coordSource.longitude = 0;
        
        coordDest.latitude = 0;
        coordDest.longitude = 0;
        
        coordSource = [self getLatLongFromAddress:strSourceAdd];
        
        double lat1 = coordSource.latitude;
        double lng1 = coordSource.longitude;
        
        CLLocationCoordinate2D  ctrpoint;
        ctrpoint.latitude = lat1;
        ctrpoint.longitude =lng1;
       
        
        
        double lat2 = coordDest.latitude;
        double lng2 = coordDest.longitude;
        
        strStartLat = [[NSNumber numberWithDouble:lat1] stringValue];
        strStartLng = [[NSNumber numberWithDouble:lng1] stringValue];
        strDestLat = [[NSNumber numberWithDouble:lat2] stringValue];
        strDestLng = [[NSNumber numberWithDouble:lng2] stringValue];
        
        [self showUserLocation:_strSource];
        
        
        
     //   [_mapViewRoute addAnnotation:annotation];
        [self showDrivers];

    }
    else if ([_txtStartSearch.text length]>0 && [_txtDestAddress.text length]>0)
    {
        [self showUserLocation:_strSource];
        coordSource.latitude = 0;
        coordSource.longitude = 0;
        
        coordDest.latitude = 0;
        coordDest.longitude = 0;
        
        coordSource = [self getLatLongFromAddress:strSourceAdd];
        coordDest = [self getLatLongFromAddress:strDestAdd];
        
      //  coordSource = [self getLatLongFromAddress:strSourceAdd];
        
        double lat1 = coordSource.latitude;
        double lng1 = coordSource.longitude;
        
        CLLocationCoordinate2D  ctrpoint;
        ctrpoint.latitude = lat1;
        ctrpoint.longitude =lng1;
        
        
        
        double lat2 = coordDest.latitude;
        double lng2 = coordDest.longitude;
        
        strStartLat = [[NSNumber numberWithDouble:lat1] stringValue];
        strStartLng = [[NSNumber numberWithDouble:lng1] stringValue];
        strDestLat = [[NSNumber numberWithDouble:lat2] stringValue];
        strDestLng = [[NSNumber numberWithDouble:lng2] stringValue];
      
        [self getDistance];
        
        [self showDestinationLocation:_txtDestAddress.text];
      //  [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(dest) userInfo:nil repeats:NO];
        
       
        
        
        
        //   [_mapViewRoute addAnnotation:annotation];
        
        [self.mapViewRoute setShowsUserLocation:YES];

        
        [self.mapViewRoute removeOverlays:self.mapViewRoute.overlays];
        
        [self showDrivers];
        ////-----------------------
        
        [self drawRouteBetweenPath];

        
    //    [self showDrivers];

    }
    
    else
    {
        [self.mapViewRoute removeOverlays:self.mapViewRoute.overlays];
        
        coordSource.latitude = 0;
        coordSource.longitude = 0;
        
        coordDest.latitude = 0;
        coordDest.longitude = 0;
        
        coordSource = [self getLatLongFromAddress:strSourceAdd];
        coordDest = [self getLatLongFromAddress:strDestAdd];
        
        double lat1 = coordSource.latitude;
        double lng1 = coordSource.longitude;
        
        double lat2 = coordDest.latitude;
        double lng2 = coordDest.longitude;
        
        strStartLat = [[NSNumber numberWithDouble:lat1] stringValue];
        strStartLng = [[NSNumber numberWithDouble:lng1] stringValue];
        strDestLat = [[NSNumber numberWithDouble:lat2] stringValue];
        strDestLng = [[NSNumber numberWithDouble:lng2] stringValue];
        [self showDrivers];
        ////-----------------------
        [self drawRouteBetweenPath];
    }
    
    
    [self.mapViewRoute setShowsUserLocation:YES];

}
-(void)dest
{
    [self showDestinationLocation:_txtDestAddress.text];
}
-(void)setLocation
{
    strAddressType = [NSString stringWithFormat:@"Source"];
    NSString *location = _strSource;
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder geocodeAddressString:location
                 completionHandler:^(NSArray* placemarks, NSError* error){
                     if (placemarks && placemarks.count > 0) {
                         CLPlacemark *topResult = [placemarks objectAtIndex:0];
                         MKPlacemark *placemark = [[MKPlacemark alloc] initWithPlacemark:topResult];
                         
                         MKCoordinateRegion region = self.mapViewRoute.region;
                         region.center = placemark.region.center;
                         region.span.longitudeDelta = 0.035;
                         region.span.latitudeDelta = 0.035;
                         
                         [self.mapViewRoute setRegion:region animated:YES];
                         // [self.mapViewRoute addAnnotation:placemark];
                         // strAddressType = [NSString stringWithFormat:@""];
                     }
                 }
     ];
    [NSThread sleepForTimeInterval:1.0];
}
-(void)changeText:(id)notification
{
    NSNotification *noti =(NSNotification*)notification;
    NSString *receivedString= noti.object;
    NSLog(@"string is :: %@",receivedString);
    _txtStartSearch.text = receivedString;
    _txtStartSearch.text = [NSString stringWithFormat:@"  %@",receivedString];
}

-(void)drawRouteBetweenPath
{
    double sourceLat = coordSource.latitude;
    double sourceLng = coordSource.longitude;
    
    double destLat = coordDest.latitude;
    double destLng = coordDest.longitude;
    
    DrawRoute * dr =[[DrawRoute alloc]init];
//    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/directions/json?origin=18.4745254,73.82095359999994&destination=18.4884,73.8279&key=AIzaSyC6SPQpZxZ_JGnUZNd8AKGeBOR8UkXHJtw"]];
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/directions/json?origin=%f,%f&destination=%f,%f&key=AIzaSyC6SPQpZxZ_JGnUZNd8AKGeBOR8UkXHJtw",sourceLat,sourceLng,destLat,destLng]];
    
    NSData *data = [ NSData dataWithContentsOfURL:url];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    NSMutableArray * paths = [dr parseResponse:dic];
    CLLocationCoordinate2D coordinates[paths.count];
    for (NSInteger index = 0; index < paths.count; index++)
    {
        CLLocation *location = [paths objectAtIndex:index];
        CLLocationCoordinate2D coordinate = location.coordinate;
        coordinates[index] = coordinate;
    }
    MKPolyline *polyLine = [MKPolyline polylineWithCoordinates:coordinates count:paths.count];
    [self.mapViewRoute addOverlay:polyLine];
    
    [self zoomInToMyLocationCoord:coordSource];
}

-(MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id<MKOverlay>)overlay
{
    MKPolylineView *polylineView = [[MKPolylineView alloc] initWithPolyline:overlay];
    polylineView.strokeColor = [UIColor blueColor];
    polylineView.lineWidth = 5.0;
    return polylineView;
}

//---- zoom to coordinates -------
-(void)zoomInToMyLocationCoord:(CLLocationCoordinate2D )locations
{
    MKCoordinateRegion region = { {0.0, 0.0 }, { 0.0, 0.0 } };
    region.center.latitude = locations.latitude;
    region.center.longitude = locations.longitude;
    region.span.longitudeDelta = 0.035f;
    region.span.latitudeDelta = 0.035f;
    [_mapViewRoute setRegion:region animated:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)btnFareEstimateTapped:(id)sender
{
}

- (IBAction)btnPaymentMethodTapped:(id)sender
{
    
}



#pragma mark BTN TAXI BOOK
- (IBAction)btnBookTaxiTapped
{
//    _btnTaxiMeter.frame = CGRectMake(0, 0, 0, 0);
//    imgTaximeter.frame = CGRectMake(0, 0, 0, 0);
//    _btnTaxiMeter.frame = CGRectMake(0, 0, 0, 0);
//    imgTaximeter.frame = CGRectMake(0, 0, 0, 0);
//    _btnTaxiMeter.frame = CGRectMake(0, 0, 0, 0);
//    imgTaximeter.frame = CGRectMake(0, 0, 0, 0);
    //nearest
    [self btnToNormalState];
    
    if([_txtDestAddress.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Please enter the destination location."];
//        [[[UIAlertView alloc] initWithTitle:nil message:@"Please enter the destination location." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }
    else
    {
       // [self costCalculationForNearest];
        [self costCalculation];
        
        imgTaximeter.hidden = NO;
        _btnTaxiMeter.hidden = NO;
        imgPremium.hidden = NO;
        _btnPremium.hidden = NO;
        
        viewBookVehicle.hidden = NO;
        strBookingType = [NSString stringWithFormat:@"Nearest"];
     //   NSString *vtype = [NSString stringWithFormat:@"%@",[dicSelectedDriver valueForKey:@"vtype"]];
        NSString *vtype = _strVtype;
        CGFloat width = self.view.frame.size.width;
        if ([vtype isEqualToString:@"Standard"])
        {
            vtype = @"Taxi";
        }
        if ([vtype isEqualToString:@"Taxi"])
        {
            if (width ==320)
            {
                _btnTaxiMeter.frame = CGRectMake(27, 110, viewBookVehicle.frame.size.width-40, 20);
                imgTaximeter.frame = CGRectMake(8, 105, 12, 12);
            }
            else if (width == 375)
            {
                _btnTaxiMeter.frame = CGRectMake(27, 135, viewBookVehicle.frame.size.width-40, 20);
                imgTaximeter.frame = CGRectMake(8, 138, 12, 12);
            }
            else if (width == 414)
            {
                _btnTaxiMeter.frame = CGRectMake(27, 152, viewBookVehicle.frame.size.width-40, 20);
                imgTaximeter.frame = CGRectMake(8, 155, 12, 12);
            }
            imgTaxi.image = [UIImage imageNamed:@"Taxi"];
            
            imgTaximeter.hidden = NO;
            _btnTaxiMeter.hidden = NO;
            imgPremium.hidden = YES;
            _btnPremium.hidden = YES;
        }

        else //if ([vtype isEqualToString:@"Premium"])
        {
            if (width ==320)
            {
                _btnPremium.frame = CGRectMake(27, 130, viewBookVehicle.frame.size.width-40, 20);
                imgPremium.frame = CGRectMake(8, 135, 12, 12);
                
                _btnTaxiMeter.frame = CGRectMake(27, 112, viewBookVehicle.frame.size.width-40, 20);
                imgTaximeter.frame = CGRectMake(8, 116, 12, 12);
            }
            else if (width == 375)
            {
                _btnPremium.frame = CGRectMake(27, 155, viewBookVehicle.frame.size.width-40, 20);
                imgPremium.frame = CGRectMake(8, 158, 12, 12);
                
                _btnTaxiMeter.frame = CGRectMake(27, 135, viewBookVehicle.frame.size.width-40, 20);
                imgTaximeter.frame = CGRectMake(8, 138, 12, 12);
            }
            else if (width == 414)
            {
                _btnPremium.frame = CGRectMake(27, 172, viewBookVehicle.frame.size.width-40, 20);
                imgPremium.frame = CGRectMake(8, 175, 12, 12);
                
                _btnTaxiMeter.frame = CGRectMake(27, 152, viewBookVehicle.frame.size.width-40, 20);
                imgTaximeter.frame = CGRectMake(8, 155, 12, 12);
            }
        }
        
        float estTaxi1=[estTaxi floatValue]*20/100;
        estTaxi1=estTaxi1+[estTaxi floatValue];
        
        NSString *strTaxi = [NSString stringWithFormat:@"Taxi (Est: $%@ to $%.2f)",estTaxi,estTaxi1];
        float estPremium1=[estPremium floatValue]*20/100;
        estPremium1=estPremium1+[estPremium floatValue];
        
        NSString *strPremium = [NSString stringWithFormat:@"Premium (Est: $%@ to $%.2f)",estPremium,estPremium1];
        float estPrivate1=[estPrivate floatValue]*20/100;
        estPrivate1=estPrivate1+[estPrivate floatValue];
        NSString *strPrivate = [NSString stringWithFormat:@"Destarny x1.0 (Est: $%@ to $%.2f)",estPrivate,estPrivate1];
        [_btnDestarnyRate setTitle:strPrivate forState:UIControlStateNormal];
        [_btnSetFare setTitle:@"Set Fare (Agreed amount)" forState:UIControlStateNormal];
        [_btnTaxiMeter setTitle:strTaxi forState:UIControlStateNormal];
        [_btnPremium setTitle:strPremium forState:UIControlStateNormal];
        
//        NSString *strTitle = [NSString stringWithFormat:@"Destarny Rate (Est. $%0.2f)",res];
//        [_btnDestarnyRate setTitle:strTitle forState:UIControlStateNormal];
//        [_btnSetFare setTitle:@"Set Fare (Agreed amount)" forState:UIControlStateNormal];
//        [_btnTaxiMeter setTitle:@"Taximeter (Standard Taximeter)" forState:UIControlStateNormal];
    }
    
 //   [self orderTaxi:strBookingType:strFareType];
}
-(void)orderTaxi:(NSString *)bookingType :(NSString *)fareType
{
    
    
    if([bookingType isEqualToString:@"Particular"]) // call perticular taxi API //
        {
            //-----
            [HUD show:YES];
            NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd"];
            
            //[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            
            NSDateFormatter *time = [[NSDateFormatter alloc] init];
            [time setDateFormat:@"HH:mm:ss"];
            
            // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
            NSLog(@"%@  and   %@",[dateFormatter stringFromDate:[NSDate date]],[time stringFromDate:[NSDate date]]);
            
            NSString *strDate = [dateFormatter stringFromDate:[NSDate date]];
            NSString *strTime = [time stringFromDate:[NSDate date]];
            
            //-----
            
            NSString *savedValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
            
          //  NSString *strDid = [dicDriverDetails valueForKey:@"id"];
            NSString *strDid = [dicSelectedDriver valueForKey:@"id"];
            
          //  NSString *strVtype = [dicDriverDetails valueForKey:@"vtype"];
            NSString *strVtype = [dicSelectedDriver valueForKey:@"vtype"];
            if([strVtype isEqualToString:@"Taxi"])
            {
                vtid = @"2";
            }
            else if([strVtype isEqualToString:@"Private"])
            {
                vtid = @"3";
            }
            else if ([strVtype isEqualToString:@"Premium"])
            {
                vtid = @"1";
            }
            
 
            
//        http://dev12.edreamz3.com/api/passenger.php/addbooking/?cid=1&vtid=1&booking_type=Current/Advance&fare_type=DestarnyRate&setfare_unfullfilled=0&booking_from_lat=111&booking_from_lng=222&booking_from=Pune&booking_to_lat=333&booking_to_lng=444&booking_to=katraj&noofpass=3&booking_time=10:20:30&booking_date=2016-03-20&notes=Helo&fareid=0
            
//  http://destarny.com/api/passenger.php/addbooking/?cid=1&booking_type=Current/Advance&fare_type=Taximeter/SetFare/DestarnyRate/Premium&setfare_unfullfilled=1/0&booking_from_lat=111&booking_from_lng=222&booking_from=Pune&booking_to_lat=333&booking_to_lng=444&booking_to=katraj&noofpass=3&booking_time=10:20:30&booking_date=2016-03-20&notes=Helo&fareid=1

  //  http://destarny.com/api/passenger.php/addbookingfordriver/?cid=1&booking_type=Current/Advance&fare_type=Taximeter/Setfare/Destarnyrate/Premium&setfare_unfullfilled=1/0&booking_from_lat=111&booking_from_lng=222&booking_from=Pune&booking_to_lat=333&booking_to_lng=444&booking_to=katraj&noofpass=3&booking_time=10:20:30&booking_date=2016-03-20&notes=Helo&fareid=1&did=1
            
     
            //      booking_type=Current&fare_type=Taximeter/SetFare/DestarnyRate/Premium
            
            NSString *strFareID;
            if ([strFareType isEqualToString:@"Setfare"])
            {
                strFareID = [NSString stringWithFormat:@"%@",strSetFare];
                strFareToSend = [NSString stringWithFormat:@"%@",estPrivate];
            }
            else
            {
                strFareID = [NSString stringWithFormat:@"0"];
            }

            
            
            NSDictionary * param=@{@"cid":savedValue,
                                   @"booking_type":@"Current",
                                   @"fare_type":strFareType,
                                   @"setfare_unfullfilled":@"0",
                                   @"booking_from_lat":strStartLat,
                                   @"booking_from_lng":strStartLng,
                                   @"booking_from":_txtStartSearch.text,
                                   @"booking_to_lat":strDestLat,
                                   @"booking_to_lng":strDestLng,
                                   @"booking_to":_txtDestAddress.text,
                                   @"noofpass":@"0",
                                   @"booking_time":strTime,
                                   @"booking_date":strDate,
                                   @"notes":@" ",
                                   @"fareid":strFareID,
                                   @"did":strDid,
                                   @"distance":strEDToSend,
                                   @"duration":strETToSend,
                                   @"calfare":strFareToSend
                                   };   //----- hard coded
            //@"did":strDid
            NSLog(@"%@",param);
            [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/addbookingfordriver/?" successResponce:^(id response)
             {
                 NSString *strStatus = [[response valueForKey:@"status"] stringValue];
                 [HUD hide:YES];
                 if([strStatus isEqualToString:@"1"])
                 {
                     //---
                     NSArray * response1 = [[NSArray alloc] init];
                     response1 = [response valueForKey:@"items"];
                     
                   //  [ALToastView toastInView:self.view withText:@""];
                     
                     // Show when booking a vehicle directly
                     UIAlertView *al = [[UIAlertView alloc] initWithTitle:nil message:@"Success! You will be notified when a driver accepts your request." delegate:self cancelButtonTitle:@"Thank you for riding with Destarny" otherButtonTitles:nil, nil];
                     
                     al.tag = 126;
                     
                     [al show];
                 }
                 else if([strStatus isEqualToString:@"0"])
                 {
                     NSString *strStatus = [response valueForKey:@"items"];
                     [ALToastView toastInView:self.view withText:strStatus];
//                     [[[UIAlertView alloc] initWithTitle:nil message:strStatus delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil]show];
                 }
             }failure:^(NSError *error)
             {
                 [HUD hide:YES];
                 NSLog(@"Error : %@",error);
             }];
        }
        else if([bookingType isEqualToString:@"Nearest"])// call nearest taxi API
        {
            //-----
            [HUD show:YES];
            NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd"];
            
            //[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            
            NSDateFormatter *time = [[NSDateFormatter alloc] init];
            [time setDateFormat:@"HH:mm:ss"];
            
            // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
            NSLog(@"%@  and   %@",[dateFormatter stringFromDate:[NSDate date]],[time stringFromDate:[NSDate date]]);
            
            NSString *strDate = [dateFormatter stringFromDate:[NSDate date]];
            NSString *strTime = [time stringFromDate:[NSDate date]];
            
            //-----
            
            NSString *savedValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
            
//            NSString *strDid = [dicDriverDetails valueForKey:@"id"];
//            
//            NSString *strVtype = [dicDriverDetails valueForKey:@"vtype"];
//            if([strVtype isEqualToString:@"Standard"])
//            {
//                vtid = @"2";
//            }
//            else if([strVtype isEqualToString:@"Van"])
//            {
//                vtid = @"3";
//            }
//            else if ([strVtype isEqualToString:@"Premium"])
//            {
//                vtid = @"1";
//            }
            
            
            NSString *strFareID;
            if ([strFareType isEqualToString:@"Setfare"])
            {
                strFareID = [NSString stringWithFormat:@"%@",strSetFare];
                strFareToSend = [NSString stringWithFormat:@"%@",estPrivate];
            }
            else
            {
                strFareID = [NSString stringWithFormat:@"0"];
            }
            
//            NSString *strFareID;
//            if ([strFareType isEqualToString:@"Setfare"])
//            {
//                strFareID = [NSString stringWithFormat:@"%@",strSetFare];
//            }
//            else
//            {
//                strFareID = [NSString stringWithFormat:@"0"];
//            }

           
            
//            NSLog(@"strEDToSend -----%@",strEDToSend);
//            NSLog(@"strETToSend-----%@",strETToSend);
//            NSLog(@"strFareToSend----%@",strFareToSend);
            
            
            NSDictionary * param=@{@"cid":savedValue,
                                   @"booking_type":@"Current",
                                   @"fare_type":strFareType,
                                   @"setfare_unfullfilled":@"0",
                                   @"booking_from_lat":strStartLat,
                                   @"booking_from_lng":strStartLng,
                                   @"booking_from":_txtStartSearch.text,
                                   @"booking_to_lat":strDestLat,
                                   @"booking_to_lng":strDestLng,
                                   @"booking_to":_txtDestAddress.text,
                                   @"noofpass":@"0",
                                   @"booking_time":strTime,
                                   @"booking_date":strDate,
                                   @"notes":@" ",
                                   @"fareid":strFareID,
                                   @"distance":strEDToSend,
                                   @"duration":strETToSend,
                                   @"calfare":strFareToSend};   //----- hard coded
            
            
            [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/addbooking/?" successResponce:^(id response)
             {
                 NSString *strStatus = [[response valueForKey:@"status"] stringValue];
                 [HUD hide:YES];
                 if([strStatus isEqualToString:@"1"])
                 {
                     //---
                     NSArray * response1 = [[NSArray alloc] init];
                     response1 = [response valueForKey:@"items"];
                     
                   //  [ALToastView toastInView:self.view withText:@""];
                     
                     // Set fare / destarny rate / taxi rate all via Book Nearest Vehicle
                     
                     UIAlertView *al = [[UIAlertView alloc] initWithTitle:nil message:@"Success! You will be notified when a driver accepts your request." delegate:self cancelButtonTitle:@"Thank you for riding with Destarny" otherButtonTitles:nil, nil];
                     
                     al.tag = 126;
                     
                     [al show];
                 }
                 else if([strStatus isEqualToString:@"0"])
                 {
                     NSString *strStatus = [response valueForKey:@"items"];
                     [ALToastView toastInView:self.view withText:strStatus];
//                     [[[UIAlertView alloc] initWithTitle:nil message:strStatus delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil]show];
                 }
             }failure:^(NSError *error)
             {
                 [HUD hide:YES];
                 NSLog(@"Error : %@",error);
             }];
        }
    

////------------------

}

- (IBAction)btnStartAddTapped:(id)sender
{
    ConfirmationStartVC * cvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ConfirmationStartVC"];
    [self.navigationController pushViewController:cvc animated:YES];
}

- (IBAction)btnDestAddTapped:(id)sender
{
    DestinationLocationVC *dest = [self.storyboard instantiateViewControllerWithIdentifier:@"DestinationLocationVC"];
    dest.delegateDestination = self;
    [self.navigationController pushViewController:dest animated:YES];
}

- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 4)
    {
        if(buttonIndex == 0)
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    else if (alertView.tag == 126)
    {
        if(buttonIndex == 0)
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}

#pragma deleagete method to receive data 
-(void)sendDataToA:(NSString *)Destination
{
    if([Destination isEqualToString:@""] || Destination == nil)
    {
        
    }
    else
    {
        NSLog(@"Destination = %@",Destination);
        _txtDestAddress.text = Destination;
        
        _txtDestAddress.text = [NSString stringWithFormat:@"%@",Destination];
        //[self MethodDrawRoute];
    }
}

#pragma mark getLatLong From address
-(CLLocationCoordinate2D )getLatLongFromAddress : (NSString *)address
{
  //   strAddressType = [NSString stringWithFormat:@""];
    
        NSString *urlSTR=[[NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?address=%@&sensor=false",address] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
 //   NSString *urlSTR=[[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/geocode/json?address=%@&sensor=true&key=AIzaSyDAgAd4dSAsdzKTdchuennLl9VDD-F_9_U",address] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
    
        NSURL *url = [NSURL URLWithString:urlSTR];
        
        NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
        NSURLResponse *responce;
        NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
        NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSArray * resultArray = [dictionary1 valueForKey:@"results"];
    CLLocationCoordinate2D coord;
    if (resultArray.count>0)
    {
        NSDictionary * dic = [resultArray objectAtIndex:0];
        NSDictionary * geo = [dic valueForKey:@"geometry"];
        NSDictionary * location = [geo valueForKey:@"location"];
        
        double lat = [[location valueForKey:@"lat"] doubleValue];
        double lng = [[location valueForKey:@"lng"] doubleValue];
        
        coord = CLLocationCoordinate2DMake(lat,lng);
    }
    else
    {
        coord.latitude = 0.0;
        coord.longitude = 0.0;
    }
    
    
       
        return coord;
    
    

    
    
    
}
-(CLLocationCoordinate2D )showUserLocation : (NSString *)userAddress
{
    //http://maps.google.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=false
    
  //   strAddressType = [NSString stringWithFormat:@"Source"];
    strAddressType = [NSString stringWithFormat:@"Source"];
    NSString *urlSTR=[[NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?address=%@&sensor=false",userAddress] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
    
    NSURL *url = [NSURL URLWithString:urlSTR];
    
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
    
    NSURLResponse *responce;
    NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
    NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSArray * resultArray = [dictionary1 valueForKey:@"results"];
    CLLocationCoordinate2D coord;
    if (resultArray.count>0)
    {
        NSDictionary * dic = [resultArray objectAtIndex:0];
        NSDictionary * geo = [dic valueForKey:@"geometry"];
        NSDictionary * location = [geo valueForKey:@"location"];
        
        double lat = [[location valueForKey:@"lat"] doubleValue];
        double lng = [[location valueForKey:@"lng"] doubleValue];
        
        CLLocationCoordinate2D zoomLocation;
        zoomLocation.latitude = lat;
        zoomLocation.longitude= lng;
        
        MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
        point.coordinate = zoomLocation;
        
     //   [self.mapViewRoute addAnnotation:point];
        
       
        sourceAnn = [[SourceAnnotation alloc] init];
        sourceAnn.coordinate = zoomLocation;
        sourceAnn.title = @"Source";
        flag = YES;
        [_mapViewRoute  removeAnnotation: sourceAnn];
        [_mapViewRoute addAnnotation: sourceAnn];
        
        coord = CLLocationCoordinate2DMake(lat,lng);
    }
        return coord;
}


-(CLLocationCoordinate2D )showDestinationLocation : (NSString *)destinationAddress
{
    //http://maps.google.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=false
    
    //   strAddressType = [NSString stringWithFormat:@"Source"];
    strAddressType = [NSString stringWithFormat:@"Destination"];
    NSString *urlSTR=[[NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?address=%@&sensor=false",destinationAddress] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
    
    NSURL *url = [NSURL URLWithString:urlSTR];
    
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
    
    NSURLResponse *responce;
    NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
    NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSArray * resultArray = [dictionary1 valueForKey:@"results"];
    NSDictionary * dic = [resultArray objectAtIndex:0];
    NSDictionary * geo = [dic valueForKey:@"geometry"];
    NSDictionary * location = [geo valueForKey:@"location"];
    
    double lat = [[location valueForKey:@"lat"] doubleValue];
    double lng = [[location valueForKey:@"lng"] doubleValue];
    
    CLLocationCoordinate2D zoomLocation;
    zoomLocation.latitude = lat;
    zoomLocation.longitude= lng;
    
    MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
    point.coordinate = zoomLocation;
    
 //   sourceAnn = [[SourceAnnotation alloc] init];
    sourceAnn.coordinate = zoomLocation;
    sourceAnn.title = @"Destination";
    flag = YES;
    [_mapViewRoute  removeAnnotation: sourceAnn];
    [_mapViewRoute addAnnotation: sourceAnn];
  //  [self.mapViewRoute addAnnotation:point];
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(lat,lng);
    
    return coord;
}


-(IBAction)btnETATapped:(id)sender
{
        NSString *strUrl = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/directions/json?origin=%@,%@&destination=%@,%@&sensor=false&mode=%@", getVLatValue,  getVLongValue, strStartLat,  strStartLng, @"DRIVING"];
        NSURL *url = [NSURL URLWithString:[strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        NSData *jsonData = [NSData dataWithContentsOfURL:url];
        if(jsonData != nil)
        {
            NSError *error = nil;
            id result = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
            NSMutableArray *arrDistance=[result objectForKey:@"routes"];
            if ([arrDistance count]==0) {
                NSLog(@"N.A.");
            }
            else{
                NSMutableArray *arrLeg=[[arrDistance objectAtIndex:0]objectForKey:@"legs"];
                NSMutableDictionary *dictleg=[arrLeg objectAtIndex:0];
                NSLog(@"%@",[NSString stringWithFormat:@"Estimated Time %@",[[dictleg   objectForKey:@"duration"] objectForKey:@"text"]]);
                NSString *strETA = [NSString stringWithFormat:@"Estimated Time %@",[[dictleg   objectForKey:@"duration"] objectForKey:@"text"]];
               
                
                [ALToastView toastInView:self.view withText:strETA];

            }
        }
        else
        {
            NSLog(@"N.A.");
        }
//    }
}
-(void)getDistance
{
    if ([_txtDestAddress.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Please select the destination."];
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please select the destination." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [alert show];
    }
    else
    {
        NSString *strUrl = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/directions/json?origin=%@,%@&destination=%@,%@&sensor=false&mode=%@",  strStartLat,  strStartLng,strDestLat,  strDestLng, @"DRIVING"];
        NSURL *url = [NSURL URLWithString:[strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        NSData *jsonData = [NSData dataWithContentsOfURL:url];
        if(jsonData != nil)
        {
            NSError *error = nil;
            id result = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
            NSMutableArray *arrDistance=[result objectForKey:@"routes"];
            if ([arrDistance count]==0) {
                NSLog(@"N.A.");
            }
            else{
                NSMutableArray *arrLeg=[[arrDistance objectAtIndex:0]objectForKey:@"legs"];
                NSMutableDictionary *dictleg=[arrLeg objectAtIndex:0];
                NSLog(@"%@",[NSString stringWithFormat:@"Estimated Time %@",[[dictleg   objectForKey:@"duration"] objectForKey:@"text"]]);
               strED = [NSString stringWithFormat:@"%@",[[dictleg   objectForKey:@"distance"] objectForKey:@"value"]];
               strEDToSend = [NSString stringWithFormat:@"%@",[[dictleg   objectForKey:@"distance"] objectForKey:@"text"]];
                
                
                
                strET = [NSString stringWithFormat:@"%@",[[dictleg   objectForKey:@"duration"] objectForKey:@"value"]];
                strETToSend = [NSString stringWithFormat:@"%@",[[dictleg   objectForKey:@"duration"] objectForKey:@"text"]];
                            }
        }
        else
        {
            NSLog(@"N.A.");
        }
    }
}

//show drivers

-(void)showDrivers
{
        NSDictionary * param=@{@"booking_from_lat":strStartLat,
                               @"booking_from_lng":strStartLng,
                               @"vtid":strVTid};   //----- hard coded
        
        //---  replace with new API
        
        //h ttp://dev12.edreamz3.com/api/passenger.php/getnearbydriversbtvtype/?booking_from_lat=18.478309&booking_from_lng=73.820923&vtid=2
        
        
        [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/getnearbydriversbtvtype/?" successResponce:^(id response)
         {
             NSString *strStatus = [[response valueForKey:@"status"] stringValue];
             
             
             if([strStatus isEqualToString:@"1"])
             {
                 //---
                 NSArray * response1 = [[NSArray alloc] init];
                 response1 = [response valueForKey:@"items"];
                 arrAllDrivers=[response valueForKey:@"items"];
                 arrDriverLatLong = response1;
                 
                 //[_mapPassenger viewForAnnotation:an];
                 arrAnnotationImg = [[NSMutableArray alloc] init];
                 NSMutableArray * annotationsToRemove = [_mapViewRoute.annotations mutableCopy ];
                 [annotationsToRemove removeObject:_mapViewRoute.userLocation];
                 
                 MKPointAnnotation *point;
                 for (NSDictionary * dic in response1)
                     
                 {
                     CustomAnnotation *custAnnotion=[[CustomAnnotation alloc]init];
                     
                     
                        NSString *strType = [NSString stringWithFormat:@"%@",[dic valueForKey:@"vtype"]];
                         if ([strType isEqualToString:@"Taxi"])
                         {
                             strVehicleImage = @"Car";
                             custAnnotion.title= @"Car";
                             
                         }
                         else if ([strType isEqualToString:@"Premium"])
                         {
                             strVehicleImage = @"PremiumCar";
                             custAnnotion.title= @"PremiumCar";
                         }
                         else if ([strType isEqualToString:@"Private"])
                         {
                             strVehicleImage = @"PrivateCar";
                             custAnnotion.title= @"PrivateCar";
                         }
                     
                     getVLatValue = [dic valueForKey:@"lat"];
                     getVLongValue = [dic valueForKey:@"lng"];
                     
                     CLLocationCoordinate2D zoomLocation;
                     zoomLocation.latitude = [getVLatValue doubleValue];
                     zoomLocation.longitude= [getVLongValue doubleValue];
                     
                     point = [[MKPointAnnotation alloc] init];
                     point.coordinate = zoomLocation;
                     strAddressType = [NSString stringWithFormat:@"Driver"];
                     sourceAnn.title = @"Driver";
                     flag = YES;
                     custAnnotion.coordinate=CLLocationCoordinate2DMake( zoomLocation.latitude, zoomLocation.longitude);
                     
                     [arrAnnotationImg addObject:custAnnotion];
                     
                 }
                 [self.mapViewRoute addAnnotations:arrAnnotationImg];
                // [self.mapViewRoute addAnnotations:arrAnnotationImages];
             }
        
             else if([strStatus isEqualToString:@"0"])
             {
             }
         }failure:^(NSError *error)
         {
             NSLog(@"Error : %@",error);
         }];
//    }
}

/*
 
 changes by sachin daingade
 
-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation
{
    //if (flag==YES) {
      
        flag=NO;
        MKPinAnnotationView *pinView;
    MKAnnotationView *pinViewCustom = nil;
    CustomAnnotation *abc=(CustomAnnotation *)annotation;
    static NSString *identifier = @"myPin";
    
    if ([sourceAnn.title isEqual:@"Driver"]  ){
        
        Annotation *ann = [[Annotation alloc] init];
        ann.title=@"1";
        
        //        if(annotation1 != _mapViewRoute.userLocation)
        //        {
        
        static NSString *defaultPinID = @"car_black";
        pinViewCustom = (MKAnnotationView *)[_mapViewRoute dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
        if (pinViewCustom == nil)
            pinViewCustom = [[MKAnnotationView alloc]
                             initWithAnnotation:annotation reuseIdentifier:defaultPinID];
        
        if (taxiAnnotation == NO)
        {
            taxiAnnotation = NO;
            return pinViewCustom;
        }
        else
        {
            pinViewCustom.canShowCallout = YES;
            pinViewCustom.image = [UIImage imageNamed:strVehicleImage];//@"car_black"];abc.title
            [pinViewCustom sizeToFit];
            return pinViewCustom;

        }
    }

    else{
        if (updateAnnotation == NO)
        {
            
        }
        else
        {
            if (pinView == nil) {
                pinView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
                if ([sourceAnn.title isEqual:@"Source"]) {
                    [pinView setPinColor:MKPinAnnotationColorGreen];
                    //strAddressType = @"";
                    //  pinView.enabled = NO;
                    return pinView;
                }
                else if ([sourceAnn.title isEqual:@"Destination"])
                {
                    updateAnnotation = NO;
                    
                    [pinView setPinColor:MKPinAnnotationColorRed];
                    // pinView.enabled = NO;
                    return pinView;
                }
            }
        }
    }
    //}
    
    return 0;

}
*/





-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 30;
}

-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation1
{
    static NSString *identifier = @"myPin";
    MKPinAnnotationView *pinView = nil;
    MKAnnotationView *pinViewCustom = nil;
    CustomAnnotation * abc=(CustomAnnotation * )annotation1;
    
    pinView = (MKPinAnnotationView *)[mV dequeueReusableAnnotationViewWithIdentifier:identifier];
    
    
    
    
    if (pinView == nil) {
        pinView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
        
        //        NSString thismodel = ((MyAnnotation ) annotationfortype).mName;
        //
        //        NSLog(@thismodel: %@", thismodel);
        
        
        UIButton* rightButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        [rightButton setTitle:annotation.title forState:UIControlStateNormal];
        [rightButton addTarget:self
                        action:@selector(showDetails:)
              forControlEvents:UIControlEventTouchUpInside];
        pinView.rightCalloutAccessoryView = rightButton;
        
        
        if ([strAddressType isEqualToString:@"Source"]) {
            [pinView setPinColor:MKPinAnnotationColorGreen];
            //strAddressType = @"";
            pinView.enabled = NO;
            
        }
        else if ([strAddressType isEqualToString:@"Destination"]){
            [pinView setPinColor:MKPinAnnotationColorRed];
            pinView.enabled = NO;
        }
        else if ([strAddressType isEqualToString:@"Driver"]){
            
            
            
            //    MKAnnotationView *pinView = nil;
            
            //                      static NSString *defaultPinID = @"car_black";
            //                      pinView = (MKAnnotationView *)[_mapViewRoute dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
            //
            //                      //[pinView setFrame:CGRectMake(0, 0, 20, 20)];
            //
            //                      if ( pinView == nil )
            //                          pinView = [[MKAnnotationView alloc]
            //                                     initWithAnnotation:annotation reuseIdentifier:defaultPinID];
            //
            //                      //pinView.pinColor = MKPinAnnotationColorGreen;
            //                      pinView.canShowCallout = YES;
            //                      //pinView.animatesDrop = YES;
            //
            //                      //abc.title
            //                      pinView.image = [UIImage imageNamed:abc.title];//@"car_black"];
            //
            //                      [pinView sizeToFit];
            //                      //i++;
            //
            //
            //                 // return pinView;
            
            
            
            if(annotation1 != _mapViewRoute.userLocation)
            {
                static NSString *defaultPinID = @"com.invasivecode.pin";
                pinViewCustom = (MKAnnotationView *)[_mapViewRoute dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
                
                //                      if (!pinViewCustom)
                //                      {
                if ( pinViewCustom == nil )
                    pinViewCustom = [[MKAnnotationView alloc]
                                     initWithAnnotation:annotation reuseIdentifier:defaultPinID];
                pinViewCustom.canShowCallout = YES;
                //   pinViewCustom.image = [UIImage imageNamed:@"Car"];
                //    pinViewCustom.image = [UIImage imageNamed:strVehicleImage];
                pinViewCustom.image = [UIImage imageNamed:abc.title];
                [pinViewCustom sizeToFit];
                
                pinViewCustom.calloutOffset = CGPointMake(0, 0);
                
                pinViewCustom.canShowCallout=NO;
                //   }
            }
            else
            {
            }
            return pinViewCustom;
            
        }
        
    }
    return pinView;
}


-(void)showDetails:(id)sender
{
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrTaxiList.count;    //count number of row from counting array hear cataGorry is An Array
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text=[NSString stringWithFormat:@"%@",[[arrTaxiList objectAtIndex:indexPath.row] valueForKey:@"vtype"]];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
}


-(void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    //-----
    strBookingType = [NSString stringWithFormat:@"Particular"];
    annotation=(MKPointAnnotation*)view.annotation;
    double latSel = annotation.coordinate.latitude;
    double lngSel = annotation.coordinate.longitude;
    
    NSString *strLat1 = [[NSNumber numberWithDouble:latSel] stringValue];
    NSString *strLng1 = [[NSNumber numberWithDouble:lngSel] stringValue];
    //-----
    
    NSString *strLat3=[NSString stringWithFormat:@"%.2f",latSel];
    NSString *strLng3=[NSString stringWithFormat:@"%.2f",lngSel];
    
    arrTaxiList =[[NSMutableArray alloc]init];
    
    for (int i=0; i<arrAllDrivers.count; i++)
    {
        NSString *strLat13=[NSString stringWithFormat:@"%.2f",[[[arrAllDrivers objectAtIndex:i] valueForKey:@"lat"] floatValue]];
        NSString *strLng13=[NSString stringWithFormat:@"%.2f",[[[arrAllDrivers objectAtIndex:i] valueForKey:@"lng"] floatValue]];
        
        if([strLat3 isEqualToString:strLat13] &&[strLng3 isEqualToString:strLng13])
        {
            NSMutableDictionary *mDict=[[NSMutableDictionary alloc]init];
            mDict=[[arrAllDrivers objectAtIndex:i] mutableCopy];
            [arrTaxiList addObject:mDict];
        }
    }
    
    
    
//    if(arrTaxiList.count>1 )
//    {
//        
//        [self.tblTaxiList reloadData];
//        _customListView.hidden=NO;
//
//        [self.view bringSubviewToFront:_customListView];
//        
//    }else
//    {
//        _customListView.hidden=YES;
    
    NSString * SelectedLat = [NSString stringWithFormat:@"%.06f", latSel];
    
    NSString *strLattitudeDriver = [[NSString alloc] init];
    
    //---
    
    for( int i = 0 ; i < arrDriverLatLong.count ; i++ )
    {
        strLattitudeDriver = [[arrDriverLatLong objectAtIndex:i] valueForKey:@"lat"];
        
        //--- driver lattitude into double ---
        
        double floatDriverLat = [strLattitudeDriver doubleValue];
        NSString *DriverLat = [NSString stringWithFormat:@"%.06f", floatDriverLat];
        
        //---------------
        
        if([DriverLat isEqualToString:SelectedLat])
        {
            dicSelectedDriver = [arrDriverLatLong objectAtIndex:i];
        }
    }
    
  
    [self costCalculation];
     viewDriverInfo.hidden = NO;
    if (dicSelectedDriver.count>0)
    {
        
    
    NSString *strFirstName = [NSString stringWithFormat:@"%@",[dicSelectedDriver valueForKey:@"fname"]];
    NSString *strLastName = [NSString stringWithFormat:@"%@",[dicSelectedDriver valueForKey:@"lname"]];
    NSString *vtype = [NSString stringWithFormat:@"%@",[dicSelectedDriver valueForKey:@"vtype"]];
    CGFloat width = self.view.frame.size.width;
    if ([vtype isEqualToString:@"Taxi"])
    {
        if (width ==320)
        {
            _btnTaxiMeter.frame = CGRectMake(27, 115, viewBookVehicle.frame.size.width-40, 20);
            imgTaximeter.frame = CGRectMake(8, 118, 12, 12);
        }
        else if (width == 375)
        {
            _btnTaxiMeter.frame = CGRectMake(27, 145, viewBookVehicle.frame.size.width-40, 20);
            imgTaximeter.frame = CGRectMake(8, 148, 12, 12);
        }
        else if (width == 414)
        {
            _btnTaxiMeter.frame = CGRectMake(27, 162, viewBookVehicle.frame.size.width-40, 20);
            imgTaximeter.frame = CGRectMake(8, 165, 12, 12);
        }
        imgTaxi.image = [UIImage imageNamed:@"Taxi"];
        
        imgTaximeter.hidden = NO;
        _btnTaxiMeter.hidden = NO;
        imgPremium.hidden = YES;
        _btnPremium.hidden = YES;
    }
    else if ([vtype isEqualToString:@"Private"])
    {
        if (width ==320)
        {
            _btnTaxiMeter.frame = CGRectMake(27, 113, viewBookVehicle.frame.size.width-40, 20);
            imgTaximeter.frame = CGRectMake(8, 116, 12, 12);
            _btnPremium.frame = CGRectMake(27, 132, viewBookVehicle.frame.size.width-40, 20);
            imgPremium.frame = CGRectMake(8, 135, 12, 12);

        }
        else if (width == 375)
        {
            _btnTaxiMeter.frame = CGRectMake(27, 135, viewBookVehicle.frame.size.width-40, 20);
            imgTaximeter.frame = CGRectMake(8, 138, 12, 12);
            _btnPremium.frame = CGRectMake(27, 157, viewBookVehicle.frame.size.width-40, 20);
            imgPremium.frame = CGRectMake(8, 160, 12, 12);

        }
        else if (width == 414)
        {
            _btnTaxiMeter.frame = CGRectMake(27, 150, viewBookVehicle.frame.size.width-40, 20);
            imgTaximeter.frame = CGRectMake(8, 153, 12, 12);
            _btnPremium.frame = CGRectMake(27, 174, viewBookVehicle.frame.size.width-40, 20);
            imgPremium.frame = CGRectMake(8, 177, 12, 12);

        }

            imgTaxi.image = [UIImage imageNamed:@"Private"];
      
        imgTaximeter.hidden = NO;
        _btnTaxiMeter.hidden = NO;
        imgPremium.hidden = NO;
        _btnPremium.hidden = NO;
    }
    else if ([vtype isEqualToString:@"Premium"])
    {
        if (width ==320)
        {
            _btnPremium.frame = CGRectMake(27, 122, viewBookVehicle.frame.size.width-40, 20);
            imgPremium.frame = CGRectMake(8, 125, 12, 12);
        }
        else if (width == 375)
        {
            _btnPremium.frame = CGRectMake(27, 145, viewBookVehicle.frame.size.width-40, 20);
            imgPremium.frame = CGRectMake(8, 148, 12, 12);
        }
        else if (width == 414)
        {
            _btnPremium.frame = CGRectMake(27, 162, viewBookVehicle.frame.size.width-40, 20);
            imgPremium.frame = CGRectMake(8, 165, 12, 12);
        }

   //     viewBookVehicle.frame = CGRectMake(20, 150, self.view.frame.size.width-40, 200);
                imgTaxi.image = [UIImage imageNamed:@"Premium"];
        
        imgTaximeter.hidden = YES;
        _btnTaxiMeter.hidden = YES;
        imgPremium.hidden = NO;
        _btnPremium.hidden = NO;
    }
    lblRegId.text = [NSString stringWithFormat:@"%@(%@)",vtype,[dicSelectedDriver valueForKey:@"driver_noplate"]];
    lblDriverName.text = [NSString stringWithFormat:@"%@ %@",strFirstName,strLastName];
    lblDriverContact.text = [NSString stringWithFormat:@"%@",[dicSelectedDriver valueForKey:@"phone_no"]];
    lblMade.text = [NSString stringWithFormat:@"%@",[dicSelectedDriver valueForKey:@"made"]];
    lblModel.text = [NSString stringWithFormat:@"%@",[dicSelectedDriver valueForKey:@"modelno"]];
    lblRating.text = [NSString stringWithFormat:@"%@",[dicSelectedDriver valueForKey:@"rating"]];
    lblSeats.text = [NSString stringWithFormat:@"Seats Available: %@",[dicSelectedDriver valueForKey:@"noofseats"]];
//    ConfirmationMapViewController *cmvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ConfirmationMapViewController"];
//    cmvc.dicDriverDetails = dicSelectedDriver;
//    isBookingTypeNearest = NO;
//    cmvc.strTypeBooking = @"perticular";
//    cmvc.strSource = [NSString stringWithFormat:@"%@",_lblSelectedLocation.text];
//    [self.navigationController pushViewController:cmvc animated:YES];
    
    //----
    }
    [_mapViewRoute deselectAnnotation:view.annotation animated:YES];
    
    
    
    
    
}

-(void)costCalculation
{
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults] objectForKey:@"VehicleDetails"];
    dict = [dict valueForKey:@"items"];
    //Premium
    for (int i=0; i<[dict count]; i++)
    {
        NSString *type = [NSString stringWithFormat:@"%@",[[dict valueForKey:@"vtype"] objectAtIndex:i]];
        if ([type isEqualToString:@"Premium"])
        {
            NSString *strMinPrice= [[dict valueForKey:@"min_price"] objectAtIndex:i];
            double minPrice = [strMinPrice doubleValue];
            NSString *strPrice= [[dict valueForKey:@"price_per_km"] objectAtIndex:i];
            double pricePerKM = [strPrice doubleValue];
            NSString *strDist = [[dict valueForKey:@"price_per_min"] objectAtIndex:i];
            double pricePerMin = [strDist doubleValue];
            
            double dist = [strED doubleValue];
            //   dist = dist/1000;
            res = 0.0;
            resDist = 0.0;
            resTime = 0.0;
            resDist = (dist * pricePerKM)/1000;
            
            double time = [strET doubleValue];
            // time = time/60;
            resTime = (time *pricePerMin)/60;
            
            res = minPrice + resDist + resTime;
            res = ceilf(res * 100) / 100;
            estPremium = [NSString stringWithFormat:@"%0.2f",res];
        }
        else if ([type isEqualToString:@"Taxi"])
        {
            NSString *strMinPrice= [[dict valueForKey:@"min_price"] objectAtIndex:i];
            double minPrice = [strMinPrice doubleValue];
            NSString *strPrice= [[dict valueForKey:@"price_per_km"] objectAtIndex:i];
            double pricePerKM = [strPrice doubleValue];
            NSString *strDist = [[dict valueForKey:@"price_per_min"] objectAtIndex:i];
            double pricePerMin = [strDist doubleValue];
            
            res = 0.0;
            resDist = 0.0;
            resTime = 0.0;
            double dist = [strED doubleValue];
            //  dist = dist/1000;
            resDist = (dist * pricePerKM)
            /1000;
            
            double time = [strET doubleValue];
            //  time = time/60;
            resTime = (time *pricePerMin)/60;
            
            res = minPrice + resDist + resTime;
            res = ceilf(res * 100) / 100;
            estTaxi = [NSString stringWithFormat:@"%0.2f",res];
        }
        else if ([type isEqualToString:@"Private"])
        {
            NSString *strMinPrice= [[dict valueForKey:@"min_price"] objectAtIndex:i];
            double minPrice = [strMinPrice doubleValue];
            NSString *strPrice= [[dict valueForKey:@"price_per_km"] objectAtIndex:i];
            double pricePerKM = [strPrice doubleValue];
            NSString *strDist = [[dict valueForKey:@"price_per_min"] objectAtIndex:i];
            double pricePerMin = [strDist doubleValue];
            res = 0.0;
            resDist = 0.0;
            resTime = 0.0;
            
            double dist = [strED doubleValue];
            //  dist = dist/1000;
            resDist = (dist * pricePerKM)/1000;
            
            double time = [strET doubleValue];
            //  time = time/60;
            resTime = (time *pricePerMin)/60;
            
            res = minPrice + resDist + resTime;
            res = ceilf(res * 100) / 100;
            estPrivate = [NSString stringWithFormat:@"%0.2f",res];
        }
    }
}

-(void)costCalculationForNearest
{
    NSString *strPrice;
    NSString *strDist;
    for (int i=0; i<[arrDriverLatLong count]; i++)
    {
        NSString *strVType = [NSString stringWithFormat:@"%@",[[arrDriverLatLong valueForKey:@"vtype"] objectAtIndex:i]];
        if ([strVType isEqualToString:@"Standard"])
        {
            [arrStandard addObject:[arrDriverLatLong objectAtIndex:i]];
            [arrPricePerKM addObject:[[arrStandard valueForKey:@"price_per_km"] objectAtIndex:0]];
            [arrPricePerMin addObject:[[arrStandard valueForKey:@"price_per_min"] objectAtIndex:0]];
        }
        else if ([strVType isEqualToString:@"Van"])
        {
            [arrVan addObject:[arrDriverLatLong objectAtIndex:i]];
            [arrPricePerKM addObject:[[arrVan valueForKey:@"price_per_km"] objectAtIndex:0]];
            [arrPricePerMin addObject:[[arrVan valueForKey:@"price_per_min"] objectAtIndex:0]];
        }
        else if ([strVType isEqualToString:@"Premium"])
        {
            [arrPremium addObject:[arrDriverLatLong objectAtIndex:i]];
            [arrPricePerKM addObject:[[arrPremium valueForKey:@"price_per_km"] objectAtIndex:0]];
            [arrPricePerMin addObject:[[arrPremium valueForKey:@"price_per_min"] objectAtIndex:0]];
        }
    }
}


-(void)btnToNormalState
{
    strFareType = [NSString stringWithFormat:@""];
    [imgDest setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgSetFare setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgTaximeter setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgPremium setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [_btnDestarnyRate setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnTaxiMeter setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnSetFare setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnPremium setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(IBAction)btnDestarnyRate:(id)sender
{
    strFareType = [NSString stringWithFormat:@"Destarnyrate"];
    [_btnDestarnyRate setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
  
    [_btnTaxiMeter setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_btnSetFare setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnPremium setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [imgDest setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
    [imgSetFare setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgTaximeter setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgPremium setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [_btnSetFare setTitle:@"Set Fare (Agreed amount)" forState:UIControlStateNormal];
    strFareToSend = [NSString stringWithFormat:@"%@",estPrivate];
}
-(IBAction)btnTaximeter:(id)sender
{
    strFareType = [NSString stringWithFormat:@"Taximeter"];
    [_btnDestarnyRate setTitleColor:[UIColor blackColor]forState:UIControlStateNormal];
    
    [_btnTaxiMeter setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
    
    [_btnSetFare setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnPremium setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [imgDest setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgSetFare setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgTaximeter setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
    [imgPremium setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [_btnSetFare setTitle:@"Set Fare (Agreed amount)" forState:UIControlStateNormal];
    strFareToSend = [NSString stringWithFormat:@"%@",estTaxi];
}
-(IBAction)btnSetFare:(id)sender
{
    strFareType = [NSString stringWithFormat:@"Setfare"];
    [_btnDestarnyRate setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_btnTaxiMeter setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnPremium setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_btnSetFare setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
    viewBookVehicle.hidden = YES;
    viewSetFare.hidden = NO;
    
    [imgDest setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgSetFare setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
    [imgTaximeter setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgPremium setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    _txtFare.text = @"";
    
}
-(IBAction)btnPremium:(id)sender
{
    strFareType = [NSString stringWithFormat:@"Premium"];
    [_btnDestarnyRate setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnTaxiMeter setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnSetFare setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnPremium setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
    [imgDest setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgSetFare setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgPremium setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
    [imgTaximeter setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [_btnSetFare setTitle:@"Set Fare (Agreed amount)" forState:UIControlStateNormal];
    strFareToSend = [NSString stringWithFormat:@"%@",estPremium];
}

#pragma mark PRIVATE OR PRIMIAR OR TAXI BOOK HERE

#pragma mark Book Nearest button tapped
-(IBAction)btnBookTapped:(id)sender
{
    viewDriverInfo.hidden = YES;
    [self btnToNormalState];
    if ([_txtStartSearch.text length]>0 && [_txtDestAddress.text length]>0)
    {
        viewBookVehicle.hidden = NO;
        
        NSString *vtype = [NSString stringWithFormat:@"%@",[dicSelectedDriver valueForKey:@"vtype"]];
        CGFloat width = self.view.frame.size.width;
        
        if ([vtype isEqualToString:@"Taxi"])
        {
            if (width ==320)
            {
                _btnTaxiMeter.frame = CGRectMake(27, 122, viewBookVehicle.frame.size.width-40, 20);
                imgTaximeter.frame = CGRectMake(8, 126, 12, 12);
            }
            else if (width == 375)
            {
                _btnTaxiMeter.frame = CGRectMake(27, 135, viewBookVehicle.frame.size.width-40, 20);
                imgTaximeter.frame = CGRectMake(8, 138, 12, 12);
            }
            else if (width == 414)
            {
                _btnTaxiMeter.frame = CGRectMake(27, 152, viewBookVehicle.frame.size.width-40, 20);
                imgTaximeter.frame = CGRectMake(8, 155, 12, 12);
            }
            imgTaxi.image = [UIImage imageNamed:@"Taxi"];
            
            imgTaximeter.hidden = NO;
            _btnTaxiMeter.hidden = NO;
            imgPremium.hidden = YES;
            _btnPremium.hidden = YES;
        }
        
        
        
        float estTaxi1=[estTaxi floatValue]*20/100;
        estTaxi1=estTaxi1+[estTaxi floatValue];
        float estPremium1=[estPremium floatValue]*20/100;
        estPremium1=estPremium1+[estPremium floatValue];
        float estPrivate1=[estPrivate floatValue]*20/100;
        estPrivate1=estPrivate1+[estPrivate floatValue];
        
        NSString *strTaxi = [NSString stringWithFormat:@"Taxi (Est: $%@ to $%.2f)",estTaxi,estTaxi1];
        NSString *strPremium = [NSString stringWithFormat:@"Premium (Est: $%@ to $%.2f)",estPremium,estPremium1];
        NSString *strPrivate = [NSString stringWithFormat:@"Destarny x1.0 (Est: $%@ to $%.2f)",estPrivate,estPrivate1];
        [_btnDestarnyRate setTitle:strPrivate forState:UIControlStateNormal];
        [_btnSetFare setTitle:@"Set Fare (Agreed amount)" forState:UIControlStateNormal];
        [_btnTaxiMeter setTitle:strTaxi forState:UIControlStateNormal];
        [_btnPremium setTitle:strPremium forState:UIControlStateNormal];
    }
    else if ([_txtDestAddress.text length]==0)
    {
        [ALToastView toastInView:self.view withText:@"Please select the destination location."];
//        [[[UIAlertView alloc] initWithTitle:nil message:@"Please select the destination location." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }
}

#pragma mark BTN BOOK
-(IBAction)btnYes:(id)sender
{
    if ([strFareType length]==0)
    {
        [ALToastView toastInView:self.view withText:@"Please select fare type."];
//        [[[UIAlertView alloc] initWithTitle:nil message:@"Please select fare type." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }
    else if ([strFareType isEqualToString:@"Setfare"] && [strSetFare length]==0)
    {
        [ALToastView toastInView:self.view withText:@"Please set the fare."];
//        [[[UIAlertView alloc] initWithTitle:nil message:@"Please set the fare." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }
    else
    {
        [self orderTaxi:strBookingType:strFareType];
    }
}

-(IBAction)btnNo:(id)sender
{
    viewBookVehicle.hidden = YES;
}

-(IBAction)btnBackFare:(id)sender
{
//    if ([_txtFare.text length]>0)
//    {
//        NSString *strFare = [NSString stringWithFormat:@"Set Fare (My Offer: $%@)",_txtFare.text];
//        [_btnSetFare setTitle:strFare forState:UIControlStateNormal];
//    }
//    else
//    {
//        [_btnSetFare setTitle:@"Set Fare (Agreed amount)" forState:UIControlStateNormal];
//    }
    
    
    viewSetFare.hidden = YES;
    viewBookVehicle.hidden = NO;
    [_txtFare resignFirstResponder];
}

-(IBAction)btnSetFareTapped:(id)sender
{
    if ([_txtFare.text length]==0)
    {
        [ALToastView toastInView:self.view withText:@"Please enter the fare."];
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please enter the fare." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [alert show];
    }
    else
    {
        if ([_txtFare.text length]>0)
        {
            NSString *strFare = [NSString stringWithFormat:@"Set Fare (My Offer: $%@)",_txtFare.text];
            [_btnSetFare setTitle:strFare forState:UIControlStateNormal];
        }
        else
        {
            [_btnSetFare setTitle:@"Set Fare (Agreed amount)" forState:UIControlStateNormal];
        }

        viewSetFare.hidden = YES;
        viewBookVehicle.hidden = NO;
        strSetFare = [NSString stringWithFormat:@"%@",_txtFare.text];
        [_txtFare resignFirstResponder];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextField:_txtFare up:YES];
    
    [textField becomeFirstResponder];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:_txtFare up:NO];
       [textField resignFirstResponder];
}

- (void) animateTextField: (UITextField*) textField up: (BOOL) up
{
    
    const int movementDistance = textField.frame.origin.y / 2; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}


-(IBAction)btnCashTapped
{
    [imgCard setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
    [imgCash setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
    
    [_btnCard setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
    
    [_btnCash setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    NSString *strType = [NSString stringWithFormat:@"Cash"];
    [self updatePaymentType:strType];
}
-(IBAction)btnCardTapped
{
    _strSetCredit = [[NSUserDefaults standardUserDefaults] valueForKey:@"TypeCredit"];
    if ([_strSetCredit isEqualToString:@"NO"]||[_strSetCredit length]==0)
    {
        BillingInfoViewCotroller *bivc = [self.storyboard instantiateViewControllerWithIdentifier:@"BillingInfoViewCotroller"];
        [self.navigationController pushViewController:bivc animated:YES];
    }
    else
    {
        [imgCash setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
        [imgCard setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
        
        [_btnCash setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
        
        [_btnCard setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        NSString *strType = [NSString stringWithFormat:@"CreditCard"];
        [self updatePaymentType:strType];
    }
}


-(void)updatePaymentType:(NSString *)type
{
//http://dev12.edreamz3.com/api/passenger.php/setpaymethodmethod/?cid=1&pay_method=Cash/CreditCard&payid=1
   
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults]valueForKey:@"dicPassengerDetails"];
    NSString *strCid =  [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];;
    NSString *strPayid = [dict valueForKey:@"payid"];
    NSDictionary * param=@{@"cid":strCid,@"pay_method":type,@"payid":strPayid};
    
    [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/setpaymethodmethod/?" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
         NSError *e = nil;
         NSString *strStatus = [response valueForKey:@"status"];
         
         //         if([strStatus isEqualToString:@"1"])
         if ([[response valueForKey:@"status"] boolValue]==1)
         {
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Updated successfully." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             
//             [alert show];
             [[NSUserDefaults standardUserDefaults]setObject:type forKey:@"PaymentType"];
         }
     }failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
//         UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Failed to update." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//         
//         [alert show];
     }];
}

@end
