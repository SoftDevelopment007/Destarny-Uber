//
//  AirportFixedPriceBookingForm_ViewController.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/21/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import "AirportFixedPriceBookingForm_ViewController.h"
#import "webManager.h"
#import "AirportListCell.h"
//#import "MBProgressHUD.h"

@interface AirportFixedPriceBookingForm_ViewController ()
{
    //   MBProgressHUD * HUD;
    
    NSString * fareAmount;
    
    CustomIOSAlertView * customAlertView;
    
    NSString * noOfBookings;
    
    BOOL isYesSelected;
    
    NSString * tbl_Booking_Id;
    
    CLLocationCoordinate2D sourceCord;
    NSString *strLat;
    NSString *strLong;
    NSMutableArray *arrAirportList;
    NSString *strAtid;
}
@end

@implementation AirportFixedPriceBookingForm_ViewController

-(void)viewWillAppear:(BOOL)animated
{
    [self getFixedFare];
    
    [self getAllVehicleDetails];
    
    //---
    
    _lblPremium.textColor = [UIColor colorWithRed:(255/255.0) green:(203/255.0) blue:(7/255.0) alpha:1];
    _lblVan.textColor = [UIColor colorWithRed:(255/255.0) green:(203/255.0) blue:(7/255.0) alpha:1];
    _lblStandard.textColor = [UIColor colorWithRed:(255/255.0) green:(203/255.0) blue:(7/255.0) alpha:1];
    
    //---
}

-(void)getAllVehicleDetails
{
    // http://ezygo.co.nz/ftpserver/taxiapp/api/getallvtype/
    
    NSString *strFlag=[NSString stringWithFormat:@"api/getallvtype/?"];
    
}

-(void)getallvtypeSuccess :(NSDictionary *)dataDic
{
    NSLog(@"%@",dataDic);
    
    
    for (NSDictionary * dic in [dataDic valueForKey:@"items"])
    {
        if([[dic valueForKey:@"vtype"]isEqualToString:@"Standard"])
        {
            _no_of_passenger_Standard = [[dic valueForKey:@"noofseats"]componentsSeparatedByString:@","];
            
        }
        else if ([[dic valueForKey:@"vtype"]isEqualToString:@"Van"])
        {
            _no_of_passenger_van = [[dic valueForKey:@"noofseats"]componentsSeparatedByString:@","];
        }
        else if ([[dic valueForKey:@"vtype"]isEqualToString:@"Premium"])
        {
            _no_of_passenegr_premium = [[dic valueForKey:@"noofseats"]componentsSeparatedByString:@","];
        }
        
    }
    // NSArray * arr = []
}

-(void)getallvtypeFail :(NSDictionary *)dataDic
{
    NSLog(@"%@",dataDic);
}


-(void)getFixedFare
{
    NSString *strFlag=[NSString stringWithFormat:@"api/getfixedfarecharges/?"];
    
    // NSString *strData=[NSString stringWithFormat:@"@",_selectedVehicleType];
    
    //    [WebManager postDataOnserver:strFlag Data:nil delegate:self onSuccess:@selector(getFixedFareChargesSuccess:) onFailure:@selector(getFixedFareChargesFail:)];
    
    //    [HUD show:YES];
}

-(void)getFixedFareChargesSuccess : (NSDictionary *)dataDic
{
    NSLog(@"%@",dataDic);
    
    fareAmount =[[[dataDic valueForKey:@"items"]objectAtIndex:0] valueForKey:@"fixedfare"];
    
    _lblFare.text =[NSString stringWithFormat:@"$ %@ - ",[[[dataDic valueForKey:@"items"]objectAtIndex:0] valueForKey:@"fixedfare"]];
    
    //    [HUD hide:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(void)getFixedFareChargesFail : (NSDictionary *)dataDic
{
    NSLog(@"%@",dataDic);
    
    //    [HUD hide:YES];
}

#pragma mark - viewDidLoad
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //__________________________ Activity Indicator initialization _________________
    
    [self initializeActvitiyIndicator];
    
    // __________ initialize Controls ________________
    [self initializeControls];
    
    
    //____________________initially hide tableView ____________________________________
    
    _tableViewNoofPassenger.hidden = YES;
    _tableViewDestination.hidden =YES;
    tableAirportList.hidden = YES;
    arrAirportList = [[NSMutableArray alloc] init];
    
    [_txtTo addTarget:self action:@selector(btnAirportDropDown:) forControlEvents:UIControlEventEditingDidBegin];
    
    [_txtFrom addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
//    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gestureHandlerMethod:)];
//    
//    [self.view addGestureRecognizer:tapRecognizer];
}
-(void)gestureHandlerMethod:(UITapGestureRecognizer*)sender
{
    [_txtNoOfPassangers resignFirstResponder];
   // [_txtFrom resignFirstResponder];
    [_txtNotes resignFirstResponder];
    [_txtTime resignFirstResponder];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_txtNoOfPassangers resignFirstResponder];
    [_txtFrom resignFirstResponder];
    [_txtNotes resignFirstResponder];
    [_txtTime resignFirstResponder];
    [_txtTo resignFirstResponder];
    _tableViewDestination.hidden=YES;
    tableAirportList.hidden = YES;
}
#pragma mark - initialize Activity indicator
-(void)initializeActvitiyIndicator
{
    //    HUD=[[MBProgressHUD alloc]initWithView:self.view];
    //    [HUD setLabelText:@"Loading"];
    //    [self.view addSubview:HUD];
}

#pragma mark - initialize Controls
-(void)initializeControls
{
    _txtFrom.layer.borderWidth = 1.0f;
    _txtFrom.layer.borderColor =[[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:.2]CGColor];
    
    _txtTo.layer.borderWidth = 1.0f;
    _txtTo.layer.borderColor =[[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:.2]CGColor];
    
    _txtNoOfPassangers.layer.borderWidth = 1.0f;
    _txtNoOfPassangers.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:.2]CGColor];
    
    _txtNotes.layer.borderWidth = 1.0f;
    _txtNotes.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:.2]CGColor];
    
    _txtPayBy.layer.borderWidth = 1.0f;
    _txtPayBy.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:.2]CGColor];
    
    _txtTime.layer.borderWidth = 1.0f;
    _txtTime.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:.2]CGColor];
    
    
    _btnNoofPassenger.layer.borderWidth = 1.0f;
    _btnNoofPassenger.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:.2]CGColor];
    
    
    _txtFrom.layer.sublayerTransform = CATransform3DMakeTranslation(8, 0, 0);
    _txtTo.layer.sublayerTransform = CATransform3DMakeTranslation(8, 0, 0);
    _txtTime.layer.sublayerTransform = CATransform3DMakeTranslation(8, 0, 0);
    _txtNoOfPassangers.layer.sublayerTransform = CATransform3DMakeTranslation(8, 0, 0);
    _txtNotes.layer.sublayerTransform = CATransform3DMakeTranslation(8, 0, 0);
    
    
    //  _btnRadioPremium.layer.cornerRadius = _btnRadioPremium.layer.frame.size.height/2;
    //  _btnRadioPremium.layer.borderWidth = 1.0f;
    //  _btnRadioPremium.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]CGColor];
    
    //   _btnRadioStandard.layer.cornerRadius = _btnRadioStandard.layer.frame.size.height/2;
    //  _btnRadioStandard.layer.borderWidth = 1.0f;
    //  _btnRadioStandard.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]CGColor];
    
    
    //  _btnRadioSUV.layer.cornerRadius = _btnRadioSUV.layer.frame.size.height/2;
    //  _btnRadioSUV.layer.borderWidth = 1.0f;
    //   _btnRadioSUV.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]CGColor];
    
    _btnOrderTaxi.layer.cornerRadius = _btnOrderTaxi.layer.frame.size.height/6;
    
    //__________________initializing number of passenger on vehicle type ______________________
    
    //    _no_of_passenger_Standard = [[NSArray alloc]initWithObjects:@"1",@"2",@"3",@"4", nil];
    //
    //    _no_of_passenger_van = [[NSArray alloc]initWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7", nil];
    //
    //    _no_of_passenegr_premium = [[NSArray alloc]initWithObjects:@"1",@"2",@"3",@"4", nil];
    
    //________________ creating datePicker programatically ________________________
    
    datePicker = [[UIDatePicker alloc]init];
    [datePicker setDate:[NSDate date]];
    datePicker.datePickerMode=UIDatePickerModeDateAndTime;
    [datePicker addTarget:self action:@selector(updateTextField:) forControlEvents:UIControlEventValueChanged];
    
    [datePicker setMinimumDate:[NSDate date]];
    
    [_txtTime setInputView:datePicker];
    _txtTime.inputAccessoryView=[self keyboardToolBar];
}

#pragma mark - datePicker methods
- (UIToolbar *)keyboardToolBar
{
    UIToolbar *toolbar = [[UIToolbar alloc] init];
    [toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [toolbar sizeToFit];
    
    UIButton * doneButton=[UIButton buttonWithType:UIButtonTypeCustom];
    doneButton.frame=CGRectMake(0, 0, 50, 30);
    [doneButton addTarget:self action:@selector(doneTapped) forControlEvents:UIControlEventTouchUpInside];
    [doneButton setTitle:@"Done" forState:UIControlStateNormal];
    [doneButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    UIBarButtonItem *fixedSpace = [[UIBarButtonItem alloc]
                                   initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                   target:nil
                                   action:nil];
    [fixedSpace setWidth:self.view.frame.size.width-70];
    UIBarButtonItem *done_Button = [[UIBarButtonItem alloc] initWithCustomView:doneButton];
    NSArray *itemsArray = [[NSArray alloc]initWithObjects:fixedSpace,done_Button, nil];
    [toolbar setItems:itemsArray];
    return toolbar;
}

//dismiss datePicker
-(void)doneTapped
{
    [_txtTime resignFirstResponder];
}

//Add selected text from datePicker to textField
-(void)updateTextField:(UIDatePicker *)sender
{
    NSDateFormatter *dateFormatter =[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd hh:mm:ss"];//date format like..22-Nov-2012
    NSDate * startDate = [datePicker date];
    
    NSString * finaldate=[dateFormatter stringFromDate:startDate];
    _txtTime.text = [NSString stringWithFormat:@"%@",finaldate];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - touches begin
//-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
//    UITouch *touch= [touches anyObject];
//    if ([touch view] == self.view)
//    {
//        _tableViewDestination.hidden = YES;
//    }
//    // _txtFrom.text = @"";
//}

#pragma mark - back button action
- (IBAction)btnBackClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
    //  Set_PickUp_Location_ViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"Set_PickUp_Location_ViewController"];
    
    // [[SlideNavigationController sharedInstance]popViewControllerAnimated:YES];
    
    
    //    if([[[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"] isEqualToString:@"Register"])
    //    {
    //        if([[[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentMethod"] isEqualToString:@"CreditCard"])
    //        {
    //            [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:4] animated:YES];
    //        }
    //        else
    //        {
    //            [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:3] animated:YES];
    //        }
    //    }
    //    else if([[[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"] isEqualToString:@"Session"])
    //    {
    //        [[SlideNavigationController sharedInstance]popViewControllerAnimated:YES];
    //    }
    //    else
    //    {
    //        [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:2] animated:YES];
    //    }
}

#pragma mark - button Order Clicked
- (IBAction)btnOrderTaxiClicked:(id)sender
{
    //    Taxi_Booking_Form_ViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"Taxi_Booking_Form_ViewController"];
    //    [[SlideNavigationController sharedInstance] pushViewController:vc animated:YES];
    
    int passenger = [_txtNoOfPassangers.text intValue];
    if ([_txtFrom.text isEqualToString:@""])
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please select from field" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        
        [alert show];
    }
    else if ([_txtTime.text isEqualToString:@""])
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please select time" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        
        [alert show];
    }
    else if(_selectedVehicleType == nil)
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please select Vehicle" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        
        [alert show];
    }
    else if ([_txtNotes.text isEqualToString:@""])
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please enter notes" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        
        [alert show];
    }
    else if ([_txtNoOfPassangers.text isEqualToString:@""])
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please enter number of passenger." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        
        [alert show];
    }
    else if (passenger>10)
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Number of passengers cannot be greater than 10." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        
        [alert show];
    }    else
    {
        
        NSString *strFlag=[NSString stringWithFormat:@"api/getvtidbyvtype/?"];
        
        NSString *strData=[NSString stringWithFormat:@"vtype=%@",_selectedVehicleType];
        
        
        
        //        [WebManager postDataOnserver:strFlag Data:strData delegate:self onSuccess:@selector(vtidSuccess:) onFailure:@selector(vtidFail:)];
        //
        //        [HUD show:YES];
        
   //   http://dev12.edreamz3.com/api/passenger.php/addbooking/?cid=1&vtid=1&booking_type=AirportTo&fare_type=FixedFare&booking_from_lat=111&booking_from_lng=222&booking_from=Pune&noofpass=3&booking_time=10:20:30&booking_date=2016-03-20&notes=Hello&atid=1
        
       //  NSString *strDid = [dicDriverDetails valueForKey:@"id"];
        NSDictionary *dict = [[NSDictionary alloc] init];
        dict = [[NSUserDefaults standardUserDefaults] valueForKey:@"dicPassengerDetails"];
        NSLog(@"%@",dict);
        NSString *strCID = [NSString stringWithFormat:@"%@",[dict valueForKey:@"id" ]];
        NSString *vtid;
       
        if([_selectedVehicleType isEqualToString:@"Standard"])
        {
            vtid = @"1";
        }
        else if([_selectedVehicleType isEqualToString:@"Van"])
        {
            vtid = @"2";
        }
        else if ([_selectedVehicleType isEqualToString:@"Premium"])
        {
            vtid = @"3";
        }
        NSString *dateString = _txtTime.text;
        NSArray *components = [dateString componentsSeparatedByString:@" "];
        NSString *date = components[0];
        NSString *time = components[1];
        

//        NSString *savedValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
        
        NSDictionary * param=@{@"cid":strCID,
                               @"vtid":vtid,
                               @"booking_type":@"AirportTo",
                               @"fare_type":@"FixedFare",
                               @"booking_from_lat":strLat,
                               @"booking_from_lng":strLong,
                               @"booking_from":_txtFrom.text,
                               @"noofpass":_txtNoOfPassangers.text,
                               @"booking_time":time,
                               @"booking_date":date,

                               @"notes":_txtNotes.text,
                                                              @"notes":@"note",
                               @"atid":strAtid};   //----- hard coded
        
               [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/addbooking/?" successResponce:^(id response)
         {
             NSError *e = nil;
             NSString *strStatus = [[response valueForKey:@"status"] stringValue];
             
             if([strStatus isEqualToString:@"1"])
             {
                 //---
                 NSArray * response1 = [[NSArray alloc] init];
                 response1 = [response valueForKey:@"items"];
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Requested successfully." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                 alert.tag = 123;
                 [alert show];
             }
             else if([strStatus isEqualToString:@"0"])
             {
                 NSString *strStatus = [response valueForKey:@"items"];
                 [[[UIAlertView alloc] initWithTitle:nil message:strStatus delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil]show];
             }
         }failure:^(NSError *error)
         {
             NSLog(@"Error : %@",error);
         }];
    

    }
    
}
-(IBAction)btnAirportDropDown:(id)sender
{
    tableAirportList.hidden = NO;
    [[webManager sharedObject] loginRequest:nil withMethod:@"passenger.php/getairporttolist" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
                 NSError *e = nil;
         NSString *strStatus = [response valueForKey:@"status"];
         
         //         if([strStatus isEqualToString:@"1"])
         if ([[response valueForKey:@"status"] boolValue]==1)
         {

             dispatch_async(dispatch_get_main_queue(), ^{
             arrAirportList = [response valueForKey:@"items"];
             [tableAirportList reloadData];
                 });
                 
         }
         
     }
                                    failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
         UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Failed to get current booking status." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
         
         [alert show];
     }];
}


-(void)vtidSuccess:(NSDictionary *)dataDic
{
    //[HUD hide:YES];
    
    NSString * cid=[[[NSUserDefaults standardUserDefaults] objectForKey:@"Cid"] objectAtIndex:0];
    
    NSString *strFlag=[NSString stringWithFormat:@"api/addbooking/?"];
    
    //    NSString *strData=[NSString stringWithFormat:@"cid=%@&vtid=%@&booking_type=%@&booking_from=%@&booking_to=%@&noofpass=%@&booking_time=%@&notes=%@",cid,[[[dataDic valueForKey:@"items"] objectAtIndex:0] valueForKey:@"vtid"],@"Advance",_txtFrom.text,_txtTo.text,_lblNoOfPassenegr.text,_txtTime.text,@"1234"];
    //
    //    [WebManager postDataOnserver:strFlag Data:strData delegate:self onSuccess:@selector(bookTaxiSuccess:) onFailure:@selector(bookTaxiFail:)];
    
    
    if([_txtFrom.text isEqualToString:@""]) //|| [_txtTo.text isEqualToString:@""])
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please enter Address." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        
        [alert show];
    }
    else
    {
        sourceCord = [self getLatLongFromAddress:_txtFrom.text];
        
        //CLLocationCoordinate2D destCord = [self getLatLongFromAddress:_txtTo.text];
        
        // NSString * date = [NSString stringWithFormat:@"%@ %@",_lbldate.text,_lblTime.text];
        
        if( _txtTime.text == nil)
        {
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please select date." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            
            [alert show];
        }
        else
        {
            
            NSString *strData=[NSString stringWithFormat:@"cid=%@&vtid=%@&booking_type=%@&booking_from_lat=%f&booking_from_lng=%f&booking_from=%@&booking_to_lat=%f&booking_to_lng=%f&booking_to=%@&noofpass=%@&booking_time=%@&notes=%@&fixedfare=%@",cid,[[[dataDic valueForKey:@"items"] objectAtIndex:0] valueForKey:@"vtid"],@"FixedAdvance",sourceCord.latitude,sourceCord.longitude,_txtFrom.text,0.0000000,00.0000000,@"abc",_lblNoofPassenger.text,_txtTime.text,_txtNotes.text,fareAmount];
            
            //            [WebManager postDataOnserver:strFlag Data:strData delegate:self onSuccess:@selector(bookTaxiSuccess:) onFailure:@selector(bookTaxiFail:)];
            //
            //            [HUD show:YES];
        }
    }
}

-(void)vtidFail : (NSDictionary *)dataDic
{
    //    [HUD hide:YES];
    
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Network problem! Please try again" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert setDelegate:self];
    alert.tag = 301;
    [alert show];
    
    NSLog(@"%@",dataDic);
}

-(void)bookTaxiSuccess:(NSDictionary *)dataDic
{
    //    [HUD hide:YES];
    NSLog(@"%@",dataDic);
    
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Ordered successfully" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert setDelegate:self];
    alert.tag = 301;
    //[alert show];
    
    
    [self sendPushNotification:dataDic];
    
    //    [self checkNoOfBookings];
    
    tbl_Booking_Id = [[[dataDic valueForKey:@"items"]objectAtIndex:0] valueForKey:@"tbid"];
    
    noOfBookings = [[[dataDic valueForKey:@"items"]objectAtIndex:0] valueForKey:@"cnt"];
    
    
    if([noOfBookings intValue] <= 0)
    {
        //        customAlertView  = [[CustomIOSAlertView alloc] init];
        //        [customAlertView setContainerView:[self createDemoView]];
        //
        //        // Modify the parameters
        //        [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:nil, nil]];
        //        [customAlertView setDelegate:self];
        //        [customAlertView setUseMotionEffects:true];
        //        [customAlertView show];
        
        
        NSString * message = [NSString stringWithFormat:@"You get %@ of $%@ Valid From %@ To %@ on this Booking.",[[[dataDic valueForKey:@"credititems"] objectAtIndex:0] valueForKey:@"offer_reason"],[[[dataDic valueForKey:@"credititems"] objectAtIndex:0] valueForKey:@"offer"],[[[dataDic valueForKey:@"credititems"] objectAtIndex:0] valueForKey:@"validfrom"],[[[dataDic valueForKey:@"credititems"] objectAtIndex:0] valueForKey:@"validto"]];
        
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"Congratulations" message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        
        alert.tag =201;
        
        [alert show];
        
    }
    else
    {
        [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
        
        [alert show];
    }
}


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == 201)
    {
        [[SlideNavigationController sharedInstance]popViewControllerAnimated:YES];
    }
}


#pragma mark - send Push Notification
-(void)sendPushNotification : (NSDictionary *)dataDic
{
    NSString * cid=[[[NSUserDefaults standardUserDefaults] objectForKey:@"Cid"] objectAtIndex:0];
    
    NSString *strFlag=[NSString stringWithFormat:@"api/addbookingpush/?"];
    
    NSString *strData=[NSString stringWithFormat:@"cid=%@&booking_from_lat=%f&booking_from_lng=%f&booking_from=%@&booking_to=%@",cid,sourceCord.latitude,sourceCord.longitude,[[[dataDic valueForKey:@"items"]objectAtIndex:0] valueForKey:@"booking_from"],[[[dataDic valueForKey:@"items"]objectAtIndex:0] valueForKey:@"booking_to"]];
    
    //    [WebManager postDataOnserver:strFlag Data:strData delegate:self onSuccess:@selector(addBookingPushSuccess:) onFailure:@selector(addBookingPushFail:)];
    //
    //    [HUD show:YES];
}

-(void)addBookingPushSuccess:(NSDictionary *)dataDic
{
    
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"success" message:@"" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    // [alert show];
    
    NSLog(@"%@",dataDic);
    
    //    [HUD hide:YES];
}

-(void)addBookingPushFail:(NSDictionary *)dataDic
{
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"URL Failed" message:@"" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    //[alert show];
    
    NSLog(@"%@",dataDic);
    
    //    [HUD hide:YES];
}

//failed login call
-(void)bookTaxiFail:(NSDictionary *)dataDic
{
    //    [HUD hide:YES];
    
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Network problem! Please try again" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [alert show];
    
    NSLog(@"%@",dataDic);
}


#pragma mark - get No Of bookings
-(void)checkNoOfBookings
{
    // http://dev7.edreamz2.com/taxiapp/api/getbookingpaymentcnt/
    
    NSString * cid=[[[NSUserDefaults standardUserDefaults] objectForKey:@"Cid"] objectAtIndex:0];
    
    NSString *strFlag=[NSString stringWithFormat:@"api/getbookingpaymentcnt/?"];
    
    NSString *strData=[NSString stringWithFormat:@"cid=%@",cid];
    
    //    [WebManager postDataOnserver:strFlag Data:strData delegate:self onSuccess:@selector(getBookingPaymentCntSuccess:) onFailure:@selector(getBookingPaymentCntFail:)];
    //
    //    [HUD show:YES];
}

-(void)getBookingPaymentCntSuccess:(NSDictionary *)dataDic
{
    //    [HUD hide: YES];
    
    noOfBookings = [[[dataDic valueForKey:@"items"]objectAtIndex:0] valueForKey:@"cnt"];
    
    
    if([noOfBookings intValue] > 0)
    {
        customAlertView  = [[CustomIOSAlertView alloc] init];
        [customAlertView setContainerView:[self createDemoView]];
        
        // Modify the parameters
        [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:nil, nil]];
        [customAlertView setDelegate:self];
        [customAlertView setUseMotionEffects:true];
        [customAlertView show];
    }
    else
    {
        [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
    }
    
    NSLog(@"%@",dataDic);
}

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    NSLog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
    
    
    [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
}

- (UIView *)createDemoView
{
    UIView *demoView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 290, 150)];
    
    UILabel * lblTitle = [[UILabel  alloc]initWithFrame:CGRectMake(20, 30, 70, 30)];
    lblTitle.text = @"Go Loyal";
    [demoView addSubview:lblTitle];
    
    _btnYes = [[UIButton alloc]initWithFrame:CGRectMake(100, 30, 30 ,30)];
    [_btnYes setBackgroundColor:[UIColor clearColor]];
    _btnYes.layer.cornerRadius =_btnYes.layer.frame.size.height/2;
    _btnYes.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]CGColor];
    _btnYes.layer.borderWidth = 1.0f;
    
    [_btnYes addTarget:self action:@selector(yesBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    [demoView addSubview:_btnYes];
    
    _imgviewYes = [[UIImageView alloc]initWithFrame:CGRectMake(108, 38, 15, 15)];
    _imgviewYes.backgroundColor = [UIColor clearColor];
    _imgviewYes.layer.cornerRadius =_imgviewYes.layer.frame.size.height/2;
    [demoView addSubview:_imgviewYes];
    
    UILabel * lblYes = [[UILabel  alloc]initWithFrame:CGRectMake(135,30,40,30)];
    lblYes.text = @"Yes";
    [demoView addSubview:lblYes];
    
    
    
    _btnNo = [[UIButton alloc]initWithFrame:CGRectMake(175,30,30,30)];
    [_btnNo setBackgroundColor:[UIColor clearColor]];
    _btnNo.layer.cornerRadius =_btnNo.layer.frame.size.height/2;
    _btnNo.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]CGColor];
    _btnNo.layer.borderWidth = 1.0f;
    
    [_btnNo addTarget:self action:@selector(noBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    [demoView addSubview:_btnNo];
    
    _imgviewNo = [[UIImageView alloc]initWithFrame:CGRectMake(183,38,15,15)];
    _imgviewNo.backgroundColor = [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1];
    _imgviewNo.layer.cornerRadius =_imgviewNo.layer.frame.size.height/2;
    [demoView addSubview:_imgviewNo];
    
    UILabel * lblNo = [[UILabel  alloc]initWithFrame:CGRectMake(210,30,40,30)];
    lblNo.text = @"No";
    [demoView addSubview:lblNo];
    
    
    _btnAddGoLoyal =[[UIButton alloc]initWithFrame:CGRectMake(115, 100, 70, 40)];
    [_btnAddGoLoyal setTitle:@"Done" forState:UIControlStateNormal];
    [_btnAddGoLoyal setTitleColor:[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1] forState:UIControlStateNormal];
    [_btnAddGoLoyal setTintColor:[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]];
    _btnAddGoLoyal.layer.cornerRadius =_btnAddGoLoyal.layer.frame.size.height/6;
    _btnAddGoLoyal.layer.borderColor = [[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]CGColor];
    _btnAddGoLoyal.layer.borderWidth = 1.0f;
    _btnAddGoLoyal.backgroundColor = [UIColor whiteColor];
    [_btnAddGoLoyal addTarget:self action:@selector(doneBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [demoView addSubview:_btnAddGoLoyal];
    
    return demoView;
}
#pragma mark - View Go Loyal Actions
- (void)noBtnClicked:(id)sender
{
    isYesSelected= NO;
    
    _imgviewNo.backgroundColor = [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1];
    _imgviewYes.backgroundColor = [UIColor clearColor];
    
}

- (void)yesBtnClicked:(id)sender
{
    isYesSelected = YES;
    
    _imgviewYes.backgroundColor = [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1];
    _imgviewNo.backgroundColor = [UIColor clearColor];
}

- (void)doneBtnClicked:(id)sender
{
    [customAlertView close];
    
    //[[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
    
    if(isYesSelected == YES)
    {
        [self addGOLoyal];
    }
    else
    {
        [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
    }
}

#pragma mark - API For GoLoyal
-(void)addGOLoyal
{
    //    http://dev9.edreamz3.com/taxiapp/api/addgoloyal/
    
    NSString * strFlag = [NSString stringWithFormat:@"api/addgoloyal/?"];
    
    NSString * strData =[NSString stringWithFormat:@"tbid=%@",tbl_Booking_Id];
    //
    //    [WebManager postDataOnserver:strFlag Data:strData delegate:self onSuccess:@selector(addGoLoyalSuccess:) onFailure:@selector(addGOLoyalFail:)];
    //
    //    [HUD show:YES];
}

-(void)addGoLoyalSuccess:(NSDictionary *)dataDic
{
    NSLog(@"%@",dataDic);
    
    
    //    [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
    
    if([[[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"] isEqualToString:@"Register"])
    {
        if([[[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentMethod"] isEqualToString:@"CreditCard"])
        {
            [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:4] animated:YES];
        }
        else
        {
            [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:3] animated:YES];
        }
    }
    else
    {
        [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:2] animated:YES];
    }
    
    //    [HUD hide:YES];
    
}

-(void)addGOLoyalFail :(NSDictionary *)dataDic
{
    NSLog(@"%@",dataDic);
    
    //    [HUD hide:YES];
}

-(void)getBookingPaymentCntFail :(NSDictionary *)dataDic
{
    //    [HUD hide:YES];
    
    NSLog(@"%@",dataDic);
}




#pragma mark getLatLong From address
-(CLLocationCoordinate2D )getLatLongFromAddress : (NSString *)address
{
    
    //  http://maps.google.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=false
    
    NSString *urlSTR=[[NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?address=%@&sensor=false",address] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
    
    NSURL *url = [NSURL URLWithString:urlSTR];
    
    
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
    
    NSURLResponse *responce;
    
    NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
    
    
    NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    
    NSArray * resultArray = [dictionary1 valueForKey:@"results"];
    
    NSDictionary * dic = [resultArray objectAtIndex:0];
    
    NSDictionary * geo = [dic valueForKey:@"geometry"];
    NSDictionary * location = [geo valueForKey:@"location"];
    
    double lat = [[location valueForKey:@"lat"]doubleValue];
    double lng = [[location valueForKey:@"lng"] doubleValue];
    
    
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(lat, lng);
    
    return coord;
}



#pragma mark - button Van,Standard,Premium Clicked

- (IBAction)btnVehicleClicked:(id)sender
{
    UIButton * button = sender;
    if(button.tag == 101)
    {
        _lblNoofPassenger.text = @"";
        _selectedVehicleType = @"Standard";
        _imgStandard.image = [UIImage imageNamed:@"standard_taxi_icon_on"];
        _imgVan.image=[UIImage imageNamed:@"van_off"];
        _imgPremium.image = [UIImage imageNamed:@"premium_taxi_icon_off"];
        
        //--
        
        //--- standard van premium
        
        _lblStandard.textColor = [UIColor whiteColor];
        _lblVan.textColor = [UIColor colorWithRed:(255/255.0) green:(203/255.0) blue:(7/255.0) alpha:1];
        _lblPremium.textColor = [UIColor colorWithRed:(255/255.0) green:(203/255.0) blue:(7/255.0) alpha:1];
        
        //--
        dispatch_async(dispatch_get_main_queue(), ^{
      
        [_tableViewNoofPassenger reloadData];
          });
    }
    else if(button.tag == 102)
    {
        _lblNoofPassenger.text = @"";
        _selectedVehicleType = @"Van";
        _imgStandard.image = [UIImage imageNamed:@"standard_taxi_icon_off"];
        _imgVan.image=[UIImage imageNamed:@"van_on"];
        _imgPremium.image = [UIImage imageNamed:@"premium_taxi_icon_off"];
        
        //----
        
        _lblStandard.textColor = [UIColor colorWithRed:(255/255.0) green:(203/255.0) blue:(7/255.0) alpha:1];
        _lblVan.textColor = [UIColor whiteColor];
        _lblPremium.textColor = [UIColor colorWithRed:(255/255.0) green:(203/255.0) blue:(7/255.0) alpha:1];
        
        //----
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [_tableViewNoofPassenger reloadData];
        });
        
        
    }
    else
    {
        _lblNoofPassenger.text = @"";
        _selectedVehicleType = @"Premium";
        _imgStandard.image = [UIImage imageNamed:@"standard_taxi_icon_off"];
        _imgVan.image=[UIImage imageNamed:@"van_off"];
        _imgPremium.image = [UIImage imageNamed:@"premium_taxi_icon_on"];
        
        //---
        
        _lblStandard.textColor = [UIColor colorWithRed:(255/255.0) green:(203/255.0) blue:(7/255.0) alpha:1];
        _lblVan.textColor = [UIColor colorWithRed:(255/255.0) green:(203/255.0) blue:(7/255.0) alpha:1];
        _lblPremium.textColor = [UIColor whiteColor];
        
        //----
        dispatch_async(dispatch_get_main_queue(), ^{
            [_tableViewNoofPassenger reloadData];

        });
        
    }
}

#pragma mark - tableView datasource and delegate methods
//-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
//{
//    //_________tableView searching places ________
//    
//    if(tableView.tag == 103)
//    {
//        if(self.isFiltered == YES)
//        {
//            return  self.filteredPlaces.count;
//        }
//        else
//        {
//            return  self.initialPlaces.count;
//        }
//    }
//    if(tableView.tag == 102)
//    {
//        if([_selectedVehicleType isEqualToString:@"Standard"])
//            return _no_of_passenger_Standard.count;
//        
//        else if ([_selectedVehicleType isEqualToString:@"Van"])
//            return _no_of_passenger_van.count;
//        
//        else
//            return _no_of_passenegr_premium.count;
//    }
//    
//    else return 1;
//}

#pragma mark - textField delegate methods
//- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
-(void)textFieldDidChange:(UITextField *)textfield
{
    if(textfield.tag == 301 )//|| textField.tag == 302)
    {
        if(textfield.text.length == 0)
        {
            _tableViewDestination.hidden = YES;
            
            // _tableViewSearch1.hidden = YES;
        }
        else
        {
            _tableViewDestination.hidden = NO;
            // _tableViewSearch1.hidden = NO;
        
        
        // NSString * urlSTR=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/textsearch/json?query=p&sensor=true&key=AIzaSyBtzqyf_2PG8NSbVyVhRym-86M_rj-OOZk"];
        
        NSString *urlSTR=[[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyBj2Y63SxN6m0XXbFLyLTbRfDgCC_orFh0",textfield.text] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
        
        NSURL *url = [NSURL URLWithString:urlSTR];
        //[NSURL URLWithString:[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyBtzqyf_2PG8NSbVyVhRym-86M_rj-OOZk",searchText]];//18.5333, 73.8514,type]];
        
        NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
        
        NSURLResponse *responce;
        
        NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
        
        NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
        _initialPlaces = [[dictionary1 valueForKey:@"predictions"]valueForKey:@"description"];
        
        if(textfield.text.length == 0)
        {
            self.isFiltered = NO;
        }
        else
        {
            self.isFiltered = YES;
            self.filteredPlaces = [NSMutableArray new];
            
            for (NSString * cityName in self.initialPlaces)
            {
                NSRange cityNameRange = [cityName rangeOfString:textfield.text options:NSCaseInsensitiveSearch];
                
                if(cityNameRange.location != NSNotFound)
                {
                    [self.filteredPlaces addObject:cityName];
                }
            }
        }
        
            dispatch_async(dispatch_get_main_queue(), ^{
                    [self.tableViewDestination reloadData];
                   });
        }
    }
    else if(textfield.tag==310)
    {
        if(textfield.text.length == 0)
        {
            tableAirportList.hidden = YES;
            // _tableViewSearch1.hidden = YES;
        }
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark - tableView datasource and delegates methods
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag == 103)
    {
        return [self.filteredPlaces count];
    }
    else
    return [arrAirportList count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 103)
    {
        //        UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        AirportFixedFare_TableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        
        if(self.isFiltered == YES)
        {
            cell.lblTitle.text = [self.filteredPlaces objectAtIndex:indexPath.row];
        }
        else
        {
            cell.lblTitle.text = [self.initialPlaces objectAtIndex:indexPath.row];
        }
        
        cell.layer.cornerRadius = cell.layer.frame.size.height/6;
        
        return cell;
    }
    else
    {
        NSString *identifier = @"AirportListCell";
        AirportListCell * cell = [tableView dequeueReusableCellWithIdentifier:@"AirportListCell"];
        if (cell==nil)
        {
            cell = [[AirportListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        cell.lblTitle.text = [[arrAirportList objectAtIndex:indexPath.row] valueForKey:@"airport_name"];
        cell.layer.cornerRadius = cell.layer.frame.size.height/6;
        
        return cell;
        
//        UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
//        
//        if([_selectedVehicleType isEqualToString:@"Standard"])
//        {
//            cell.textLabel.text = [_no_of_passenger_Standard objectAtIndex:indexPath.section];
//        }
//        else if ([_selectedVehicleType isEqualToString:@"Van"])
//        {
//            cell.textLabel.text = [_no_of_passenger_van objectAtIndex:indexPath.section];
//        }
//        else
//        {
//            cell.textLabel.text = [_no_of_passenegr_premium objectAtIndex:indexPath.section];
//        }
//        cell.layer.cornerRadius = cell.layer.frame.size.height/6;
//        
//        return cell;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if( tableView.tag == 103)
    {
        NSString * address;
        
        if(self.isFiltered == YES)
        {
            address   = [self.filteredPlaces objectAtIndex:indexPath.section];
        }
        else
        {
            address = [self.initialPlaces objectAtIndex:indexPath.section];
        }
        _txtFrom.text = address;
        [self geoCodeUsingAddress:address];
        _tableViewDestination.hidden = YES;
        
        
    }
    
    else
    {
        _txtTo.text = [[arrAirportList objectAtIndex:indexPath.row] valueForKey:@"airport_name"];
        strAtid = [[arrAirportList objectAtIndex:indexPath.row] valueForKey:@"atid"];
        tableAirportList.hidden = YES;
        
//        if([_selectedVehicleType isEqualToString:@"Standard"])
//        {
//            _lblNoofPassenger.text = [_no_of_passenger_Standard objectAtIndex:indexPath.section];
//            //            [_btnNoOfPasseneger setTitle:str forState:UIControlStateNormal];
//        }
//        else if ([_selectedVehicleType isEqualToString:@"Van"])
//        {
//            _lblNoofPassenger.text = [_no_of_passenger_van objectAtIndex:indexPath.section];
//            // [_btnNoOfPasseneger setTitle:str forState:UIControlStateNormal];
//        }
//        else
//        {
//            _lblNoofPassenger.text = [_no_of_passenegr_premium objectAtIndex:indexPath.section];
//            //[_btnNoOfPasseneger setTitle:str forState:UIControlStateNormal];
//        }
//        _tableViewNoofPassenger.hidden = YES;
        
    }
}
- (CLLocationCoordinate2D) geoCodeUsingAddress:(NSString *)address
{
    double latitude = 0, longitude = 0;
    NSString *esc_addr =  [address stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
    NSString *result = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
    if (result) {
        NSScanner *scanner = [NSScanner scannerWithString:result];
        if ([scanner scanUpToString:@"\"lat\" :" intoString:nil] && [scanner scanString:@"\"lat\" :" intoString:nil]) {
            [scanner scanDouble:&latitude];
            if ([scanner scanUpToString:@"\"lng\" :" intoString:nil] && [scanner scanString:@"\"lng\" :" intoString:nil]) {
                [scanner scanDouble:&longitude];
            }
        }
    }
    CLLocationCoordinate2D center;
    center.latitude = latitude;
    center.longitude = longitude;
    strLat = [NSString stringWithFormat:@"%f",center.latitude];
    strLong = [NSString stringWithFormat:@"%f",center.longitude];
    return center;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGRect frame = CGRectMake(0, 0, tableView.frame.size.width,0.0f);
    UIView *view = [[UIView alloc] initWithFrame:frame];
    view.backgroundColor = [UIColor colorWithRed:26/255.0 green:24/255.0 blue:29/255.0 alpha:1];
    return view;
}

- (CGFloat)tableView:(UITableView*)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        return 6.0;
    }
    return 6.0;
}

#pragma mark - noOfPassenger button action
- (IBAction)btnNoofPassengerClicked:(id)sender
{
    if(_selectedVehicleType.length == 0)
    {
        _tableViewNoofPassenger.hidden = YES;
    }
    else
        _tableViewNoofPassenger.hidden = NO;
}

-(void)getNearestAirport : (CLLocationCoordinate2D)locationCord
{
    
    //https://maps.googleapis.com/maps/api/place/search/json?location=%f,%f&radius=500&types=%@&sensor=true&key=AIzaSyA-dPUqLDPnjTFz48nK7R0-dPWHsMfAaLg"
    
//    NSString *urlSTR=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/search/json?location=%f,%f&radius=100000&types=%@&sensor=true&key=AIzaSyBj2Y63SxN6m0XXbFLyLTbRfDgCC_orFh0",locationCord.latitude,locationCord.longitude,@"airport"];u
    
//    NSURL *url = [NSURL URLWithString:urlSTR];
    //[NSURL URLWithString:[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyBtzqyf_2PG8NSbVyVhRym-86M_rj-OOZk",searchText]];//18.5333, 73.8514,type]];
    
//    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
    
//    NSURLResponse *responce;
    
//    NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
    
//    NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
}

@end
