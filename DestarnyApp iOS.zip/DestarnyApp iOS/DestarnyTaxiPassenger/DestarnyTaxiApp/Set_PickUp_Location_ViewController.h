//
//  Set_PickUp_Location_ViewController.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/24/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "Add_Home_and_WorkViewController.h"
#import "SlideNavigationController.h"
//#import "ConfirmationViewController.h"
#import "LeftMenuViewController.h"
#import <MapKit/MapKit.h>
#import "Annotation.h"
#import <CoreLocation/CoreLocation.h>
//#import <FBSDKLoginKit/FBSDKLoginKit.h>
//#import <FBSDKCoreKit/FBSDKCoreKit.h>
//#import "SCSettings.h"
//#import "SCProfilePictureButton.h"
//#import "MBProgressHUD.h"
#import "SearchPlaceViewController.h"
#import "SearchBarCell.h"
#import "SEFilterControl.h"


#define Passenger_Current_Location locationManager.location.coordinate.latitude,locationManager.location.coordinate.longitude

@protocol serviceTypeDelegate <NSObject>
@required
-(void)selectedValue:(NSString *)strKey;
@end


@interface Set_PickUp_Location_ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,MKMapViewDelegate,CLLocationManagerDelegate,UIGestureRecognizerDelegate,MKAnnotation,UITextFieldDelegate,serviceTypeDelegate,UITextFieldDelegate,UISearchBarDelegate>
{
    CLLocationManager * locationManager;
    NSString * currentLocationAddress;
    NSMutableArray *arraydriverLatLong;
   // IBOutlet UIView *viewDriverInfo;
    IBOutlet UIView *searchView;
    NSMutableArray *arrSearchRes;
    NSDictionary *dicSelectedLoc;
    NSString *strSearchedAddress;
    MKCoordinateSpan span;
    IBOutlet UIView *annotationView;
    IBOutlet UIButton *btnGo;
    IBOutlet UIView *locView;
    int count;
}


//------- left menu --------
@property(nonatomic,assign)id <serviceTypeDelegate> delegateServiceType;
@property (weak, nonatomic) IBOutlet UITableView *tblLeftMenu;

@property (weak, nonatomic) IBOutlet UIButton *menuBtn1;

@property (weak, nonatomic) IBOutlet UIButton *menuBtn2;

@property (weak, nonatomic) IBOutlet MKMapView *mapPassenger;

@property (weak, nonatomic) IBOutlet UIView *viewSearchLoc;

- (IBAction)btnLogoutTapped:(id)sender;

- (IBAction)btnCurrentLocationTapped:(id)sender;

//---------------------------

//_______________ properties ______________________________

@property (weak, nonatomic) IBOutlet UIView *viewLeftMenu;

@property (weak, nonatomic) IBOutlet UIView *viewSearch;

//____________ property for storing selected vehicle type _____________

@property(nonatomic,retain)NSString * selectedVehicle;


//______________ for Facebook user name _______________

@property (nonatomic,retain)NSString * strName;

//____getting addresss from AddHome_Work Controller

@property (nonatomic,retain) NSString * selectedAddress;


@property (weak, nonatomic) IBOutlet MKMapView *mapView;


@property (weak, nonatomic) IBOutlet UITextField *txtPickUpLocation;


@property(nonatomic) BOOL isLogin;


@property (nonatomic, weak) IBOutlet SEFilterControl *filterControl;

@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (strong, nonatomic) IBOutlet UITableView *tblSearchOptions;
@property (weak, nonatomic) IBOutlet UIImageView *imgViewStandard;


@property (weak, nonatomic) IBOutlet UIImageView *imgViewPremium;

@property (weak, nonatomic) IBOutlet UIImageView *imgViewSUV;

@property (weak, nonatomic) IBOutlet UIImageView *imgViewSUV1;

@property (weak, nonatomic) IBOutlet UIButton *btnSUV;

@property (weak, nonatomic) IBOutlet UIButton *btnSUV2;

@property (weak, nonatomic) IBOutlet UIButton *btnCarTapped;

@property (weak, nonatomic) IBOutlet UILabel *lblPickupLocation;

@property (weak, nonatomic) IBOutlet UILabel *lblDistance;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *btnMenu;
//- (IBAction)btnMenuClicked:(id)sender;

//@property (weak, nonatomic) IBOutlet UIButton *btnMenu;

//- (IBAction)btnMenuClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *lblsetPickupLocation;

@property (weak, nonatomic) IBOutlet UIImageView *imgCar;

@property (weak, nonatomic) IBOutlet UIButton *btnPremium;


@property (weak, nonatomic) IBOutlet UIImageView *imgStandard;

@property (weak, nonatomic) IBOutlet UIImageView *imgPremium;


@property (weak, nonatomic) IBOutlet UIImageView *imgViewVan;


@property (weak, nonatomic) IBOutlet UILabel *lblpickupLocation1;

@property (weak, nonatomic) IBOutlet UIImageView *btnPickupLocation;

//------

@property (strong, nonatomic) IBOutlet UIButton *btnCurrentLoc;

@property (strong, nonatomic) IBOutlet UILabel *lblSelectedLocation;


//___________ Actions ____________
- (IBAction)btnCarTapped:(id)sender;

- (IBAction)btnMenuClicked:(id)sender;

- (IBAction)btnPremiumClicked:(id)sender;

- (IBAction)getNearByDriversTapped:(id)sender;

///-------- view --------

@property (strong, nonatomic) IBOutlet UIView *viewVehiclePan;
@property (weak, nonatomic) IBOutlet UIView *viewDriverInfo;
@property (weak, nonatomic) IBOutlet UILabel *lblDriverName;
@property (weak, nonatomic) IBOutlet UILabel *lblRego;
@property (weak, nonatomic) IBOutlet UILabel *lblETA;
@property (weak, nonatomic) IBOutlet UILabel *lblModel;

//-----------------------
- (IBAction)btnBookNearestTapped:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnNearestTaxi;
@property (copy, nonatomic) NSString *strSetCredit;
@end
