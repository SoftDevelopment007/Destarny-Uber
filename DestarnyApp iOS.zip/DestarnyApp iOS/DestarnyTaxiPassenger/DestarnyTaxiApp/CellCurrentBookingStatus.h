//
//  CellCurrentBookingStatus.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 3/12/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellCurrentBookingStatus : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *cellBackground;
@property (strong, nonatomic) IBOutlet UILabel *lbl1,*lbl2,*lbl3,*lbl4,*lbl5,*lbl6,*lbl7;
@property (strong, nonatomic) IBOutlet UILabel *lblDriverName;
@property (strong, nonatomic) IBOutlet UILabel *lblETAT;

@property (strong, nonatomic) IBOutlet UILabel *lblPassenger;

@property (strong, nonatomic) IBOutlet UILabel *lblContactNumber;

@property (strong, nonatomic) IBOutlet UILabel *lblModelNumber;
@property (strong, nonatomic) IBOutlet UILabel *lblTaxiNumberPlate;

@property (strong, nonatomic) IBOutlet UILabel *lblMade;

@property (strong, nonatomic) IBOutlet UILabel *lblBookingFrom;

@property (strong, nonatomic) IBOutlet UILabel  *lblBookingTo;
@property (strong, nonatomic) IBOutlet UILabel *lblDistance;
@property (strong, nonatomic) IBOutlet UILabel *lblDuration;
@property (strong, nonatomic) IBOutlet UILabel *lblRego;
@property (strong, nonatomic) IBOutlet UILabel *lblBookingTime;
@property (strong, nonatomic) IBOutlet UILabel *lblBookingType;
@property (strong, nonatomic) IBOutlet UIButton *btnCancelBooking;
@property (strong, nonatomic) IBOutlet UIButton *btnCancelBookingPassenger;
@property (strong, nonatomic) IBOutlet UIButton *btnCall;
@end
