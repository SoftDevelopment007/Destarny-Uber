//
//  MenuViewController.m
//  SlideMenu
//
//  Created by Aryan Gh on 4/24/13.
//  Copyright (c) 2013 Aryan Ghassemi. All rights reserved.
//

#import "LeftMenuViewController.h"
#import "SlideNavigationContorllerAnimatorFade.h"
#import "SlideNavigationContorllerAnimatorSlide.h"
#import "SlideNavigationContorllerAnimatorScale.h"
#import "SlideNavigationContorllerAnimatorScaleAndFade.h"
#import "SlideNavigationContorllerAnimatorSlideAndFade.h"
//#import "CurrentBookingVC_ViewController.h"
//#import "CreditViewController.h"

@implementation LeftMenuViewController

#pragma mark - UIViewController Methods -

- (id)initWithCoder:(NSCoder *)aDecoder
{
//	self.slideOutAnimationEnabled = YES;
    self.slideOutAnimationEnabled = NO;
	
	return [super initWithCoder:aDecoder];
}

-(void)viewWillAppear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshTableWithNotification:) name:@"RefreshTable" object:nil];
    
    _myScrollView.contentSize = CGSizeMake(320, 500);
    
    
    if([[[NSUserDefaults standardUserDefaults]valueForKey:@"FBLogin"] isEqualToString:@"LoggedIn"])
    {
        //_btnFB.hidden = NO;
        _btnLogout.hidden = YES;
        _lblLogout.hidden  =YES;
        _imgLogout.hidden = YES;
    }
    else
    {
       // _btnFB.hidden = YES;
        _btnLogout.hidden = NO;
        _lblLogout.hidden = NO;
        _imgLogout.hidden = NO;
    }
}

//- (void)loginButtonDidLogOut:(FBSDKLoginButton *)loginButton
//{
//    [[NSUserDefaults standardUserDefaults] setObject:@"LoggedOut" forKey:@"FBLogin"];
//    
//  //  if (_viewIsVisible)
//  //  {
//        SignInViewController * vc=[self.storyboard instantiateViewControllerWithIdentifier:@"SignInViewController"];
//        
//        //[self.navigationController pushViewController:gymDetail animated:YES];
//        
//        [[SlideNavigationController sharedInstance] pushViewController:vc animated:YES];
//  //  }
//}

- (void)viewDidLoad
{
	[super viewDidLoad];
	
    NSDictionary *dict=[[NSDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"data" ofType:@"plist"]];
    self.items=[dict valueForKey:@"Items"];
    self.itemsInTable=[[NSMutableArray alloc] init];
    [self.itemsInTable addObjectsFromArray:self.items];
    
    
    self.tableView.separatorColor = [UIColor lightGrayColor];
	
	UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Background.png"]];
    
	self.tableView.backgroundView = imageView;
}

// Add this method just beneath viewDidLoad:
- (void)refreshTableWithNotification:(NSNotification *)notification
{
   //refresh cell BookInAdvance of menu
    NSDictionary *dic=[self.itemsInTable objectAtIndex:5];
    NSArray *arr=[dic valueForKey:@"SubItems"];
    [self CollapseRows:arr];
    
    [self.tableView reloadData];
    
    if([[[NSUserDefaults standardUserDefaults]valueForKey:@"FBLogin"] isEqualToString:@"LoggedIn"])
    {
       // _btnFB.hidden = NO;
        _btnLogout.hidden = YES;
        _imgLogout.hidden = YES;
        _lblLogout.hidden =YES;
    }
    else
    {
       // _btnFB.hidden = YES;
        _btnLogout.hidden = NO;
        _imgLogout.hidden = NO;
        _lblLogout.hidden = NO;
    }
}

#pragma mark - UITableView Delegate & Datasrouce -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"%d",self.itemsInTable.count);
    return [self.itemsInTable count];
    
	//return 8;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.frame.size.width, 20)];
	view.backgroundColor = [UIColor clearColor];
	return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LeftMenu_TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"leftMenuCell"];
    
    NSString *Title= [[self.itemsInTable objectAtIndex:indexPath.row] valueForKey:@"Name"];
    
    cell.lblMenu.text = Title;//@"Home";
    cell.imgMenu.image = [UIImage imageNamed:[[self.itemsInTable objectAtIndex:indexPath.row] valueForKey:@"image"]];
    
//    LeftMenu_TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"leftMenuCell"];
////    cell.imgMenu.image = [UIImage imageNamed:@"Home1.png"];
////    cell.lblMenu.text = @"Home";
//	switch (indexPath.row)
//	{
//		case 0:
//            cell.imgMenu.image = [UIImage imageNamed:@"Home1.png"];
//            cell.lblMenu.text = @"Home";
//            
//			break;
//			
//		case 1:
//            cell.imgMenu.image = [UIImage imageNamed:@"Profile"];
//            cell.lblMenu.text = @"Profile";
//			break;
//			
//		case 2:
//            cell.imgMenu.image = [UIImage imageNamed:@"GoLoyal"];
//            cell.lblMenu.text = @"Go Loyal";
//			break;
//			
//		case 3:
//            cell.imgMenu.image = [UIImage imageNamed:@"BillingInfo"];
//            cell.lblMenu.text = @"Billing Info";
//			break;
//            
//        case 4:
//            cell.imgMenu.image=[UIImage imageNamed:@"Favourites"];
//            cell.lblMenu.text = @"Favourites";
//            break;
//        case 5:
//            cell.imgMenu.image = [UIImage imageNamed:@"BookInAdvance"];
//            cell.lblMenu.text =@"Book in advance";
//            break;
//            
//        case 6:
//            cell.imgMenu.image = [UIImage imageNamed:@"InviteFriends"];
//            cell.lblMenu.text =@"Invite Friends";
//            break;
//        case 7:
//            cell.imgMenu.image = [UIImage imageNamed:@"Contact"];
//            cell.lblMenu.text = @"Contact";
//            break;
//	}
//	
	cell.backgroundColor = [UIColor clearColor];
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIViewController *vc ;
    NSString * flag = [[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"];
    NSString * flag1 = [[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentMethod"];
    
    NSDictionary *dic=[self.itemsInTable objectAtIndex:indexPath.row];
    NSLog(@" index path = %d",indexPath.row);
    
    if([dic valueForKey:@"SubItems"])
    {
        NSArray *arr=[dic valueForKey:@"SubItems"];
        BOOL isTableExpanded=NO;
        
        for(NSDictionary *subitems in arr )
        {
            NSInteger index=[self.itemsInTable indexOfObjectIdenticalTo:subitems];
            isTableExpanded=(index>0 && index!=NSIntegerMax);
            if(isTableExpanded) break;
        }
        
        if(isTableExpanded)
        {
            [self CollapseRows:arr];
        }
        else
        {
            NSUInteger count=indexPath.row+1;
            NSMutableArray *arrCells=[NSMutableArray array];
            for(NSDictionary *dInner in arr )
            {
                [arrCells addObject:[NSIndexPath indexPathForRow:count inSection:0]];
                [self.itemsInTable insertObject:dInner atIndex:count++];
            }
            [self.tableView insertRowsAtIndexPaths:arrCells withRowAnimation:UITableViewRowAnimationLeft];
        }
    }
    else
    {
        NSString *Title= [[self.itemsInTable objectAtIndex:indexPath.row] valueForKey:@"Name"];
        
        if([Title isEqualToString:@"Home"])
        {
            NSString * flag = [[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"];
            
            NSString * flag1 = [[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentMethod"];
            
            if([flag isEqualToString:@"Register"])
            {
                if([flag1 isEqualToString:@"CreditCard"])
                {
                    [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:4] animated:NO];
                }
                else
                {
                    [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:3] animated:YES];
                }
            }
            else if([flag isEqualToString:@"Session"])
            {
//                Set_PickUp_Location_ViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"Set_PickUp_Location_ViewController"];
//                [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
            }
            else
            {
//                [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:2] animated:YES];
            }
            
            /*
            if([flag isEqualToString:@"Register"])
            {
                if([flag1 isEqualToString:@"CreditCard"])
                {
                    [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:4] animated:NO];
                }
                else
                {
                    [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:3] animated:YES];
                }
            }
            else
            {
                [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:2] animated:YES];
            }
            */
        }
        
        if ([Title isEqualToString:@"Profile"])
        {
//            vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
//                        [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
        }
        
        if ([Title isEqualToString:@"Go Loyal"])
        {
            //vc = [self.storyboard instantiateViewControllerWithIdentifier: @"FriendsViewController"];
        }
        
        if ([Title isEqualToString:@"Billing Info"])
        {
//            vc = [self.storyboard instantiateViewControllerWithIdentifier:@"BillingInfoViewController"];
//            [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
        }
        
        if ([Title isEqualToString:@"Favourites"])
        {
//            vc  = [self.storyboard instantiateViewControllerWithIdentifier:@"FavouriteViewController"];
//            [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
        }
        if ([Title isEqualToString:@"Invite Friends"])
        {
//            vc = [self.storyboard instantiateViewControllerWithIdentifier:@"InviteFriendsViewController"];
//            [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
        }
        
        if ([Title isEqualToString:@"Contact"])
        {
//            vc = [self.storyboard instantiateViewControllerWithIdentifier:@"EmergencyViewController"];
//            [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
        }
        
        if ( [Title isEqualToString:@"Pre booking Form"])
        {
//            vc = [self.storyboard instantiateViewControllerWithIdentifier:@"Taxi_Booking_Form_ViewController"];
//            [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
        }
        
        if([Title isEqualToString:@"Fixed Fare to Airport"])
        {
//            vc =[self.storyboard instantiateViewControllerWithIdentifier: @"AirportFixedPriceBookingForm_ViewController"];
//            [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
        }
        
        if([Title isEqualToString:@"Pre Booking Info"])
        {
//            vc =[self.storyboard instantiateViewControllerWithIdentifier: @"PerBookingHistoryViewController"];
//            [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
        }
        
        if([Title isEqualToString:@"Pay Now"])
        {
//            CurrentBookingVC_ViewController * vc =[self.storyboard instantiateViewControllerWithIdentifier:@"CurrentBookingVC_ViewController"];
//            [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
        }
        
        if([Title isEqualToString:@"Current Booking Status"])
        {
//            CurrentBookingVC_ViewController * vc =[self.storyboard instantiateViewControllerWithIdentifier:@"CurrentBookingVC_ViewController"];
//            [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
        }
        
        if([Title isEqualToString:@"Credit"])
        {
//            CreditViewController * vc =[self.storyboard instantiateViewControllerWithIdentifier:@"CreditViewController"];
//            [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
        }
    }

//	UIViewController *vc ;
//	NSString * flag = [[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"];
//    NSString * flag1 = [[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentMethod"];
//	switch (indexPath.row)
//	{
//		case 0:
//         if([flag isEqualToString:@"Register"])
//         {
//             
//             if([flag1 isEqualToString:@"CreditCard"])
//             {
//                 [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:4] animated:NO];
//             }
//             else
//             {
//                 [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:3] animated:YES];
//            }
//         }
//            else
//            {
//                
//                 [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:2] animated:YES];
//            }
//			break;
//			
//		case 1:
//            vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
//            [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
//			break;
//			
//		case 2:
//			//vc = [self.storyboard instantiateViewControllerWithIdentifier: @"FriendsViewController"];
//			break;
//			
//		case 3:
//            vc = [self.storyboard instantiateViewControllerWithIdentifier:@"BillingInfoViewController"];
//            [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
//            break;
//        case 4:
//            vc  = [self.storyboard instantiateViewControllerWithIdentifier:@"FavouriteViewController"];
//            [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
//            break;
//            
//        case 5:
//            vc =[self.storyboard instantiateViewControllerWithIdentifier: @"AirportFixedPriceBookingForm_ViewController"];
//            [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
//			//return;
//			break;
//        case 6:
//            vc = [self.storyboard instantiateViewControllerWithIdentifier:@"InviteFriendsViewController"];
//            [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
//            break;
//        case 7:
//            vc = [self.storyboard instantiateViewControllerWithIdentifier:@"EmergencyViewController"];
//            [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
//                       
//            break;
//	}
	
//[[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc withSlideOutAnimation:self.slideOutAnimationEnabled andCompletion:nil];
}


-(void)CollapseRows:(NSArray*)ar
{
    for(NSDictionary *dInner in ar )
    {
        NSUInteger indexToRemove=[self.itemsInTable indexOfObjectIdenticalTo:dInner];
        NSArray *arInner=[dInner valueForKey:@"SubItems"];
        if(arInner && [arInner count]>0)
        {
            [self CollapseRows:arInner];
        }
        
        if([self.itemsInTable indexOfObjectIdenticalTo:dInner]!=NSNotFound)
        {
            [self.itemsInTable removeObjectIdenticalTo:dInner];
            [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:
                                                        [NSIndexPath indexPathForRow:indexToRemove inSection:0]
                                                        ]
                                      withRowAnimation:UITableViewRowAnimationLeft];
        }
    }
}

- (UITableViewCell*)createCellWithTitle:(NSString *)title image:(UIImage *)image  indexPath:(NSIndexPath*)indexPath
{
    //NSString *CellIdentifier = @"Cell";
    
    LeftMenu_TableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"leftMenuCell"];
    
   // ExpandableTableViewCell* cell = [self.menuTableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    UIView *bgView = [[UIView alloc] init];
    bgView.backgroundColor = [UIColor grayColor];
    cell.selectedBackgroundView = bgView;
    cell.lblMenu.text = title;
    
//    cell.lblTitle.textColor = [UIColor blackColor];
    
    [cell setIndentationLevel:[[[self.itemsInTable objectAtIndex:indexPath.row] valueForKey:@"level"] intValue]];
    cell.indentationWidth = 25;
    
    float indentPoints = cell.indentationLevel * cell.indentationWidth;
    
    cell.contentView.frame = CGRectMake(indentPoints,cell.contentView.frame.origin.y,cell.contentView.frame.size.width - indentPoints,cell.contentView.frame.size.height);
    
    NSDictionary *d1=[self.itemsInTable objectAtIndex:indexPath.row] ;
    
    if([d1 valueForKey:@"SubItems"])
    {
     //   cell.btnExpand.alpha = 1.0;
      //  [cell.btnExpand addTarget:self action:@selector(showSubItems:) forControlEvents:UIControlEventTouchUpInside];
    }
    else
    {
        //cell.btnExpand.alpha = 0.0;
    }
    return cell;
}

-(void)showSubItems :(id) sender
{
    UIButton *btn = (UIButton*)sender;
    CGRect buttonFrameInTableView = [btn convertRect:btn.bounds toView:self.tableView];
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:buttonFrameInTableView.origin];
    
    if(btn.alpha==1.0)
    {
        if ([[btn imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"down-arrow.png"]])
        {
            [btn setImage:[UIImage imageNamed:@"up-arrow.png"] forState:UIControlStateNormal];
        }
        else
        {
            [btn setImage:[UIImage imageNamed:@"down-arrow.png"] forState:UIControlStateNormal];
        }
    }
    
    NSDictionary *d=[self.itemsInTable objectAtIndex:indexPath.row] ;
    NSArray *arr=[d valueForKey:@"SubItems"];
    if([d valueForKey:@"SubItems"])
    {
        BOOL isTableExpanded=NO;
        for(NSDictionary *subitems in arr )
        {
            NSInteger index=[self.itemsInTable indexOfObjectIdenticalTo:subitems];
            isTableExpanded=(index>0 && index!=NSIntegerMax);
            if(isTableExpanded) break;
        }
        
        if(isTableExpanded)
        {
            [self CollapseRows:arr];
        }
        else
        {
            NSUInteger count=indexPath.row+1;
            NSMutableArray *arrCells=[NSMutableArray array];
            for(NSDictionary *dInner in arr )
            {
                [arrCells addObject:[NSIndexPath indexPathForRow:count inSection:0]];
                [self.itemsInTable insertObject:dInner atIndex:count++];
            }
            [self.tableView insertRowsAtIndexPaths:arrCells withRowAnimation:UITableViewRowAnimationLeft];
        }
    }
}


- (IBAction)btnLogoutClicked:(id)sender
{
    [[SlideNavigationController sharedInstance]popToRootViewControllerAnimated:NO];
}

- (IBAction)btnShareClicked:(id)sender
{
//    ShareViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ShareViewController"];
//    [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
}

@end
