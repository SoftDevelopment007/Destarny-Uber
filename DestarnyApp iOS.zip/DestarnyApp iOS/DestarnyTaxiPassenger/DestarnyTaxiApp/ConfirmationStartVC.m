//
//  ConfirmationStartVC.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/19/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "ConfirmationStartVC.h"
#import "CellConfirmationStart.h"
#import "Utilits.h"
#import "AppDelegate.h"
#import "ServiceHelper.h"

@interface ConfirmationStartVC ()
{
    CLLocationManager *locationManager;
    double CurrentLatitude;
    double CurrentLongitude;
}
@property (nonatomic, retain)NSMutableArray *mArrayLocation;

@end

@implementation ConfirmationStartVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    _mArrayLocation = [[NSMutableArray alloc]init];
    _viewSearchLoc1.layer.cornerRadius = 5;
    _viewSearchLoc1.clipsToBounds = YES;
    
    [_txtSearch becomeFirstResponder];
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _mArrayLocation.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"CellConfirmationStart";
    CellConfirmationStart *cell = [_tblStartSearch dequeueReusableCellWithIdentifier:MyIdentifier];
    if (cell == nil)
    {
        cell = [[CellConfirmationStart alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
    }
    cell.lblLocPred.text = [_mArrayLocation objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _txtSearch.text = [_mArrayLocation objectAtIndex:indexPath.row];
    
    [[NSNotificationCenter defaultCenter]postNotificationName:@"SelectedLocation"
    object:_txtSearch.text];
    
    [self.navigationController popViewControllerAnimated:YES];
    
}


-(void)getCurrentLocation
{
    //current location latitude and longitude...
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    if ([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)])
    {
        [locationManager requestWhenInUseAuthorization];
    }
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    [locationManager startUpdatingLocation];
    CurrentLatitude = locationManager.location.coordinate.latitude;
    CurrentLongitude = locationManager.location.coordinate.longitude;
    NSLog(@" current location lat = %f & long = %f ",CurrentLatitude,CurrentLongitude);
}

- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self.txtSearchBar resignFirstResponder];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)SearchBar
{
    [_txtSearchBar resignFirstResponder];
}

- (IBAction)txtdidchange:(id)sender
{
    if ([Utilits Trim:_txtSearch.text].length>0)
    {
        [self getLocation];
    }
    else if([_txtSearch.text length]==0)
    {
        self.mArrayLocation=nil;
        [self.tblStartSearch reloadData];
    }
    else
    {
        [self.mArrayLocation removeAllObjects];
        [self.tblStartSearch reloadData];
    }
}

-(void)getLocation
{
    [self getCurrentLocation];
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSString *endPoint = [[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&lat=%f&longi=%f&radius=%@&sensor=true&key=AIzaSyC6SPQpZxZ_JGnUZNd8AKGeBOR8UkXHJtw",self.txtSearch.text,CurrentLatitude,CurrentLongitude,@"5000"]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [ServiceHelper getResponseWithEndPoint:endPoint success:^(id response)
     {
        if (response)
        {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                
                
                self.mArrayLocation = [[[response valueForKey:@"predictions"] valueForKey:@"description"]mutableCopy];
                [self.tblStartSearch reloadData];
                
            });
        }
    } error:^(NSError *error) {
        
    }];
    
    NSLog(@"mArrayLocation = %@",_mArrayLocation);
}

@end
