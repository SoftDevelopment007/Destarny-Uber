//
//  ConfirmationStartVC.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/19/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ConfirmationStartVC : UIViewController<CLLocationManagerDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tblStartSearch;
@property (strong, nonatomic) IBOutlet UISearchBar *txtSearchBar;
@property (weak, nonatomic) IBOutlet UITextField *txtSearch;

@property (strong, nonatomic) IBOutlet UIView *viewSearchLoc1;

- (IBAction)btnBackTapped:(id)sender;
- (IBAction)txtdidchange:(id)sender;

@end
