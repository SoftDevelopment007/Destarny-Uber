//
//  CustomAnnotation.m
//  DestarnyTaxiApp
//
//  Created by edreamz on 28/07/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "CustomAnnotation.h"

@implementation CustomAnnotation

@end
