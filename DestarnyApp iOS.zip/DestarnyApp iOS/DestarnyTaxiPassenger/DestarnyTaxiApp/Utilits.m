//
//  StringUtilityClass.m
//  HawaiiTours
//
//  Created by PD Maxter on 26/08/13.
//  Copyright (c) 2013 LinkITes LLC . All rights reserved.
//

#import "Utilits.h"
#import <UIKit/UIKit.h>

@implementation Utilits

+ (UIImage*)resizeImage:(UIImage*)aImage reSize:(CGSize)newSize
{
    UIGraphicsBeginImageContextWithOptions(newSize, YES, [UIScreen mainScreen].scale);
    // [aImage drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    [aImage drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}
+(NSString *)getDateFromTimeStamp:(NSString *)timeStamp{
    
    int time = [timeStamp intValue];
    NSDate *date = [NSDate dateWithTimeIntervalSinceNow:time];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"EEE hh:mm a"];
    
    return [formatter stringFromDate:date];
    
}
+(UIImage *)imageOptimized:(UIImage *)aImage
{
    int width = 320;
    int height = 480;
    float actualHeight = aImage.size.height;
    float actualWidth = aImage.size.width;
    float imgRatio = actualWidth/actualHeight;
    float maxRatio = width/height;
    
    if(imgRatio!=maxRatio){
        if(imgRatio < maxRatio){
            imgRatio = height / actualHeight;
            actualWidth = imgRatio * actualWidth;
            actualHeight = height;
        }
        else{
            imgRatio = width / actualWidth;
            actualHeight = imgRatio * actualHeight;
            actualWidth = width;
        }
    }
    CGRect rect = CGRectMake(0.0, 0.0, actualWidth, actualHeight);
    //UIGraphicsBeginImageContext(rect.size);
    UIGraphicsBeginImageContextWithOptions(rect.size, YES, [UIScreen mainScreen].scale);
    [aImage drawInRect:CGRectMake(0, 0, rect.size.width, rect.size.height)];
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return img;
}

+(void)donwloadFileFromUrl:(NSString *)url withName:(NSString *)filename ReturnCompletionBlock:(void (^)(id))completed
{
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    AFURLConnectionOperation *operation =   [[AFHTTPRequestOperation alloc] initWithRequest:request];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *filePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"CSV"];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath])
        [[NSFileManager defaultManager] createDirectoryAtPath:filePath withIntermediateDirectories:NO attributes:nil error:nil]; //Create folder if it doesn't already exist
    filePath = [filePath stringByAppendingPathComponent:filename];
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath])
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
    
    operation.outputStream = [NSOutputStream outputStreamToFileAtPath:filePath append:NO];
    
    [operation setDownloadProgressBlock:^(NSUInteger bytesRead, long long totalBytesRead, long long totalBytesExpectedToRead) {
        
    }];
    
    [operation setCompletionBlock:^{
       
        completed(filePath);
    }];
    
    
    [operation start];
    
    
}
+(void)sendEmailToEmail:(NSString *)receptEmail WithMessage:(NSString *)message inController:(UIViewController *)viewController
{
   
}
+(void)makeCallWithNumber:(NSString *)phone
{
    NSString *phoneNumber = [@"tel://" stringByAppendingString:phone];
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:phoneNumber]]) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
    }else
    {
        [Utilits ShowAlertMessageWithHeader:@"Alert" Message:@"Phone feature not availablel"];
    }
}

+(UIImage *)getDepartMentImage:(NSString *)departmentName
{departmentName = [departmentName lowercaseString];
   
    UIImage *image = image = [UIImage imageNamed:@"ca"];
    if ([departmentName rangeOfString:@"fire"].length>0) {
        image = [UIImage imageNamed:@"fire"];
    }else if ([departmentName rangeOfString:@"pgi"].length>0) {
         image = [UIImage imageNamed:@"pgi"];
    }else if ([departmentName rangeOfString:@"co-operative societies"].length>0 || [departmentName rangeOfString:@"co-op. house building societies"].length>0)
    {
         image = [UIImage imageNamed:@"coop"];
    }else if ([departmentName rangeOfString:@"election"].length>0)
    {
         image = [UIImage imageNamed:@"election"];
    }else if ([departmentName rangeOfString:@"employment"].length>0 )
    {
         image = [UIImage imageNamed:@"employment"];
    }else if ([departmentName rangeOfString:@"engineering"].length>0)
    {
         image = [UIImage imageNamed:@"engineering.jpg"];
        
    }else if ([departmentName rangeOfString:@"food & supplies"].length>0)
    {
      image = [UIImage imageNamed:@"food"];
    }else if ([departmentName rangeOfString:@"punjab raj bhawan"].length>0)
    {
         image = [UIImage imageNamed:@"rajbhawan"];
    }else if ([departmentName rangeOfString:@"mcc"].length>0 || [departmentName rangeOfString:@"municipal corporation"].length>0)
    {
         image = [UIImage imageNamed:@"mcc"];
    }else if ([departmentName rangeOfString:@"32"].length>0)
    {
         image = [UIImage imageNamed:@"gmch32"];
    }else if ([departmentName rangeOfString:@"spic"].length>0)
    {
         image = [UIImage imageNamed:@"spic.gif"];
    }else if ([departmentName rangeOfString:@"steps"].length>0)
    {
        image = [UIImage imageNamed:@"steps"];
        
    }else if ([departmentName rangeOfString:@"statistics"].length>0)
    {
         image = [UIImage imageNamed:@"statistics"];
    }else if ([departmentName rangeOfString:@"tourism"].length>0)
    {
         image = [UIImage imageNamed:@"tourism.gif"];
    }else if ([departmentName rangeOfString:@"chandigarh housing board"].length>0)
    {
        image = [UIImage imageNamed:@"chb"];
        
    }else if ([departmentName rangeOfString:@"electricity"].length>0)
    {
         image = [UIImage imageNamed:@"electricity"];
    }else if ([departmentName rangeOfString:@"medical college & hospital"].length>0)
    {
        
         image = [UIImage imageNamed:@"gmch32"];
    }else if ([departmentName rangeOfString:@"vety. hospital"].length>0||[departmentName rangeOfString:@"veterinary"].length>0)
    {
         image = [UIImage imageNamed:@"veterinary"];
    }else if ([departmentName rangeOfString:@"hospital"].length>0 || [departmentName rangeOfString:@"medical"].length>0)
    {
         image = [UIImage imageNamed:@"hospital"];
    }else if ([departmentName rangeOfString:@"bank"].length>0)
    {
      image = [UIImage imageNamed:@"bank"];
    }else if ([departmentName rangeOfString:@"education"].length>0 || [departmentName rangeOfString:@"school"].length>0)
    {
         image = [UIImage imageNamed:@"education"];
    }else if ([departmentName rangeOfString:@"prisons"].length>0)
    {
        image = [UIImage imageNamed:@"prison.png"];
    }else if ([departmentName rangeOfString:@"police"].length>0)
    {
        image = [UIImage imageNamed:@"police"];
    }else if ([departmentName rangeOfString:@"women"].length>0)
    {
        image = [UIImage imageNamed:@"womenchild.png"];
    }else if ([departmentName rangeOfString:@"women"].length>0)
    {
        image = [UIImage imageNamed:@"womenchild.png"];
    }else if ([departmentName rangeOfString:@"state transport authority"].length>0)
    {
        image = [UIImage imageNamed:@"truck"];
    }else if ([departmentName rangeOfString:@"chandigarh transport undertaking"].length>0)
    {
        image = [UIImage imageNamed:@"ctu"];
    }else if ([departmentName rangeOfString:@"hockey"].length>0)
    {
        image = [UIImage imageNamed:@"hockey"];
    }else if ([departmentName rangeOfString:@"information technology"].length>0)
    {
        image = [UIImage imageNamed:@"it"];
    }else if ([departmentName rangeOfString:@"sarva"].length>0)
    {
        image = [UIImage imageNamed:@"ssa"];
    }else if ([departmentName rangeOfString:@"treasury"].length>0)
    {
        image = [UIImage imageNamed:@"treasury"];
    }else if ([departmentName rangeOfString:@"animal husbandry & fisheries"].length>0)
    {
        image = [UIImage imageNamed:@"animalfisheries"];
    }else if ([departmentName rangeOfString:@"national informatics centre"].length>0 || [departmentName rangeOfString:@"national informatics center"].length>0)
    {
        image = [UIImage imageNamed:@"nic"];
    }
    
    return image;
}

+ (NSMutableArray *)loadAndParseWithStringData:(NSString*)stringData hasHeaderFields:(BOOL)hasHeaderFields{
    NSArray *gcRawData = [stringData componentsSeparatedByString:@"\n"];
    NSArray *singleGC = [NSArray array];
    NSMutableArray *allGC = [NSMutableArray array];
    for (int i = 0; i < gcRawData.count; i++)
    {
        NSString *nextGCString = [NSString stringWithFormat:@"%@", gcRawData[i]];
        singleGC = [nextGCString componentsSeparatedByString:@","];
        NSMutableArray *arrayOfComponents = [NSMutableArray array];
        for (int j=0; j<singleGC.count; j++) {
            NSString *str = [singleGC objectAtIndex:j];
            if([str hasPrefix:@"\""]) {
                for (int k=j+1; k<singleGC.count; k++) {
                    str = [str stringByAppendingFormat:@",%@",[singleGC objectAtIndex:k]];
                    j++;
                    if([str hasSuffix:@"\""] || [str hasSuffix:@"\"\r"]) {
                        break;
                    }
                }
            } else if([str hasPrefix:@"\'"]) {
                for (int k=j+1; k<singleGC.count; k++) {
                    str = [str stringByAppendingFormat:@",%@",[singleGC objectAtIndex:k]];
                    j++;
                    if([str hasSuffix:@"\'"] || [str hasSuffix:@"\'\r"]) {
                        break;
                    }
                }
            }
            [arrayOfComponents addObject:str];
        }
        [allGC addObject:arrayOfComponents];
    }
    if(hasHeaderFields) {
        NSArray *arrayOfHeader = [allGC objectAtIndex:0];
        NSMutableArray *newDataArray = [NSMutableArray array];
        for (NSArray *ar in allGC) {
            if([ar isEqual:arrayOfHeader]) continue;
            if(ar.count!=arrayOfHeader.count) continue;
            NSMutableDictionary *dOfRow = [NSMutableDictionary dictionary];
            for (NSString *strHeaderName in arrayOfHeader) {
                [dOfRow setObject:[ar objectAtIndex:[arrayOfHeader indexOfObject:strHeaderName]] forKey:strHeaderName];
            }
            [newDataArray addObject:dOfRow];
        }
        return newDataArray;
    }
    return allGC;
}

+ (NSString*)base64forData:(NSData*)theData
{
    const uint8_t* input = (const uint8_t*)[theData bytes];
    NSInteger length = [theData length];
    
    static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    
    NSMutableData* data = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    uint8_t* output = (uint8_t*)data.mutableBytes;
    
    NSInteger i;
    for (i=0; i < length; i += 3) {
        NSInteger value = 0;
        NSInteger j;
        for (j = i; j < (i + 3); j++) {
            value <<= 8;
            
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        NSInteger theIndex = (i / 3) * 4;
        output[theIndex + 0] =                    table[(value >> 18) & 0x3F];
        output[theIndex + 1] =                    table[(value >> 12) & 0x3F];
        output[theIndex + 2] = (i + 1) < length ? table[(value >> 6)  & 0x3F] : '=';
        output[theIndex + 3] = (i + 2) < length ? table[(value >> 0)  & 0x3F] : '=';
    }
    
    
    return [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding] ;
}

/************************************************
 Method				:	Color with hex string
 Purpose			:	Convert hex string to color code
 Parameters			:	None
 Return Value		:	None
 Modified By		:	Amit
 ************************************************/

-(UIColor*)colorWithHexString:(NSString*)hex
{
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor grayColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}

//- (CLLocationCoordinate2D) geoCodeUsingAddress:(NSString *)address
//{
//    double latitude = 0, longitude = 0;
//    NSString *esc_addr =  [address stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
//    NSString *result = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
//    if (result) {
//        NSScanner *scanner = [NSScanner scannerWithString:result];
//        if ([scanner scanUpToString:@"\"lat\" :" intoString:nil] && [scanner scanString:@"\"lat\" :" intoString:nil]) {
//            [scanner scanDouble:&latitude];
//            if ([scanner scanUpToString:@"\"lng\" :" intoString:nil] && [scanner scanString:@"\"lng\" :" intoString:nil]) {
//                [scanner scanDouble:&longitude];
//            }
//        }
//    }
//    CLLocationCoordinate2D center;
//    center.latitude = latitude;
//    center.longitude = longitude;
//    return center;
//}


/************************************************
 Method				:	validateEmail
 Purpose			:	Email Validation
 Parameters			:	None
 Return Value		:	None
 Modified By		:	Amit
 ************************************************/
+(BOOL)validateEmail:(NSString*)email  
{  
	if( (0 != [email rangeOfString:@"@"].length) &&  (0 != [email rangeOfString:@"."].length) )  
	{ 	
		NSMutableCharacterSet *invalidCharSet = [[[NSCharacterSet alphanumericCharacterSet] invertedSet]mutableCopy];  
		[invalidCharSet removeCharactersInString:@"_-"];  
		NSRange range1 = [email rangeOfString:@"@" options:NSCaseInsensitiveSearch];  
		NSString *usernamePart = [email substringToIndex:range1.location];  
		NSArray *stringsArray1 = [usernamePart componentsSeparatedByString:@"."];  
		for (NSString *string in stringsArray1) 
		{	NSRange rangeOfInavlidChars=[string rangeOfCharacterFromSet: invalidCharSet];  
			if(rangeOfInavlidChars.length !=0 || [string isEqualToString:@""])
				return NO;  
		}  
		NSString *domainPart = [email substringFromIndex:range1.location+1];  
		NSArray *stringsArray2 = [domainPart componentsSeparatedByString:@"."];  
		for (NSString *string in stringsArray2) 
		{	NSRange rangeOfInavlidChars=[string rangeOfCharacterFromSet:invalidCharSet];  
			if(rangeOfInavlidChars.length !=0 || [string isEqualToString:@""])  
				return NO;  
		}  
		return YES;
	}else 
        return NO;  
}



/************************************************
 Method				:	validateEmail
 Purpose			:	Email Validation
 Parameters			:	None
 Return Value		:	None
 Modified By		:	Amit
 ************************************************/
+(void)ShowAlertMessageWithHeader:(NSString*)header Message:(NSString*)message
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:header message:message
												   delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
	//NSMutableArray *buttonArray = [alert valueForKey:@"_buttons"];
	[alert show];
	//[[buttonArray objectAtIndex:0] setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
	//[alert release];
}


/************************************************
 Method				:	validateEmail
 Purpose			:	Email Validation
 Parameters			:	None
 Return Value		:	None
 Modified By		:	Amit
 ************************************************/
+(NSString*)Trim:(NSString*)value
{
	value = [value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return value;
}



/************************************************
 Method				:	validateEmail
 Purpose			:	Email Validation
 Parameters			:	None
 Return Value		:	None
 Modified By		:	Amit
 ************************************************/
-(NSString*)convertToXMLEntities:(NSString *) myString 
{
    NSMutableString * temp = [myString mutableCopy];
	
    [temp replaceOccurrencesOfString:@"&" withString:@"%26" options:0 range:NSMakeRange(0, [temp length])];
    //[temp replaceOccurrencesOfString:@"<" withString:@"&lt;" options:0 range:NSMakeRange(0, [temp length])];
    //[temp replaceOccurrencesOfString:@">" withString:@"&gt;" options:0 range:NSMakeRange(0, [temp length])];
    //[temp replaceOccurrencesOfString:@"\"" withString:@"&quot;" options:0 range:NSMakeRange(0, [temp length])];
    //[temp replaceOccurrencesOfString:@"'" withString:@"&apos;" options:0 range:NSMakeRange(0, [temp length])];
	
    return temp;
}



/************************************************
 Method				:	validateEmail
 Purpose			:	Email Validation
 Parameters			:	None
 Return Value		:	None
 Modified By		:	Amit
 ************************************************/

+(NSRange)fromString:(NSString *)frString rangeAfterString:(NSString *)inString  bySkippingNestedOpenTags:(NSString *)openTagStr toStartOfCloseTag:(NSString *)closeTagStr
{
	size_t    strLength = [frString length];
	size_t    foundLocation = 0, tagSearchLocation = 0;
	
	int       nestedOpenTagCnt = 0;
	
	NSRange   startStrRange = NSMakeRange (0, 0);
	NSRange   endStrRange   = NSMakeRange (strLength, 0);  // if no end string, end here
	NSRange   closingSearchRange, nestedSearchRange;
	NSRange   resultRange;
	
	if (inString)  {
		startStrRange = [frString rangeOfString:inString options:0 range:NSMakeRange(0, strLength)];
		if (startStrRange.location == NSNotFound)
			return (startStrRange);	// not found
		foundLocation = NSMaxRange (startStrRange);
		tagSearchLocation = foundLocation;
		nestedOpenTagCnt = 1;
	}
	
	do  {
		closingSearchRange = NSMakeRange (foundLocation, strLength - foundLocation);
		
		if (closeTagStr)  {
			endStrRange = [frString rangeOfString:closeTagStr options:0 range:closingSearchRange];
			if (endStrRange.location == NSNotFound)
				return (endStrRange);	// not found
			nestedOpenTagCnt--;
			foundLocation = endStrRange.location + [closeTagStr length];
		}
		
		if (openTagStr)  {
			nestedSearchRange = NSMakeRange(tagSearchLocation, NSMaxRange(closingSearchRange) - tagSearchLocation);
			nestedSearchRange = [frString rangeOfString:openTagStr options:0 range:nestedSearchRange];
			if (nestedSearchRange.location != NSNotFound)  {
				nestedOpenTagCnt++;	// not found
				tagSearchLocation = nestedSearchRange.location + [openTagStr length];
			}
		}
	} while (nestedOpenTagCnt > 0);
	
	size_t  rangeLoc = startStrRange.location + [inString length];
	size_t  rangeLen = NSMaxRange (endStrRange) - rangeLoc - [closeTagStr length];
	
	resultRange = NSMakeRange (rangeLoc, rangeLen);
	
	return (resultRange);
}



/************************************************
 Method				:	validateEmail
 Purpose			:	Email Validation
 Parameters			:	None
 Return Value		:	None
 Modified By		:	Amit
 ************************************************/
+(NSString *)removeHTMLStringFromString:(NSString *)html {
	
	NSScanner *theScanner;
	NSString *text = nil;
	theScanner = [NSScanner scannerWithString:html];
	while ([theScanner isAtEnd] == NO) {
		// find start of tag
		[theScanner scanUpToString:@"<" intoString:NULL] ;
		// find end of tag
		[theScanner scanUpToString:@">" intoString:&text] ;
		// replace the found tag with a space
		//(you can filter multi-spaces out later if you wish)
		html = [html stringByReplacingOccurrencesOfString:
				[ NSString stringWithFormat:@"%@>", text]
											   withString:@""];
	} // while //
	html = [html stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	return html;
}

/************************************************
 Method				:	validateEmail
 Purpose			:	Email Validation
 Parameters			:	None
 Return Value		:	None
 Modified By		:	Amit
 ************************************************/
+(void)SetUINavigationBarStyleWithImage:(NSString*)strImageName
{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] > 4.9) 
    {
        UIImage *image = [UIImage imageNamed:strImageName];
        [[UINavigationBar appearance] setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    }
}


/************************************************
 Method				:	validateEmail
 Purpose			:	Email Validation
 Parameters			:	None
 Return Value		:	None
 Modified By		:	Amit
 ************************************************/

+(void)changeNavigationBackGround:(UINavigationBar *)navBar imageName:(NSString *)imageName
{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] < 5)  {
        navBar.tintColor=[UIColor colorWithRed:100.0f/150.0f  green:0.0 blue:0.0 alpha:1.0f];
        //giving error on layer.contents
       // navigationBar.layer.contents=(id)[UIImage imageNamed:imageName].CGImage;
    }else{
        navBar.tintColor=[UIColor colorWithRed:100.0f/150.0f  green:0.0 blue:0.0 alpha:1.0f];
        [navBar setBackgroundImage:[UIImage imageNamed:imageName] forBarMetrics:UIBarMetricsDefault];
    }
}
/************************************************
 Method				:	validateEmail
 Purpose			:	Email Validation
 Parameters			:	None
 Return Value		:	None
 Modified By		:	Amit
 ************************************************/

+(void)changeNavigation:(UINavigationItem *)navigationItem Title:(NSString *)title CustomFontName:(NSString *)fontName
{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont fontWithName:fontName size:26];
    label.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor =[UIColor whiteColor];
    label.text=title;  
    navigationItem.titleView = label;      
    
}

//this method return the date in format of ago system
+(NSString *)dateDiff:(NSString *)origDate
{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setFormatterBehavior:NSDateFormatterBehavior10_4];
    [df setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSDate *convertedDate = [df dateFromString:origDate];
    // [df release];
    NSDate *todayDate = [NSDate date];
    double ti = [convertedDate timeIntervalSinceDate:todayDate];
    ti = ti * -1;
    if(ti < 1) {
        return @"never";
    } else if (ti < 60) {
        return @"less than a minute ago";
    } else if (ti < 3600) {
        int diff = round(ti / 60);
        return [NSString stringWithFormat:@"%d minutes ago", diff];
    } else if (ti < 86400) {
        int diff = round(ti / 60 / 60);
        return[NSString stringWithFormat:@"%d hours ago", diff];
    } else if (ti < 2629743) {
        int diff = round(ti / 60 / 60 / 24);
        return[NSString stringWithFormat:@"%d days ago", diff];
    } else if (ti < 31536000)
    {
        int diff = round(ti / 60 / 60 / 24 / 30);
        return[NSString stringWithFormat:@"%d months ago", diff];
    }
    else{
        int diff = round(ti / 60 / 60 / 24 / 365);
        return[NSString stringWithFormat:@"%d years ago", diff];
    }
    return @"never";
    
}

//this method will return the view controller with navigation controller 
+(id)GetNavigationToViewController:(UIViewController *)viewController
{
    UINavigationController *navigationController = [[UINavigationController alloc]initWithRootViewController:viewController];
    return navigationController;
}

//this method will return formatted String 
+(NSString *)GetFormattedString:(NSString *)strTitle
{
    NSString *encodedString = strTitle;
    NSString *decodedString = [NSString stringWithUTF8String:[encodedString cStringUsingEncoding:[NSString defaultCStringEncoding]]];
    return decodedString;
}


+ (NSDate *)strictDateFromDate:(NSDate *)date
{
    NSUInteger flags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit;
    NSDateComponents *components = [[NSCalendar currentCalendar] components:flags
                                                                   fromDate:date];
    
    NSString *stringDate = [NSString stringWithFormat:@"%ld/%ld/%ld 00:00:00 +0000", components.year,(long)components.month,(long)components.day];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy/MM/dd hh:mm:ss +0000";
    [formatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    
    return [formatter dateFromString:stringDate];
}


@end
