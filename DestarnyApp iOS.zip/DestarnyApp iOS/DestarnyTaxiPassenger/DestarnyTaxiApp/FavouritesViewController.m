//
//  FavouritesViewController.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//


#import "FavouritesViewController.h"
#import "CellPrevBookings.h"
#import "webManager.h"
#import "MBProgressHUD.h"
#import "ALToastView.h"

@interface FavouritesViewController ()
{
    NSMutableArray *arrPrevBookings,*arrFavBookings;
    NSString *strSelectedSeg;
    MBProgressHUD *HUD;
}
@end

@implementation FavouritesViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    arrPrevBookings = [[NSMutableArray alloc] init];
    arrFavBookings = [[NSMutableArray alloc] init];
    strSelectedSeg = [[NSString alloc] init];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    HUD.labelText = @"Loading";
    [self.view addSubview:HUD];
}

-(void)viewWillAppear:(BOOL)animated
{
    
    //-  prev bookings
    [HUD show:YES];
    [self getAllPrevBookings];
     strSelectedSeg = @"Prev";
    [_segPastNFav setSelectedSegmentIndex:0];
    
    //-----
    
    _tblPrevBookings.hidden = YES;
}

- (IBAction)segmentPastNFavChecked:(id)sender
{
    _segPastNFav = (UISegmentedControl *) sender;
    NSInteger selectedSegment = _segPastNFav.selectedSegmentIndex;
    if(selectedSegment == 0)
    {
        
        _tblPrevBookings.hidden = YES;
        [self getAllPrevBookings];
        strSelectedSeg = @"Prev";
        
    }
    else if (selectedSegment == 1)
    {
        
        _tblPrevBookings.hidden = YES;
        [self getAllFavBookings];
        strSelectedSeg = @"Past";
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(void)getAllFavBookings
{
    /*
     
     http://dev12.edreamz3.com/destarny_taxi_app/api/passanger_get_all_favourite_booking.php
     Passenger get all favourites booking must be POST method
     
     cid : <Passenger ID>
     
     ////---- new API
     
     http://dev12.edreamz3.com/api/passenger.php/getfavoritesbooking/?cid=9
     
     */
    [HUD show:YES];
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *myString = [prefs stringForKey:@"passengerID"];
    
    NSDictionary * param = @{@"cid":myString};
    
    [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/getfavoritesbooking/?" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
         NSString *strStatus = [[response valueForKey:@"status"] stringValue];
         [HUD hide:YES];
        /*
         
         {
         items =     (
         {
         acceptdate = "0000-00-00 00:00:00";
         "appx_calfare" = "0.00";
         "appx_distance" = "2.3 km";
         "appx_duration" = "8 mins";
         "appx_duration_in_traffic" = "9 mins";
         "booking_date" = "2016-04-27";
         "booking_from" = "Deccan Gymkhana, Pune, Maharashtra, India";
         "booking_from_lat" = "18.51756";
         "booking_from_lng" = "73.84166";
         "booking_status" = Droped;
         "booking_time" = "11:52:00";
         "booking_to" = "Shivajinagar, Pune, Maharashtra, India";
         "booking_to_lat" = "18.53082";
         "booking_to_lng" = "73.84747";
         "booking_type" = Advance;
         cid = 13;
         collectdate = "0000-00-00 00:00:00";
         did = 0;
         dropdate = "0000-00-00 00:00:00";
         "fare_type" = Taximeter;
         fareid = 0;
         "favorites_booking" = 1;
         id = 32;
         noofpass = 2;
         notes = note;
         opendate = "2016-04-21 06:23:46";
         "setfare_unfullfilled" = 0;
         "tot_distance" = "0.00";
         "tot_duration" = "0.00";
         "tot_fare" = "0.00";
         vtid = 2;
         }
         );
         status = 1;
         }
         
         */
         
         if([strStatus isEqualToString:@"1"])
         {
             arrFavBookings = [response valueForKey:@"items"];
             [_tblPrevBookings reloadData];
             _tblPrevBookings.hidden = NO;
         }
         else if([strStatus isEqualToString:@"0"])
         {
             NSString  *msg = [NSString stringWithFormat:@"%@",[response valueForKey:@"items"]];
             if ([msg isEqualToString:@"<null>"])
             {
                 msg = @"Record Not Found.";
             }
             [ALToastView toastInView:self.view withText:msg];
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:msg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             [alert show];
         }

     }failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
         [ALToastView toastInView:self.view withText:@"Failed to get favorite bookings."];
//         UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Failed to get favorite bookings." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//         
//         [alert show];
         [HUD hide:YES];
     }];
}

-(void)getAllPrevBookings
{
    /*
     
     Parameter:
     http://dev12.edreamz3.com/destarny_taxi_app/api/get_all_past_booking_by_cid.php
     Passenger get all past booking must be POST method
     
     cid : <Passenger ID
     
     ////--- new
     http://dev12.edreamz3.com/api/passenger.php/completedbookingforpass/?cid=9
     
     */
    [HUD show:YES];
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *myString = [prefs stringForKey:@"passengerID"];
    
    NSDictionary * param = @{@"cid":myString};
    
    [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/completedbookingforpass/?" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
         NSString *strStatus = [[response valueForKey:@"status"] stringValue];
         [HUD hide:YES];
         /*
          
          {
          items =     (
          {
          acceptdate = "0000-00-00 00:00:00";
          "appx_calfare" = "0.00";
          "appx_distance" = "2.3 km";
          "appx_duration" = "8 mins";
          "appx_duration_in_traffic" = "9 mins";
          "booking_date" = "2016-04-27";
          "booking_from" = "Deccan Gymkhana, Pune, Maharashtra, India";
          "booking_from_lat" = "18.51756";
          "booking_from_lng" = "73.84166";
          "booking_status" = Droped;
          "booking_time" = "11:52:00";
          "booking_to" = "Shivajinagar, Pune, Maharashtra, India";
          "booking_to_lat" = "18.53082";
          "booking_to_lng" = "73.84747";
          "booking_type" = Advance;
          cid = 13;
          collectdate = "0000-00-00 00:00:00";
          did = 0;
          dropdate = "0000-00-00 00:00:00";
          "fare_type" = Taximeter;
          fareid = 0;
          "favorites_booking" = 0;
          id = 32;
          noofpass = 2;
          notes = note;
          opendate = "2016-04-21 06:23:46";
          "setfare_unfullfilled" = 0;
          "tot_distance" = "0.00";
          "tot_duration" = "0.00";
          "tot_fare" = "0.00";
          vtid = 2;
          }
          );
          status = 1;
          }
          
          */
         
         if([strStatus isEqualToString:@"1"])
         {
             arrPrevBookings = [response valueForKey:@"items"];
             [_tblPrevBookings reloadData];
             _tblPrevBookings.hidden = NO;
         }
         else if([strStatus isEqualToString:@"0"])
         {
             NSString  *msg = [NSString stringWithFormat:@"%@",[response valueForKey:@"items"]];
             if ([msg isEqualToString:@"<null>"])
             {
                 msg = @"Record Not Found.";
             }
             [ALToastView toastInView:self.view withText:msg];
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:msg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             [alert show];
         }
     }failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
         [ALToastView toastInView:self.view withText:@"Failed to get past bookings."];
//         UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Failed to get past bookings." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//         
//         [alert show];
         [HUD hide:YES];
     }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if([strSelectedSeg isEqualToString:@"Prev"])
    {
        return arrPrevBookings.count;
    }
    else //if([strSelectedSeg isEqualToString:@"Past"])
    {
        return arrFavBookings.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"CellPrevBookings";
    CellPrevBookings *cell = [_tblPrevBookings dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if (cell == nil)
    {
        cell = [[CellPrevBookings alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
    }

    cell.btnAddToFav.hidden = NO;
    if([strSelectedSeg isEqualToString:@"Prev"])
    {
        NSString *strStart = [[arrPrevBookings objectAtIndex:indexPath.row] valueForKey:@"booking_from"];
        NSString *strDest = [[arrPrevBookings objectAtIndex:indexPath.row] valueForKey:@"booking_to"];
        
        cell.lblBookingFrom.text = [NSString stringWithFormat:@": %@",strStart];
        cell.lblBookingTo.text = [NSString stringWithFormat:@": %@",strDest];
        cell.lblDistance.text = [NSString stringWithFormat:@": %@ Km",[[arrPrevBookings objectAtIndex:indexPath.row] valueForKey:@"tot_distance"]];
        cell.lblDuration.text = [NSString stringWithFormat:@": %@ Min",[[arrPrevBookings objectAtIndex:indexPath.row] valueForKey:@"tot_duration"]];
        cell.lblCost.text = [NSString stringWithFormat:@": $ %@",[[arrPrevBookings objectAtIndex:indexPath.row] valueForKey:@"tot_fare"]];
        
        
        //----
        NSString *strFav = [NSString stringWithFormat:@"%@",[[arrPrevBookings objectAtIndex:indexPath.row] valueForKey:@"favorites_booking"]];
        if ([strFav isEqualToString:@"1"])
        {
            [cell.btnAddToFav setImage:[UIImage imageNamed:@"star_filled"] forState:UIControlStateNormal];
        }
        else
        {
            [cell.btnAddToFav setImage:[UIImage imageNamed:@"star.png"] forState:UIControlStateNormal];
        }
        cell.btnAddToFav.hidden = NO;
        cell.btnAddToFav.tag = indexPath.row;
        [cell.btnAddToFav addTarget:self action:@selector(btnAddToFavClicked:) forControlEvents:UIControlEventTouchUpInside];
        //------
    }
    else
    {
        NSString *strStart = [[arrFavBookings objectAtIndex:indexPath.row] valueForKey:@"booking_from"];
        NSString *strDest = [[arrFavBookings objectAtIndex:indexPath.row] valueForKey:@"booking_to"];
        
        cell.lblBookingFrom.text = [NSString stringWithFormat:@"%@",strStart];
        cell.lblBookingTo.text = [NSString stringWithFormat:@"%@",strDest];
        cell.lblDistance.text = [NSString stringWithFormat:@"%@ Km",[[arrFavBookings objectAtIndex:indexPath.row] valueForKey:@"tot_distance"]];
        cell.lblDuration.text = [NSString stringWithFormat:@"%@ Min",[[arrFavBookings objectAtIndex:indexPath.row] valueForKey:@"tot_duration"]];
        cell.lblCost.text = [NSString stringWithFormat:@"$ %@",[[arrFavBookings objectAtIndex:indexPath.row] valueForKey:@"tot_fare"]];

        
        //---
        [cell.btnAddToFav setImage:[UIImage imageNamed:@"star_filled"] forState:UIControlStateNormal];
        cell.btnAddToFav.userInteractionEnabled = NO;
       // cell.btnAddToFav.hidden = YES;
    }
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}

-(void)btnAddToFavClicked:(UIButton*)sender
{
    if (sender.tag == 0)
    {
        NSLog(@"sender 0");
    }
    
    NSInteger bTag = sender.tag;
    NSString *inStr = [NSString stringWithFormat:@"%ld", (long)bTag ];
    /*
     
     Parameter:
     http://dev12.edreamz3.com/destarny_taxi_app/api/passanger_add_favourite_booking.php
     Passenger add favourites booking must be POST method
     
     cid : <Passenger ID>
     btid: <past booking ID>
     
     // new API
     http://dev12.edreamz3.com/api/passenger.php/setfavoritesbooking/?bid=1
     
     */
    
    NSString *strBid = [[arrPrevBookings objectAtIndex:bTag] valueForKey:@"id"];

    NSDictionary * param = @{@"bid":strBid};
    
    [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/setfavoritesbooking/?" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
         NSString *strStatus = [[response valueForKey:@"status"] stringValue];
         
         /*
          
          {
          Response =     {
          ErrorCode = 0;
          Message = "Request_Successful";
          };
          status = Success;
          }
          
          */
         
         if([strStatus isEqualToString:@"1"])
         {
             [self getAllPrevBookings];
             [_tblPrevBookings reloadData];
         }
         else if([strStatus isEqualToString:@"0"])
         {
             [ALToastView toastInView:self.view withText:[response valueForKey:@"items"]];
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil message:[response valueForKey:@"items"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             
//             [alert show];
         }
     }failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
         [ALToastView toastInView:self.view withText:@"Failed to get past bookings."];
//         UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil message:@"Failed to get past bookings." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//         
//         [alert show];
     }];
}

@end
