//
//  CurrentBookingStatus.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "CurrentBookingStatus.h"
#import "webManager.h"
#import "CellCurrentBookingStatus.h"
#import "MBProgressHUD.h"
#import "ALToastView.h"

@interface CurrentBookingStatus ()
{
    NSMutableArray *arrBookings;
    NSString *bid;
    MBProgressHUD *HUD;
}
@end

@implementation CurrentBookingStatus

- (void)viewDidLoad
{
    [super viewDidLoad];
    arrBookings = [[NSMutableArray alloc] init];
    // Do any additional setup after loading the view.
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    HUD.labelText = @"Loading";
    [self.view addSubview:HUD];

    cancelView.hidden = YES;
    lblNote.layer.borderColor = [UIColor redColor].CGColor;
    lblNote.layer.borderWidth = 1.0;
    
    txtReason.layer.borderWidth = 0.5;
    txtReason.layer.borderColor = [UIColor lightGrayColor].CGColor;
 //   txtReason.text = @"Please enter the reason for cancelling";
    cancelView.layer.cornerRadius = 2.0;
    btnNo.layer.cornerRadius = 2.0;
    btnYes.layer.cornerRadius = 2.0;
    
    UITapGestureRecognizer *tapRec = [[UITapGestureRecognizer alloc]
                                      initWithTarget:self action:@selector(tap)];
    [tapRec setCancelsTouchesInView:NO];
    [_tblBookingStatus addGestureRecognizer:tapRec];
}
-(void)tap
{
    _tblBookingStatus.scrollEnabled = YES;
    cancelView.hidden = YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [self animateTextView: YES];
    if ([textView.text isEqualToString:@"Please enter the reason for cancelling"]) {
        textView.text = @"";
        textView.textColor = [UIColor blackColor]; //optional
    }
    
    [textView becomeFirstResponder];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    [self animateTextView: NO];
    if ([textView.text isEqualToString:@""]) {
        textView.text = @"Please enter the reason for cancelling";
        textView.textColor = [UIColor lightGrayColor]; //optional
    }
    [textView resignFirstResponder];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [txtReason resignFirstResponder];
}
-(void)viewWillAppear:(BOOL)animated
{
    [self getCurrentBookingStatus];
}
-(IBAction)btnRefreshTapped:(id)sender
{
    [self getCurrentBookingStatus];
}
-(void)getCurrentBookingStatus
{
    /*
     
     http://dev12.edreamz3.com/destarny_taxi_app/api/get_passanger_current_booking_status.php
     
     */
    
   
    [HUD show:YES];
    
    NSDictionary *dict = [[NSUserDefaults standardUserDefaults]valueForKey:@"dicPassengerDetails"];
    NSString *strCid = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
    NSDictionary * param=@{@"cid":strCid};
    
    
    [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/acceptedbooking/?" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
                  NSError *e = nil;
         NSString *strStatus = [response valueForKey:@"status"];
         [HUD hide:YES];
         if([[response valueForKey:@"status"] boolValue]==1)
         {
             [HUD hide:YES];
             arrBookings = [response valueForKey:@"items"];
             [_tblBookingStatus reloadData];
         }
         else if([[response valueForKey:@"status"] boolValue]==0)
         {
           //  NSString *msg = [response valueForKey:@"items"];
             [ALToastView toastInView:self.view withText:@"No Records Found."];
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"No Records Found." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             [alert show];

             [HUD hide:YES];
         }
         
     }failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
         [ALToastView toastInView:self.view withText:@"Failed to get current booking status."];
//         UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Failed to get current booking status." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//         [alert show];
         [HUD hide:YES];
     }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrBookings.count;    //count number of row from counting array hear cataGorry is An Array
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"CellCurrentBookingStatus";
    CellCurrentBookingStatus *cell = [_tblBookingStatus dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if (cell == nil)
    {
        cell = [[CellCurrentBookingStatus alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
    }
    [cell.contentView.layer setBorderColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1].CGColor];
    [cell.contentView.layer setBorderWidth:1.0f];
    
    
    
    NSString *did = [NSString stringWithFormat:@"%@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"did"]];
    
    NSString *fname = [NSString stringWithFormat:@"%@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"fname"]];
  
    if ([did isEqualToString:@"0"] || [fname isEqualToString:@"(null)"] || [fname length]==0)
    {
        tableView.rowHeight = 320.0f;
        cell.lblBookingFrom.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"booking_from"]];
        cell.lblBookingTo.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"booking_to"]];
        cell.lblBookingTime.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"booking_time"]];
        cell.lblBookingType.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"booking_type"]];
        cell.lblDistance.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"appx_distance"]];
        cell.lblDuration.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"appx_duration"]];
        
        //
        cell.lblPassenger.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"noofpass"]];
        cell.lblETAT.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"appx_duration_in_traffic"]];
        
        cell.lbl1.hidden = cell.lbl2.hidden = cell.lbl3.hidden = cell.lbl4.hidden = cell.lbl5.hidden = cell.lbl6.hidden = cell.lblDriverName.hidden = cell.lblContactNumber.hidden = cell.lblModelNumber.hidden = cell.lblTaxiNumberPlate.hidden = cell.lblMade.hidden = cell.lbl7.hidden = cell.lblRego.hidden = YES;
        cell.btnCall.hidden = YES;
        //        CGRect frame1 = cell.btnCancelBooking.frame;
//        frame1.origin.y=300;
       
        cell.btnCancelBooking.hidden = YES;
         cell.btnCancelBookingPassenger.hidden = NO;
        cell.btnCancelBookingPassenger.tag = indexPath.row;
        [cell.btnCancelBookingPassenger addTarget:self action:@selector(cancelBooking:) forControlEvents:UIControlEventTouchUpInside];
    }
    else
    {
        cell.lbl1.hidden = cell.lbl2.hidden = cell.lbl3.hidden = cell.lbl4.hidden = cell.lbl5.hidden = cell.lbl6.hidden = cell.lbl7.hidden = cell.lblRego.hidden = cell.lblDriverName.hidden = cell.lblContactNumber.hidden = cell.lblModelNumber.hidden = cell.lblTaxiNumberPlate.hidden = cell.lblMade.hidden = NO;
        cell.btnCall.hidden = NO;
        tableView.rowHeight = 484.0f;
        cell.lblBookingFrom.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"booking_from"]];
        cell.lblBookingTo.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"booking_to"]];
        cell.lblBookingTime.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"booking_time"]];
        cell.lblBookingType.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"booking_type"]];
        cell.lblDistance.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"appx_distance"]];
        cell.lblDuration.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"appx_duration"]];
        //
        cell.lblPassenger.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"noofpass"]];
        cell.lblETAT.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"appx_duration_in_traffic"]];
        cell.btnCancelBookingPassenger.hidden = YES;
        cell.btnCancelBooking.hidden = NO;
        cell.lblDriverName.text = [NSString stringWithFormat:@": %@ %@",[[arrBookings objectAtIndex:indexPath.row ] valueForKey:@"fname"],[[arrBookings objectAtIndex:indexPath.row] valueForKey:@"lname"]];
        cell.lblRego.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"driver_noplate"]];
        cell.lblContactNumber.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"phone_no"]];
        
        cell.lblModelNumber.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row]valueForKey:@"modelno"]];
        
        cell.lblTaxiNumberPlate.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row] valueForKey:@"driver_noplate"]];
        
        cell.lblMade.text = [NSString stringWithFormat:@": %@",[[arrBookings objectAtIndex:indexPath.row] valueForKey:@"made"]];
        cell.btnCancelBooking.tag = indexPath.row;
        [cell.btnCancelBooking addTarget:self action:@selector(cancelBooking:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    cell.btnCall.tag = indexPath.row;
    
    [cell.btnCall addTarget:self action:@selector(callDriver:) forControlEvents:UIControlEventTouchUpInside];
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

-(void)cancelBooking:(UIButton *)sender
{
    _tblBookingStatus.scrollEnabled = NO;
    cancelView.hidden = NO;
    NSInteger i = sender.tag;
//    NSIndexPath *indexpath = [NSIndexPath indexPathForRow:sender.tag inSection:0];
//   CellCurrentBookingStatus *cell = (CellCurrentBookingStatus *)[_tblBookingStatus cellForRowAtIndexPath:indexpath];
     bid = [[arrBookings objectAtIndex:i] valueForKey:@"id"];
}

-(void)callDriver:(UIButton *)sender
{
    NSInteger i = sender.tag;
//    NSIndexPath *indexpath = [NSIndexPath indexPathForRow:sender.tag inSection:0];
//    CellCurrentBookingStatus *cell = (CellCurrentBookingStatus *)[_tblBookingStatus cellForRowAtIndexPath:indexpath];
    NSString *strPhone = [[arrBookings objectAtIndex:i] valueForKey:@"phone_no"];
 //   NSString *phoneNumber = [@"telprompt://" stringByAppendingString:strPhone];
 //   [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
    
   
    NSURL *phoneUrl = [NSURL URLWithString:[NSString  stringWithFormat:@"telprompt:%@",strPhone]];
    
    if ([[UIApplication sharedApplication] canOpenURL:phoneUrl])
    {
        [[UIApplication sharedApplication] openURL:phoneUrl];
    }
    else
    {
        [ALToastView toastInView:self.view withText:@"Call facility is not available!!!"];
//       UIAlertView *calert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Call facility is not available!!!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [calert show];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}


-(IBAction)btnYesTapped:(id)sender
{
    //http://dev12.edreamz3.com/api/passenger.php/cancelbooking/?bid=1&cid=1&cancel_reason=Hello
 //   NSDictionary *dict = [[NSUserDefaults standardUserDefaults]valueForKey:@"dicPassengerDetails"];
    NSString *savedValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
   // NSString *strCid = [dict valueForKey:@"tcid"];
    NSString *strBid = [NSString stringWithFormat:@"%@",bid];
    _tblBookingStatus.scrollEnabled = YES;
    if ([txtReason.text length]==0 || [txtReason.text isEqualToString:@"Please enter the reason for cancelling."])
    {
        [ALToastView toastInView:self.view withText:@"Please enter the reason for cancelling."];
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please enter the reason for cancelling." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [alert show];
    }
    else
    {
    NSDictionary * param=@{@"cid":savedValue,@"bid":strBid,@"cancel_reason":txtReason.text};
    
    [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/cancelbooking/?" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
         NSError *e = nil;
         
         if([[response valueForKey:@"status"] boolValue]==1)
         {
             [ALToastView toastInView:self.view withText:@"Booking cancelled successfully."];
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil message:@"Booking cancelled successfully." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             [alert show];
             [self getCurrentBookingStatus];
             //   [_tblBookingStatus reloadData];
         }
         else if([[response valueForKey:@"status"] boolValue]==0)
         {
             NSString *msg = [NSString stringWithFormat:@"%@",[response valueForKey:@"items"]];
             [ALToastView toastInView:self.view withText:msg];
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil message:msg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             [alert show];
         }

     }failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
         [ALToastView toastInView:self.view withText:@"Failed to cancel booking."];
//         UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil message:@"Failed to cancel booking." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//         [alert show];
         [_tblBookingStatus reloadData];
     }];
    }
   
    cancelView.hidden = YES;
    [txtReason resignFirstResponder];
    txtReason.text = @"";
}

-(IBAction)btnNoTapped:(id)sender
{
    [txtReason resignFirstResponder];
    _tblBookingStatus.scrollEnabled = YES;
    cancelView.hidden = YES;
    txtReason.text = @"";
}


-(IBAction)bttnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) animateTextField: (UITextField*) textField up: (BOOL) up
{
    const int movementDistance = textField.frame.origin.y / 2; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}

- (void) animateTextView:(BOOL) up
{
    
    const int movementDistance =txtReason.frame.origin.y / 2; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed
    int movement= movement = (up ? -movementDistance : movementDistance);
    NSLog(@"%d",movement);
    
    [UIView beginAnimations: @"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}


@end
