//
//  Taxi_Booking_Form_ViewController.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/24/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SBFlatDatePicker.h"
#import "SBFlatDatePickerDelegate.h"
#import "SlideNavigationController.h"
#import "DatePicker.h"
#import "DatePickerDelegate.h"
//#import "WebManager.h"
#import "TaxiBookingForm_TableViewCell.h"
#import "TaxiBookingForm_TableViewCell1.h"
#import "CustomIOSAlertView.h"

@interface Taxi_Booking_Form_ViewController : UIViewController<SBFLatDatePickerDelegate,DatePickerDelegate,UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UIScrollViewDelegate>
{
    SBFlatDatePicker *timePicker;
    DatePicker * datePicker;
    IBOutlet UIScrollView *scroll;
}
@property (strong, nonatomic) IBOutlet UITableView *tblSetFare;

@property (weak, nonatomic) IBOutlet UILabel *lblTime;

@property (weak, nonatomic) IBOutlet UILabel *lbldate;

@property (weak, nonatomic) IBOutlet UIButton *btnTime;

@property (weak, nonatomic) IBOutlet UIButton *btnCalender;


@property (weak, nonatomic) IBOutlet UIButton *btnToday;

@property (strong, nonatomic) IBOutlet UIButton *btnSetfare;


- (IBAction)btnTimeClicked:(id)sender;


- (IBAction)btnSetfareTapped:(id)sender;


@property (weak, nonatomic) IBOutlet UITextField *txtNoofPassenger;

@property(nonatomic,retain)NSMutableArray * initialPlaces;

@property (nonatomic,retain)NSMutableArray * filteredPlaces;

@property(nonatomic)BOOL isFiltered;

@property (weak, nonatomic) IBOutlet UITableView *tableViewSearch;


@property (weak, nonatomic) IBOutlet UITableView *tableViewSearch1;


@property(nonatomic,retain) NSString * selectedVehicle;


@property (weak, nonatomic) IBOutlet UITextField *txtFrom;

@property (weak, nonatomic) IBOutlet UITextField *txtTo;

@property (weak, nonatomic) IBOutlet UITextField *txtTime;


@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;

//@property (weak, nonatomic) IBOutlet UIButton *btnTime;

@property (weak, nonatomic) IBOutlet UIButton *btnDay;
//@property (weak, nonatomic) IBOutlet UIButton *btnCalender;
@property (weak, nonatomic) IBOutlet UIButton *btnNow;
@property (weak, nonatomic) IBOutlet UIButton *btnDone;
@property (weak, nonatomic) IBOutlet UIButton *btnBookTaxiNOw;
@property (weak, nonatomic) IBOutlet UIView *myView;

@property (weak, nonatomic) IBOutlet UIView *view1;


- (IBAction)btnBackClicked:(id)sender;


- (IBAction)btnBookTaxiNowClicked:(id)sender;

- (IBAction)btnCalenderClicked:(id)sender;

- (IBAction)btnTodayClicked:(id)sender;

- (IBAction)btnTomorrowClicked:(id)sender;



//____________ property for checking vehicleType selected_____________

@property (nonatomic,retain)NSString * selectedVehicleType;

- (IBAction)btnStandardClicked:(id)sender;

- (IBAction)btnVanClicked:(id)sender;

- (IBAction)btnPremiumClicked:(id)sender;

@property (weak, nonatomic) IBOutlet UIImageView *imgStandard;

@property (weak, nonatomic) IBOutlet UIImageView *imgVan;

@property (weak, nonatomic) IBOutlet UIImageView *imgPremium;



//______________array to define maximum of number of Passenger ________

@property(nonatomic,retain)NSArray * no_of_passenger_Standard;

@property(nonatomic,retain)NSArray * no_of_passenger_van;

@property (nonatomic,retain)NSArray * no_of_passenegr_premium;

@property (weak, nonatomic) IBOutlet UITableView *tableviewNoOfPassenger;

@property (weak, nonatomic) IBOutlet UIButton *btnNoOfPasseneger;

- (IBAction)btnNoofPassengerClicked:(id)sender;

@property (weak, nonatomic) IBOutlet UILabel *lblNoOfPassenegr;


- (IBAction)btnDoneClicked:(id)sender;



//_____________ goloyal View Propertiees and Actions________



@property ( nonatomic) IBOutlet UIImageView *imgviewYes;

@property ( nonatomic) IBOutlet UIImageView *imgviewNo;

@property (nonatomic) IBOutlet UIButton *btnYes;

@property ( nonatomic) IBOutlet UIButton *btnNo;

@property ( nonatomic) IBOutlet UIButton *btnAddGoLoyal;


@property ( nonatomic) IBOutlet UIView *viewGoLoyal;




- (IBAction)btnNoClicked:(id)sender;

- (IBAction)btnYesClicked:(id)sender;


//--- (IBAction)btnDoneClicked:(id)sender;


//-------- new - changes in ----------

@property (strong, nonatomic) IBOutlet UITextField *txtMySetFare;
@property (strong, nonatomic) IBOutlet UITextField *txtNoOfPassenger;
@property (strong, nonatomic) IBOutlet UIImageView *imgMeteredTaxi;

//-----

- (IBAction)btnMeteredTaxiTapped:(id)sender;

//-----

@property (strong, nonatomic) IBOutlet UITableView *tblStartAdd;
@property (strong, nonatomic) IBOutlet UITableView *tblDestAdd;


@property (strong, nonatomic) IBOutlet UIButton *btnMeteredTaxi;
@property (strong, nonatomic) IBOutlet UIButton *btnAny;
@property (strong, nonatomic) IBOutlet UIButton *btnWagon;
@property (strong, nonatomic) IBOutlet UIButton *btnPremium;
@property (strong, nonatomic) IBOutlet UILabel *lblSetFarefulfield;

- (IBAction)btnAnyTapped:(id)sender;
- (IBAction)btnPremiumTapped:(id)sender;
- (IBAction)btnWagonTapped:(id)sender;

- (IBAction)btnFareTypeTapped:(id)sender;


@end
