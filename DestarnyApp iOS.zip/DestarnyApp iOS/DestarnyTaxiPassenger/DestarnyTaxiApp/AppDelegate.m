//
//  AppDelegate.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/2/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "AppDelegate.h"
#import "SlidebarViewController.h"
#import "LoginViewController.h"
#import "Set_PickUp_Location_ViewController.h"
#import "SignInViewController.h"
#import "webManager.h"
//#import <Stripe/Stripe.h>
#define kGoogleAPIKey @"AIzaSyA_fUVkv-X8d6_PIx04iPSNkeuaDdDl0wY"
@interface AppDelegate ()
{
    NSInteger badgeCount;
}

@end


NSString *const SubscriptionTopic = @"/topics/global";


@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
 //   [Stripe setDefaultPublishableKey:@"pk_test_VDJL9n9Rfkx3kNMwLxlfTq0k"];
 
    NSString *strLogin = [[NSUserDefaults standardUserDefaults] stringForKey:@"login"];
    if([strLogin isEqualToString:@"YES"])
    {
        //----  navigate to next dirctly if already login
        
        Set_PickUp_Location_ViewController *loginController=[[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"Set_PickUp_Location_ViewController"]; //or the homeController
        UINavigationController *navController=[[UINavigationController alloc]initWithRootViewController:loginController];
       
        self.window.rootViewController = navController;
        
        ////-----------

    }
    else
    {
        //----  navigate to next dirctly if not already login
        
        SignInViewController *loginController=[[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"SignInViewController"]; //or the homeController
        UINavigationController *navController=[[UINavigationController alloc]initWithRootViewController:loginController];

        self.window.rootViewController = navController;
        
        //----
    }
    
    
    UIUserNotificationType userNotificationTypes = (UIUserNotificationTypeAlert |
                                                    UIUserNotificationTypeBadge |
                                                    UIUserNotificationTypeSound);
    UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:userNotificationTypes categories:nil];
    [application registerUserNotificationSettings:settings];
    [application registerForRemoteNotifications];
    
    _registrationKey = @"onRegistrationCompleted";
    _messageKey = @"onMessageReceived";
    // Configure the Google context: parses the GoogleService-Info.plist, and initializes
    // the services that have entries in the file
    NSError* configureError;
    [[GGLContext sharedInstance] configureWithError:&configureError];
    NSAssert(!configureError, @"Error configuring Google services: %@", configureError);
    _gcmSenderID = [[[GGLContext sharedInstance] configuration] gcmSenderID];
    
    
    GCMConfig *gcmConfig = [GCMConfig defaultConfig];
    gcmConfig.receiverDelegate = self;
    
    [[GCMService sharedInstance] startWithConfig:gcmConfig];
    // [END start_gcm_service]
    __weak typeof(self) weakSelf = self;
    // Handler for registration token request
    _registrationHandler = ^(NSString *registrationToken, NSError *error){
        if (registrationToken != nil)
        {
            weakSelf.registrationToken = registrationToken;
            NSLog(@"Registration Token: %@", registrationToken);
            [[NSUserDefaults standardUserDefaults] setObject:registrationToken forKey:@"DeviceID"];
            NSDictionary *userInfo = @{@"registrationToken":registrationToken};
            [[NSUserDefaults standardUserDefaults]setObject:registrationToken forKey:@"DeviceToken"];
            [[NSNotificationCenter defaultCenter] postNotificationName:weakSelf.registrationKey
                                                                object:nil
                                                              userInfo:userInfo];
        }
        else
        {
            NSLog(@"%@",error.description);
            NSLog(@"Registration to GCM failed with error: %@", error.localizedDescription);
            NSDictionary *userInfo = @{@"error":error.localizedDescription};
            [[NSNotificationCenter defaultCenter] postNotificationName:weakSelf.registrationKey
                                                                object:nil
                                                              userInfo:userInfo];
        }
    };
    
    
    ////---------------------------------------
    
    // [START_EXCLUDE]
       
    return YES;
}
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
   
        //____________ Used to get the device token and store that device token as MID in the App._______//
        
        
        GGLInstanceIDConfig *instanceIDConfig = [GGLInstanceIDConfig defaultConfig];
        instanceIDConfig.delegate = self;
        // Start the GGLInstanceID shared instance with the that config and request a registration
        // token to enable reception of notifications
        [[GGLInstanceID sharedInstance] startWithConfig:instanceIDConfig];
        _registrationOptions = @{kGGLInstanceIDRegisterAPNSOption:deviceToken,
                                 kGGLInstanceIDAPNSServerTypeSandboxOption:@YES};        [[GGLInstanceID sharedInstance] tokenWithAuthorizedEntity:_gcmSenderID
                                                            scope:kGGLInstanceIDScopeGCM
                                                          options:_registrationOptions
                                                          handler:_registrationHandler];
        
    
    NSLog(@"My token is: %@", deviceToken);
    
    NSString *devToken = [[[[deviceToken description]
                            stringByReplacingOccurrencesOfString:@"<" withString:@""]
                           stringByReplacingOccurrencesOfString:@">" withString:@""]
                          stringByReplacingOccurrencesOfString: @" " withString: @""];
    
    NSLog(@"Device ..............................token: %@", devToken);
    
}

- (void)onTokenRefresh {
    // A rotation of the registration tokens is happening, so the app needs to request a new token.
    NSLog(@"The GCM registration token needs to be changed.");
    [[GGLInstanceID sharedInstance] tokenWithAuthorizedEntity:_gcmSenderID
                                                        scope:kGGLInstanceIDScopeGCM
                                                      options:_registrationOptions
                                                      handler:_registrationHandler];
}
///-----------------------------

- (void)subscribeToTopic
{
    
    // If the app has a registration token and is connected to GCM, proceed to subscribe to the
    // topic
    
    if (_registrationToken && _connectedToGCM)
    {
        [[GCMPubSub sharedInstance] subscribeWithToken:_registrationToken
                                                 topic:SubscriptionTopic
                                               options:nil
                                               handler:^(NSError *error) {
                                                   if (error) {
                                                       // Treat the "already subscribed" error more gently
                                                       if (error.code == 3001) {
                                                           NSLog(@"Already subscribed to %@",
                                                                 SubscriptionTopic);
                                                       } else {
                                                           NSLog(@"Subscription failed: %@",
                                                                 error.localizedDescription);
                                                       }
                                                   } else {
                                                       self.subscribedToTopic = true;
                                                       NSLog(@"Subscribed to %@", SubscriptionTopic);
                                                   }
                                               }];
    }
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"%@",userInfo);
    
    //    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:[[[userInfo valueForKey:@"aps"] valueForKey:@"alert"] valueForKey:@"title"] message:[[[userInfo valueForKey:@"aps"] valueForKey:@"alert"] valueForKey:@"body"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert show];
    
    badgeCount = [[[NSUserDefaults standardUserDefaults]valueForKey:@"badgeCount"]integerValue];
    
    if(badgeCount == 0)
    {
        badgeCount ++;
        [[NSUserDefaults standardUserDefaults]setInteger:badgeCount forKey:@"badgeCount"];
    }
    else
    {
        badgeCount = [[[NSUserDefaults standardUserDefaults]valueForKey:@"badgeCount"]integerValue];
        badgeCount ++;
        
        [[NSUserDefaults standardUserDefaults]setInteger:badgeCount forKey:@"badgeCount"];
    }
    
    [UIApplication sharedApplication].applicationIconBadgeNumber = badgeCount;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"receivedNotification" object:nil];
    
    
}



/////-----------------------------------


- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [[GCMService sharedInstance] connectWithHandler:^(NSError *error) {
        if (error) {
            NSLog(@"Could not connect to GCM: %@", error.localizedDescription);
        } else {
            _connectedToGCM = true;
            NSLog(@"Connected to GCM");
            // [START_EXCLUDE]
            [self subscribeToTopic];
            // [END_EXCLUDE]
        }
    }];
    
    
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    [[NSUserDefaults standardUserDefaults]setInteger:0 forKey:@"badgeCount"];
}

- (void)application:(UIApplication *)application
didReceiveRemoteNotification:(NSDictionary *)userInfo
fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))handler {
    NSLog(@"Notification received: %@", userInfo);
    // This works only if the app started the GCM service
    [[GCMService sharedInstance] appDidReceiveMessage:userInfo];
    
    
    badgeCount = [[[NSUserDefaults standardUserDefaults]valueForKey:@"badgeCount"]integerValue];
    
    if(badgeCount == 0)
    {
        badgeCount ++;
        [[NSUserDefaults standardUserDefaults]setInteger:badgeCount forKey:@"badgeCount"];
    }
    else
    {
        badgeCount = [[[NSUserDefaults standardUserDefaults]valueForKey:@"badgeCount"]integerValue];
        badgeCount ++;
        
        [[NSUserDefaults standardUserDefaults]setInteger:badgeCount forKey:@"badgeCount"];
    }
    
    [UIApplication sharedApplication].applicationIconBadgeNumber = badgeCount;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"receivedNotification" object:nil];

    // Handle the received message
    // Invoke the completion handler passing the appropriate UIBackgroundFetchResult value
    // ...
}

- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void (^)())handler {
    //    [[UAirship push] appReceivedActionWithIdentifier:identifier
    //                                        notification:userInfo
    //                                    applicationState:application.applicationState
    //                                   completionHandler:handler];
}

- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo withResponseInfo:(NSDictionary *)responseInfo completionHandler:(void (^)())handler {
    //    [[UAirship push] appReceivedActionWithIdentifier:identifier
    //                                        notification:userInfo
    //                                        responseInfo:responseInfo
    //                                    applicationState:application.applicationState
    //                                   completionHandler:handler];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
