//
//  AppDelegate.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/2/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Google/CloudMessaging.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,GGLInstanceIDDelegate, GCMReceiverDelegate>

@property (strong, nonatomic) UIWindow *window;




@property(nonatomic, strong) void (^registrationHandler)
(NSString *registrationToken, NSError *error);

@property(nonatomic, strong) NSString* registrationToken;

@property(nonatomic, readonly, strong) NSString *registrationKey;
@property(nonatomic, readonly, strong) NSString *messageKey;
@property(nonatomic, readonly, strong) NSString *gcmSenderID;
@property(nonatomic, readonly, strong) NSDictionary *registrationOptions;
@property(nonatomic, assign) BOOL subscribedToTopic;
@property(nonatomic, assign) BOOL connectedToGCM;




@end

