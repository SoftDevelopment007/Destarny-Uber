//
//  SignInAsPassangerViewController.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/20/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import "SignInAsPassangerViewController.h"
#import "webManager.h"
#import "NetworkManager.h"
#import "TermsConditionViewController.h"
#import "ALToastView.h"

@interface SignInAsPassangerViewController ()
{
//    MBProgressHUD * HUD;
      BOOL acceptTermsAndConditions;
    NSString *strPaymentMode;
    BOOL checketTC;
    UIColor *colour;
}
@end

@implementation SignInAsPassangerViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    acceptTermsAndConditions = 0;
    
    strPaymentMode = [[NSString alloc] init];
    
    _txtUserName.tag = 20;
    
    //_________ initialize activity indicator_____________
    [self initializeActivityIndicator];
    
    //_________ initializing controls ____________
    [self initializingControls];
    
    //-----------
    
    colour = [UIColor colorWithRed:253/255.0 green:197/255.0 blue:21/255.0 alpha:1];
    
    //Your entry string
    NSString *myString = @"I agree with all Terms and Conditions.";
    //Create mutable string from original one
    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:myString];
    
    NSRange range = [myString rangeOfString:@"Terms and Conditions."];
    [attString addAttribute:NSForegroundColorAttributeName value:colour range:range];
    
    //Add it to the label - notice its not text property but it's attributeText
    _lblTandC.attributedText = attString;
    
    // Do any additional setup after loading the view.
    
    _imgCard.image = [UIImage imageNamed:@"radioCircleNew.png"];
    _imgCash.image = [UIImage imageNamed:@"radioButtonNew.png"];
    strPaymentMode = @"cash";
}

#pragma mark - ViewWillAppear
-(void)viewWillAppear:(BOOL)animated
{
    //--
    
    checketTC = NO;
    [_btnTancC setImage:[UIImage imageNamed:@"checkBoxNew.png"] forState:UIControlStateNormal];
    
    //----
    
//    _imgCash.image = [UIImage imageNamed:@"radioCircleNew.png"];
//    _imgCard.image = [UIImage imageNamed:@"radioCircleNew.png"];
}

//-(void)viewWillLayoutSubviews
//{
//    [_mainscrollview
//     contentSizeToFit];
//    [_mainscrollview layoutIfNeeded];
//    self.mainscrollview.contentSize=self.view1.bounds.size;
//}

#pragma mark - initialize activity Indicator
-(void)initializeActivityIndicator
{
//    HUD=[[MBProgressHUD alloc]initWithView:self.view];
//    [HUD setLabelText:@"Loading"];
//    [self.view addSubview:HUD];
}

#pragma mark - initializing controls 
-(void)initializingControls
{
    //setting button's corner rounded
    self.btnSignIn.layer.cornerRadius = self.btnSignIn.layer.frame.size.height/6;
    
    //changing placeholder's color
    UIColor *colour = [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1];
    NSString *str = @" First Name";
    self.txtPassangerFName.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName:colour}];
    
    NSString *str4 = @" Last Name";
    self.txtPassangerLName.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str4 attributes:@{NSForegroundColorAttributeName:colour}];
    
    NSString * str1=@"Email address";
    self.txtEmailAddress.attributedPlaceholder = [[NSAttributedString alloc]initWithString:str1 attributes:@{NSForegroundColorAttributeName:colour}];
    
    NSString * str2=@"Password";
    self.txtPassword.attributedPlaceholder = [[NSAttributedString alloc]initWithString:str2 attributes:@{NSForegroundColorAttributeName:colour}];
    
    NSString * str3=@"Contact Number";
    self.txtContactNumber.attributedPlaceholder = [[NSAttributedString alloc]initWithString:str3 attributes:@{NSForegroundColorAttributeName:colour}];
    
    NSString * str5=@"Username";
    self.txtUserName.attributedPlaceholder = [[NSAttributedString alloc]initWithString:str5 attributes:@{NSForegroundColorAttributeName:colour}];
    
    _btnIAgree.layer.borderColor =[[UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1]CGColor];
    _btnIAgree.layer.borderWidth = 1.0f;
    
    //setting toolbar button to contactNumber field
    _txtContactNumber.inputAccessoryView = [self keyboardToolBar];
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

#pragma mark - toolBar method
- (UIToolbar *)keyboardToolBar
{
    UIToolbar *toolbar = [[UIToolbar alloc] init];
    [toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [toolbar sizeToFit];
    
    UIButton * doneButton=[UIButton buttonWithType:UIButtonTypeCustom];
    doneButton.frame=CGRectMake(0, 0, 50, 30);
    [doneButton addTarget:self action:@selector(doneTapped) forControlEvents:UIControlEventTouchUpInside];
    [doneButton setTitle:@"Done" forState:UIControlStateNormal];
    [doneButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    UIBarButtonItem *fixedSpace = [[UIBarButtonItem alloc]
                                   initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                   target:nil
                                   action:nil];
    [fixedSpace setWidth:self.view.frame.size.width-70];
    UIBarButtonItem *done_Button = [[UIBarButtonItem alloc] initWithCustomView:doneButton];
    NSArray *itemsArray = [[NSArray alloc]initWithObjects:fixedSpace,done_Button, nil];
    [toolbar setItems:itemsArray];
    return toolbar;
}

-(void)doneTapped
{
    [_txtContactNumber resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - textField delegate method

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

#pragma  mark - back button method
- (IBAction)btnBackClicked:(id)sender
{
    // ********** go to previous page ************************

    [self.navigationController popViewControllerAnimated:YES];
    
   // [[SlideNavigationController sharedInstance]popToRootViewControllerAnimated:YES];
    
}

#pragma mark - Email Validation method
- (BOOL)validateEmail:(NSString *)emailStr
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+]+@[A-Za-z0-9.]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailStr];
}



- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    int allowedLength = 50;
    switch(textField.tag) {
        
        case 301:
            allowedLength = 35;      // triggered for input fields with tag = 1
            break;
        case 302:
            allowedLength = 40;   // triggered for input fields with tag = 2
            break;
        case 303:
            allowedLength = 70;   // triggered for input fields with tag = 2
            break;
        case 304:
            allowedLength = 20;   // triggered for input fields with tag = 2
            break;
        case 305:
            allowedLength = 70;   // triggered for input fields with tag = 2
            break;
        case 306:
            allowedLength = 15;   // triggered for input fields with tag = 2
            break;
        default:
            allowedLength = 20;
            break;
    }
    
    if (textField.text.length >= allowedLength && range.length == 0) {
        return NO; // Change not allowed
    } else {
        return YES; // Change allowed
    }
}




#pragma  mark - button register method

- (IBAction)btnRegisterClicked:(id)sender
{
    if ([_txtPassangerFName.text isEqualToString:@""])
    {
        [self showMessage:@"Please enter first name."];
    }
    else if ([_txtPassangerLName.text isEqualToString:@""])
    {
        [self showMessage:@"Please enter last name."];
    }
    else if ([_txtEmailAddress.text isEqualToString:@""])
    {
        [self showMessage:@"Please enter email id."];
    }
    else if ([self validateEmail:_txtEmailAddress.text] == NO)
    {
        [ALToastView toastInView:self.view withText:@"Please enter valid Email Id"];
//        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please enter valid Email Id" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//        
//        [alert show];
    }
    else if ([_txtUserName.text isEqualToString:@""])
    {
        [self showMessage:@"Please enter username."];
    }
    else if ([_txtPassword.text isEqualToString:@""])
    {
        [self showMessage:@"Please enter password."];
    }
    else if([_txtContactNumber.text isEqualToString:@""])
    {
        [self showMessage:@"Please enter contact number."];
    }
    else if([_txtContactNumber.text length]>15)
    {
        [self showMessage:@"Contact number exceeds the limit."];
    }
    
    
    
    
    
    
    
    
    else if ([strPaymentMode isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Please select payment method."];
//        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please select payment method." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//        
//        [alert show];
    }
    
    else if (checketTC == NO)
    {
        [ALToastView toastInView:self.view withText:@"Please accept terms and conditions."];
//        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please accept terms and conditions." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//        
//        [alert show];
    }
    
    /*
     ////----- new API -----
     
     h ttp://dev12.edreamz3.com/api/passenger.php/signup/?fname=raju&lname=patil&username=raj&password=123&emailid=vijay.b@edreamz.in&phone_no=3333&deviceid=888&device_type=Android&pay_method=Cash/CreditCard
     
     ///
     
     */
    
    else
    {
        NSString *strDeviceID = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"DeviceID"]];
        NSDictionary * param=@{@"fname":_txtPassangerFName.text,
                               @"lname":_txtPassangerLName.text,
                               @"username":_txtUserName.text,
                               @"password":_txtPassword.text,
                               @"emailid":_txtEmailAddress.text,
                               @"phone_no":_txtContactNumber.text,
                               @"deviceid":strDeviceID, ////===== hard coded
                               @"device_type":@"iOS",
                               @"pay_method":strPaymentMode,
                               @"tcid":@"2"};
        
//        [[webManager sharedObject] loginRequest:param withMethod:@"passenger_registration.php" successResponce:^(id response)
        [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/signup/?" successResponce:^(id response)
         {
             NSLog(@"Responce : %@",response);
             
             NSError *e = nil;
//             NSDictionary *dicResponce = [NSJSONSerialization JSONObjectWithData:response options: NSJSONReadingMutableContainers error: &e];
             
             /*
              
              {
              items =     (
              {
              "action_date" = "2016-03-30 06:32:13";
              "device_type" = iOS;
              deviceid = DeviceID;
              emailid = "p@passenger.com";
              fname = passenger;
              id = 12;
              "is_activate" = 0;
              "is_deleted" = 0;
              lname = p;
              password = p;
              "pay_method" = Cash;
              payid = 0;
              "phone_no" = 123;
              "reg_date" = "2016-03-30 06:32:13";
              tcid = 2;
              username = p;
              }
              );
              status = 1;
              }
              
              */
             
             NSString *strStatus = [[response valueForKey:@"status"] stringValue];
             
             if([strStatus isEqualToString:@"1"])
             {
                // [ALToastView toastInView:self.view withText:@"Registered Successfully."];
                 UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil message:@"Registered Successfully." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                 
                 [alert show];
                 
                 alert.tag = 20;
             }
             else if([strStatus isEqualToString:@"0"])
             {
                 // [ALToastView toastInView:self.view withText:@"Registered Successfully."];
                 UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil message:[response valueForKey:@"items"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                 
                 [alert show];
                 
                 alert.tag = 20;
             }
         }failure:^(NSError *error)
         {
             NSLog(@"Error : %@",error);
             [ALToastView toastInView:self.view withText:@"Registration Failed!"];
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Registration Failed!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             
//             [alert show];
         }];
    }
}

-(void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    CGFloat height = _view1.bounds.size.height;
    CGFloat deviceWidth = self.view.frame.size.width;
    
    _view1.frame = CGRectMake(0, 20, deviceWidth, height);
    _mainscrollview.contentSize = CGSizeMake(_view1.frame.size.width, _view1.frame.size.height+40);

}
-(void)showMessage:(NSString *)message
{
    [ALToastView toastInView:self.view withText:message];
//    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:nil message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//    [alert show];
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 20)
    {
        //Do something
        if(buttonIndex == 0)
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    else
    {
        //Do something else
    }
}


///----- username validaton

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.tag == 20)
    {
        NSLog(@"user name text field starts editing");
    }
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField.tag == 20)
    {
        NSLog(@"user name text field ends editing");
        
        //------ username validation API call --------
        
        /*
         
//         http://dev12.edreamz3.com/destarny_taxi_app/api/driver_username_check.php
//         
//         driver check username must be POST method
//         username: <Passenger username>
//         
//         Response:
//         True or false <Passenger username>
         
         
        
        NSString *string = _txtUserName.text;
        NSString *trimmedString = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        
        NSDictionary * param=@{@"username":trimmedString};
        
        [[webManager sharedObject] loginRequest:param withMethod:@"passenger_username_check.php" successResponce:^(id response)
         {
             NSLog(@"Responce : %@",response);
             
         
              
//              {
//              Response =     {
//              ErrorCode = 1;0
//              Message = "username_already_exists";
//              };
//              status = false;
//              }
              
         
         
         
             
             NSString *strStatus = [response valueForKey:@"status"];
             
             if([strStatus isEqualToString:@"Success"])
             {
                 // valid username
             }
             else if ([strStatus isEqualToString:@"false"])
             {
                 UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Username already exists." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                 [alert show];
                 _txtUserName.text = @"";
             }
             
         }failure:^(NSError *error)
         {
             NSLog(@"Error : %@",error);
             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil message:@"Failed to get username validation." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
             [alert show];
             _txtUserName.text = @"";
         }];
         
         */
    }
}

- (IBAction)btnCashTapped:(id)sender
{
    _imgCard.image = [UIImage imageNamed:@"radioCircleNew.png"];
    _imgCash.image = [UIImage imageNamed:@"radioButtonNew.png"];
    strPaymentMode = @"cash";
}

- (IBAction)btnBankingTapped:(id)sender
{
    _imgCash.image = [UIImage imageNamed:@"radioCircleNew.png"];
    _imgCard.image = [UIImage imageNamed:@"radioButtonNew.png"];
    strPaymentMode = @"banking";
}

- (IBAction)btnTandCTapped:(id)sender
{
    if(checketTC == NO)
    {
        [_btnTancC setImage:[UIImage imageNamed:@"checkMarkNew.png"] forState:UIControlStateNormal];
        checketTC = YES;
    }
    else
    {
        [_btnTancC setImage:[UIImage imageNamed:@"checkBoxNew.png"] forState:UIControlStateNormal];
        checketTC = NO;
    }
}

-(IBAction)btnTermsAndConditions:(id)sender
{
    TermsConditionViewController *objTerms = [self.storyboard instantiateViewControllerWithIdentifier:@"TermsConditionViewController"];
    [self.navigationController presentViewController:objTerms animated:YES completion:nil];
}


@end
