//
//  CreditCardTableViewCell.h
//  DestarnyTaxiApp
//
//  Created by satyaprakash.n on 5/5/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreditCardTableViewCell : UITableViewCell
@property (strong, nonatomic)IBOutlet UILabel *lblCardNo, *lblCardLastDigits, *lblCardExp, *lblCVN;
@property (strong, nonatomic)IBOutlet UIButton *btnCheck;
@end
