//
//  Taxi_Booking_Form_ViewController.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/24/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import "Taxi_Booking_Form_ViewController.h"
#import "setFareCell.h"
#import "webManager.h"
#import <MapKit/MapKit.h>
#import "Annotation.h"
#import <CoreLocation/CoreLocation.h>
#import "MBProgressHUD.h"
#import "ALToastView.h"

@interface Taxi_Booking_Form_ViewController ()
{
    CLLocationCoordinate2D selectedLocationCoordStart,selectedLocationCoordDest;
    
    BOOL txtToSelected ;
    
    NSMutableArray *arrSearchRes,*arrSearchResDest,*arrSetFare;
    
    NSString * noOfBookings,*strBookingType,*steSetFareFulfield,*strFareID,*strStartAddLat,*strStartAddLng,*strDestAddLat,*strDestAddLng;
    
    NSMutableArray *arrFares,*arrFareDetails;
    
    BOOL isYesSelected,isMeteredTaxi,isSetfareFulfield;
    
    NSString *strVehicleType;
    
    NSString * tbl_Booking_Id;
    
    //-------
    
    NSString *fareType;
    NSString *strLngSelectedST,*strLatSelectedST,*strLngSelectedD,*strLatSelectedD;
    MBProgressHUD *HUD;
}
@end

@implementation Taxi_Booking_Form_ViewController

-(void)viewWillAppear:(BOOL)animated
{
    //    [self initializeTimePicker];
    //
    //    [self getAllVehicleDetails];
    
    _tblSetFare.hidden = YES;
    
    //--- metered taxi by default -----
    
    [arrSetFare addObject:@"Metered Taxi"];
    _txtMySetFare.text = [arrSetFare objectAtIndex:0];
    _btnSetfare.hidden = YES;
    _lblSetFarefulfield.hidden = YES;
    strBookingType = @"Taximeter";
    strFareID = @"0";
    
    //-------
    
    steSetFareFulfield = @"0";
    [self getAllFares];
}

-(void)getAllVehicleDetails
{
    // http://ezygo.co.nz/ftpserver/taxiapp/api/getallvtype/
    
    NSString *strFlag=[NSString stringWithFormat:@"api/getallvtype/?"];
}



#pragma mark - initialize timePicker
-(void)initializeTimePicker
{
    //New view controller
    //  UIViewController *pickerViewController = [[UIViewController alloc] init];
    
    //Init the datePicker view and set self as delegate
    timePicker = [[SBFlatDatePicker alloc] initWithFrame:self.view1.bounds];
    [timePicker setDelegate:self];
    
    //OPTIONAL: Choose the background color
    [timePicker setBackgroundColor:[UIColor blackColor]];
    
    //OPTIONAL - Choose Date Range (0 starts At Today. Non continous sets acceptable (use some enumartion for [indexSet addIndex:yourIndex];
    
    timePicker.dayRange = [NSMutableIndexSet indexSetWithIndexesInRange:NSMakeRange(0, 365)];
    
    //Set the data picker as view of the new view controller
    [_view1 addSubview:timePicker];
    
    [_view1 addSubview:_datePicker];
}

//Delegate
-(void)flatDatePicker:(SBFlatDatePicker *)datePicker saveDate:(NSDate *)date
{
    NSLog(@"%@",[date description]);
}

#pragma mark - viewDidLoad method
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    HUD.labelText = @"Loading";
    [self.view addSubview:HUD];

    [self initializeActivityIndicator];
    [self initializeControls];
    [self initializeTimePicker];
    [self getAllVehicleDetails];
    
    ////--- textfield selector ---
    
    [_txtFrom addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [_txtTo addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    
    //-----
    
    arrSearchRes = [[NSMutableArray alloc] init];
    arrSearchResDest = [[NSMutableArray alloc] init];
    
    //-----
    
    _btnTime.hidden = YES;
    
    _tableViewSearch1.hidden = YES;
    _tableViewSearch.hidden = YES;
    _tableviewNoOfPassenger.hidden =YES;
    
    //-----------------
    
    _txtMySetFare.layer.borderWidth = 1;
    _txtMySetFare.layer.borderColor = [UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:0.5].CGColor;
    [_txtMySetFare setValue:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1] forKeyPath:@"_placeholderLabel.textColor"];
    _txtMySetFare.layer.sublayerTransform = CATransform3DMakeTranslation(8, 0, 0);
    
    //---------------------------------
    
    _txtNoOfPassenger.layer.borderWidth = 1;
    _txtNoOfPassenger.layer.borderColor = [UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:0.5].CGColor;
    
    //---------------------------------
    
    //    _btnMeteredTaxi.layer.cornerRadius = 5;
    //    _btnMeteredTaxi.clipsToBounds = YES;
    //    _btnMeteredTaxi.layer.borderWidth = 1;
    //    _btnMeteredTaxi.layer.borderColor =[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:0.5].CGColor;
    
    //-----------------
    
    arrSetFare = [[NSMutableArray alloc] init];
    
    isMeteredTaxi = NO;
    isSetfareFulfield = NO;
    
    [scroll addSubview:_tableViewSearch];
    [scroll addSubview:_tableViewSearch1];
    [scroll addSubview:_tableviewNoOfPassenger];
    
//    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gestureHandlerMethod:)];
//    [self.view addGestureRecognizer:tapRecognizer];
    
    
    UIToolbar* keyboardToolbar = [[UIToolbar alloc] init];
    [keyboardToolbar sizeToFit];
    UIBarButtonItem *flexBarButton = [[UIBarButtonItem alloc]
                                      initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                      target:nil action:nil];
    UIBarButtonItem *doneBarButton = [[UIBarButtonItem alloc]
                                      initWithBarButtonSystemItem:UIBarButtonSystemItemDone
                                      target:self action:@selector(doneClicked)];
    keyboardToolbar.items = @[flexBarButton, doneBarButton];
    self.txtNoOfPassenger.inputAccessoryView = keyboardToolbar;
}
- (void)doneClicked
{
    [_txtNoOfPassenger resignFirstResponder];
}


-(void)gestureHandlerMethod:(UITapGestureRecognizer*)sender
{
    [self.view endEditing:YES];
    [_txtNoOfPassenger resignFirstResponder];
    [_txtFrom resignFirstResponder];
    [_txtTo resignFirstResponder];
    [_txtNoOfPassenger resignFirstResponder];
    _tableViewSearch.hidden = YES;
    _tableviewNoOfPassenger.hidden = YES;
    _tableViewSearch1.hidden = YES;
}



#pragma  mark - initialize Controls
-(void)initializeControls
{
    //making ViewPicker's view rounded
    _view1.layer.cornerRadius = _view1.layer.frame.size.height/16;
    
    _view1.layer.borderColor =[[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:.5]CGColor];
    
    //[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1.0]
    
    _view1.layer.borderWidth = 1.0f;
    _view1.layer.masksToBounds = YES;
    
    
    //changing placeholder's color
    UIColor *colour = [UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1];
    NSString *str = @"Source Location";
    self.txtFrom.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName:colour}];
    
    _txtFrom.layer.borderWidth = 1.0f;
    _txtFrom.layer.borderColor = [[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:0.5]CGColor];
    _txtFrom.layer.sublayerTransform = CATransform3DMakeTranslation(8, 0, 0);
    
    NSString *str1 = @"Now";
    self.txtTime.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str1 attributes:@{NSForegroundColorAttributeName:colour}];
    
    _txtTime.layer.borderWidth = 1.0f;
    _txtTime.layer.borderColor = [[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:0.5]CGColor];
    _txtTime.layer.sublayerTransform = CATransform3DMakeTranslation(8, 0, 0);
    
    NSString *str2 = @"Destination Location";
    self.txtTo.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str2 attributes:@{NSForegroundColorAttributeName:colour}];
    
    _txtTo.layer.borderWidth = 1.0f;
    _txtTo.layer.borderColor = [[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:0.5]CGColor];
    _txtTo.layer.sublayerTransform = CATransform3DMakeTranslation(8, 0, 0);
    
    _btnNoOfPasseneger.layer.borderColor = [[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:0.2]CGColor];
    _btnNoOfPasseneger.layer.borderWidth = 1.0f;
    
    //making button's rounded
    
    _btnBookTaxiNOw.layer.cornerRadius = _btnBookTaxiNOw.layer.frame.size.height/6;
    _btnCalender.layer.cornerRadius = _btnCalender.layer.frame.size.height/6;
    _btnDay.layer.cornerRadius = _btnDay.layer.frame.size.height/6;
    _btnDone.layer.cornerRadius = _btnDone.layer.frame.size.height/6;
    _btnNow.layer.cornerRadius = _btnNow.layer.frame.size.height/6;
    _btnTime.layer.cornerRadius = _btnTime.layer.frame.size.height/6;
    _btnToday.layer.cornerRadius = _btnToday.layer.frame.size.height/6;
    
    _myView.layer.cornerRadius = _myView.layer.frame.size.height/12;
    
    //__________________ initializing number of passenger on vehicle type ______________________
    
}

#pragma mark - Initialize Activity Indicator
-(void)initializeActivityIndicator
{
    //    HUD=[[MBProgressHUD alloc]initWithView:self.view];
    //    [HUD setLabelText:@"Loading"];
    //    [self.view addSubview:HUD];
}

/*
 #pragma mark - textField delegate methods
 -(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
 {
 
 if(textField.tag == 20 || textField.tag == 25)
 {
 NSUInteger lengthOfString = string.length;
 for (NSInteger index = 0; index < lengthOfString; index++) {
 unichar character = [string characterAtIndex:index];
 if (character < 48) return NO; // 48 unichar for 0
 if (character > 57) return NO; // 57 unichar for 9
 }
 // Check for total length
 NSUInteger proposedNewLength = textField.text.length - range.length + string.length;
 if (proposedNewLength > 6)
 return YES;
 return YES;
 }
 
 if(textField.tag == 301 )//|| textField.tag == 302)
 {
 if(textField.text.length == 0)
 {
 _tableViewSearch.hidden = YES;
 // _tableViewSearch1.hidden = YES;
 }
 else
 {
 _tableViewSearch.hidden = NO;
 // _tableViewSearch1.hidden = NO;
 }
 
 // NSString * urlSTR=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/textsearch/json?query=p&sensor=true&key=AIzaSyBtzqyf_2PG8NSbVyVhRym-86M_rj-OOZk"];
 
 NSString *urlSTR=[[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyBj2Y63SxN6m0XXbFLyLTbRfDgCC_orFh0",textField.text] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
 
 NSURL *url = [NSURL URLWithString:urlSTR];
 //[NSURL URLWithString:[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyBtzqyf_2PG8NSbVyVhRym-86M_rj-OOZk",searchText]];//18.5333, 73.8514,type]];
 
 NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
 
 NSURLResponse *responce;
 
 NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
 
 NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
 
 _initialPlaces = [[dictionary1 valueForKey:@"predictions"]valueForKey:@"description"];
 
 if(textField.text.length == 0)
 {
 // self.isFiltered = NO;
 }
 else
 {
 //         self.isFiltered = YES;
 //         self.filteredPlaces = [NSMutableArray new];
 //
 //         for (NSString * cityName in self.initialPlaces)
 //         {
 //             NSRange cityNameRange = [cityName rangeOfString:textField.text options:NSCaseInsensitiveSearch];
 //
 //             if(cityNameRange.location != NSNotFound)
 //             {
 //                 [self.filteredPlaces addObject:cityName];
 //             }
 //         }
 }
 
 [self.tableViewSearch reloadData];
 //[self.tableViewSearch1 reloadData];
 }
 if(textField.tag == 302)
 {
 if(textField.text.length == 0)
 {
 _tableViewSearch1.hidden = YES;
 }
 else
 {
 _tableViewSearch1.hidden = NO;
 }
 
 // NSString * urlSTR=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/textsearch/json?query=p&sensor=true&key=AIzaSyBtzqyf_2PG8NSbVyVhRym-86M_rj-OOZk"];
 
 NSString *urlSTR=[[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyBj2Y63SxN6m0XXbFLyLTbRfDgCC_orFh0",textField.text] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
 
 NSURL *url = [NSURL URLWithString:urlSTR];
 //[NSURL URLWithString:[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyBtzqyf_2PG8NSbVyVhRym-86M_rj-OOZk",searchText]];//18.5333, 73.8514,type]];
 
 NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
 
 NSURLResponse *responce;
 
 NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
 
 NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
 
 _initialPlaces = [[dictionary1 valueForKey:@"predictions"]valueForKey:@"description"];
 
 if(textField.text.length == 0)
 {
 //     self.isFiltered = NO;
 }
 else
 {
 //          self.isFiltered = YES;
 //          self.filteredPlaces = [NSMutableArray new];
 //
 //          for (NSString * cityName in self.initialPlaces)
 //          {
 //              NSRange cityNameRange = [cityName rangeOfString:textField.text options:NSCaseInsensitiveSearch];
 //
 //              if(cityNameRange.location != NSNotFound)
 //              {
 //                  [self.filteredPlaces addObject:cityName];
 //              }
 //          }
 }
 [self.tableViewSearch1 reloadData];
 }
 return YES;
 }
 */

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    //_____________textField To action ___________
    if(textField.tag == 302)
    {
        txtToSelected = YES;
        //        [_tableViewSearch setFrame:CGRectMake(_tableViewSearch.frame.origin.x, _tableViewSearch.frame.origin.y + _txtTo.frame.size.height +10, _tableViewSearch.frame.size.width, _tableViewSearch.frame.size.height)];
    }
    else
    {
        txtToSelected = NO;
    }
    //_tableviewNoOfPassenger.hidden = NO;
}

//-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
//{
//    SBPickerScrollView *sv = (SBPickerScrollView *)scrollView;
//    [sv setScrollEnabled:YES];
//    [sv dehighlightLastCell];
//}

#pragma mark - touches begin
//-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
//    UITouch *touch= [touches anyObject];
//    if ([touch view] == self.view)
//    {
//        //Action
//        _tableViewSearch.hidden = YES;
//        _tableviewNoOfPassenger.hidden = YES;
//        _tableViewSearch1.hidden = YES;
//    }
//    // _txtFrom.text = @"";
//}

#pragma mark- tableView Datasource and delegate methods
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView.tag == 100)
    {
        return arrSearchRes.count;
    }
    else if(tableView.tag == 127)
    {
        return arrSetFare.count;
    }
    else
    {
        return arrSearchResDest.count;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView.tag == 100)
    {
        static NSString *MyIdentifier = @"TaxiBookingForm_TableViewCell";
        TaxiBookingForm_TableViewCell *cell = [_tblStartAdd dequeueReusableCellWithIdentifier:MyIdentifier];
        
        if (cell == nil)
        {
            cell = [[TaxiBookingForm_TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
        }
        
        cell.lblTitle.text = [[arrSearchRes objectAtIndex:indexPath.row] valueForKey:@"description"];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        return cell;
    }
    else if(tableView.tag == 127)
    {
        static NSString *MyIdentifier = @"setFareCell";
        setFareCell *cell = [_tblSetFare dequeueReusableCellWithIdentifier:MyIdentifier];
        
        if (cell == nil)
        {
            cell = [[setFareCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
        }
        
        cell.lblFare.text = [arrSetFare objectAtIndex:indexPath.row];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        return cell;
    }
    else
    {
        static NSString *MyIdentifier = @"TaxiBookingForm_TableViewCell1";
        TaxiBookingForm_TableViewCell1 *cell = [_tblDestAdd dequeueReusableCellWithIdentifier:MyIdentifier];
        
        if (cell == nil)
        {
            cell = [[TaxiBookingForm_TableViewCell1 alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
        }
        
        cell.lblTitle.text = [[arrSearchResDest objectAtIndex:indexPath.row] valueForKey:@"description"];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        return cell;
    }
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGRect frame = CGRectMake(0, 0, tableView.frame.size.width,0.0f);
    UIView *view = [[UIView alloc] initWithFrame:frame];
    view.backgroundColor = [UIColor colorWithRed:26/255.0 green:24/255.0 blue:29/255.0 alpha:1];
    return view;
}

- (CGFloat)tableView:(UITableView*)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        return 6.0;
    }
    return 6.0;
}

#pragma mark - back button action
- (IBAction)btnBackClicked:(id)sender
{
    // [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
    [self.navigationController popViewControllerAnimated:YES];
}



- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    int allowedLength = 0;
    switch(textField.tag) {
        case 25:
            allowedLength = 2;      // triggered for input fields with tag = 1
            break;
        default:
            allowedLength = 100;   // triggered for input fields with tag = 2
            break;
    }
    
    if (textField.text.length >= allowedLength && range.length == 0) {
        return NO; // Change not allowed
    } else {
        return YES; // Change allowed
    }
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [_txtNoOfPassenger resignFirstResponder];
//    _tableViewSearch.hidden = YES;
//    _tableviewNoOfPassenger.hidden = YES;
//    _tableViewSearch1.hidden = YES;
    [self.view endEditing:YES];
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}


#pragma mark - Book TaxiNow Clicked
- (IBAction)btnBookTaxiNowClicked:(id)sender
{
    /*
     
     Standard
     Van
     Premium
     
     */
    
    
    /*
     _selectedVehicleType = @"Van";
     
     if(_selectedVehicleType == nil)
     {
     UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please select Vehicle" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
     
     [alert show];
     }
     else
     {
     [self getVehicalId:_selectedVehicleType];
     }
     */
    
    
    /////-------------------
    
    NSLog(@"%@ %@",_lbldate.text, _lblTime.text);
    int passenger = [_txtNoOfPassenger.text intValue];
    
    
    if ([_txtFrom.text isEqualToString:@""])
    {
         [ALToastView toastInView:self.view withText:@"Select starting location."];
//        UIAlertView *al = [[UIAlertView alloc] initWithTitle:nil message:@"Select starting location." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [al show];
    }
    
    else if ([_txtTo.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Select destination location."];
//        UIAlertView *al = [[UIAlertView alloc] initWithTitle:nil message:@"Select destination location." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [al show];
    }
    else if ([strVehicleType isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Select vehicle type."];
//        UIAlertView *al = [[UIAlertView alloc] initWithTitle:nil message:@"Select vehicle type." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [al show];
    }

    else if ([_txtNoOfPassenger.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Enter number of passenger."];
//        UIAlertView *al = [[UIAlertView alloc] initWithTitle:nil message:@"Enter number of passenger." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [al show];
    }
    
    else if (passenger>11)
    {
        [ALToastView toastInView:self.view withText:@"Number of passengers must be less than 10."];
//        UIAlertView *al = [[UIAlertView alloc] initWithTitle:nil message:@"Number of passengers must be less than 10." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [al show];
    }
    

    
    else if ([_lbldate.text isEqualToString:@""] || [_lblTime.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Enter date and time"];
//        UIAlertView *al = [[UIAlertView alloc] initWithTitle:nil message:@"Enter date and time" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [al show];
    }
    else if ([fareType length]==0)
    {
        [ALToastView toastInView:self.view withText:@"Please select vehicle."];
//        UIAlertView *al = [[UIAlertView alloc] initWithTitle:nil message:@"Please select vehicle." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [al show];
    }
    
    
    else
    {
        [HUD show:YES];
        
        /////----------
        
        NSString *savedValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
        
        NSDictionary * param=@{@"cid":savedValue,
                               @"booking_type":@"Advance",
                               @"fare_type":@"DestarnyRate",
                               @"setfare_unfullfilled":steSetFareFulfield,
                               @"booking_from_lat":strLatSelectedST,
                               @"booking_from_lng":strLngSelectedST,
                               @"booking_from":_txtFrom.text,
                               @"booking_to_lat":strLatSelectedD,
                               @"booking_to_lng":strLngSelectedD,
                               @"booking_to":_txtTo.text,
                               @"noofpass":_txtNoOfPassenger.text,
                               @"booking_time":_lblTime.text,
                               @"booking_date":_lbldate.text,
                               @"notes":@"note",
                               @"fareid":strFareID,
                               @"distance":@"",
                               @"duration":@"",
                               @"calfare":@""
                               };   //----- hard coded
        
 //   http://destarny.com/api/passenger.php/addbooking/?cid=1&booking_type=Current/Advance&fare_type=Taximeter/SetFare/DestarnyRate/Premium&setfare_unfullfilled=1/0&booking_from_lat=111&booking_from_lng=222&booking_from=Pune&booking_to_lat=333&booking_to_lng=444&booking_to=katraj&noofpass=3&booking_time=10:20:30&booking_date=2016-03-20&notes=Helo&fareid=1
        
        
        [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/addbooking/?" successResponce:^(id response)
         {
             NSError *e = nil;
             NSString *strStatus = [[response valueForKey:@"status"] stringValue];
             [HUD hide:YES];
             if([strStatus isEqualToString:@"1"])
             {
                 //---
                 NSArray * response1 = [[NSArray alloc] init];
                 response1 = [response valueForKey:@"items"];
                 
                // [ALToastView toastInView:self.view withText:@""];
                 // Book in advance booking successful message
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Success! You will be notified when a driver accepts your request. Drivers may accept your job well in advance and will SMS on approach." delegate:self cancelButtonTitle:@"Thank you for riding with Destarny" otherButtonTitles:nil, nil];
                 alert.tag = 123;
                 [alert show];
             }
             else if([strStatus isEqualToString:@"0"])
             {
                 NSString *strStatus = [response valueForKey:@"items"];
                 [ALToastView toastInView:self.view withText:strStatus];
//                 [[[UIAlertView alloc] initWithTitle:nil message:strStatus delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil]show];
             }
         }failure:^(NSError *error)
         {
             NSLog(@"Error : %@",error);
             [HUD hide:YES];
         }];
    }
    ////------------------
}

#pragma mark - getVehicalId methods
-(void)getVehicalId : (NSString *)vehicalType
{
    NSString *strFlag=[NSString stringWithFormat:@"api/getvtidbyvtype/?"];
    
    NSString *strData=[NSString stringWithFormat:@"vtype=%@",vehicalType];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == 201)
    {
        [[SlideNavigationController sharedInstance]popViewControllerAnimated:YES];
    }
    if(alertView.tag == 123)
    {
        if(buttonIndex == 0)
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    NSLog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
    
    [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
}

- (UIView *)createDemoView
{
    UIView *demoView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 290, 150)];
    
    UILabel * lblTitle = [[UILabel  alloc]initWithFrame:CGRectMake(20, 30, 70, 30)];
    lblTitle.text = @"Go Loyal";
    [demoView addSubview:lblTitle];
    
    _btnYes = [[UIButton alloc]initWithFrame:CGRectMake(100, 30, 30 ,30)];
    [_btnYes setBackgroundColor:[UIColor clearColor]];
    _btnYes.layer.cornerRadius =_btnYes.layer.frame.size.height/2;
    _btnYes.layer.borderColor = [[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1]CGColor];
    _btnYes.layer.borderWidth = 1.0f;
    
    [_btnYes addTarget:self action:@selector(yesBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    [demoView addSubview:_btnYes];
    
    _imgviewYes = [[UIImageView alloc]initWithFrame:CGRectMake(108, 38, 15, 15)];
    _imgviewYes.backgroundColor = [UIColor clearColor];
    _imgviewYes.layer.cornerRadius =_imgviewYes.layer.frame.size.height/2;
    [demoView addSubview:_imgviewYes];
    
    UILabel * lblYes = [[UILabel  alloc]initWithFrame:CGRectMake(135,30,40,30)];
    lblYes.text = @"Yes";
    [demoView addSubview:lblYes];
    
    
    _btnNo = [[UIButton alloc]initWithFrame:CGRectMake(175,30,30,30)];
    [_btnNo setBackgroundColor:[UIColor clearColor]];
    _btnNo.layer.cornerRadius =_btnNo.layer.frame.size.height/2;
    _btnNo.layer.borderColor = [[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1]CGColor];
    _btnNo.layer.borderWidth = 1.0f;
    [_btnNo addTarget:self action:@selector(noBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [demoView addSubview:_btnNo];
    
    
    _imgviewNo = [[UIImageView alloc]initWithFrame:CGRectMake(183,38,15,15)];
    _imgviewNo.backgroundColor = [UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1];
    _imgviewNo.layer.cornerRadius =_imgviewNo.layer.frame.size.height/2;
    [demoView addSubview:_imgviewNo];
    
    
    UILabel * lblNo = [[UILabel  alloc]initWithFrame:CGRectMake(210,30,40,30)];
    lblNo.text = @"No";
    [demoView addSubview:lblNo];
    
    
    _btnAddGoLoyal =[[UIButton alloc]initWithFrame:CGRectMake(115, 100, 70, 40)];
    [_btnAddGoLoyal setTitle:@"Done" forState:UIControlStateNormal];
    [_btnAddGoLoyal setTitleColor:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1] forState:UIControlStateNormal];
    [_btnAddGoLoyal setTintColor:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1]];
    _btnAddGoLoyal.layer.cornerRadius =_btnAddGoLoyal.layer.frame.size.height/6;
    _btnAddGoLoyal.layer.borderColor = [[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1]CGColor];
    _btnAddGoLoyal.layer.borderWidth = 1.0f;
    [_btnAddGoLoyal addTarget:self action:@selector(doneBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    [demoView addSubview:_btnAddGoLoyal];
    
    return demoView;
}

#pragma mark - View Go Loyal Actions
- (void)noBtnClicked:(id)sender
{
    isYesSelected= NO;
    
    _imgviewNo.backgroundColor = [UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1];
    _imgviewYes.backgroundColor = [UIColor clearColor];
    
}

- (void)yesBtnClicked:(id)sender
{
    isYesSelected = YES;
    
    _imgviewYes.backgroundColor = [UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1];
    _imgviewNo.backgroundColor = [UIColor clearColor];
}

- (void)doneBtnClicked:(id)sender
{
    /*
     [customAlertView close];
     
     //[[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
     
     
     if(isYesSelected == YES)
     {
     [self addGOLoyal];
     }
     else
     {
     [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
     }
     */
}

#pragma mark - API For GoLoyal
-(void)addGOLoyal
{
    
    /*
     
     //    http://dev9.edreamz3.com/taxiapp/api/addgoloyal/
     
     NSString * strFlag = [NSString stringWithFormat:@"api/addgoloyal/?"];
     
     NSString * strData =[NSString stringWithFormat:@"tbid=%@",tbl_Booking_Id];
     
     [WebManager postDataOnserver:strFlag Data:strData delegate:self onSuccess:@selector(addGoLoyalSuccess:) onFailure:@selector(addGOLoyalFail:)];
     
     [HUD show:YES];
     
     */
    
}


/*
 -(void)addGoLoyalSuccess:(NSDictionary *)dataDic
 {
 NSLog(@"%@",dataDic);
 
 
 //    [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
 
 if([[[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"] isEqualToString:@"Register"])
 {
 if([[[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentMethod"] isEqualToString:@"CreditCard"])
 {
 [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:4] animated:YES];
 }
 else
 {
 [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:3] animated:YES];
 }
 }
 else
 {
 [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:2] animated:YES];
 }
 
 [HUD hide:YES];
 }
 
 -(void)addGOLoyalFail :(NSDictionary *)dataDic
 {
 NSLog(@"%@",dataDic);
 
 [HUD hide:YES];
 }
 
 -(void)getBookingPaymentCntFail :(NSDictionary *)dataDic
 {
 [HUD hide:YES];
 
 NSLog(@"%@",dataDic);
 }
 */

/*
 #pragma mark - send Push Notification
 -(void)sendPushNotification : (NSDictionary *)dataDic
 {
 
 NSString * cid=[[[NSUserDefaults standardUserDefaults] objectForKey:@"Cid"] objectAtIndex:0];
 
 NSString *strFlag=[NSString stringWithFormat:@"api/addbookingpush/?"];
 
 NSString *strData=[NSString stringWithFormat:@"cid=%@&booking_from_lat=%f&booking_from_lng=%f&booking_from=%@&booking_to=%@",cid,sourceCord.latitude,sourceCord.longitude,[[[dataDic valueForKey:@"items"]objectAtIndex:0] valueForKey:@"booking_from"],[[[dataDic valueForKey:@"items"]objectAtIndex:0] valueForKey:@"booking_to"]];
 
 [WebManager postDataOnserver:strFlag Data:strData delegate:self onSuccess:@selector(addBookingPushSuccess:) onFailure:@selector(addBookingPushFail:)];
 
 [HUD show:YES];
 }
 
 -(void)addBookingPushSuccess:(NSDictionary *)dataDic
 {
 [HUD hide:YES];
 
 UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"success" message:@"" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
 
 [alert show];
 
 NSLog(@"%@",dataDic);
 }
 
 -(void)addBookingPushFail:(NSDictionary *)dataDic
 {
 [HUD hide:YES];
 
 UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"URL Failed" message:@"" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
 
 //  [alert show];
 
 NSLog(@"%@",dataDic);
 }
 */

/*
 #pragma mark getLatLong From address
 -(CLLocationCoordinate2D )getLatLongFromAddress : (NSString *)address
 {
 
 //  http://maps.google.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=false
 
 NSString *urlSTR=[[NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?address=%@&sensor=false",address] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
 
 NSURL *url = [NSURL URLWithString:urlSTR];
 
 
 NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
 
 NSURLResponse *responce;
 
 NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
 
 
 NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
 
 NSArray * resultArray = [dictionary1 valueForKey:@"results"];
 
 NSDictionary * dic = [resultArray objectAtIndex:0];
 
 NSDictionary * geo = [dic valueForKey:@"geometry"];
 NSDictionary * location = [geo valueForKey:@"location"];
 
 double lat = [[location valueForKey:@"lat"]doubleValue];
 double lng = [[location valueForKey:@"lng"] doubleValue];
 
 
 CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(lat, lng);
 
 return coord;
 }
 */


#pragma mark- Calender button action
- (IBAction)btnCalenderClicked:(id)sender
{
    _btnTime.hidden = NO;
    _btnCalender.hidden = YES;
    
    //Init the datePicker view and set self as delegate
    datePicker = [[DatePicker alloc] initWithFrame:self.view1.bounds];
    [datePicker setDelegate:self];
    
    //OPTIONAL: Choose the background color
    [datePicker setBackgroundColor:[UIColor blackColor]];
    
    //OPTIONAL - Choose Date Range (0 starts At Today. Non continous sets acceptable (use some enumartion for [indexSet addIndex:yourIndex];
    //datePicker.dayRange1 = [NSMutableIndexSet indexSetWithIndexesInRange:NSMakeRange(0, 365)];
    
    //Set the data picker as view of the new view controller
    [_view1 addSubview:datePicker];
}

#pragma mark - button today action
- (IBAction)btnTodayClicked:(id)sender
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    NSString *date= [formatter stringFromDate:[NSDate date]];
    
    _lbldate.text = date;
    
    formatter.dateFormat = @"hh:mm:ss";
    NSString *time= [formatter stringFromDate:[NSDate date]];
    
    _lblTime.text =time;
}

#pragma mark - button tomorrow action
- (IBAction)btnTomorrowClicked:(id)sender
{
    NSDate *now = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    
    int daysToAdd = 1;
    NSDate *newDate1 = [now dateByAddingTimeInterval:60*60*24*daysToAdd];
    
    NSString *dateTomorrow=[formatter stringFromDate:newDate1];
    _lbldate.text = [NSString stringWithFormat:@"%@",dateTomorrow];
    
    formatter.dateFormat = @"hh:mm:ss";
    NSString *time= [formatter stringFromDate:newDate1];
    
    _lblTime.text =time;
}



#pragma mark- done button action
- (IBAction)btnDoneClicked:(id)sender
{
//    NSString * time = [timePicker getSelectedTimeFromPicker];
//    
//    _lblTime.text = time;
//    
//    //Create date
//    NSString * date1 = ;
//    NSDate *date = [datePicker createDateWithFormat:@"dd-MM-yyyy hh:mm:ss a" andDateString:@"%@ %@:%@:00 %@"];
//    
//    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
//    formatter.dateFormat = @"yyyy-MM-dd";//hh:mm:ss";
//    NSString * date1 = [formatter stringFromDate:date];
//    
//    _lbldate.text = date1;
//    NSLog(@"%@",_lbldate.text);
}


#pragma mark- Time button action

- (IBAction)btnTimeClicked:(id)sender
{
    _btnCalender.hidden = NO;
    _btnTime.hidden = YES;
    
    //Init the datePicker view and set self as delegate
    timePicker = [[SBFlatDatePicker alloc] initWithFrame:self.view1.bounds];
    [timePicker setDelegate:self];
    
    //OPTIONAL: Choose the background color
    [timePicker setBackgroundColor:[UIColor blackColor]];
    
    //Set the data picker as view of the new view controller
    [_view1 addSubview:timePicker];
}

- (IBAction)btnSetfareTapped:(id)sender
{
    isSetfareFulfield = !isSetfareFulfield;
    if(isSetfareFulfield == YES)
    {
        [_btnSetfare setBackgroundImage:[UIImage imageNamed:@"checkMarkNew.png"] forState:UIControlStateNormal];
        steSetFareFulfield = @"1";
    }
    else
    {
        [_btnSetfare setBackgroundImage:[UIImage imageNamed:@"checkBoxNew.png"] forState:UIControlStateNormal];
        steSetFareFulfield = @"0";
    }
}



- (IBAction)btnAnyTapped:(id)sender
{
    [_btnWagon setTitleColor:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1.0] forState:UIControlStateNormal];
    [_btnPremium setTitleColor:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1.0] forState:UIControlStateNormal];
    [_btnAny setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    strVehicleType = @"1";
    fareType = @"Taximeter";
}

- (IBAction)btnPremiumTapped:(id)sender
{
    [_btnWagon setTitleColor:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1.0] forState:UIControlStateNormal];
    [_btnAny setTitleColor:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1.0] forState:UIControlStateNormal];
    [_btnPremium setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    strVehicleType = @"2";
    fareType = @"DestarnyRate";
}

- (IBAction)btnWagonTapped:(id)sender
{
    [_btnAny setTitleColor:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1.0] forState:UIControlStateNormal];
    [_btnPremium setTitleColor:[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1.0] forState:UIControlStateNormal];
    [_btnWagon setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    strVehicleType = @"3";
    fareType = @"Premium";
}

- (IBAction)btnFareTypeTapped:(id)sender
{
    _tblSetFare.hidden = !_tblSetFare.hidden;
}

- (IBAction)btnMeteredTaxiTapped:(id)sender
{
    isMeteredTaxi = !isMeteredTaxi;
    if(isMeteredTaxi == YES)
    {
        [_btnMeteredTaxi setBackgroundImage:[UIImage imageNamed:@"checkMarkNew.png"] forState:UIControlStateNormal];
    }
    else
    {
        [_btnMeteredTaxi setBackgroundImage:[UIImage imageNamed:@"checkBoxNew.png"] forState:UIControlStateNormal];
    }
    //    _imgMeteredTaxi.hidden = !_imgMeteredTaxi.hidden;
}


-(void)textFieldDidChange:(UITextField *)textfield
{
    if(textfield.tag == 301)
    {
        if([textfield.text isEqualToString:@""])
        {
            _tblStartAdd.hidden = YES;
        }
        else
        {
            _tblStartAdd.hidden = NO;
            _tblStartAdd.hidden = NO;
            NSString *urlSTR=[[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyC6SPQpZxZ_JGnUZNd8AKGeBOR8UkXHJtw",_txtFrom.text] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
            
            NSURL *url = [NSURL URLWithString:urlSTR];
            
            NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
            NSURLResponse *responce;
            NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
            NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            
            if( [[dictionary1 valueForKey:@"status"] isEqualToString:@"OK"])
            {
                dispatch_async(dispatch_get_main_queue(), ^{
               
                
                arrSearchRes = [dictionary1 valueForKey:@"predictions"];
                [_tblStartAdd reloadData];
                    
                     });
            }
            else
            {
                _tblStartAdd.hidden = YES;
            }
        }
    }
    else if(textfield.tag == 302)
    {
        if([textfield.text isEqualToString:@""])
        {
            _tblDestAdd.hidden = YES;
        }
        else
        {
            _tblDestAdd.hidden = NO;
            NSString *urlSTR=[[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?input=%@&types=geocode&key=AIzaSyC6SPQpZxZ_JGnUZNd8AKGeBOR8UkXHJtw",_txtTo.text] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
            
            NSURL *url = [NSURL URLWithString:urlSTR];
            
            NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
            NSURLResponse *responce;
            NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
            NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            
            if( [[dictionary1 valueForKey:@"status"] isEqualToString:@"OK"])
            {
                dispatch_async(dispatch_get_main_queue(), ^{
               
                arrSearchResDest = [dictionary1 valueForKey:@"predictions"];
                [_tblDestAdd reloadData];
                     });
            }
            else
            {
                _tblDestAdd.hidden = YES;
            }
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView.tag == 100)
    {
        _tblStartAdd.hidden = YES;
        NSString *strStartAdd = [[arrSearchRes objectAtIndex:indexPath.row] valueForKey:@"description"];
        _txtFrom.text = strStartAdd;
        
        /////---- get lat long
        
        selectedLocationCoordStart = [self getLatLongFromAddress:strStartAdd];
        
        float lat = selectedLocationCoordStart.latitude;
        float lng = selectedLocationCoordStart.longitude;
        
        strLatSelectedST =  [[NSNumber numberWithFloat:lat] stringValue];
        strLngSelectedST =  [[NSNumber numberWithFloat:lng] stringValue];
        
        //--------------
    }
    
    else if (tableView.tag == 127)
    {
        _tblSetFare.hidden = _tblSetFare.hidden;
        if(indexPath.row == 0)
        {
            _btnSetfare.hidden = YES;
            _lblSetFarefulfield.hidden = YES;
            strBookingType = @"Taximeter";
            strFareID = @"0";
            steSetFareFulfield = @"0";
            
        }
        else
        {
            
            NSInteger tmp=indexPath.row-1;
            
            _btnSetfare.hidden = NO;
            _lblSetFarefulfield.hidden = NO;
            strBookingType = @"SetFare";
            strFareID = [[arrFares objectAtIndex:tmp] valueForKey:@"id"];
        }
        
        _txtMySetFare.text = [arrSetFare objectAtIndex:indexPath.row];
        _tblSetFare.hidden = YES;
    }
    
    else
    {
        _tblDestAdd.hidden = YES;
        NSString *strDestAdd = [[arrSearchResDest objectAtIndex:indexPath.row] valueForKey:@"description"];
        _txtTo.text = strDestAdd;
        
        /////---- get lat long
        
        selectedLocationCoordDest = [self getLatLongFromAddress:strDestAdd];
        
        float lat = selectedLocationCoordDest.latitude;
        float lng = selectedLocationCoordDest.longitude;
        
        strLatSelectedD =  [[NSNumber numberWithFloat:lat] stringValue];
        strLngSelectedD =  [[NSNumber numberWithFloat:lng] stringValue];
        
        //--------------
    }
}


-(void)getAllFares
{
    
    //    NSDictionary * param=@{@"cid":@"",
    //                           @"vtid":@"",
    //                           @"booking_type":@"2",
    //                           @"fare_type":@"",
    //                           @"setfare_unfullfilled":@"",
    //                           @"booking_from_lat":@"",
    //                           @"booking_from_lng":@"",
    //                           @"booking_from":@"",
    //                           @"booking_to_lat":@"",
    //                           @"booking_to_lng":@"",
    //                           @"booking_to":@"",
    //                           @"noofpass":@"",
    //                           @"booking_time":@"",
    //                           @"booking_date":@"",
    //                           @"notes":@"",
    //                           @"fareid":@""};   //----- hard coded
    
    //---  replace with new API
    // http://dev12.edreamz3.com/api/passenger.php/getsetfares
    
    
    [[webManager sharedObject] loginRequest:nil withMethod:@"passenger.php/getsetfares" successResponce:^(id response)
     {
         NSError *e = nil;
         NSString *strStatus = [[response valueForKey:@"status"] stringValue];
         
         if([strStatus isEqualToString:@"1"])
         {
             //---
             NSArray * response1 = [[NSArray alloc] init];
             response1 = [response valueForKey:@"items"];
             
             //NSMutableArray *arrFares = [[NSMutableArray alloc] init];
             arrFares = [response valueForKey:@"items"];
             
             for (int i = 0 ; i < arrFares.count ; i++)
             {
                 NSString *str = [[arrFares objectAtIndex:i] valueForKey:@"fare"] ;
                 [arrSetFare addObject:str];
             }
             
             dispatch_async(dispatch_get_main_queue(), ^{
            
             [_tblSetFare reloadData];
                  });
         }
         else if([strStatus isEqualToString:@"0"])
         {
             
         }
     }failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
     }];
    
    ////------------------
}

#pragma mark getLatLong From address
-(CLLocationCoordinate2D )getLatLongFromAddress : (NSString *)address
{
    //http://maps.google.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=false
    
    NSString *urlSTR=[[NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?address=%@&sensor=false",address] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
    
    NSURL *url = [NSURL URLWithString:urlSTR];
    
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60.0];
    
    NSURLResponse *responce;
    NSData *data = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&responce error:nil];
    NSDictionary *dictionary1 = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSArray * resultArray = [dictionary1 valueForKey:@"results"];
    NSDictionary * dic = [resultArray objectAtIndex:0];
    NSDictionary * geo = [dic valueForKey:@"geometry"];
    NSDictionary * location = [geo valueForKey:@"location"];
    
    double lat = [[location valueForKey:@"lat"] doubleValue];
    double lng = [[location valueForKey:@"lng"] doubleValue];
    
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(lat,lng);
    
    return coord;
}

@end
