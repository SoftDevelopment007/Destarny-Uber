//
//  SignInAsPassangerViewController.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/20/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "SlideNavigationController.h"
//#import "Set_PickUp_Location_ViewController.h"
//#import "AddPaymentViewController.h"
//#import "PaymentMethod_ViewController.h"
//#import "WebManager.h"
//#import "MBProgressHUD.h"
//#import "TermsAndConditionsViewController.h"

#import "TPKeyboardAvoidingScrollView.h"
@interface SignInAsPassangerViewController : UIViewController<UITextFieldDelegate,UIAlertViewDelegate>



//___________ properties ______________________

@property (weak, nonatomic) IBOutlet UIView *view1;

@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *mainscrollview;

@property (weak, nonatomic) IBOutlet UIButton *btnSignIn;

@property(nonatomic)BOOL isLogin;

@property (weak, nonatomic) IBOutlet UITextField *txtPassangerFName;

@property (weak, nonatomic) IBOutlet UITextField *txtPassangerLName;

@property (weak, nonatomic) IBOutlet UITextField *txtEmailAddress;

@property (weak, nonatomic) IBOutlet UITextField *txtPassword;

@property (weak, nonatomic) IBOutlet UITextField *txtContactNumber;

@property (weak, nonatomic) IBOutlet UITextField *txtUserName;


@property (weak, nonatomic) IBOutlet UIButton *btnIAgree;
@property (strong, nonatomic) IBOutlet UILabel *lblTandC;
@property (strong, nonatomic) IBOutlet UIButton *btnTancC;

///----------------------------

@property (strong, nonatomic) IBOutlet UIImageView *imgCash;
@property (strong, nonatomic) IBOutlet UIImageView *imgCard;

//___________ Actions __________

- (IBAction)btnBackClicked:(id)sender;

- (IBAction)btnRegisterClicked:(id)sender;

- (IBAction)btnCashTapped:(id)sender;

- (IBAction)btnBankingTapped:(id)sender;

- (IBAction)btnTandCTapped:(id)sender;

@end
