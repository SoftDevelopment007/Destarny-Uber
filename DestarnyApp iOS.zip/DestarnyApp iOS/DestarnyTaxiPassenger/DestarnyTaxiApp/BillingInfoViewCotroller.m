//
//  BillingInfoViewCotroller.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "BillingInfoViewCotroller.h"
#import "webManager.h"
#import "CreditCardTableViewCell.h"
#import "Set_PickUp_Location_ViewController.h"
#import "ConfirmationMapViewController.h"
#import "MBProgressHUD.h"
#import "ALToastView.h"

@interface BillingInfoViewCotroller ()
{
    NSMutableArray *arrCardDetails;
    NSString *strCid;
    int selectedIndex;
    CreditCardTableViewCell *cell;
    MBProgressHUD *HUD;
}
@end

@implementation BillingInfoViewCotroller

- (void)viewDidLoad
{
    [super viewDidLoad];
    arrCardDetails = [[NSMutableArray alloc] init];
    // Do any additional setup after loading the view.
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    HUD.labelText = @"Loading";
    [self.view addSubview:HUD];

    addCardView.hidden = YES;
    _btnDone.hidden = YES;
    NSDictionary *dictPay = [[NSUserDefaults standardUserDefaults] valueForKey:@"dicPassengerDetails"];
    
    NSString *payMethod = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"PaymentType"]];
    if (![payMethod isEqualToString:@"Cash"] || [payMethod isEqualToString:@"CreditCard"]) {
        payMethod = [NSString stringWithFormat:@"%@",[dictPay valueForKey:@"pay_method"]];
    }
    _lblAlert.hidden = YES;
    tableCard.hidden = YES;
    if ([payMethod isEqualToString:@"Cash"])
    {
        [imgCard setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
        [imgCash setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
        
        [_btnCard setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
        
        [_btnCash setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    else
    {
        [imgCash setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
        [imgCard setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
        
        [_btnCash setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
        
        [_btnCard setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    strType = [NSString stringWithFormat:@"%@", payMethod];
    NSString *strSelected = [[NSUserDefaults standardUserDefaults] valueForKey:@"CreditStatus"];
    if ([strSelected isEqualToString:@"YES"])
    {
        NSString *str = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"SelectedCard"]];
        int index = [str intValue];
        selectedIndex = index;
    }
    else
    {
        selectedIndex = -1;
    }
    [self initializeControls];
    [self getCardDetails];
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gestureHandlerMethod:)];
    [self.view addGestureRecognizer:tapRecognizer];
    [_txtMonth addTarget:self action:@selector(textFieldMonthDidChange) forControlEvents:UIControlEventEditingChanged];
    [_txtYear addTarget:self action:@selector(textFieldYearDidChange) forControlEvents:UIControlEventEditingChanged];
}

-(void)gestureHandlerMethod:(UITapGestureRecognizer*)sender
{
    [self hideKeyboard];
}

-(void)textFieldMonthDidChange
{
    if ([_txtMonth.text length]==2)
    {
        NSInteger month = [_txtMonth.text integerValue];
        if (month>12)
        {
            [ALToastView toastInView:self.view withText:@"Month cannot be greater than 12."];
//            [[[UIAlertView alloc] initWithTitle:nil message:@"Month cannot be greater than 12." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
            _txtMonth.text = @"";
        }
        else
        {
            NSLog(@"ok");
        }
    }
}
-(void)textFieldYearDidChange
{
    if ([_txtYear.text length]==2)
    {
        NSInteger setYear = [_txtYear.text integerValue];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yy"];
        NSString *yearString = [formatter stringFromDate:[NSDate date]];
        NSInteger currentYear = [yearString integerValue];
        if (setYear<currentYear)
        {
            [ALToastView toastInView:self.view withText:@"Year cannot be less than current year."];
//            [[[UIAlertView alloc] initWithTitle:nil message:@"Year cannot be less than current year." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
            _txtYear.text = @"";
        }
        else
        {
            NSLog(@"ok");
        }
    }
}


-(void)getCardDetails
{
    /*
     
     http://dev12.edreamz3.com/destarny_taxi_app/api/get_passanger_current_booking_status.php
     
     */
    [HUD show:YES];
//    NSString *savedValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
  //  NSDictionary *dict = [[NSUserDefaults standardUserDefaults]valueForKey:@"dicPassengerDetails"];
   // strCid = [dict valueForKey:@"id"];
    strCid = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
    NSDictionary * param=@{@"cid":strCid};
    
    [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/getpaymentmethod/?" successResponce:^(id response)
     {
         
         NSLog(@"Responce : %@",response);
      //           NSError *e = nil;
         [HUD hide:YES];
     //    NSString *strStatus = [response valueForKey:@"status"];
         
         //         if([strStatus isEqualToString:@"1"])
         if ([[response valueForKey:@"status"] boolValue]==1)
         {
             arrCardDetails = [response valueForKey:@"items"];
             dispatch_async(dispatch_get_main_queue(), ^{
                 [tableCard reloadData];
                  tableCard.hidden = NO;
                 _lblAlert.hidden = YES;

             });
         }
         if (arrCardDetails.count<=0)
         {
             _lblAlert.hidden = NO;
             tableCard.hidden = YES;
         }
         else
         {
             _lblAlert.hidden = NO;
             tableCard.hidden = YES;
         }
     }failure:^(NSError *error)
     {
         _lblAlert.hidden = NO;
         tableCard.hidden = YES;
         NSLog(@"Error : %@",error);
         [ALToastView toastInView:self.view withText:@"Failed to get current booking status."];
//         UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Failed to get current booking status." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//         
//         [alert show];
         [HUD hide:YES];
     }];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrCardDetails.count;    //count number of row from counting array hear cataGorry is An Array
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"CreditCardCell";
    cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if (cell == nil)
    {
        cell = [[CreditCardTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
    }
    
    tableCard.backgroundColor = [UIColor clearColor];
    
    NSString *CNO= [[arrCardDetails objectAtIndex:indexPath.row]valueForKey:@"cnolastdigits"];
  //  NSString *strCard = [CNO substringFromIndex: [CNO length] - 4];
    
  //  NSString *cardNO = [NSString stringWithFormat:@"XXXX XXXX XXXX %@",strCard];
    
    cell.lblCardNo.text = CNO;
    cell.lblCardLastDigits.text = [[arrCardDetails objectAtIndex:indexPath.row]valueForKey:@"cnolastdigits"];
    
  //  cell.lblCVN.text = [[arrCardDetails objectAtIndex:indexPath.row]valueForKey:@"cvn"];
    
    NSString *originalString = [[arrCardDetails objectAtIndex:indexPath.row]valueForKey:@"expdate"];
    
   // NSString *strDate = [originalString stringByReplacingOccurrencesOfString:@" " withString:@"/"];
    
    cell.lblCardExp.text = [NSString stringWithFormat:@"%@",originalString];
    
  //  cell.lblCardExp.text = [originalString stringByReplacingOccurancesOfString:@" " withString:@"/20"];
    
    
    //[cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    [cell.btnCheck addTarget:self action:@selector(checkTapped:) forControlEvents:UIControlEventTouchUpInside];
    cell.btnCheck.tag = indexPath.row;
    
    if(indexPath.row == selectedIndex)
    {
        strSETPAYID = [NSString stringWithFormat:@"%@",[[arrCardDetails objectAtIndex:indexPath.row] valueForKey:@"id"]];
     //   cell.accessoryType = UITableViewCellAccessoryCheckmark;
        [cell.btnCheck setImage:[UIImage imageNamed:@"check_on"] forState:UIControlStateNormal];
        NSString *str = [NSString stringWithFormat:@"YES"];
        [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"CreditStatus"];
        NSString *index = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
        [[NSUserDefaults standardUserDefaults] setObject:index forKey:@"SelectedCard"];
    }
    else
    {
        strSETPAYID = @"";
     //   cell.accessoryType = UITableViewCellAccessoryNone;
        [cell.btnCheck setImage:[UIImage imageNamed:@"check_off"] forState:UIControlStateNormal];
      //  NSString *str = [NSString stringWithFormat:@"NO"];
     //   [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"CreditStatus"];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    selectedIndex = indexPath.row;
//    [tableView reloadData];
}


-(void)checkTapped:(UIButton *)sender
{
    selectedIndex = sender.tag;
    
    NSIndexPath *indexpath = [NSIndexPath indexPathForRow:sender.tag inSection:0];
    cell = (CreditCardTableViewCell *)[tableCard cellForRowAtIndexPath:indexpath];
    
    if ([cell.btnCheck.imageView.image isEqual:[UIImage imageNamed:@"check_off"]])
    {
        _btnDone.hidden = NO;
        [cell.btnCheck setImage:[UIImage imageNamed:@"check_on"] forState:UIControlStateNormal];
        NSString *str = [NSString stringWithFormat:@"Yes"];
        [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"TypeCredit"];
        [tableCard reloadData];
    }
    else
    {
        _btnDone.hidden = YES;
        strSETPAYID = @"";
        [cell.btnCheck setImage:[UIImage imageNamed:@"check_off"] forState:UIControlStateNormal];
        NSString *str = [NSString stringWithFormat:@"NO"];
        [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"CreditStatus"];
        [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"TypeCredit"];
    }
}


-(void)initializeControls
{
    //making ViewPicker's view rounded
    _txtCardNo.layer.cornerRadius = _txtCVN.layer.cornerRadius = _txtMonth.layer.cornerRadius = _txtYear.layer.cornerRadius=addCardView.layer.cornerRadius = _btnDone.layer.cornerRadius = 2.0;
    
    _txtCardNo.layer.borderColor =_txtCVN.layer.borderColor=_txtMonth.layer.borderColor=_txtYear.layer.borderColor=addCardView.layer.borderColor =[[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:.5]CGColor];
    
    //[UIColor colorWithRed:255/255.0 green:203/255.0 blue:7/255.0 alpha:1.0]
    
    _txtCardNo.layer.borderWidth =_txtCVN.layer.borderWidth=_txtMonth.layer.borderWidth=_txtYear.layer.borderWidth=addCardView.layer.borderWidth = 1.0f;
   
    
    
    //changing placeholder's color
    UIColor *colour = [UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1];
    NSString *str = @"Credit Card Number";
    self.txtCardNo.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName:colour}];
    
    
    NSString *str1 = @"CVV";
    self.txtCVN.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str1 attributes:@{NSForegroundColorAttributeName:colour}];
    
    
    
    NSString *str2 = @"MM";
    self.txtMonth.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str2 attributes:@{NSForegroundColorAttributeName:colour}];
    
    NSString *str3 = @"YY";
    self.txtYear.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str3 attributes:@{NSForegroundColorAttributeName:colour}];
}



-(IBAction)btnAddCard:(id)sender
{
    _txtCardNo.text = @"";
    _txtCVN.text = @"";
    _txtMonth.text = @"";
    _txtYear.text = @"";
    _btnDone.hidden = YES;
    viewPaymentMethod.hidden = YES;
    addCardView.hidden = NO;
    tableCard.hidden = YES;
}

-(IBAction)btnCancel:(id)sender
{
    _btnDone.hidden = NO;
    viewPaymentMethod.hidden = NO;
    addCardView.hidden = YES;
    tableCard.hidden = NO;
    [self hideKeyboard];
}

-(void)hideKeyboard
{
    [_txtCardNo resignFirstResponder];
    [_txtCVN resignFirstResponder];
    [_txtMonth resignFirstResponder];
    [_txtYear resignFirstResponder];
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    int allowedLength = 0;
    switch(textField.tag) {
        case 1:
            allowedLength = 16;      // triggered for input fields with tag = 1
            break;
        case 2:
            allowedLength = 3;   // triggered for input fields with tag = 2
            break;
        case 3:
            allowedLength = 2;   // triggered for input fields with tag = 2
            break;

        case 4:
            allowedLength = 2;   // triggered for input fields with tag = 2
            break;
    }
    
    if (textField.text.length >= allowedLength && range.length == 0) {
        return NO; // Change not allowed
    } else {
        return YES; // Change allowed
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(IBAction)btnSubmit:(id)sender
{
    [self hideKeyboard];
    
    int validMonth = [_txtMonth.text intValue];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yy"];
    NSString *yearString = [formatter stringFromDate:[NSDate date]];
    int validYear = [yearString intValue];
    int enteredYear = [_txtYear.text intValue];
    
    
    if ([_txtCardNo.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Please enter credit card number."];

    }
    
    else if ([_txtCVN.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Please enter CVN."];
    }
    
    else if ([_txtMonth.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Please enter credit card expiry month."];

    }
    
    else if ([_txtYear.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Please enter credit card expiry year."];
    }
    
    else if ([_txtCardNo.text length]>16)
    {
      //  [ALToastView toastInView:self.view withText:errMsg];
        UIAlertView *al = [[UIAlertView alloc] initWithTitle:nil message:@"Credit card number cannot be greater than 16 digits." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [al show];
    }
    else if (validMonth>12 || validMonth<=0)
    {
        [ALToastView toastInView:self.view withText:@"Please enter the valid month."];
    }
    else if (enteredYear<validYear)
    {
        [ALToastView toastInView:self.view withText:@"Please enter the valid year."];
    }

    else
    {
        addCardView.hidden = YES;
        tableCard.hidden = NO;
        _btnDone.hidden = NO;
        viewPaymentMethod.hidden = NO;
        /////----------
     //   http://dev12.edreamz3.com/api/passenger.php/addpaymethodmethod/?cid=9&cno=43433534&cvn=123&expdate=08 2016
        NSString *savedValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
        NSString *strCNO = [NSString stringWithFormat:@"%@",_txtCardNo.text];
        NSString *strCVN = [NSString stringWithFormat:@"%@",_txtCVN.text];
        NSString *strCM = [NSString stringWithFormat:@"%d",[_txtMonth.text intValue]];
        NSString *strCY = [NSString stringWithFormat:@"%@",_txtYear.text];
       // NSString *strExpDate = [NSString stringWithFormat:@"%@ %@",strCM, strCY];
        //yyyy/mm/dd
        NSString *strExpDate = [NSString stringWithFormat:@"20%@/%@/01",strCY,strCM];

        [HUD show:YES];
        NSDictionary * param=@{@"cid":strCid,
                               @"cno":strCNO,
                               @"cvn":strCVN,
                               @"expdate":strExpDate,
                               @"setfare_unfullfilled":strCY
                               };   //----- hard coded
        
        
        NSLog(@"%@",param);
        [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/addpaymethodmethod/?" successResponce:^(id response)
         {
             NSString *strStatus = [[response valueForKey:@"status"] stringValue];
             [HUD hide:YES];
             if([strStatus isEqualToString:@"1"])
             {
                 //---
                 NSArray * response1 = [[NSArray alloc] init];
                 response1 = [response valueForKey:@"items"];
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Requested successfully." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                 alert.tag = 123;
                 [alert show];
                 [self getCardDetails];
             }
             else if([strStatus isEqualToString:@"0"])
             {
                 NSString *strStatus = [response valueForKey:@"items"];
                 [[[UIAlertView alloc] initWithTitle:nil message:strStatus delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil]show];
             }
         }failure:^(NSError *error)
         {
             [HUD hide:YES];
             NSLog(@"Error : %@",error);
         }];
    }
}

-(IBAction)btnDoneTapped:(id)sender
{
//    Set_PickUp_Location_ViewController *objSet = [[Set_PickUp_Location_ViewController alloc] init];
//    ConfirmationMapViewController *objConfirm = [[ConfirmationMapViewController alloc] init];
//       objSet.strSetCredit = [NSString stringWithFormat:@"YES"];
//    objConfirm.strSetCredit = [NSString stringWithFormat:@"YES"];
    [self updatePaymentType:strType];
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)btnCashTapped
{
//    [imgCard setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
//    [imgCash setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
//    
//    [_btnCard setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
//    
//    [_btnCash setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    strType = [NSString stringWithFormat:@"Cash"];
    [self updatePaymentType:strType];
}
-(IBAction)btnCardTapped
{
//        [imgCash setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
//        [imgCard setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
//        
//        [_btnCash setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
//        
//        [_btnCard setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        strType = [NSString stringWithFormat:@"CreditCard"];
        [self updatePaymentType:strType];
}

-(void)updatePaymentType:(NSString *)type
{
 //   http://dev12.edreamz3.com/api/passenger.php/setpaymethodmethod/?cid=1&pay_method=Cash/CreditCard&payid=1
    
  //  NSDictionary *dict = [[NSUserDefaults standardUserDefaults]valueForKey:@"dicPassengerDetails"];
//    NSString *strCid1 = [dict valueForKey:@"id"];
//    NSString *strPayid1 = [dict valueForKey:@"payid"];
    if ([strSETPAYID length]==0) {
        strSETPAYID = @"";
    }
    NSDictionary * param=@{@"cid":strCid,@"pay_method":type,@"payid":strSETPAYID};
    
    [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/setpaymethodmethod/?" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
     //    NSError *e = nil;
      //   NSString *strStatus = [response valueForKey:@"status"];
         
         //         if([strStatus isEqualToString:@"1"])
         if ([[response valueForKey:@"status"] boolValue]==1)
         {
             [ALToastView toastInView:self.view withText:@"Payment Method Updated Successfully."];

             
             if ([type isEqualToString:@"Cash"])
             {
                 [imgCard setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
                 [imgCash setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
                 
                 [_btnCard setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
                 
                 [_btnCash setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                 
             }
             else
             {
                 [imgCash setImage:[UIImage imageNamed: @"radioCircleNew.png"]];
                 [imgCard setImage:[UIImage imageNamed: @"radioButtonNew.png"]];
                 
                 [_btnCash setTitleColor:[UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:7.0/255.0f alpha:1] forState:UIControlStateNormal];
                 
                 [_btnCard setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
             }

             
             
             [[NSUserDefaults standardUserDefaults]setObject:type forKey:@"PaymentType"];
         }
         else
         {
             [ALToastView toastInView:self.view withText:[response valueForKey:@"items"]];
         }
         
     }failure:^(NSError *error)
     {
         NSLog(@"Error : %@",error);
         [ALToastView toastInView:self.view withText:@"Failed to update."];
//                  UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Failed to update." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//                  [alert show];
     }];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnBackTapped:(id)sender
{
    [self hideKeyboard];
    [self.navigationController popViewControllerAnimated:YES];
}
@end
