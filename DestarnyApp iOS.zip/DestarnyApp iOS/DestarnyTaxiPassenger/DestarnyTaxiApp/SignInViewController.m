//
//  SignInViewController.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/20/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import "SignInViewController.h"
#import "LoginViewController.h"
#import "SignInAsPassangerViewController.h"

@interface SignInViewController ()

@end

@implementation SignInViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden = YES;
    
    NSString* Identifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString]; // IOS 6+
    NSLog(@"output is : %@", Identifier);
    
     //  740981DD-8B29-4216-9D58-D27BBE837685
    
    [self initializeControls];
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

#pragma mark - initialize controls
-(void)initializeControls
{
    //setting color to placeholders in textfields
    //    UIColor *colour = [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1];
    //    NSString *str = @"Sign in as a Passanger";
    //    self.txtSignInAsPassanger.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName:colour}];
    //
    //    NSString *str1 = @"Sign in as a Driver";
    //    self.txtSignInAsDriver.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str1 attributes:@{NSForegroundColorAttributeName:colour}];
    
    //setting border to textfields

    self.btnSignInAsPassanger.layer.borderWidth=2.0f;
    self.btnSignInAsPassanger.layer.borderColor=[[UIColor colorWithRed:36/255.0 green:31/255.0 blue:25/255.0 alpha:1] CGColor];
    
    self.btnRegister.layer.cornerRadius = self.btnRegister.layer.frame.size.height/6;
    
    //    //setting alignment to placeholder
    //    self.txtSignInAsDriver.textAlignment = NSTextAlignmentCenter;
    //    self.txtSignInAsPassanger.textAlignment = NSTextAlignmentCenter;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnSignInAsPassengerClicked:(id)sender
{
    LoginViewController *lvc = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
    [self.navigationController pushViewController:lvc animated:YES];
}

- (IBAction)btnRegisterClicked:(id)sender
{
//    SignInAsPassangerViewController * vc =[self.storyboard instantiateViewControllerWithIdentifier:@"SignInAsPassangerViewController"];  
//    [[SlideNavigationController sharedInstance] pushViewController:vc animated:YES];
    
    SignInAsPassangerViewController *siap = [self.storyboard instantiateViewControllerWithIdentifier:@"SignInAsPassangerViewController"];
    [self.navigationController pushViewController:siap animated:YES];
}

@end
