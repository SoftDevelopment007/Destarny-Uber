//
//  LeftMenu_TableViewCell.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/27/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftMenu_TableViewCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UIImageView *imgMenu;

@property (weak, nonatomic) IBOutlet UILabel *lblMenu;

@end
