//
//  SearchBarCell.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/17/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchBarCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIView *viewBackground;

@property (strong, nonatomic) IBOutlet UILabel *lblPredAdress;
@end
