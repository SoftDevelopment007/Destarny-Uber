//
//  LeftMenuTableCell.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftMenuTableCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imgMenuIcon;
@property (strong, nonatomic) IBOutlet UILabel *lblMenu;
@property (strong, nonatomic) IBOutlet UILabel *lblBaseLine;

@end
