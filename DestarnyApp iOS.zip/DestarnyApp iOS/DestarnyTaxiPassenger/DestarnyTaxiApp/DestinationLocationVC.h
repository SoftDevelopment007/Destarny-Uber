//
//  DestinationLocationVC.h
//  DestarnyTaxiApp
//
//  Created by edreamz on 3/1/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>


@protocol senddataProtocol <NSObject>

-(void)sendDataToA:(NSString *)DestinationLocation;

@end



@interface DestinationLocationVC : UIViewController<CLLocationManagerDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tblDestination;
@property (weak, nonatomic) IBOutlet UITextField *txtDest;
@property(nonatomic,assign)id delegateDestination;
@property (strong, nonatomic) IBOutlet UIView *viewSearchLoc2;


- (IBAction)TxtDidChange:(id)sender;
- (IBAction)btnBackTapped:(id)sender;

@end
