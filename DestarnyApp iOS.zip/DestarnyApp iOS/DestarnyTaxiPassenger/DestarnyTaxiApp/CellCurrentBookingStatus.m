//
//  CellCurrentBookingStatus.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 3/12/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "CellCurrentBookingStatus.h"

@implementation CellCurrentBookingStatus

- (void)awakeFromNib {
    // Initialization code
    _cellBackground.layer.borderColor = [UIColor colorWithRed:253/255.0 green:197/255.0 blue:21/255.0 alpha:1].CGColor;
    _cellBackground.layer.borderWidth = 1.0;
    
   // CGFloat width = _cellBackground.frame.size.width;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
