//
//  NetworkManager.m
//  MarketOfMums
//
//  Created by IsoDev1 on 10/27/15.
//  Copyright © 2015 Neha. All rights reserved.
//

#import "NetworkManager.h"
#import <netinet/in.h>
#import <SystemConfiguration/SCNetworkReachability.h>
//#define Main_URL @"http://dev12.edreamz3.com/api/"
//#define Main_URL @"http://www.destarny.com/api/"


#define Main_URL @"https://mysetfare.com/au/sydney/api/"      

//#define Main_URL @"http://edreamztaxi.edreamz1.com/api/"

//h ttp://dev12.edreamz3.com/api/

//#define Main_URL @"http://dev12.edreamz3.com/destarny_taxi_app/new_api/"

//#define Main_URL @"http://dev12.edreamz3.com/destarny_taxi_app/api/"

//#define Main_URL @"http://dev8.edreamz3.com/API/"

//http://dev12.edreamz3.com/destarny_taxi_app/api/

@implementation NetworkManager


+(BOOL)connectedToNetwork
{
    struct sockaddr_in zeroAddress;
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.sin_len = sizeof(zeroAddress);
    zeroAddress.sin_family = AF_INET;
    SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);
    SCNetworkReachabilityFlags flags;
    BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
    CFRelease(defaultRouteReachability);
    if (!didRetrieveFlags)
    {
        return 0;
    }
    BOOL isReachable = flags & kSCNetworkFlagsReachable;
    BOOL needsConnection = flags & kSCNetworkFlagsConnectionRequired;
    return (isReachable && !needsConnection) ? YES : NO;
}

+(void)sendWebRequest:(NSDictionary*)parameters withMethod:(NSString*)method successResponce:(void(^)(id response))success failure:(void (^)(NSError *error))failure
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    /*
    [manager GET:[NSString stringWithFormat:@"%@%@",Main_URL,method] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSError *error=nil;
        
        NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
        
        success(dataDic);
        
    }
         failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         [[[UIAlertView alloc] initWithTitle:error.localizedDescription
                                     message:error.localizedRecoverySuggestion
                                    delegate:nil
                           cancelButtonTitle:NSLocalizedString(@"OK", nil)
                           otherButtonTitles:nil, nil] show];
         
         failure(error);
         
     }];
     */
   
//    NSData *postData = [parameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
//    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
//    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
//    [request setURL:[NSURL URLWithString:strCompleteURL]];
//    [request setHTTPMethod:@"POST"];
//    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
//    [request setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"KEY"] forHTTPHeaderField:@"key"];
//    [request setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"PIN"] forHTTPHeaderField:@"pin"];
//    [request setHTTPBody:postData];
//    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
//    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
//        NSString *requestReply = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
//        NSLog(@"requestReply: %@", requestReply);
//    }] resume];

    
    
    
    
    
    
    
    
    
    [manager POST:[NSString stringWithFormat:@"%@%@",Main_URL,method] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSError *error=nil;
        
        NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
        
        success(dataDic);
    }
         failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
//         [[[UIAlertView alloc] initWithTitle:error.localizedDescription
//                                     message:error.localizedRecoverySuggestion
//                                    delegate:nil
//                           cancelButtonTitle:NSLocalizedString(@"OK", nil)
//                           otherButtonTitles:nil, nil] show];
//         
//         failure(error);
         
     }];
}

+(void)uploadImage:(NSDictionary*)parameters withMethod:(NSString*)method WithFilePath:(UIImage*)image successResponce:(void(^)(id response))success failure:(void (^)(NSError *error))failure
{
    
//    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
//    [manager POST:[NSString stringWithFormat:@"%@%@",Main_URL,method] parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
//        [formData appendPartWithFileURL:filePath name:name error:nil];
//    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSLog(@"Success: %@", responseObject);
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error)
//    {
//        NSLog(@"Error: %@", error);
//    }];
    
    NSString *fileName = [NSString stringWithFormat:@"%ld%c%c.jpg", (long)[[NSDate date] timeIntervalSince1970], arc4random_uniform(26) + 'a', arc4random_uniform(26) + 'a'];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
 
    /// !!! only jpg, have to cover png as well
    NSData *imageData = UIImageJPEGRepresentation(image, 0.5); // image size ca. 50 KB
    [manager POST:[NSString stringWithFormat:@"%@%@",Main_URL,method] parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"image" fileName:fileName mimeType:@"image/jpeg"];
    } success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
        NSLog(@"Success %@", responseObject);
         success(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Failure %@, %@", error, operation.responseString);
        failure(error);
    }];

}

+(void)uploadProductImages:(NSDictionary*)parameters withMethod:(NSString*)method WithImageArr:(NSMutableArray*)imageArr successResponce:(void(^)(id response))success failure:(void (^)(NSError *error))failure
{
    
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    
    NSLog(@"%@%@",Main_URL,method);

//        NSLog(@"%u",imageData.length/1024);
        [manager POST:[NSString stringWithFormat:@"%@%@",Main_URL,method] parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData)
        {
            for (int i=0; i<imageArr.count; i++)
            {
                NSString *fileName = [NSString stringWithFormat:@"%ld%c%c.jpg", (long)[[NSDate date] timeIntervalSince1970], arc4random_uniform(26) + 'a', arc4random_uniform(26) + 'a'];
                UIImage *img;
                img=[imageArr objectAtIndex:i];
                
                NSData *imageData = UIImageJPEGRepresentation(img, 0); // image size ca. 50 KB
                
            [formData appendPartWithFileData:imageData name:@"files[]" fileName:fileName mimeType:@"image/jpeg"];
            }
        }
        success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSLog(@"Success %@", responseObject);
             success(responseObject);
         } failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Failure %@, %@", error, operation.responseString);
             failure(error);
         }];
    
}

@end
