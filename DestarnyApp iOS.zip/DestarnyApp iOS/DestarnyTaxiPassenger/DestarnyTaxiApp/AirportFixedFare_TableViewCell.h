//
//  AirportFixedFare_TableViewCell.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 10/13/15.
//  Copyright © 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AirportFixedFare_TableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;


@end
