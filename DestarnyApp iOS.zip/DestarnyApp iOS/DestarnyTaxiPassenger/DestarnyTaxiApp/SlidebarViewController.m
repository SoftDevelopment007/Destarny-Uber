
//
//  SlidebarViewController.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 10/8/15.
//  Copyright © 2015 pavan bhandari. All rights reserved.
//

#import "SlidebarViewController.h"

@interface SlidebarViewController ()
{
   // MBProgressHUD * HUD;
}
@end

@implementation SlidebarViewController

-(void)viewWillAppear:(BOOL)animated
{
    
    [_view1 setFrame:CGRectMake(0, 0, 240, 770)];
        
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshTableWithNotification:) name:@"RefreshTable" object:nil];

    
//    if([[[NSUserDefaults standardUserDefaults]valueForKey:@"FBLogin"] isEqualToString:@"LoggedIn"])
//    {
//        _btnFB.hidden = NO;
//        _btnLogout.hidden = YES;
//        _lblLogout.hidden  =YES;
//        _imgLogout.hidden = YES;
//    }
//    else
//    {
//        _btnFB.hidden = YES;
//        _btnLogout.hidden = NO;
//        _lblLogout.hidden = NO;
//        _imgLogout.hidden = NO;
//    }
}

//- (void)loginButtonDidLogOut:(FBSDKLoginButton *)loginButton
//{
//    [[NSUserDefaults standardUserDefaults] setObject:@"LoggedOut" forKey:@"FBLogin"];
//    
//    //  if (_viewIsVisible)
//    //  {
//    SignInViewController * vc=[self.storyboard instantiateViewControllerWithIdentifier:@"SignInViewController"];
//    
//    //[self.navigationController pushViewController:gymDetail animated:YES];
//    
//    [[SlideNavigationController sharedInstance] pushViewController:vc animated:YES];
//    //  }
//}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   
    
//    if([[[NSUserDefaults standardUserDefaults]valueForKey:@"FBLogin"] isEqualToString:@"LoggedIn"])
//    {
//        _btnFB.hidden = NO;
//        _btnLogout.hidden = YES;
//        _imgLogout.hidden = YES;
//        _lblLogout.hidden =YES;
//    }
//    else
//    {
//        _btnFB.hidden = YES;
//        _btnLogout.hidden = NO;
//        _imgLogout.hidden = NO;
//        _lblLogout.hidden = NO;
//    }
    
    
    
    _btnBooking.tag=101;
    
    _viewShow.hidden=YES;
    
    self.viewbottom.frame=CGRectMake(0,_viewbottom.frame.origin.y - _viewShow.frame.size.height-7 , 240, 162); //Viewshow frame
    
    
    
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"Background"]]];
}



- (void)refreshTableWithNotification:(NSNotification *)notification
{
    _btnBooking.tag=101;
    _viewShow.hidden=YES;
    self.viewbottom.frame=CGRectMake(0, 608- 112-7 , 240, 162); //Viewshow frame
    
    [_mainscrollview setContentOffset:CGPointMake(0,0) animated:YES];
    
//refresh cell BookInAdvance of menu
//    NSDictionary *dic=[self.itemsInTable objectAtIndex:5];
//    NSArray *arr=[dic valueForKey:@"SubItems"];
//    [self CollapseRows:arr];
//    
//    [self.tableView reloadData];
//    
//
//    if([[[NSUserDefaults standardUserDefaults]valueForKey:@"FBLogin"] isEqualToString:@"LoggedIn"])
//    {
//        _btnFB.hidden = NO;
//        _btnLogout.hidden = YES;
//        _imgLogout.hidden = YES;
//        _lblLogout.hidden =YES;
//    }
//    else
//    {
//        _btnFB.hidden = YES;
//        _btnLogout.hidden = NO;
//        _imgLogout.hidden = NO;
//        _lblLogout.hidden = NO;
//    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBookingClicked:(id)sender
{
    if (_btnBooking.tag==101)
    {
        
        _viewShow.hidden=NO;
        CATransition *transition = [CATransition animation];
        transition.duration = 0.5;
        transition.type = kCATransitionPush;
        transition.subtype = kCATransitionFromLeft;
        [transition setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
        self.viewShow.frame = CGRectMake(44, 493  , 195, 112); //view show

        
        [self.viewShow.layer addAnimation:transition forKey:nil];
        
//        [UIView animateWithDuration:0.5
//                              delay:0.1
//                            options:UIViewAnimationTransitionFlipFromLeft
//                         animations:^{
//                             self.viewShow.frame = CGRectMake(53, 412, 189, 118);
//                         }
//                         completion:^(BOOL finished){
//                         }];
//        [self.view addSubview:self.viewShow];

        self.viewbottom.frame=CGRectMake(0, 608, 240, 162); //view bottom
        _btnBooking.tag=102;
    }
    else if(_btnBooking.tag==102)
    {
        _viewShow.hidden=YES;
//        [UIView animateWithDuration:0.5
//                              delay:0.1
//                            options:UIViewAnimationCurveEaseOut
//                         animations:^{
//                             self.viewShow.frame = CGRectMake(0, 0, 0, 0);
//                         }
//                         completion:^(BOOL finished){
//                         }];
//        [self.view1 addSubview:self.viewShow];
        
        self.viewbottom.frame=CGRectMake(0,_viewbottom.frame.origin.y - _viewShow.frame.size.height-7 , 240, 162); //view show
        _btnBooking.tag=101;
    }
}

#pragma mark - Layout subview method
-(void)viewWillLayoutSubviews
{
    [_mainscrollview contentSizeToFit];
    [_mainscrollview layoutIfNeeded];
   // self.mainscrollview.contentSize=CGSizeMake(self.view1.frame.size.width, self.viewbottom.frame.origin.y+self.viewbottom.frame.size.height+60);
    
    self.mainscrollview.contentSize = CGSizeMake(self.view1.frame.size.width, self.view1.frame.size.height-20);
}

#pragma mark - Home button Action
- (IBAction)btnHomeClicked:(id)sender
{
    NSString * flag = [[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"];
    
    NSString * flag1 = [[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentMethod"];
    
    if([flag isEqualToString:@"Register"])
    {
        
        if([flag1 isEqualToString:@"CreditCard"])
        {
            [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:4] animated:NO];
        }
        else
        {
            [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:3] animated:YES];
        }
    }
    else if([flag isEqualToString:@"Session"])
    {
//        Set_PickUp_Location_ViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"Set_PickUp_Location_ViewController"];
//        [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
    }
    else
    {
        [[SlideNavigationController  sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:2] animated:YES];
    }
}


- (IBAction)btnProfileClicked:(id)sender
{
//    ProfileViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
//    [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
    
}

- (IBAction)btnGoloyalClicked:(id)sender
{
    
}

- (IBAction)btnBillingInfoClicked:(id)sender
{
//   BillingInfoViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"BillingInfoViewController"];
//    [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
}

- (IBAction)btnFavouriteClicked:(id)sender
{
//   FavouriteViewController * vc  = [self.storyboard instantiateViewControllerWithIdentifier:@"FavouriteViewController"];
//    [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
}

- (IBAction)btnPrebookingClicked:(id)sender
{
//    Taxi_Booking_Form_ViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"Taxi_Booking_Form_ViewController"];
//    [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
}

- (IBAction)btnFixedFareToAirportClicked:(id)sender
{
//   AirportFixedPriceBookingForm_ViewController * vc =[self.storyboard instantiateViewControllerWithIdentifier: @"AirportFixedPriceBookingForm_ViewController"];
//    
//    [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
}

#pragma mark - menu invite friend action
- (IBAction)btnInviteFriendsClicked:(id)sender
{
//    InviteFriendsViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"InviteFriendsViewController"];
//    [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
}

#pragma mark - menu contact action
- (IBAction)btnContactClicked:(id)sender
{
//    EmergencyViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"EmergencyViewController"];
//    [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
}



#pragma mark - button current booking status
- (IBAction)btnCurrentBookingStatusClicked:(id)sender
{
//    CurrentBookingVC_ViewController * vc =[self.storyboard instantiateViewControllerWithIdentifier:@"CurrentBookingVC_ViewController"];
//    
//    [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
}

#pragma mark - logout menu action
- (IBAction)btnShareClicked:(id)sender
{
//    ShareViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ShareViewController"];
//    [[SlideNavigationController sharedInstance] pushViewController:vc animated:NO];
}

#pragma mark - menu logout action
- (IBAction)btnLogoutClicked:(id)sender
{
       if([[[NSUserDefaults standardUserDefaults] objectForKey:@"FBLogin"] isEqualToString:@"LoggedIn"])// setObject:@"LoggedIn" forKey:@"FBLogin"];)
       {
//           FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
//           
//           [[NSUserDefaults standardUserDefaults] setObject:@"LoggedOut" forKey:@"FBLogin"];
//           
//           [login logOut];
           
           [[SlideNavigationController sharedInstance]popToRootViewControllerAnimated:NO];
           
          // _btnFB.hidden = YES;
           _btnLogout.hidden = NO;
           _lblLogout.hidden = NO;
           _imgLogout.hidden = NO;
       }
       else
       {
           NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
           [defaults setObject:@"" forKey:@"username"];
           [defaults setObject:@"" forKey:@"password"];
           [defaults setObject:@"" forKey:@"isLoginOrRegister"];
           [defaults setObject:@"" forKey:@"FromBillingInfo"];
           [defaults setObject:@"" forKey:@"FromConfirmationPage"];
           
           [[SlideNavigationController sharedInstance]popToRootViewControllerAnimated:NO];
           
           [[NSUserDefaults standardUserDefaults]setObject:@"" forKey:@"selectedAddress"];
           [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"selectedAddress1"];
       }
}

#pragma mark - menu prebooking action
- (IBAction)btnPreBookingClicked:(id)sender
{
//    PerBookingHistoryViewController * vc = [self.storyboard instantiateViewControllerWithIdentifier:@"PerBookingHistoryViewController"];
//    [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
}

#pragma mark - menu prebooking action
- (IBAction)btnGoLoyalCreditClicked:(id)sender
{
//    CreditViewController * vc =[self.storyboard instantiateViewControllerWithIdentifier:@"CreditViewController"];
//    [[SlideNavigationController sharedInstance]pushViewController:vc animated:NO];
}

@end


