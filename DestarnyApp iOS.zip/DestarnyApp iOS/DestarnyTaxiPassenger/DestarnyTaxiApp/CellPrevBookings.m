//
//  CellPrevBookings.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 3/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "CellPrevBookings.h"

@implementation CellPrevBookings

- (void)awakeFromNib
{
    // Initialization code
    _lblBackground.layer.cornerRadius = 5;
    _lblBackground.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
