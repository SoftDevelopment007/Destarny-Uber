//
//  TaxiBookingForm_TableViewCell.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 9/29/15.
//  Copyright © 2015 pavan bhandari. All rights reserved.
//

#import "TaxiBookingForm_TableViewCell.h"

@implementation TaxiBookingForm_TableViewCell

- (void)awakeFromNib {
    // Initialization code
    _lblBackground.layer.cornerRadius = 5;
    _lblBackground.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
