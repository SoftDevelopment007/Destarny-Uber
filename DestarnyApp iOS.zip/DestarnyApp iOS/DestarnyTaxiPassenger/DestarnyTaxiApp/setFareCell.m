//
//  setFareCell.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 4/19/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "setFareCell.h"

@implementation setFareCell

- (void)awakeFromNib {
    // Initialization code
    _lblFare.layer.cornerRadius = 5;
    _lblFare.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
