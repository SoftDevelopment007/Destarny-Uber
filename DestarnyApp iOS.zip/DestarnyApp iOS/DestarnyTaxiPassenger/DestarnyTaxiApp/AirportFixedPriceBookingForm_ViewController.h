//
//  AirportFixedPriceBookingForm_ViewController.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/21/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Set_PickUp_Location_ViewController.h"
#import "Taxi_Booking_Form_ViewController.h"
#import "AirportFixedFare_TableViewCell.h"


@interface AirportFixedPriceBookingForm_ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
{
    NSInteger no_Of_Passemger;
    NSInteger vehicleType; 
    UIDatePicker * datePicker;
    IBOutlet UITableView *tableAirportList;
}

//____________ Properties ___________

@property (weak, nonatomic) IBOutlet UILabel *lblFare;

@property (weak, nonatomic) IBOutlet UITableView *tableViewDestination;

@property (weak, nonatomic) IBOutlet UITableView *tableViewNoofPassenger;

@property(nonatomic,retain)NSMutableArray * initialPlaces;

@property (nonatomic,retain)NSMutableArray * filteredPlaces;

@property(nonatomic)BOOL isFiltered;

@property (weak, nonatomic) IBOutlet UITextField *txtFrom;
@property (weak, nonatomic) IBOutlet UITextField *txtTo;

@property (weak, nonatomic) IBOutlet UITextField *txtTime;

@property (weak, nonatomic) IBOutlet UITextField *txtNotes;

@property (weak, nonatomic) IBOutlet UITextField *txtPayBy;

@property (weak, nonatomic) IBOutlet UITextField *txtNoOfPassangers;

@property (weak, nonatomic) IBOutlet UIButton *btnOrderTaxi;




@property (weak, nonatomic) IBOutlet UIButton *btnStandard;

@property (weak, nonatomic) IBOutlet UIButton *btnVan;

@property (weak, nonatomic) IBOutlet UIButton *btnPremium;


@property (nonatomic,retain)NSString * selectedVehicleType;


@property (weak, nonatomic) IBOutlet UIImageView *imgVan;
@property (weak, nonatomic) IBOutlet UIImageView *imgPremium;
@property (weak, nonatomic) IBOutlet UIImageView *imgStandard;




@property (weak, nonatomic) IBOutlet UILabel *lblNoofPassenger;

//______________array to define maximum of number of Passenger ________
@property(nonatomic,retain)NSArray * no_of_passenger_Standard;

@property(nonatomic,retain)NSArray * no_of_passenger_van;

@property (nonatomic,retain)NSArray * no_of_passenegr_premium;

//@property (weak, nonatomic) IBOutlet UITableView *tableViewNoofPassenger;

@property (weak, nonatomic) IBOutlet UIButton *btnNoofPassenger;




//______________ Actions _________________

- (IBAction)btnOrderTaxiClicked:(id)sender;

- (IBAction)btnBackClicked:(id)sender;

- (IBAction)btnUpClicked:(id)sender;

- (IBAction)btnDownClicked:(id)sender;

- (IBAction)btnVehicleClicked:(id)sender;

- (IBAction)btnNoofPassengerClicked:(id)sender;


//_____________ goloyal View Propertiees and Actions________



@property ( nonatomic) IBOutlet UIImageView *imgviewYes;

@property ( nonatomic) IBOutlet UIImageView *imgviewNo;

@property (nonatomic) IBOutlet UIButton *btnYes;

@property ( nonatomic) IBOutlet UIButton *btnNo;

@property ( nonatomic) IBOutlet UIButton *btnAddGoLoyal;


@property ( nonatomic) IBOutlet UIView *viewGoLoyal;




- (IBAction)btnNoClicked:(id)sender;

- (IBAction)btnYesClicked:(id)sender;

- (IBAction)btnDoneClicked:(id)sender;

//---------

@property (strong, nonatomic) IBOutlet UILabel *lblPremium;
@property (strong, nonatomic) IBOutlet UILabel *lblStandard;
@property (strong, nonatomic) IBOutlet UILabel *lblVan;

//---------


@end
