//
//  SlidebarViewController.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 10/8/15.
//  Copyright © 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"
#import "SlideNavigationContorllerAnimatorFade.h"
#import "SlideNavigationContorllerAnimatorSlide.h"
#import "SlideNavigationContorllerAnimatorScale.h"
#import "SlideNavigationContorllerAnimatorScaleAndFade.h"
#import "SlideNavigationContorllerAnimatorSlideAndFade.h"

#import "SlideNavigationController.h"
#import "LeftMenu_TableViewCell.h"
//-- #import "AirportFixedPriceBookingForm_ViewController.h"
//-- #import "Review_ViewController.h"
#import "SignInViewController.h"
//-- #import "EmergencyViewController.h"
//-- #import "ProfileViewController.h"
//-- #import "InviteFriendsViewController.h"
//-- #import "ShareViewController.h"
//-- #import "FavouriteViewController.h"
//-- #import "BillingInfoViewController.h"
//-- #import "Taxi_Booking_Form_ViewController.h"
//-- #import "PerBookingHistoryViewController.h"
//-- #import "CurrentBookingVC_ViewController.h"
//-- #import "GoLoyal_ViewController.h"
//-- #import "CreditViewController.h"

//#import <FBSDKCoreKit/FBSDKCoreKit.h>
//#import <FBSDKLoginKit/FBSDKLoginKit.h>




@interface SlidebarViewController : UIViewController//<FBSDKLoginButtonDelegate>
{
BOOL _viewDidAppear;
BOOL _viewIsVisible;
}

@property (weak, nonatomic) IBOutlet UIView *viewShow;
@property (weak, nonatomic) IBOutlet UIButton *btnBooking;

@property (weak, nonatomic) IBOutlet UIButton *btnInvitefrnd;

- (IBAction)btnBookingClicked:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *btnInviteFrndclick;

@property (weak, nonatomic) IBOutlet UIView *viewbottom;

@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *mainscrollview;

@property (weak, nonatomic) IBOutlet UIView *view1;






- (IBAction)btnHomeClicked:(id)sender;

- (IBAction)btnProfileClicked:(id)sender;

- (IBAction)btnGoloyalClicked:(id)sender;

- (IBAction)btnBillingInfoClicked:(id)sender;

- (IBAction)btnFavouriteClicked:(id)sender;

- (IBAction)btnPrebookingClicked:(id)sender;

- (IBAction)btnFixedFareToAirportClicked:(id)sender;

- (IBAction)btnInviteFriendsClicked:(id)sender;

- (IBAction)btnContactClicked:(id)sender;

- (IBAction)btnLiveMeterClicked:(id)sender;

- (IBAction)btnCurrentBookingStatusClicked:(id)sender;




- (IBAction)btnShareClicked:(id)sender;

- (IBAction)btnLogoutClicked:(id)sender;


//@property (weak, nonatomic) IBOutlet FBSDKLoginButton *btnFB;
//@property (weak, nonatomic) IBOutlet UIButton *btnFB;

@property (weak, nonatomic) IBOutlet UIButton *btnLogout;

@property (weak, nonatomic) IBOutlet UIImageView *imgLogout;

@property (weak, nonatomic) IBOutlet UILabel *lblLogout;


//- (IBAction)btnLogoutFbClicked:(id)sender;



- (IBAction)btnPreBookingClicked:(id)sender;

- (IBAction)btnGoLoyalCreditClicked:(id)sender;










@end
