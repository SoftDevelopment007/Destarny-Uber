//
//  CellConfirmationStart.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/19/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "CellConfirmationStart.h"

@implementation CellConfirmationStart

- (void)awakeFromNib
{
    // Initialization code
    _viewPredBack.layer.cornerRadius = 5;
    _viewPredBack.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
