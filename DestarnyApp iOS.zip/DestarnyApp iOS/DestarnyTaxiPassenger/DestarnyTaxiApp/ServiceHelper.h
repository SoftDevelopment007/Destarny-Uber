//
//  ServiceHelper.h
//  n0W
//
//  Created by Lakshaya on 1/28/15.
//  Copyright (c) 2015 Lakshaya. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Constant.h"
#import <UIKit/UIKit.h>

@interface ServiceHelper : NSObject
{
    NSMutableData *receivedData;
}

+(void)uploadImageWithParams:(NSMutableDictionary *)params endPoint:(NSString *)endpoint image:(UIImage *)img success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock;

-(void)postParametersSimple:(NSMutableDictionary *)dictParams withEndPoint:(NSString *)endPoint success:(void (^)(id))successBlock error:(void (^)(NSError *))errorBlock;


//Post Parameters with server url
+(void)postParameters:(NSMutableDictionary *)dictParams withEndPoint:(NSString *)endPoint success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock;

+(void)postAlertParameters:(NSMutableDictionary *)dictParams withEndPoint:(NSString *)endPoint success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock;

//Get Response with server url
+(void)getResponseWithEndPoint:(NSString *)serverUr success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock;

+(void)getResponseWithEndPoint:(NSString *)endPoint Parameters:(NSMutableDictionary *)dictParams success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock;

+(void)uploadImage:(NSString *)serverUr image:(UIImage *)img success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock;

+(void)synchronizeMessageWithID:(NSString *)msgId Success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock;

+(void)uploadVideoWithParams:(NSMutableDictionary *)params endPoint:(NSString *)end image:(NSData *)data success:(void (^)(id))successBlock error:(void (^)(NSError *error))errorBlock;
@end
