//
//  DatePicker.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 9/14/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DatePickerDelegate;

//Button for save
@interface SBPickerButton1 : UIButton

@end

//Scroll view
@interface SBPickerScrollView1 : UITableView

@property NSInteger tagLastSelected1;


- (void)dehighlightLastCell;
- (void)highlightCellWithIndexPathRow:(NSUInteger)indexPathRow;
@end


@interface DatePicker : UIView<UIScrollViewDelegate,UITableViewDataSource,UITableViewDelegate>


//Date & Time Ranges
@property NSMutableIndexSet* dayRange1;
@property NSMutableIndexSet* minuterange1;

//Format of Day column
@property NSString* dayFormat1;


@property (nonatomic, weak) id<DatePickerDelegate> delegate;
@property (nonatomic, strong, readonly) NSDate *selectedDate1;



- (NSDate *)createDateWithFormat:(NSString *)format andDateString:(NSString *)dateString;

@end
