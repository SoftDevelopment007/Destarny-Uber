//
//  LoginViewController.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/2/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"

@interface LoginViewController : UIViewController

- (IBAction)btnForgotPasswordTapped:(id)sender;

- (IBAction)btnLoginTapped:(id)sender;

- (IBAction)btnBackTapped:(id)sender;


@property (strong, nonatomic) IBOutlet UIButton *btnRemember;
@property (strong, nonatomic) IBOutlet UIButton *btnLogin;
@property (strong, nonatomic) IBOutlet UITextField *txtUsername;
@property (strong, nonatomic) IBOutlet UITextField *txtPassword;
@property (strong, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *myScrollView;
@property (strong, nonatomic) IBOutlet UIView *view1;
@end
