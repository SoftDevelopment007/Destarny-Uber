//
//  FavouritesViewController.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavouritesViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tblPrevBookings;
@property (strong, nonatomic) IBOutlet UISegmentedControl *segPastNFav;

- (IBAction)btnBackTapped:(id)sender;

@end
