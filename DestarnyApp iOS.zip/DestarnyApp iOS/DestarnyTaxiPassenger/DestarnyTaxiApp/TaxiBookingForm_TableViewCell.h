//
//  TaxiBookingForm_TableViewCell.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 9/29/15.
//  Copyright © 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TaxiBookingForm_TableViewCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@property (strong, nonatomic) IBOutlet UILabel *lblBackground;



@end
