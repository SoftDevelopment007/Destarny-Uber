//
//  ProfileViewController.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 9/5/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import "ProfileViewController.h"
#import "webManager.h"
#import "MBProgressHUD.h"
#import "ALToastView.h"

@interface ProfileViewController ()
{
    MBProgressHUD *  HUD;
    NSString *strPaymentMode;
}

@end

@implementation ProfileViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _btnEdit.layer.cornerRadius = 5;
    _btnEdit.clipsToBounds = YES;
    
    strPaymentMode = [[NSString alloc] init];
    
    //________________ Activity Indicator ____________________
    
        HUD=[[MBProgressHUD alloc]initWithView:self.view];
        [HUD setLabelText:@"Loading"];
        [self.view addSubview:HUD];
    
    
    //    //changing placeholder's color
    //    UIColor *colour = [UIColor colorWithRed:203/255.0 green:170/255.0 blue:81/255.0 alpha:1];
    //    NSString *str = @" John Abbache";
    //    self.txtName.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName:colour}];
    //
    //    NSString * str1=@"Name@example.com";
    //    self.txtEmailID.attributedPlaceholder = [[NSAttributedString alloc]initWithString:str1 attributes:@{NSForegroundColorAttributeName:colour}];
    //
    //    NSString * str2=@"name123";
    //    self.txtPassword.attributedPlaceholder = [[NSAttributedString alloc]initWithString:str2 attributes:@{NSForegroundColorAttributeName:colour}];
    //
    //    NSString * str3=@"91 8800 5437";
    //    self.txtContactNo.attributedPlaceholder = [[NSAttributedString alloc]initWithString:str3 attributes:@{NSForegroundColorAttributeName:colour}];
    
    
    //making button's corner rounded
    _btnEdit.layer.cornerRadius = _btnEdit.layer.frame.size.height/6;
    
    NSArray * arraydic = [[NSUserDefaults standardUserDefaults]objectForKey:@"dataDictionary"];
    //dicPassengerDetails
    //  NSDictionary *dic = [arraydic objectAtIndex:0];
    NSDictionary *dic = [[NSUserDefaults standardUserDefaults]objectForKey:@"dicPassengerDetails"];
    
    _txtContactNo.text = [dic valueForKey:@"phone_no"];
    _txtEmailID.text = [dic valueForKey:@"emailid"];
    _txtFirstName.text = [dic valueForKey:@"fname"];
    _txtLastName.text = [dic valueForKey:@"lname"];
    _txtPassword.text = [dic valueForKey:@"password"];
    _txtUserName.text = [dic valueForKey:@"username"];
    NSString *strPayMethod = [dic valueForKey:@"pay_method"];
    
    [self paymentSelector:strPayMethod];
    

    _txtContactNo.inputAccessoryView = [self keyboardToolBar];
}

-(void)viewWillAppear:(BOOL)animated
{
    NSDictionary *dic = [[NSUserDefaults standardUserDefaults]objectForKey:@"dicPassengerDetails"];
    
    _txtContactNo.text = [dic valueForKey:@"phone_no"];
    _txtEmailID.text = [dic valueForKey:@"emailid"];
    _txtFirstName.text = [dic valueForKey:@"fname"];
    _txtLastName.text = [dic valueForKey:@"lname"];
    _txtPassword.text = [dic valueForKey:@"password"];
    _txtUserName.text = [dic valueForKey:@"username"];
    
    NSString *strPayMethod = [dic valueForKey:@"pay_method"];
    
    //----
    
    _imgCash.image = [UIImage imageNamed:@"radioCircleNew.png"];
    _imgCard.image = [UIImage imageNamed:@"radioCircleNew.png"];
    
    [self paymentSelector:strPayMethod];
}

-(void)paymentSelector:(NSString *)strPayMethod
{
    if([strPayMethod isEqualToString:@"Cash"])
    {
        _imgCard.image = [UIImage imageNamed:@"radioCircleNew.png"];
        _imgCash.image = [UIImage imageNamed:@"radioButtonNew.png"];
        strPaymentMode = @"cash";
    }
    else
    {
        _imgCash.image = [UIImage imageNamed:@"radioCircleNew.png"];
        _imgCard.image = [UIImage imageNamed:@"radioButtonNew.png"];
        strPaymentMode = @"banking";
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

//Scroll View method
-(void)viewWillLayoutSubviews
{
    [_mainScrollView
     contentSizeToFit];
    [_mainScrollView layoutIfNeeded];
    self.mainScrollView.contentSize=self.view1.bounds.size;
}

#pragma mark - toolBar method

- (UIToolbar *)keyboardToolBar
{
    UIToolbar *toolbar = [[UIToolbar alloc] init];
    [toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [toolbar sizeToFit];
    
    UIButton * doneButton=[UIButton buttonWithType:UIButtonTypeCustom];
    doneButton.frame=CGRectMake(0, 0, 50, 30);
    [doneButton addTarget:self action:@selector(doneTapped) forControlEvents:UIControlEventTouchUpInside];
    [doneButton setTitle:@"Done" forState:UIControlStateNormal];
    [doneButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    UIBarButtonItem *fixedSpace = [[UIBarButtonItem alloc]
                                   initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                   target:nil
                                   action:nil];
    [fixedSpace setWidth:self.view.frame.size.width-70];
    UIBarButtonItem *done_Button = [[UIBarButtonItem alloc] initWithCustomView:doneButton];
    NSArray *itemsArray = [[NSArray alloc]initWithObjects:fixedSpace,done_Button, nil];
    [toolbar setItems:itemsArray];
    return toolbar;
}

-(void)doneTapped
{
    [_txtContactNo resignFirstResponder];
}

#pragma mark - textField delegate method
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

//#pragma mark - Email Validation method
//- (BOOL)validateEmail:(NSString *)emailStr
//{
//    NSString *emailRegex = @"[A-Z0-9a-z._%+]+@[A-Za-z0-9.]+\\.[A-Za-z]{2,4}";
//    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
//    return [emailTest evaluateWithObject:emailStr];
//}

#pragma mark - update button method
- (IBAction)btnEditClicked:(id)sender
{
    [HUD show:YES];
    if([_txtContactNo.text isEqualToString:@""] || [_txtEmailID.text isEqualToString:@""] || [_txtFirstName.text isEqualToString:@""] || [_txtLastName.text isEqualToString:@""] ||[_txtPassword.text isEqualToString:@""] || [_txtUserName.text isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"All Fields are Mandatory"];
//        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"All Fields are Mandatory" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
//        
//        alert.delegate = self;
//        [alert show];
         [HUD hide:YES];
    }
    else if ([self validateEmail:_txtEmailID.text]==NO)
    {
        [ALToastView toastInView:self.view withText:@"Please enter valid Email Id"];
//        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please enter valid Email Id" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//        
//        [alert show];
    }
    else if ([strPaymentMode isEqualToString:@""])
    {
        [ALToastView toastInView:self.view withText:@"Please select payment method."];
//        [[[UIAlertView alloc] initWithTitle:nil message:@"Please select payment method." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }
    else
    {
        /*
         h ttp://dev12.edreamz3.com/api/passenger.php/editprofile/?
         id=9&
         fname=raju1&
         lname=patil&
         username=raj&
         password=123&
         emailid=sachin.d@edreamz.in&
         phone_no=3333&
         deviceid=888&
         device_type=Android/iOS&
         pay_method=Cash
         */
        
        NSString *savedValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"passengerID"];
         NSString *strDeviceID = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"DeviceID"]];
        
        NSDictionary * param=@{@"id":savedValue,
                               @"fname":_txtFirstName.text,
                               @"lname":_txtLastName.text,
                               @"username":_txtUserName.text,
                               @"password":_txtPassword.text,
                               @"emailid":_txtEmailID.text,
                               @"phone_no":_txtContactNo.text,
                               @"deviceid":strDeviceID,
                               @"device_type":@"iOS",
                               @"pay_method":strPaymentMode};
        
        [[webManager sharedObject] loginRequest:param withMethod:@"passenger.php/editprofile/?" successResponce:^(id response)
         {
             NSLog(@"Responce : %@",response);
             
             /*
              
              {"Response":{"ErrorCode":0,"Message":"Request_Successful"},"status":"Success"}
              
              */
             
             NSError *e = nil;
             NSString *strStatus = [[response valueForKey:@"status"] stringValue];
             [HUD hide:YES];
             if([strStatus isEqualToString:@"1"])
             {
                 NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                 
                 //--- other save to user deafults
                 
                 NSString *strCid = [[[response valueForKey:@"items"] objectAtIndex:0] valueForKey:@"id"];
                 [defaults setValue:strCid forKey:@"passengerID"];
                 
                 NSDictionary *dicUserDetails = [[NSDictionary alloc] init];
                 dicUserDetails = [[response valueForKey:@"items"] objectAtIndex:0];
                 [defaults setValue:dicUserDetails forKey:@"dicPassengerDetails"];
                 
//                 [ALToastView toastInView:self.view withText:@"Profile updated successfully."];
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Profile updated successfully." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                 
                 [alert show];
                 alert.tag = 20;
             }  
         }failure:^(NSError *error)
         {
             NSLog(@"Error : %@",error);
             [ALToastView toastInView:self.view withText:@"Failed to update profile."];
//             UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Failed to update profile." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             
//             [alert show];
              [HUD hide:YES];
         }];
    }
    
}



#pragma mark - Email Validation method
- (BOOL)validateEmail:(NSString *)emailStr
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+]+@[A-Za-z0-9.]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailStr];
}

#pragma mark -alertView delegate method

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == 301)
    {
        if([[[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"] isEqualToString:@"Register"])
        {
            if([[[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentMethod"] isEqualToString:@"CreditCard"])
            {
                [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:4] animated:YES];
            }
            else
            {
                [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:3] animated:YES];
            }
        }
        else if([[[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"] isEqualToString:@"Session"])
        {
            [[SlideNavigationController sharedInstance]popViewControllerAnimated:YES];
        }
        else
        {
            [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:2] animated:YES];
        }
    }
    
    if(alertView.tag == 20)
    {
        if(buttonIndex == 0)
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

#pragma mark - Back button action
- (IBAction)btnBackClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
    
    /*
     //  [[SlideNavigationController sharedInstance] popViewControllerAnimated:YES];
     
     if([[[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"] isEqualToString:@"Register"])
     {
     if([[[NSUserDefaults standardUserDefaults] objectForKey:@"PaymentMethod"] isEqualToString:@"CreditCard"])
     {
     [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:4] animated:YES];
     }
     else
     {
     [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:3] animated:YES];
     }
     }
     else if([[[NSUserDefaults standardUserDefaults] objectForKey:@"isLoginOrRegister"] isEqualToString:@"Session"])
     {
     [[SlideNavigationController sharedInstance]popViewControllerAnimated:YES];
     }
     else
     {
     [[SlideNavigationController sharedInstance] popToViewController:[[SlideNavigationController sharedInstance].viewControllers objectAtIndex:2] animated:YES];
     }
     */
}



- (IBAction)btnCashTapped:(id)sender
{
    _imgCard.image = [UIImage imageNamed:@"radioCircleNew.png"];
    _imgCash.image = [UIImage imageNamed:@"radioButtonNew.png"];
    strPaymentMode = @"cash";
}

- (IBAction)btnBankingTapped:(id)sender
{
    _imgCash.image = [UIImage imageNamed:@"radioCircleNew.png"];
    _imgCard.image = [UIImage imageNamed:@"radioButtonNew.png"];
    strPaymentMode = @"banking";
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextField: textField up: YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField: textField up: NO];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
- (void) animateTextField: (UITextField*) textField up: (BOOL) up
{
    const int movementDistance = textField.frame.origin.y / 2; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed

    int movement = (up ? -movementDistance : movementDistance);

    [UIView beginAnimations: @"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}



@end
