//
//  SearchBarCell.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/17/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "SearchBarCell.h"

@implementation SearchBarCell

- (void)awakeFromNib
{
    // Initialization code
    
    _viewBackground.layer.cornerRadius = 5;
    _viewBackground.clipsToBounds = YES;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
