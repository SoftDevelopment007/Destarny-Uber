//
//  ProfileViewController.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 9/5/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideNavigationController.h"
//#import "WebManager.h"
#import "TPKeyboardAvoidingScrollView.h"
//#import "MBProgressHUD.h"


@interface ProfileViewController : UIViewController<UITextFieldDelegate,UIAlertViewDelegate>



//***********Property*************


@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *mainScrollView;

@property (weak, nonatomic) IBOutlet UIView *view1;

@property (weak, nonatomic) IBOutlet UITextField *txtPassword;

@property (weak, nonatomic) IBOutlet UITextField *txtContactNo;

@property (weak, nonatomic) IBOutlet UITextField *txtFirstName;

@property (weak, nonatomic) IBOutlet UITextField *txtLastName;

@property (weak, nonatomic) IBOutlet UITextField *txtEmailID;

@property (weak, nonatomic) IBOutlet UITextField *txtUserName;

@property (weak, nonatomic) IBOutlet UIButton *btnEdit;


@property (strong, nonatomic) IBOutlet UIImageView *imgCash;

@property (strong, nonatomic) IBOutlet UIImageView *imgCard;

//**********Action***********

- (IBAction)btnEditClicked:(id)sender;

- (IBAction)btnBackClicked:(id)sender;



- (IBAction)btnCashTapped:(id)sender;

- (IBAction)btnBankingTapped:(id)sender;




@end
