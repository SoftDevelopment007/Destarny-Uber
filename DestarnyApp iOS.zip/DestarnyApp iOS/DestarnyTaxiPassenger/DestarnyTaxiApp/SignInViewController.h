//
//  SignInViewController.h
//  TaxiAPP
//
//  Created by Snehal Bhase on 8/20/15.
//  Copyright (c) 2015 pavan bhandari. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "ViewController.h"
//#import "SignInAsDriverViewController.h"
//#import "SignInAsPassangerViewController.h"

@interface SignInViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *btnSignInAsPassanger;
@property (weak, nonatomic) IBOutlet UIButton *btnRegister;

- (IBAction)btnSignInAsPassengerClicked:(id)sender;
- (IBAction)btnRegisterClicked:(id)sender;

@end


