//
//  CellPrevBookings.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 3/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellPrevBookings : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblBookingFrom;
@property (strong, nonatomic) IBOutlet UILabel *lblBookingTo;
@property (strong, nonatomic) IBOutlet UILabel *lblDistance;
@property (strong, nonatomic) IBOutlet UILabel *lblDuration;
@property (strong, nonatomic) IBOutlet UILabel *lblCost;
@property (strong, nonatomic) IBOutlet UILabel *lblBackground;
@property (strong, nonatomic) IBOutlet UIButton *btnAddToFav;

@end
