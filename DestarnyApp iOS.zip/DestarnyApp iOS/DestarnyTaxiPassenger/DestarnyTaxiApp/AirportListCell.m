//
//  AirportListCell.m
//  DestarnyTaxiApp
//
//  Created by satyaprakash.n on 5/11/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "AirportListCell.h"

@implementation AirportListCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
