//
//  CurrentBookingStatus.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/4/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CurrentBookingStatus : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    IBOutlet UIView *cancelView;
    IBOutlet UILabel *lblNote;
    IBOutlet UITextView *txtReason;
    IBOutlet UIButton *btnYes, *btnNo;
}
- (IBAction)bttnBackTapped:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *tblBookingStatus;

@end
