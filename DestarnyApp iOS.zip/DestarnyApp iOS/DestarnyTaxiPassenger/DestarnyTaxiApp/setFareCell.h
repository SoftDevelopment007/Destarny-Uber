//
//  setFareCell.h
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 4/19/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface setFareCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblFare;

@end
