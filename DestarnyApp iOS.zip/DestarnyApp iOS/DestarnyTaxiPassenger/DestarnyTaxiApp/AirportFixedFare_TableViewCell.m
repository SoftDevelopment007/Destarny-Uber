//
//  AirportFixedFare_TableViewCell.m
//  TaxiAPP
//
//  Created by Snehal Bhase on 10/13/15.
//  Copyright © 2015 pavan bhandari. All rights reserved.
//

#import "AirportFixedFare_TableViewCell.h"

@implementation AirportFixedFare_TableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
