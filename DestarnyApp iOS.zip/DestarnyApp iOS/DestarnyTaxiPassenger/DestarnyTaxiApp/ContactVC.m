//
//  ContactVC.m
//  DestarnyTaxiApp
//
//  Created by EdreamzTech on 2/5/16.
//  Copyright © 2016 Edreamz. All rights reserved.
//

#import "ContactVC.h"
#import "webManager.h"
#import "ALToastView.h"

@interface ContactVC ()

@end

@implementation ContactVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    lblTitle.text = [NSString stringWithFormat:@"%@",_strType];
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(void)viewWillAppear:(BOOL)animated
{
    [[webManager sharedObject] loginRequest:nil withMethod:@"passenger.php/getemergencynos" successResponce:^(id response)
     {
         NSLog(@"Responce : %@",response);
         NSError *e = nil;
         
         
         NSString *strStatus = [[response valueForKey:@"status"] stringValue];
         if([strStatus isEqualToString:@"0"])
         {
             [ALToastView toastInView:self.view withText:@"Failed"];
//             [[[UIAlertView alloc] initWithTitle:nil message:@"Failed to login." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
         }
         
         else if([strStatus isEqualToString:@"1"])
         {
             NSDictionary *dict = [[response valueForKey:@"items"] objectAtIndex:0];
             lbl1.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"emergency_no"]];
             lbl2.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"admin_no"]];
         }
         
     }
                                    failure:^(NSError *error)
     {
        
         NSLog(@"Error : %@",error);
         [ALToastView toastInView:self.view withText:@"Failed!"];
//         UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Login Failed!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//         
//         [alert show];
     }];
}

-(IBAction)btnEmergencyTapped:(id)sender
{
    
    NSURL *phoneUrl = [NSURL URLWithString:[NSString  stringWithFormat:@"telprompt:%@",lbl1.text]];
    
    if ([[UIApplication sharedApplication] canOpenURL:phoneUrl])
    {
        [[UIApplication sharedApplication] openURL:phoneUrl];
    }
    else
    {
        [ALToastView toastInView:self.view withText:@"Call facility is not available!!!"];
//        UIAlertView *calert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Call facility is not available!!!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [calert show];
    }
    
}

-(IBAction)btnAdminTapped:(id)sender
{
    NSURL *phoneUrl = [NSURL URLWithString:[NSString  stringWithFormat:@"telprompt:%@",lbl2.text]];
    
    if ([[UIApplication sharedApplication] canOpenURL:phoneUrl])
    {
        [[UIApplication sharedApplication] openURL:phoneUrl];
    }
    else
    {
        [ALToastView toastInView:self.view withText:@"Call facility is not available!!!"];
//        UIAlertView *calert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Call facility is not available!!!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//        [calert show];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
