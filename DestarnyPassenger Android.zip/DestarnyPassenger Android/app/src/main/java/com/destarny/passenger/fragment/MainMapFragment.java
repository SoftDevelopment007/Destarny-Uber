package com.destarny.passenger.fragment;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;

import java.util.List;

import com.destarny.passenger.R;
import com.destarny.passenger.utils.GPSTracker;
import com.destarny.passenger.utils.Utils_SliderLayout;

/**
 * Created by Admin on 04-06-2015.
 */
public class MainMapFragment extends Fragment implements OnMapReadyCallback {

    public static final String ARG_PLANET_NUMBER = "value";
    private GoogleMap googlemap;
    private GPSTracker gps;
    private Context mContext;
    private String strAddress = null;
    private Address address;
    private TextView btnLocation;
    LinearLayout linearLayout, layoutMarker;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);

       /* FragmentManager fmanager = getActivity().getSupportFragmentManager();
        Fragment fragment = fmanager.findFragmentById(R.id.map);
        SupportMapFragment supportmapfragment = (SupportMapFragment) fragment;
        googlemap = ((SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map)).getMap();
*/

        btnLocation = (TextView) v.findViewById(R.id.btn_pin_loc);
        linearLayout = (LinearLayout) v.findViewById(R.id.linearLayout);
        layoutMarker = (LinearLayout) v.findViewById(R.id.layoutMarker);

        SupportMapFragment mapFragment = (SupportMapFragment) this.getChildFragmentManager()
                .findFragmentById(R.id.map);
        googlemap = mapFragment.getMap();
        mapFragment.getMapAsync(this);
        mContext = getActivity();
        gps = new GPSTracker(mContext);
        gps.getLocation();
        ((Utils_SliderLayout) v.findViewById(R.id.unlockButton))
                .setSlideButtonListener(new Utils_SliderLayout.SlideButtonListener() {
                    @Override
                    public void handleSlid(String s) {
                        unlockScreen();
                    }

                    private void unlockScreen() {

                    }
                });


        layoutMarker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


        return v;
    }

    private void initialiseMap(GoogleMap map) {
        if (gps.getLocation() != null) {
            //map.setMyLocationEnabled(true);
            CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(new LatLng(gps.getLatitude(), gps.getLongitude())).zoom(12f).build();
            //map.setMyLocationEnabled(true);
            map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

            map.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener() {
                @Override
                public void onCameraChange(CameraPosition cameraPosition) {
                    //Toast.makeText(getActivity(),"Testing",Toast.LENGTH_SHORT).show();
                    getAddressFromLocation(cameraPosition.target, btnLocation);
                }
            });
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        initialiseMap(googleMap);
    }

    private void getAddressFromLocation(final LatLng latlng, final TextView et) {
        et.setText("Waiting for Address");
        et.setTextColor(Color.GRAY);
        new Thread(new Runnable() {
            @Override
            public void run() {
                Geocoder gCoder = new Geocoder(getActivity());
                try {
                    final List<Address> list = gCoder.getFromLocation(latlng.latitude, latlng.longitude, 1);
                    if (list != null && list.size() > 0) {
                        address = list.get(0);
                        StringBuilder sb = new StringBuilder();
                        if (address.getAddressLine(0) != null) {
                            if (address.getMaxAddressLineIndex() > 0) {
                                for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                                    sb.append(address.getAddressLine(i)).append(" ");
                                }
                                sb.append(",");
                                sb.append(address.getCountryName());
                            } else {
                                sb.append(address.getAddressLine(0));
                            }
                        }
                        strAddress = sb.toString();
                        strAddress = strAddress.replace(",null", "");
                        strAddress = strAddress.replace("null", "");
                        strAddress = strAddress.replace("Unnamed", "");
                    }
                    if (getActivity() == null)
                        return;

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!TextUtils.isEmpty(strAddress)) {
                                et.setFocusable(false);
                                et.setFocusableInTouchMode(false);
                                et.setText(strAddress);
                                et.setTextColor(getResources().getColor(android.R.color.black));
                                et.setFocusable(true);
                                et.setFocusableInTouchMode(true);
                            } else {
                                et.setText("");
                                et.setTextColor(getResources().getColor(android.R.color.black));
                            }
                            //etSource.setEnabled(true);
                        }
                    });
                } catch (Exception exc) {
                    exc.printStackTrace();
                }
            }
        }).start();
    }

}
