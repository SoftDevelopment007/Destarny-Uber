package com.destarny.passenger.interfaces;

/**
 * Created by sachi on 5/11/2016.
 */
public interface PastBookingAllInteface {
    public void AddFavBook(int position);


}
