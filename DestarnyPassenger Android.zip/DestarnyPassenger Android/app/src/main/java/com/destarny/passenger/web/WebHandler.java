package com.destarny.passenger.web;

import android.net.Uri;

import java.io.IOException;
import java.util.HashMap;

import com.destarny.passenger.utils.Constant;

/**
 * Created by ApkDev3 on 12/16/2015.
 */
public class WebHandler {

    Web mWeb;
    String strUrl = "";

    public WebHandler() {
        mWeb = new Web();
    }


    public String mPassengerLogin(String strUserName, String strPassword, String token) throws IOException {

        strUrl = Constant.LOGIN_URL;
       /* Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter(Constant.USERNAME, strUserName)
                .appendQueryParameter(Constant.PASSWORD, strPassword)
                .appendQueryParameter(Constant.DEVICETYPE, "android")
                .appendQueryParameter(Constant.UDID, token);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter(Constant.USERNAME, strUserName)
//                .appendQueryParameter(Constant.PASSWORD, strPassword)
//                .appendQueryParameter(Constant.DEVICETYPE, "android")
//                .appendQueryParameter(Constant.UDID, token).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put(Constant.USERNAME, strUserName);
        postDataParams.put(Constant.PASSWORD, strPassword);
        postDataParams.put(Constant.DEVICETYPE, "android");
        postDataParams.put(Constant.UDID, token);
        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String mPassengerRegister(String strFirstName, String strLstName, String strUsername, String strEmail, String strPassword, String strContactNo, String strToken, String strPayment, String strAgree) throws IOException {

        strUrl = Constant.REGISTER_URL;
     /*   Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter(Constant.FIRSTNAME, strFirstName)
                .appendQueryParameter(Constant.LASTNAME, strLstName)
                .appendQueryParameter(Constant.USERNAME, strUsername)
                .appendQueryParameter(Constant.PASSWORD, strPassword)
                .appendQueryParameter(Constant.EMAIL, strEmail)
                .appendQueryParameter(Constant.CONTACTNO, strContactNo)
                .appendQueryParameter(Constant.UDID, strToken)
                .appendQueryParameter(Constant.DEVICETYPE, "android")
                .appendQueryParameter(Constant.PAY_METHOD, strPayment)
                .appendQueryParameter(Constant.TCID, strAgree);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                postDataParams.put(Constant.FIRSTNAME, strFirstName)
//                .appendQueryParameter(Constant.LASTNAME, strLstName)
//                .appendQueryParameter(Constant.USERNAME, strUsername)
//                .appendQueryParameter(Constant.PASSWORD, strPassword)
//                .appendQueryParameter(Constant.EMAIL, strEmail)
//                .appendQueryParameter(Constant.CONTACTNO, strContactNo)
//                .appendQueryParameter(Constant.UDID, strToken)
//                .appendQueryParameter(Constant.DEVICETYPE, "android")
//                .appendQueryParameter(Constant.PAY_METHOD, strPayment)
//                .appendQueryParameter(Constant.TCID, strAgree).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put(Constant.FIRSTNAME, strFirstName);
        postDataParams.put(Constant.LASTNAME, strLstName);
        postDataParams.put(Constant.USERNAME, strUsername);
        postDataParams.put(Constant.PASSWORD, strPassword);
        postDataParams.put(Constant.EMAIL, strEmail);
        postDataParams.put(Constant.CONTACTNO, strContactNo);
        postDataParams.put(Constant.UDID, strToken);
        postDataParams.put(Constant.DEVICETYPE, "android");
        postDataParams.put(Constant.PAY_METHOD, strPayment);
        postDataParams.put(Constant.TCID, strAgree);
        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String mPassengerGetTermsCondition() throws IOException {
        strUrl = Constant.GET_TERMS_CONDITION;
        return mWeb.mWebMethod(strUrl);
    }

    public String getNearestTaxiList(String lat, String lng, String vid, String pass_id) throws IOException {

        strUrl = Constant.GET_NEAREST_TAXI_LIST;
     /*   Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter(Constant.BOOKING_FROM_LAT, lat)
                .appendQueryParameter(Constant.BOOKING_FROM_LNG, lng)
                .appendQueryParameter(Constant.VTID, vid);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/


//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", pass_id)
//                .appendQueryParameter(Constant.BOOKING_FROM_LAT, lat)
//                .appendQueryParameter(Constant.BOOKING_FROM_LNG, lng)
//                .appendQueryParameter(Constant.VTID, vid).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", pass_id);
        postDataParams.put(Constant.BOOKING_FROM_LAT, lat);
        postDataParams.put(Constant.BOOKING_FROM_LNG, lng);
        postDataParams.put(Constant.VTID, vid);
        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String updateUserProfile(String firstname, String lastname, String email, String contactNumber, String pass_id) throws IOException {
        strUrl = Constant.UPDATE_PROFILE;
      /*  Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("cid", pass_id)
                .appendQueryParameter(Constant.FIRSTNAME, firstname)
                .appendQueryParameter(Constant.LASTNAME, lastname)
                .appendQueryParameter(Constant.EMAIL, email)
                .appendQueryParameter(Constant.CONTACTNO, contactNumber);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", pass_id)
//                .appendQueryParameter(Constant.FIRSTNAME, firstname)
//                .appendQueryParameter(Constant.LASTNAME, lastname)
//                .appendQueryParameter(Constant.EMAIL, email)
//                .appendQueryParameter(Constant.CONTACTNO, contactNumber).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", pass_id);
        postDataParams.put(Constant.FIRSTNAME, firstname);
        postDataParams.put(Constant.LASTNAME, lastname);
        postDataParams.put(Constant.EMAIL, email);
        postDataParams.put(Constant.CONTACTNO, contactNumber);

        return mWeb.mWebMethod(strUrl, postDataParams);

    }

    public String bookNearestTaxi(String cid, String vtid, String booking_type, String fare_type,
                                  String setfare_unfullfilled, String booking_from_lat, String booking_from_lng,
                                  String booking_from, String booking_to_lat, String booking_to_lng, String booking_to,
                                  String noofpass, String booking_time, String booking_date, String notes, String fareid) throws IOException {

        strUrl = Constant.BOOK_NEAREST_TAXI;
      /*  Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("cid", cid)
                .appendQueryParameter(Constant.VTID, vtid)
                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
                .appendQueryParameter(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled)
                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
                .appendQueryParameter(Constant.BOOKING_TO_LAT, booking_to_lat)
                .appendQueryParameter(Constant.BOOKING_TO_LNG, booking_to_lng)
                .appendQueryParameter(Constant.BOOKING_TO, booking_to)
                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
                .appendQueryParameter(Constant.NOTES, notes)
                .appendQueryParameter(Constant.FARE_ID, fareid);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);
*/
//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", cid)
//                .appendQueryParameter(Constant.VTID, vtid)
//                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
//                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
//                .appendQueryParameter(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled)
//                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
//                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
//                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
//                .appendQueryParameter(Constant.BOOKING_TO_LAT, booking_to_lat)
//                .appendQueryParameter(Constant.BOOKING_TO_LNG, booking_to_lng)
//                .appendQueryParameter(Constant.BOOKING_TO, booking_to)
//                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
//                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
//                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
//                .appendQueryParameter(Constant.NOTES, notes)
//                .appendQueryParameter(Constant.FARE_ID, fareid).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", cid);
        postDataParams.put(Constant.VTID, vtid);
        postDataParams.put(Constant.BOOKING_TYPE, booking_type);
        postDataParams.put(Constant.FARE_TYPE, fare_type);
        postDataParams.put(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled);
        postDataParams.put(Constant.BOOKING_FROM_LAT, booking_from_lat);
        postDataParams.put(Constant.BOOKING_FROM_LNG, booking_from_lng);
        postDataParams.put(Constant.BOOKING_FROM, booking_from);
        postDataParams.put(Constant.BOOKING_TO_LAT, booking_to_lat);
        postDataParams.put(Constant.BOOKING_TO_LNG, booking_to_lng);
        postDataParams.put(Constant.BOOKING_TO, booking_to);
        postDataParams.put(Constant.NO_OF_PASS, noofpass);
        postDataParams.put(Constant.BOOKING_TIME, booking_time);
        postDataParams.put(Constant.BOOKING_DATE, booking_date);
        postDataParams.put(Constant.NOTES, notes);
        postDataParams.put(Constant.FARE_ID, fareid);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String bookNearestTaxi(String cid, String booking_type, String fare_type,
                                  String setfare_unfullfilled, String booking_from_lat, String booking_from_lng,
                                  String booking_from, String booking_to_lat, String booking_to_lng, String booking_to,
                                  String noofpass, String booking_time, String booking_date,
                                  String notes, String fareid, String distance, String duration,
                                  String approxCalfare) throws IOException {

        strUrl = Constant.BOOK_NEAREST_TAXI;
      /*  Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("cid", cid)
                .appendQueryParameter(Constant.VTID, vtid)
                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
                .appendQueryParameter(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled)
                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
                .appendQueryParameter(Constant.BOOKING_TO_LAT, booking_to_lat)
                .appendQueryParameter(Constant.BOOKING_TO_LNG, booking_to_lng)
                .appendQueryParameter(Constant.BOOKING_TO, booking_to)
                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
                .appendQueryParameter(Constant.NOTES, notes)
                .appendQueryParameter(Constant.FARE_ID, fareid);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);
*/
//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", cid)
//                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
//                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
//                .appendQueryParameter(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled)
//                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
//                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
//                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
//                .appendQueryParameter(Constant.BOOKING_TO_LAT, booking_to_lat)
//                .appendQueryParameter(Constant.BOOKING_TO_LNG, booking_to_lng)
//                .appendQueryParameter(Constant.BOOKING_TO, booking_to)
//                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
//                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
//                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
//                .appendQueryParameter(Constant.NOTES, notes)
//                .appendQueryParameter(Constant.FARE_ID, fareid)
//                .appendQueryParameter(Constant.DISTANCE, distance)
//                .appendQueryParameter(Constant.DURATION, duration)
//                .appendQueryParameter(Constant.APPX_FARE, approxCalfare).build().toString();
//
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", cid);
        postDataParams.put(Constant.BOOKING_TYPE, booking_type);
        postDataParams.put(Constant.FARE_TYPE, fare_type);
        postDataParams.put(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled);
        postDataParams.put(Constant.BOOKING_FROM_LAT, booking_from_lat);
        postDataParams.put(Constant.BOOKING_FROM_LNG, booking_from_lng);
        postDataParams.put(Constant.BOOKING_FROM, booking_from);
        postDataParams.put(Constant.BOOKING_TO_LAT, booking_to_lat);
        postDataParams.put(Constant.BOOKING_TO_LNG, booking_to_lng);
        postDataParams.put(Constant.BOOKING_TO, booking_to);
        postDataParams.put(Constant.NO_OF_PASS, noofpass);
        postDataParams.put(Constant.BOOKING_TIME, booking_time);
        postDataParams.put(Constant.BOOKING_DATE, booking_date);
        postDataParams.put(Constant.NOTES, notes);
        postDataParams.put(Constant.FARE_ID, fareid);
        postDataParams.put(Constant.DISTANCE, distance);
        postDataParams.put(Constant.DURATION, duration);
        postDataParams.put(Constant.APPX_FARE, approxCalfare);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

//    public String bookSelectedTaxi(String cid, String vtid, String booking_type, String fare_type,
//                                   String setfare_unfullfilled, String booking_from_lat, String booking_from_lng,
//                                   String booking_from, String booking_to_lat, String booking_to_lng, String booking_to,
//                                   String noofpass, String booking_time, String booking_date, String notes, String fareid,
//                                   String did) throws IOException {
//
//        strUrl = Constant.BOOK_SELECTED_TAXI;
//        /*Uri.Builder builder = new Uri.Builder()
//                .appendQueryParameter("cid", cid)
//                .appendQueryParameter(Constant.VTID, vtid)
//                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
//                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
//                .appendQueryParameter(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled)
//                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
//                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
//                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
//                .appendQueryParameter(Constant.BOOKING_TO_LAT, booking_to_lat)
//                .appendQueryParameter(Constant.BOOKING_TO_LNG, booking_to_lng)
//                .appendQueryParameter(Constant.BOOKING_TO, booking_to)
//                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
//                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
//                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
//                .appendQueryParameter(Constant.NOTES, notes)
//                .appendQueryParameter(Constant.FARE_ID, fareid)
//                .appendQueryParameter(Constant.DID, did);
//
//        String query = builder.build().getEncodedQuery();
//        return mWeb.mWebMethod(strUrl, query);*/
//
//
//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", cid)
//                .appendQueryParameter(Constant.VTID, vtid)
//                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
//                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
//                .appendQueryParameter(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled)
//                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
//                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
//                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
//                .appendQueryParameter(Constant.BOOKING_TO_LAT, booking_to_lat)
//                .appendQueryParameter(Constant.BOOKING_TO_LNG, booking_to_lng)
//                .appendQueryParameter(Constant.BOOKING_TO, booking_to)
//                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
//                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
//                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
//                .appendQueryParameter(Constant.NOTES, notes)
//                .appendQueryParameter(Constant.FARE_ID, fareid)
//                .appendQueryParameter(Constant.DID, did).build().toString();
//        return mWeb.mWebMethod(uri);
//
//    }

    public String bookSelectedTaxi(String cid, String booking_type, String fare_type,
                                   String setfare_unfullfilled, String booking_from_lat, String booking_from_lng,
                                   String booking_from, String booking_to_lat, String booking_to_lng, String booking_to,
                                   String noofpass, String booking_time, String booking_date, String notes, String fareid,
                                   String did) throws IOException {

        strUrl = Constant.BOOK_SELECTED_TAXI;
        /*Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("cid", cid)
                .appendQueryParameter(Constant.VTID, vtid)
                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
                .appendQueryParameter(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled)
                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
                .appendQueryParameter(Constant.BOOKING_TO_LAT, booking_to_lat)
                .appendQueryParameter(Constant.BOOKING_TO_LNG, booking_to_lng)
                .appendQueryParameter(Constant.BOOKING_TO, booking_to)
                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
                .appendQueryParameter(Constant.NOTES, notes)
                .appendQueryParameter(Constant.FARE_ID, fareid)
                .appendQueryParameter(Constant.DID, did);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/


//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", cid)
////                .appendQueryParameter(Constant.VTID, vtid)
//                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
//                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
//                .appendQueryParameter(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled)
//                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
//                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
//                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
//                .appendQueryParameter(Constant.BOOKING_TO_LAT, booking_to_lat)
//                .appendQueryParameter(Constant.BOOKING_TO_LNG, booking_to_lng)
//                .appendQueryParameter(Constant.BOOKING_TO, booking_to)
//                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
//                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
//                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
//                .appendQueryParameter(Constant.NOTES, notes)
//                .appendQueryParameter(Constant.FARE_ID, fareid)
//                .appendQueryParameter(Constant.DID, did).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", cid);
//                postDataParams.put(Constant.VTID, vtid);
        postDataParams.put(Constant.BOOKING_TYPE, booking_type);
        postDataParams.put(Constant.FARE_TYPE, fare_type);
        postDataParams.put(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled);
        postDataParams.put(Constant.BOOKING_FROM_LAT, booking_from_lat);
        postDataParams.put(Constant.BOOKING_FROM_LNG, booking_from_lng);
        postDataParams.put(Constant.BOOKING_FROM, booking_from);
        postDataParams.put(Constant.BOOKING_TO_LAT, booking_to_lat);
        postDataParams.put(Constant.BOOKING_TO_LNG, booking_to_lng);
        postDataParams.put(Constant.BOOKING_TO, booking_to);
        postDataParams.put(Constant.NO_OF_PASS, noofpass);
        postDataParams.put(Constant.BOOKING_TIME, booking_time);
        postDataParams.put(Constant.BOOKING_DATE, booking_date);
        postDataParams.put(Constant.NOTES, notes);
        postDataParams.put(Constant.FARE_ID, fareid);
        postDataParams.put(Constant.DID, did);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String bookSelectedTaxi(String cid, String booking_type, String fare_type,
                                   String setfare_unfullfilled, String booking_from_lat, String booking_from_lng,
                                   String booking_from, String booking_to_lat, String booking_to_lng, String booking_to,
                                   String noofpass, String booking_time, String booking_date, String notes, String fareid,
                                   String did, String distance, String duration, String approxCalfare) throws IOException {

        strUrl = Constant.BOOK_SELECTED_TAXI;
        /*Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("cid", cid)
                .appendQueryParameter(Constant.VTID, vtid)
                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
                .appendQueryParameter(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled)
                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
                .appendQueryParameter(Constant.BOOKING_TO_LAT, booking_to_lat)
                .appendQueryParameter(Constant.BOOKING_TO_LNG, booking_to_lng)
                .appendQueryParameter(Constant.BOOKING_TO, booking_to)
                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
                .appendQueryParameter(Constant.NOTES, notes)
                .appendQueryParameter(Constant.FARE_ID, fareid)
                .appendQueryParameter(Constant.DID, did);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/


//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", cid)
////                .appendQueryParameter(Constant.VTID, vtid)
//                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
//                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
//                .appendQueryParameter(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled)
//                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
//                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
//                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
//                .appendQueryParameter(Constant.BOOKING_TO_LAT, booking_to_lat)
//                .appendQueryParameter(Constant.BOOKING_TO_LNG, booking_to_lng)
//                .appendQueryParameter(Constant.BOOKING_TO, booking_to)
//                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
//                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
//                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
//                .appendQueryParameter(Constant.NOTES, notes)
//                .appendQueryParameter(Constant.FARE_ID, fareid)
//                .appendQueryParameter(Constant.DID, did)
//                .appendQueryParameter(Constant.DISTANCE, distance)
//                .appendQueryParameter(Constant.DURATION, duration)
//                .appendQueryParameter(Constant.APPX_FARE, approxCalfare).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", cid);
//                postDataParams.put(Constant.VTID, vtid);
        postDataParams.put(Constant.BOOKING_TYPE, booking_type);
        postDataParams.put(Constant.FARE_TYPE, fare_type);
        postDataParams.put(Constant.SET_FARE_UNFULFILLED, setfare_unfullfilled);
        postDataParams.put(Constant.BOOKING_FROM_LAT, booking_from_lat);
        postDataParams.put(Constant.BOOKING_FROM_LNG, booking_from_lng);
        postDataParams.put(Constant.BOOKING_FROM, booking_from);
        postDataParams.put(Constant.BOOKING_TO_LAT, booking_to_lat);
        postDataParams.put(Constant.BOOKING_TO_LNG, booking_to_lng);
        postDataParams.put(Constant.BOOKING_TO, booking_to);
        postDataParams.put(Constant.NO_OF_PASS, noofpass);
        postDataParams.put(Constant.BOOKING_TIME, booking_time);
        postDataParams.put(Constant.BOOKING_DATE, booking_date);
        postDataParams.put(Constant.NOTES, notes);
        postDataParams.put(Constant.FARE_ID, fareid);
        postDataParams.put(Constant.DID, did);
        postDataParams.put(Constant.DISTANCE, distance);
        postDataParams.put(Constant.DURATION, duration);
        postDataParams.put(Constant.APPX_FARE, approxCalfare);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String bookTaxiToAirport(String cid, String vtid, String booking_type, String fare_type,
                                    String booking_from_lat, String booking_from_lng, String booking_from,
                                    String noofpass, String booking_time, String booking_date, String notes,
                                    String atid) throws IOException {

        strUrl = Constant.BOOK_NEAREST_TAXI;
        /*Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("cid", cid)
                .appendQueryParameter(Constant.VTID, vtid)
                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
                .appendQueryParameter(Constant.NOTES, notes)
                .appendQueryParameter(Constant.ATID, atid);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", cid)
//                .appendQueryParameter(Constant.VTID, vtid)
//                .appendQueryParameter(Constant.BOOKING_TYPE, booking_type)
//                .appendQueryParameter(Constant.FARE_TYPE, fare_type)
//                .appendQueryParameter(Constant.BOOKING_FROM_LAT, booking_from_lat)
//                .appendQueryParameter(Constant.BOOKING_FROM_LNG, booking_from_lng)
//                .appendQueryParameter(Constant.BOOKING_FROM, booking_from)
//                .appendQueryParameter(Constant.NO_OF_PASS, noofpass)
//                .appendQueryParameter(Constant.BOOKING_TIME, booking_time)
//                .appendQueryParameter(Constant.BOOKING_DATE, booking_date)
//                .appendQueryParameter(Constant.NOTES, notes)
//                .appendQueryParameter(Constant.ATID, atid).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", cid);
        postDataParams.put(Constant.VTID, vtid);
        postDataParams.put(Constant.BOOKING_TYPE, booking_type);
        postDataParams.put(Constant.FARE_TYPE, fare_type);
        postDataParams.put(Constant.BOOKING_FROM_LAT, booking_from_lat);
        postDataParams.put(Constant.BOOKING_FROM_LNG, booking_from_lng);
        postDataParams.put(Constant.BOOKING_FROM, booking_from);
        postDataParams.put(Constant.NO_OF_PASS, noofpass);
        postDataParams.put(Constant.BOOKING_TIME, booking_time);
        postDataParams.put(Constant.BOOKING_DATE, booking_date);
        postDataParams.put(Constant.NOTES, notes);
        postDataParams.put(Constant.ATID, atid);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String forgotPassword(String email) throws IOException {
        strUrl = Constant.FORGOT_PASSWORD;
        /*Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter(Constant.EMAIL, email);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter(Constant.EMAIL, email).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put(Constant.EMAIL, email);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String getUserProfile(String pass_id) throws IOException {
        strUrl = Constant.GET_USER_PROFILE;
       /* Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("id", pass_id);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("id", pass_id).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("id", pass_id);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String editUserProfile(String pass_id, String firstname, String lastname, String email, String contactNumber,
                                  String username, String password, String deviceId, String deviceType, String payMethod) throws IOException {
        strUrl = Constant.EDIT_PROFILE;

        /*Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("id", pass_id)
                .appendQueryParameter(Constant.FIRSTNAME, firstname)
                .appendQueryParameter(Constant.LASTNAME, lastname)
                .appendQueryParameter(Constant.USERNAME, username)
                .appendQueryParameter(Constant.PASSWORD, password)
                .appendQueryParameter(Constant.EMAIL, email)
                .appendQueryParameter(Constant.CONTACTNO, contactNumber)
                .appendQueryParameter(Constant.UDID, deviceId)
                .appendQueryParameter(Constant.DEVICETYPE, deviceType)
                .appendQueryParameter(Constant.PAY_METHOD, payMethod);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("id", pass_id)
//                .appendQueryParameter(Constant.FIRSTNAME, firstname)
//                .appendQueryParameter(Constant.LASTNAME, lastname)
//                .appendQueryParameter(Constant.USERNAME, username)
//                .appendQueryParameter(Constant.PASSWORD, password)
//                .appendQueryParameter(Constant.EMAIL, email)
//                .appendQueryParameter(Constant.CONTACTNO, contactNumber)
//                .appendQueryParameter(Constant.UDID, deviceId)
//                .appendQueryParameter(Constant.DEVICETYPE, deviceType)
//                .appendQueryParameter(Constant.PAY_METHOD, payMethod).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("id", pass_id);
        postDataParams.put(Constant.FIRSTNAME, firstname);
        postDataParams.put(Constant.LASTNAME, lastname);
        postDataParams.put(Constant.USERNAME, username);
        postDataParams.put(Constant.PASSWORD, password);
        postDataParams.put(Constant.EMAIL, email);
        postDataParams.put(Constant.CONTACTNO, contactNumber);
        postDataParams.put(Constant.UDID, deviceId);
        postDataParams.put(Constant.DEVICETYPE, deviceType);
        postDataParams.put(Constant.PAY_METHOD, payMethod);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String getPaymentMethod(String pass_id) throws IOException {
        strUrl = Constant.GET_PAYMENT_METHOD;

        /*Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("cid", pass_id);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", pass_id).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", pass_id);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String addPaymentMethod(String pass_id, String cno, String cvn, String expDate) throws IOException {
        strUrl = Constant.ADD_PAYMENT_METHOD;

//        Uri.Builder builder = new Uri.Builder()
//                .appendQueryParameter("cid", pass_id)
//                .appendQueryParameter(Constant.CNO, cno)
//                .appendQueryParameter(Constant.CVN, cvn)
//                .appendQueryParameter(Constant.EXP_DATE, expDate);
//
//        String query = builder.build().getEncodedQuery();
//        return mWeb.mWebMethod(strUrl, query);

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", pass_id)
//                .appendQueryParameter(Constant.CNO, cno)
//                .appendQueryParameter(Constant.CVN, cvn)
//                .appendQueryParameter(Constant.EXP_DATE, expDate).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", pass_id);
        postDataParams.put(Constant.CNO, cno);
        postDataParams.put(Constant.CVN, cvn);
        postDataParams.put(Constant.EXP_DATE, expDate);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String setPaymentMethod(String pass_id, String payMethod, String payId) throws IOException {
        strUrl = Constant.SET_PAYMENT_METHOD;

        /*Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("cid", pass_id)
                .appendQueryParameter(Constant.PAY_METHOD, payMethod)
                .appendQueryParameter(Constant.PAY_ID, payId);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", pass_id)
//                .appendQueryParameter(Constant.PAY_METHOD, payMethod)
//                .appendQueryParameter(Constant.PAY_ID, payId).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", pass_id);
        postDataParams.put(Constant.PAY_METHOD, payMethod);
        postDataParams.put(Constant.PAY_ID, payId);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String getPreBookingInfo(String pass_id) throws IOException {
        strUrl = Constant.PRE_BOOKING_INFO;

//        Uri.Builder builder = new Uri.Builder()
//                .appendQueryParameter("cid", pass_id);
//
//        String query = builder.build().getEncodedQuery();
//        return mWeb.mWebMethod(strUrl, query);

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", pass_id).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", pass_id);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String getCurrentBookingStatus(String pass_id) throws IOException {
        strUrl = Constant.CURRENT_BOOKING_STATUS;

        /*Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("cid", pass_id);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", pass_id).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", pass_id);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String cancelBooking(String bid, String pass_id, String cancelReason) throws IOException {
        strUrl = Constant.CANCEL_BOOKING;

//        Uri.Builder builder = new Uri.Builder()
//                .appendQueryParameter(Constant.BID, bid)
//                .appendQueryParameter("cid", pass_id)
//                .appendQueryParameter(Constant.CANCEL_REASON, cancelReason);
//
//        String query = builder.build().getEncodedQuery();
//        return mWeb.mWebMethod(strUrl, query);

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter(Constant.BID, bid)
//                .appendQueryParameter("cid", pass_id)
//                .appendQueryParameter(Constant.CANCEL_REASON, cancelReason).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put(Constant.BID, bid);
        postDataParams.put("cid", pass_id);
        postDataParams.put(Constant.CANCEL_REASON, cancelReason);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String mDeleteCreditCard(String crdId, String passID) throws IOException {

        strUrl = Constant.DELETE_CREDIT_CARD_DETAILS;

        /*Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("payid", crdId)
                .appendQueryParameter("cid", passID);

        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);*/

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("payid", crdId)
//                .appendQueryParameter("cid", passID).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("payid", crdId);
        postDataParams.put("cid", passID);

        return mWeb.mWebMethod(strUrl, postDataParams);
    }

/*
    public String PassengerLogin(String strUserName, String strPassword) throws IOException {
        strUrl = Constant.LOGIN_URL;
        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter(Constant.USERNAME, strUserName)
                .appendQueryParameter(Constant.PASSWORD, strPassword)
                .appendQueryParameter(Constant.UDID, strPassword)
                .appendQueryParameter(Constant.DEVICETYPE, "android");
        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);
    }

    public String PassengerRegister(String strFirstName, String strLstName, String strUsername, String strEmail, String strPassword, String strContactNo) throws IOException {

        strUrl = Constant.LOGIN_URL;
        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("fname", strFirstName)
                .appendQueryParameter("lname", strLstName)
                .appendQueryParameter("username", strUsername)
                .appendQueryParameter("password", strEmail)
                .appendQueryParameter("emailid", strPassword)
                .appendQueryParameter("phone_no", strContactNo)
                .appendQueryParameter("deviceid", strContactNo);
        String query = builder.build().getEncodedQuery();
        return mWeb.mWebMethod(strUrl, query);

    }*/
}
