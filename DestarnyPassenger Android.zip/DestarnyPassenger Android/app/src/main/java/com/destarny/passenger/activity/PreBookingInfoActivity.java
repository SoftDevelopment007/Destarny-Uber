package com.destarny.passenger.activity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import com.destarny.passenger.R;
import com.destarny.passenger.adapter.PreBookingInfoAdapter;
import com.destarny.passenger.model.PreBookingInfo;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.WebHandler;

public class PreBookingInfoActivity extends AppCompatActivity {

    private ImageView imgBack;
    private TextView txtTitle;

    private ListView preBookingInfoLV;
    private PreBookingInfoAdapter preBookingInfoAdapter = null;
    private String response = null;

    private ShardPrefClass mPref = null;
    private WebHandler mWebHandler = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre_booking_info);
        getSupportActionBar().hide();

        imgBack = (ImageView) findViewById(R.id.toolbar_left);
        txtTitle = (TextView) findViewById(R.id.toolbar_title);
        txtTitle.setVisibility(View.VISIBLE);
        txtTitle.setText("Pre Booking Info");
        imgBack.setVisibility(View.VISIBLE);
        imgBack.setImageResource(R.drawable.ic_action_back);
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        preBookingInfoLV = (ListView) findViewById(R.id.lv_pre_booking_info);

        initObjects();

        if (Utils.isNetworkAvailable(PreBookingInfoActivity.this))
            new GetPreBookingInfo().execute();
        else
            Toast.makeText(PreBookingInfoActivity.this,
                    "Please check the Internet Connection!", Toast.LENGTH_SHORT).show();
    }

    private void initObjects() {
        mPref = new ShardPrefClass(PreBookingInfoActivity.this);
        mWebHandler = new WebHandler();
    }

    private class GetPreBookingInfo extends AsyncTask<Void, Void, String> {

        private ProgressDialog progressDialog = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(PreBookingInfoActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String cid = mPref.getPassengerId();
            try {
                response = mWebHandler.getPreBookingInfo(cid);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getBoolean("status")) {

                    JSONArray itemsJsonArray = object.getJSONArray("items");
                    ArrayList<PreBookingInfo> preBookingInfos = new ArrayList<>();
                    int size = itemsJsonArray.length();
                    for (int i = 0; i < size; i++) {
                        JSONObject item = itemsJsonArray.getJSONObject(i);
                        String booking_from = item.getString("booking_from");
                        String booking_to = item.getString("booking_to");
                        String vtid = item.getString("vtid");
                        String noofpass = item.getString("noofpass");
                        String fare_type = item.getString("fare_type");
                        String booking_date = item.getString("booking_date");
                        String booking_time = item.getString("booking_time");

                        PreBookingInfo preBookingInfo = new PreBookingInfo();
                        preBookingInfo.setBookingFrom(booking_from);
                        preBookingInfo.setBookingTo(booking_to);
                        preBookingInfo.setVtid(vtid);
                        preBookingInfo.setNoofpass(noofpass);
                        preBookingInfo.setFareType(fare_type);
                        preBookingInfo.setBookingDate(booking_date);
                        preBookingInfo.setBookingTime(booking_time);

                        preBookingInfos.add(preBookingInfo);
                    }
                    preBookingInfoAdapter = new PreBookingInfoAdapter(PreBookingInfoActivity.this, R.layout.pre_booking_info_item, preBookingInfos);
                    preBookingInfoLV.setAdapter(preBookingInfoAdapter);
                } else {

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }


}
