package com.destarny.passenger.model;

public class NearestTaxi {
    private String fname;
    private String phone_no;
    private String lname;

    private String lng;
    private String distance;
    private String did;
    private String lat;
    private String vType;
    private String numberPlate;

    private double pricePerKm;
    private double pricePerMin;
    private double minPrice;
    private double distFromPickupLoc;

    private String rating;


    public NearestTaxi(String fname, String phone_no, String lname, String lng, String distance,
                       String did, String lat, String vType, String numberPlate) {
        this.fname = fname;
        this.phone_no = phone_no;
        this.lname = lname;
        this.lng = lng;
        this.distance = distance;

        this.did = did;
        this.lat = lat;
        this.vType = vType;
        this.numberPlate = numberPlate;
    }

    public NearestTaxi(String fname, String phone_no, String lname, String lng, String distance,
                       String did, String lat, String vType, String numberPlate, double pricePerKm,
                       double pricePerMin, double minPrice, double distFromPickupLoc) {
        this.fname = fname;
        this.phone_no = phone_no;
        this.lname = lname;
        this.lng = lng;
        this.distance = distance;

        this.did = did;
        this.lat = lat;
        this.vType = vType;
        this.numberPlate = numberPlate;

        this.pricePerKm = pricePerKm;
        this.pricePerMin = pricePerMin;
        this.minPrice = minPrice;
        this.distFromPickupLoc = distFromPickupLoc;
    }

    public NearestTaxi(String fname, String phone_no, String lname, String lng, String distance,
                       String did, String lat, String vType, String numberPlate, double pricePerKm,
                       double pricePerMin, double minPrice, double distFromPickupLoc, String rating) {
        this.fname = fname;
        this.phone_no = phone_no;
        this.lname = lname;
        this.lng = lng;
        this.distance = distance;

        this.did = did;
        this.lat = lat;
        this.vType = vType;
        this.numberPlate = numberPlate;

        this.pricePerKm = pricePerKm;
        this.pricePerMin = pricePerMin;
        this.minPrice = minPrice;
        this.distFromPickupLoc = distFromPickupLoc;
        this.rating = rating;
    }

    public String getFname() {
        return this.fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getPhone_no() {
        return this.phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }

    public String getLname() {
        return this.lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getLng() {
        return this.lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getDistance() {
        return this.distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getDid() {
        return this.did;
    }

    public void setDid(String did) {
        this.did = did;
    }

    public String getLat() {
        return this.lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getvType() {
        return this.vType;
    }

    public void setvType(String vType) {
        this.vType = vType;
    }

    public String getNumberPlate() {
        return numberPlate;
    }

    public void setNumberPlate(String numberPlate) {
        this.numberPlate = numberPlate;
    }

    public double getPricePerKm() {
        return pricePerKm;
    }

    public void setPricePerKm(double pricePerKm) {
        this.pricePerKm = pricePerKm;
    }

    public double getPricePerMin() {
        return pricePerMin;
    }

    public void setPricePerMin(double pricePerMin) {
        this.pricePerMin = pricePerMin;
    }

    public double getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(double minPrice) {
        this.minPrice = minPrice;
    }

    public double getDistFromPickupLoc() {
        return distFromPickupLoc;
    }

    public void setDistFromPickupLoc(double distFromPickupLoc) {
        this.distFromPickupLoc = distFromPickupLoc;
    }
}
