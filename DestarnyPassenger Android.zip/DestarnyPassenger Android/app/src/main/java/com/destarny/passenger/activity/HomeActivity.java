package com.destarny.passenger.activity;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.destarny.passenger.R;
import com.destarny.passenger.adapter.ExpandableListAdapter;
import com.destarny.passenger.map.NewMapsActivity;
import com.destarny.passenger.model.NearestTaxi;
import com.destarny.passenger.utils.Constant;
import com.destarny.passenger.utils.GPSTracker;
import com.destarny.passenger.utils.LocationUtils;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils_SliderLayout;
import com.destarny.passenger.web.Web;
import com.destarny.passenger.web.WebHandler;
import com.destarny.passenger.web.WebMapUtils;

public class HomeActivity extends AppCompatActivity implements OnMapReadyCallback,
        GoogleMap.OnMarkerClickListener, ActivityCompat.OnRequestPermissionsResultCallback {


    private static final String TAG = HomeActivity.class.getSimpleName();
    private static final int PERMISSIONS_REQUEST = 111;
    private GPSTracker gps;
    private Web mWeb = null;
    private WebHandler mWebHandler;
    private WebMapUtils mWebMapUtils;
    private ShardPrefClass mPrefClass;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private DrawerLayout drawerLayout;
    private ImageView imgDrawer;
    private ExpandableListView mDrawerList;
    private ExpandableListAdapter mAdapter;
    private ArrayList<Integer> mArrayList = new ArrayList<Integer>();
    private List<String> listDataHeader;
    private HashMap<String, List<String>> listDataChild;
    private View mLayout;
    private boolean isRecieverRegistered = false, isNetDialogShowing = false, isGpsDialogShowing = false;
    private AlertDialog internetDialog, gpsAlertDialog, locationAlertDialog;
    private LocationManager manager;
    private static String[] PERMISSIONS_CONTACT = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
    private static final int REQUEST_LOCATION = 0;

    //fragment instances
    public static final String ARG_PLANET_NUMBER = "value";
    private GoogleMap googlemap = null;

    private Context mContext;
    private String strAddress = null;
    private Address address;
    private TextView btnLocation;
    LinearLayout /*linearLayout, */layoutMarker;
    private ProgressBar mAddressLoadingBar;
    private TextView txtSelectLocation;

    private AsyncTask<String, String, String> mAsyncTaskGetTaxiList;
    //map controller init
    private ProgressBar mDistnceProgressBar;
    private ImageView imgSquareLeft, imgSqureRight;
    private TextView mTxtDistance;

    private ProgressBar mToolBarRightProgressBar;

    private ImageView helpImageView;
    private ImageView shareImageView;
    private ImageView imgLogout;

    // Taxi List
    private ArrayList<NearestTaxi> mNearestTaxiList = new ArrayList<NearestTaxi>();
    private LinearLayout mSourceAddressLayout;
    private LinearLayout linear_logout;

    private boolean isTaxiAvailable = false;

    private AutoCompleteTextView mAutoPlace;
    private ProgressBar mLoadingBar;
    private ListView mLstLocationList;
    private AsyncTask<String, List<String>, List<String>> mAddressSuggestionAsyncTask;
    private List<String> mAddressList;
    private ArrayAdapter<String> mSourceAddressListAdapter;
    private Dialog dialog;
    private boolean isSourceSelected = false;
    private boolean isTimeUp = false;

    private Handler getDriverLocationUpdateHandler = new Handler();

    DecimalFormat decimalFormat = new DecimalFormat("#.######");
    private final int GET_DRIVER_UPDATES_PER_MS = 10000;

    private GetVehicleType getVehicleType = null;

    private boolean addressFromMap = false;
    private boolean addressFromText = false;
    private boolean addressFromGPS = false;
    private LinearLayout logoutLinearLayout;
    private LinearLayout shareLinearLayout;
    private LinearLayout helpLinearLayout;

    private AsyncTask<String, List<String>, String> mAddressFromLatLng = null;
    private boolean debtAccountDialogShowing = false;
    private LinearLayout mDriverInfoLayout;
    private TextView mDriverNameTextView;
    private TextView mVehicleDescriptionTextView;
    private TextView mRegoTextView;
    private TextView mETATextView;
    private ProgressBar mCenterProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        permissionForM();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        imgDrawer = (ImageView) findViewById(R.id.toolbar_left);
        mToolBarRightProgressBar = (ProgressBar) findViewById(R.id.progress_right);
        mDrawerList = (ExpandableListView) findViewById(R.id.drawer_list);
        setSupportActionBar(toolbar);
        mAddressLoadingBar = (ProgressBar) findViewById(R.id.progress_bar);
        mCenterProgressBar = (ProgressBar) findViewById(R.id.progressBar_center);

        mAddressLoadingBar.getIndeterminateDrawable().setColorFilter(Color.parseColor("#FFCB07"),
                PorterDuff.Mode.SRC_IN);
        getSupportActionBar().setTitle("");
        mWeb = new Web();
        mWebHandler = new WebHandler();
        mPrefClass = new ShardPrefClass(getApplicationContext());
        mWebMapUtils = new WebMapUtils();
        mDistnceProgressBar = (ProgressBar) findViewById(R.id.pBar);
        imgSquareLeft = (ImageView) findViewById(R.id.progress_barSqure);
        imgSqureRight = (ImageView) findViewById(R.id.imgSqureRight);
        mTxtDistance = (TextView) findViewById(R.id.txtDistance);
        txtSelectLocation = (TextView) findViewById(R.id.setPickupLocation);
        //actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.app_name, R.string.app_name);
        manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        View header = (View) getLayoutInflater().inflate(R.layout.header, null);

        mCenterProgressBar.setVisibility(View.VISIBLE);




        mSourceAddressLayout = (LinearLayout) findViewById(R.id.linearLayout);
        mDrawerList.addHeaderView(header);
        mArrayList.add(R.drawable.ic_home);
        mArrayList.add(R.drawable.ic_profile);
        mArrayList.add(R.drawable.ic_billing_info);
        mArrayList.add(R.drawable.ic_favourites);
        mArrayList.add(R.drawable.ic_book);
        mArrayList.add(R.drawable.ic_favourites);
        mArrayList.add(R.drawable.ic_book);
        mArrayList.add(R.drawable.ic_invite_friends);
        mArrayList.add(R.drawable.ic_contact);

        mDriverInfoLayout = (LinearLayout) findViewById(R.id.ll_driver_info);
        mDriverNameTextView = (TextView) findViewById(R.id.tv_driver_name);
        mVehicleDescriptionTextView = (TextView) findViewById(R.id.tv_vehicle_description);
        mRegoTextView = (TextView) findViewById(R.id.tv_rego);
        mETATextView = (TextView) findViewById(R.id.tv_eta);

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                // Code here will be triggered once the drawer closes as we dont want anything to happen so we leave this blank
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                // Code here will be triggered once the drawer open as we dont want anything to happen so we leave this blank
                super.onDrawerOpened(drawerView);
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessay or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();


        addDataInToList();
        mAdapter = new ExpandableListAdapter(getApplicationContext(), listDataHeader, listDataChild, mArrayList);

        mDrawerList.setAdapter(mAdapter);

        mDrawerList.setOnChildClickListener(new DrawerChildItemClickListner());
        mDrawerList.setOnGroupClickListener(new DrawerItemClickListener());
        //mDrawerList.OnGroupClickListenerr();

        View footer = (View) getLayoutInflater().inflate(R.layout.layout_list_footer, null);
        helpImageView = (ImageView) footer.findViewById(R.id.iv_help);
        helpLinearLayout = (LinearLayout) footer.findViewById(R.id.linear_help);
        shareImageView = (ImageView) footer.findViewById(R.id.iv_share);
        shareLinearLayout = (LinearLayout) footer.findViewById(R.id.linear_share);
        imgLogout = (ImageView) footer.findViewById(R.id.imgLogOut);
        logoutLinearLayout = (LinearLayout) footer.findViewById(R.id.linear_logout);
        mDrawerList.addFooterView(footer);

        btnLocation = (TextView) findViewById(R.id.btn_pin_loc);
//        linearLayout = (LinearLayout) findViewById(R.id.linearLayout);
        layoutMarker = (LinearLayout) findViewById(R.id.layoutMarker);

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        googlemap = mapFragment.getMap();

        mContext = getApplicationContext();
        gps = new GPSTracker(mContext);
        gps.getLocation();
        LocationUtils.USER_CURRENT_LATITUDE = gps.getLatitude();
        LocationUtils.USER_CURRENT_LONGITUDE = gps.getLongitude();
        LocationUtils.USER_CURRENT_ACCURACY = gps.getAccuracy();
        LocationUtils.USER_CURRENT_LATITUDE = Double.valueOf(decimalFormat
                .format(LocationUtils.USER_CURRENT_LATITUDE));
        LocationUtils.USER_CURRENT_LONGITUDE = Double.valueOf(decimalFormat
                .format(LocationUtils.USER_CURRENT_LONGITUDE));
        LocationUtils.CURRENT_VEHICLE_TYPE = "3";

        addressFromMap = false;
        addressFromText = false;
        addressFromGPS = true;

        ((Utils_SliderLayout) findViewById(R.id.unlockButton))
                .setSlideButtonListener(new Utils_SliderLayout.SlideButtonListener() {
                    @Override
                    public void handleSlid(String s) {

                        LocationUtils.CURRENT_VEHICLE_TYPE = s;
                        unlockScreen();
                    }

                    private void unlockScreen() {
                        getNearestTaxiAsyncTaskCall();
                    }
                });


        layoutMarker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        helpImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, HelpActivity.class));
            }
        });

        helpLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, HelpActivity.class));
            }
        });

        shareImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String shareText = "Destarny Share";
                Intent textShareIntent = new Intent(Intent.ACTION_SEND);
                textShareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
                textShareIntent.setType("text/plain");
                startActivity(Intent.createChooser(textShareIntent, "Share Text with..."));
            }
        });

        shareLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String shareText = "Destarny Share";
                Intent textShareIntent = new Intent(Intent.ACTION_SEND);
                textShareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
                textShareIntent.setType("text/plain");
                startActivity(Intent.createChooser(textShareIntent, "Share Text with..."));
            }
        });

        imgLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPrefClass.setPassengerLogin(false);
                startActivity(new Intent(HomeActivity.this, SwitchActivity.class));
                finish();
            }
        });

        logoutLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPrefClass.setPassengerLogin(false);
                startActivity(new Intent(HomeActivity.this, SwitchActivity.class));
                finish();
            }
        });

        mSourceAddressLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectSourceMethod();
            }
        });
        btnLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectSourceMethod();
            }
        });

        getNearestTaxiAsyncTaskCall();
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run()
            {
                mCenterProgressBar.setVisibility(View.INVISIBLE);

            }
        }, 8000);


        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                Log.e(TAG, "Updating Drivers On Map!");
//                                    mAsyncTaskGetTaxiList = new GetNearestTaxi();
//                                    mAsyncTaskGetTaxiList.execute("" + LocationUtils.USER_CURRENT_LATITUDE,
//                                            "" + LocationUtils.USER_CURRENT_LONGITUDE,
//                                            LocationUtils.CURRENT_VEHICLE_TYPE);
                // TODO: 6/21/2016 getUserLocation
                double lat = gps.getLatitude();
                double lng = gps.getLongitude();
                double acc = gps.getAccuracy();

                if (LocationUtils.USER_CURRENT_LATITUDE == 0
                        && LocationUtils.USER_CURRENT_LONGITUDE == 0) {
                    LocationUtils.USER_CURRENT_LATITUDE = lat;
                    LocationUtils.USER_CURRENT_LONGITUDE = lng;
                }

                addressFromMap = false;
                addressFromText = false;
                addressFromGPS = true;

                Log.e(TAG, "\n" + lat + ", " + lng + ", " + acc);

                getNearestTaxiAsyncTaskCall();
                getDriverLocationUpdateHandler.postDelayed(this, GET_DRIVER_UPDATES_PER_MS);
            }
        };

        getDriverLocationUpdateHandler.postDelayed(runnable, 0);

        getVehicleType = new GetVehicleType();
        getVehicleType.execute();
    }

    private void permissionForM() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {

            int hasStoragePermission = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            int hasCoarseLocation = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION);
            int hasFineLocation = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION);
            int hasCallPhonePermission = checkSelfPermission(Manifest.permission.CALL_PHONE);


            List<String> permissions = new ArrayList<>();
            if (hasStoragePermission != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
            if (hasCoarseLocation != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            }
            if (hasFineLocation != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
            }
            if (hasCallPhonePermission != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.CALL_PHONE);
            }

            if (!permissions.isEmpty()) {
                requestPermissions(permissions.toArray(new String[permissions.size()]),
                        PERMISSIONS_REQUEST);
            }
        }
    }

    private void getNearestTaxiAsyncTaskCall() {
        if (mAsyncTaskGetTaxiList != null) {
            mAsyncTaskGetTaxiList.cancel(true);
        }

        mAsyncTaskGetTaxiList = new GetNearestTaxi();
        mAsyncTaskGetTaxiList.execute("" + LocationUtils.USER_CURRENT_LATITUDE, ""
                + LocationUtils.USER_CURRENT_LONGITUDE, LocationUtils.CURRENT_VEHICLE_TYPE);
    }


    private void selectSourceMethod() {

        dialog = new Dialog(HomeActivity.this,
                android.R.style.Theme_Black_NoTitleBar);
        dialog.setContentView(R.layout.layout_select_source_address);
        mAutoPlace = (AutoCompleteTextView) dialog
                .findViewById(R.id.select_place);
        mLoadingBar = (ProgressBar) dialog
                .findViewById(R.id.progressBarLoading);
        mLstLocationList = (ListView) dialog.findViewById(R.id.lst_locations);
        dialog.show();

        mAutoPlace.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {

                if (mAddressSuggestionAsyncTask != null) {
                    mAddressSuggestionAsyncTask.cancel(true);
                }
                if (s.length() >= 1) {
                    new GetAddressSuggestionAsyncTask()
                            .execute(s.toString());
                } else {

                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                // getSuggestonAsyncTask.execute(s.toString());
            }
        });


    }


    private void addDataInToList() {

        listDataHeader = new ArrayList<String>();
        listDataChild = new HashMap<String, List<String>>();

        // Adding child data
        listDataHeader.add("Home");
        listDataHeader.add("Profile");
        listDataHeader.add("Billing Info");
        listDataHeader.add("Past Bookings");
        listDataHeader.add("Current Booking Status");
//        listDataHeader.add("Credit");
        listDataHeader.add("Book in Advance");
        listDataHeader.add("Invite Friend");
        listDataHeader.add("Contact");

        // Adding child data
        List<String> Home = new ArrayList<String>();
        List<String> Profile = new ArrayList<String>();
        List<String> BillingInfo = new ArrayList<String>();
        List<String> Favourites = new ArrayList<String>();
        List<String> CurrentBookStatus = new ArrayList<String>();
//        List<String> Credit = new ArrayList<String>();
        List<String> BookInAdnce = new ArrayList<String>();
        BookInAdnce.add("Pre Booking Form");
//        BookInAdnce.add("Booking Airport");
        BookInAdnce.add("Pre Booking info");

        List<String> inviteFriend = new ArrayList<String>();
        List<String> Contact = new ArrayList<String>();
        listDataChild.put(listDataHeader.get(0), Home); // Header, Child data
        listDataChild.put(listDataHeader.get(1), Profile);
        listDataChild.put(listDataHeader.get(2), BillingInfo);
        listDataChild.put(listDataHeader.get(3), Favourites);
        listDataChild.put(listDataHeader.get(4), CurrentBookStatus);
//        listDataChild.put(listDataHeader.get(5), Credit);
        listDataChild.put(listDataHeader.get(5), BookInAdnce);
        listDataChild.put(listDataHeader.get(6), inviteFriend);
        listDataChild.put(listDataHeader.get(7), Contact);
    }


    private class DrawerChildItemClickListner implements ExpandableListView.OnChildClickListener {

        @Override
        public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

            if (groupPosition == 5) {

                if (childPosition == 0) {
                    startActivity(new Intent(getApplicationContext(), PreBookingActivity.class));
                    parent.collapseGroup(groupPosition);
                    drawerLayout.closeDrawer(mDrawerList);

                } else if (childPosition == 1) {
                    // TODO: Airport Booking is commented out below
//                    startActivity(new Intent(getApplicationContext(), TaxiToAirportActivity.class));
//                    parent.collapseGroup(groupPosition);
//                    drawerLayout.closeDrawer(mDrawerList);
//                } else if (childPosition == 2) {
                    startActivity(new Intent(getApplicationContext(), PreBookingInfoActivity.class));
                    parent.collapseGroup(groupPosition);
                    drawerLayout.closeDrawer(mDrawerList);
                }

            }

            return false;
        }
    }

    private class DrawerItemClickListener implements ExpandableListView.OnGroupClickListener {

        @Override
        public boolean onGroupClick(ExpandableListView parent, View v, int position, long id) {

            if (position == 0) {
                // selectItem(position);
                drawerLayout.closeDrawer(mDrawerList);
            } else if (position == 1) {
                startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                drawerLayout.closeDrawer(mDrawerList);
            } else if (position == 2) {
                startActivity(new Intent(getApplicationContext(), BillingInfoActivity.class));
                // TODO: 1/25/2017 New Credit Card Scenario
//                startActivity(new Intent(getApplicationContext(), CreditActivity.class));
                drawerLayout.closeDrawer(mDrawerList);
            } else if (position == 3) {
                startActivity(new Intent(getApplicationContext(), FavouriteActivity.class));
                drawerLayout.closeDrawer(mDrawerList);
            } else if (position == 4) {
                startActivity(new Intent(getApplicationContext(), CurrentBookingStatusActivity.class));
                drawerLayout.closeDrawer(mDrawerList);
            } else if (position == 5) {
//                startActivity(new Intent(getApplicationContext(), CreditActivity.class));
//                drawerLayout.closeDrawer(mDrawerList);
            } else if (position == 6) {
//                String userEntry = textEntry.getText().toString();

                String userEntry = "Testing Share";
                Intent textShareIntent = new Intent(Intent.ACTION_SEND);
                textShareIntent.putExtra(Intent.EXTRA_TEXT, userEntry);
                textShareIntent.setType("text/plain");
                startActivity(Intent.createChooser(textShareIntent, "Share text with..."));

                /*parent.smoothScrollToPosition(position);

                if (parent.isGroupExpanded(position)) {
                    parent.collapseGroup(position);
                } else {
                    parent.expandGroup(position);
                }*/
            } else if (position == 7) {
                startActivity(new Intent(getApplicationContext(), EmergencyActivity.class));
                drawerLayout.closeDrawer(mDrawerList);
            }

            return false;
        }

    }


    public BroadcastReceiver GpsChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            final LocationManager manager = (LocationManager) context
                    .getSystemService(Context.LOCATION_SERVICE);
            if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                // do something
                removeGpsDialog();
                isGpsDialogShowing = false;
            } else {
                // do something else
                if (isGpsDialogShowing) {
                    return;
                }
                ShowGpsDialog();
                isGpsDialogShowing = true;
            }

        }
    };
    public BroadcastReceiver internetConnectionReciever = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            ConnectivityManager connectivityManager = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetInfo = connectivityManager
                    .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            NetworkInfo activeWIFIInfo = connectivityManager
                    .getNetworkInfo(connectivityManager.TYPE_WIFI);

            if (activeWIFIInfo.isConnected() || activeNetInfo.isConnected()) {
                removeInternetDialog();
            } else {
                if (isNetDialogShowing) {
                    return;
                }
                showInternetDialog();
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            ShowGpsDialog();
        } else {
            removeGpsDialog();

            intialiseMap(googlemap);

            LocationUtils.CURRENT_VEHICLE_TYPE = "3";

            ((Utils_SliderLayout) findViewById(R.id.unlockButton)).setProgress(50);

            ((Utils_SliderLayout) findViewById(R.id.unlockButton))
                    .setSlideButtonListener(new Utils_SliderLayout.SlideButtonListener() {
                        @Override
                        public void handleSlid(String s) {
                            LocationUtils.CURRENT_VEHICLE_TYPE = s;
                            unlockScreen();
                        }

                        private void unlockScreen() {
                            getNearestTaxiAsyncTaskCall();
                        }
                    });
        }

        registerReceiver(internetConnectionReciever, new IntentFilter(
                "android.net.conn.CONNECTIVITY_CHANGE"));
        registerReceiver(GpsChangeReceiver, new IntentFilter(
                LocationManager.PROVIDERS_CHANGED_ACTION));
        isRecieverRegistered = true;


        checkGPSPermision();
    }

    private void checkGPSPermision() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Camera permission has not been granted.

            requestLocationRuntime();
        } else {
            // Camera permissions is already available, show the camera preview.
            //showCameraPreview();
        }
    }


    private void requestLocationRuntime() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.CAMERA)) {
            ActivityCompat.requestPermissions(HomeActivity.this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_LOCATION);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA},
                    REQUEST_LOCATION);
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //Mint.closeSession(this);
        //AndyUtils.removeCustomProgressDialog();
        // Mint.closeSession(this);
        if (isRecieverRegistered) {
            unregisterReceiver(internetConnectionReciever);
            unregisterReceiver(GpsChangeReceiver);
        }
        //unregisterIsApproved();

    }

    private void ShowGpsDialog() {
        //AndyUtils.removeCustomProgressDialog();
        isGpsDialogShowing = true;
        AlertDialog.Builder gpsBuilder = new AlertDialog.Builder(
                HomeActivity.this);
        gpsBuilder.setCancelable(false);
        gpsBuilder
                .setTitle(getString(R.string.dialog_no_gps))
                .setMessage(getString(R.string.dialog_no_gps_messgae))
                .setPositiveButton(getString(R.string.dialog_enable_gps),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // continue with delete
                                Intent intent = new Intent(
                                        android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                startActivity(intent);
                                removeGpsDialog();
                            }
                        })

                .setNegativeButton(getString(R.string.dialog_exit),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // do nothing
                                removeGpsDialog();
                                finish();
                            }
                        });
        gpsAlertDialog = gpsBuilder.create();
        gpsAlertDialog.show();
    }

    private void removeGpsDialog() {
        if (gpsAlertDialog != null && gpsAlertDialog.isShowing()) {
            gpsAlertDialog.dismiss();
            isGpsDialogShowing = false;
            gpsAlertDialog = null;
        }
    }

    private void removeInternetDialog() {
        if (internetDialog != null && internetDialog.isShowing()) {
            internetDialog.dismiss();
            isNetDialogShowing = false;
            internetDialog = null;
        }
    }

    private void showInternetDialog() {
        //AndyUtils.removeCustomProgressDialog();
        isNetDialogShowing = true;
        AlertDialog.Builder internetBuilder = new AlertDialog.Builder(
                HomeActivity.this);
        internetBuilder.setCancelable(false);
        internetBuilder
                .setTitle(getString(R.string.dialog_no_internet))
                .setMessage(getString(R.string.dialog_no_inter_message))
                .setPositiveButton(getString(R.string.dialog_enable_3g),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // continue with delete
                                Intent intent = new Intent(
                                        android.provider.Settings.ACTION_SETTINGS);
                                startActivity(intent);
                                removeInternetDialog();
                            }
                        })
                .setNeutralButton(getString(R.string.dialog_enable_wifi),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // User pressed Cancel button. Write
                                // Logic Here
                                startActivity(new Intent(
                                        Settings.ACTION_WIFI_SETTINGS));
                                removeInternetDialog();
                            }
                        })
                .setNegativeButton(getString(R.string.dialog_exit),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // do nothing
                                removeInternetDialog();
                                finish();
                            }
                        });
        internetDialog = internetBuilder.create();
        internetDialog.show();
    }


    private void intialiseMap(GoogleMap map) {
        if (gps.getLocation() != null) {

            //map.setMyLocationEnabled(true);
            CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(new LatLng(gps.getLatitude(), gps.getLongitude())).zoom(14.5f).build();
            //map.setMyLocationEnabled(true);
            map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

            map.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener() {
                @Override
                public void onCameraChange(CameraPosition cameraPosition) {
                    //Toast.makeText(getActivity(),"Testing",Toast.LENGTH_SHORT).show();

                    LocationUtils.USER_CURRENT_LATITUDE = cameraPosition.target.latitude;
                    LocationUtils.USER_CURRENT_LONGITUDE = cameraPosition.target.longitude;
                    LocationUtils.USER_CURRENT_LATITUDE = Double.valueOf(decimalFormat
                            .format(LocationUtils.USER_CURRENT_LATITUDE));
                    LocationUtils.USER_CURRENT_LONGITUDE = Double.valueOf(decimalFormat
                            .format(LocationUtils.USER_CURRENT_LONGITUDE));

                    getAddressFromLocation(cameraPosition.target, btnLocation);

                    addressFromMap = true;
                    addressFromText = false;
                    addressFromGPS = false;
                }
            });
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                map.setMyLocationEnabled(true);
            } else {
                Toast.makeText(HomeActivity.this,
                        "You have to accept all the permissions to enjoy all app's services!",
                        Toast.LENGTH_LONG).show();
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
                    map.setMyLocationEnabled(true);
                }
            }

        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        intialiseMap(googleMap);
    }

    private class GetVehicleType extends AsyncTask<String, String, String> {
        //        private ProgressDialog mDlg;
        private String strResponse = "";
        private JSONObject mObject;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            mDlg = new ProgressDialog(NewMapsActivity.this);
//            mDlg.setMessage("Please wait..");
//            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                String url = Constant.GET_VEHICLE_TYPE;
                strResponse = mWeb.mWebMethod(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return strResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
//            mDlg.dismiss();
            try {
                mObject = new JSONObject(s);
                if (mObject.getBoolean("status")) {
                    JSONArray itemsJsonArray = mObject.getJSONArray("items");

                    mPrefClass.setVehicleTypes(itemsJsonArray.toString());
//                    getVehicleType(itemsJsonArray);
                } else {
//                    String items = mPrefClass.getVehicleTypes();
//                    if (items != null) {
//                        JSONArray itemsJsonArray = new JSONArray(items);
//                        getVehicleType(itemsJsonArray);
//                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }

    private void getAddressFromLocation(final LatLng latlng, final TextView et) {
        et.setText("Waiting for address");

        mAddressLoadingBar.setVisibility(View.VISIBLE);
        et.setTextColor(Color.GRAY);

        if (mAddressFromLatLng != null)
            mAddressFromLatLng.cancel(true);
        mAddressFromLatLng = new GetAddressFromLatLngAsyncTask(latlng, et)
                .execute();

//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                Geocoder gCoder = new Geocoder(getApplicationContext());
//                try {
//                    final List<Address> list = gCoder.getFromLocation(latlng.latitude, latlng.longitude, 1);
//                    if (list != null && list.size() > 0) {
//                        address = list.get(0);
//                        StringBuilder sb = new StringBuilder();
//                        if (address.getAddressLine(0) != null) {
//                            if (address.getMaxAddressLineIndex() > 0) {
//                                for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
//                                    sb.append(address.getAddressLine(i)).append(" ");
//                                }
//                                sb.append(",");
//                                sb.append(address.getCountryName());
//                            } else {
//                                sb.append(address.getAddressLine(0));
//                            }
//                        }
//                        strAddress = sb.toString();
//                        strAddress = strAddress.replace(",null", "");
//                        strAddress = strAddress.replace("null", "");
//                        strAddress = strAddress.replace("Unnamed", "");
//                    }
//
//
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            if (!TextUtils.isEmpty(strAddress)) {
//                                et.setFocusable(false);
//                                et.setFocusableInTouchMode(false);
//                                et.setText(strAddress);
//                                et.setTextColor(getResources().getColor(android.R.color.black));
//                                et.setFocusable(true);
//                                et.setFocusableInTouchMode(true);
//
//                                mAddressLoadingBar.setVisibility(View.INVISIBLE);
//                            } else {
//                                mAddressLoadingBar.setVisibility(View.INVISIBLE);
//                                et.setText("");
//                                et.setTextColor(getResources().getColor(android.R.color.black));
//                            }
//                            //etSource.setEnabled(true);
//                            if (mAsyncTaskGetTaxiList != null) {
//                                mAsyncTaskGetTaxiList.cancel(true);
//                            }
//
////                            restrictAsyncTaskCalls();
//                            mAsyncTaskGetTaxiList = new GetNearestTaxi();
//                            mAsyncTaskGetTaxiList.execute("" + LocationUtils.USER_CURRENT_LATITUDE,
//                                    "" + LocationUtils.USER_CURRENT_LONGITUDE,
//                                    LocationUtils.CURRENT_VEHICLE_TYPE);
//
////                            final int GET_DRIVER_UPDATES_PER_MS = 60000;
////
////                            Runnable runnable = new Runnable() {
////                                @Override
////                                public void run() {
////                                    Log.e(TAG, "Updating Drivers On Map!");
//////                                    mAsyncTaskGetTaxiList = new GetNearestTaxi();
//////                                    mAsyncTaskGetTaxiList.execute("" + LocationUtils.USER_CURRENT_LATITUDE,
//////                                            "" + LocationUtils.USER_CURRENT_LONGITUDE,
//////                                            LocationUtils.CURRENT_VEHICLE_TYPE);
////                                    // TODO: 6/21/2016 getUserLocation
////                                    double lat = gps.getLatitude();
////                                    double lng = gps.getLongitude();
////                                    double acc = gps.getAccuracy();
////
////                                    Log.e(TAG, "\n" + lat + ", " + lng + ", " + acc);
////
////                                    getNearestTaxiAsyncTaskCall();
////                                    getDriverLocationUpdateHandler.postDelayed(this, GET_DRIVER_UPDATES_PER_MS);
////                                }
////                            };
////
////                            getDriverLocationUpdateHandler.postDelayed(runnable, GET_DRIVER_UPDATES_PER_MS);
//
//
//                        }
//                    });
//                } catch (Exception exc) {
//                    exc.printStackTrace();
//                }
//            }
//        }).start();
    }

    private class GetNearestTaxi extends AsyncTask<String, String, String> {

        private String strResponse = "";
        private Exception e = null;
        private JSONArray mArray;
        private JSONObject mParentObject, mChildObject;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mToolBarRightProgressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO: 7/25/2016 send Passenger Id get boolean value for driver id
            String cid = mPrefClass.getPassengerId();
            try {
                strResponse = mWebHandler.getNearestTaxiList(params[0], params[1], params[2], cid);
            } catch (IOException e) {
                e.printStackTrace();
                this.e = e;
            }

            return strResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mToolBarRightProgressBar.setVisibility(View.INVISIBLE);
            Log.e(TAG, "New markers!");
            googlemap.clear();
            LocationUtils.NEAREST_CAR_LOCATION = s;

            // Check no. of available Taxis
            int counter = 0;

            if (e == null) {
                try {
                    mParentObject = new JSONObject(s);
                    if (mParentObject.getBoolean("status")) {

                        mArray = mParentObject.getJSONArray("items");

                        double dist = 0.0;
                        if (mArray.length() > 0) {

                            boolean isAnyAcceptedDriver = false;

                            for (int i = 0; i < mArray.length(); i++) {

                                NearestTaxi mTaxiObj;
                                mChildObject = mArray.getJSONObject(i);

                                boolean accepteddriverst = mChildObject.getBoolean("accepteddriverst");

                                if (accepteddriverst) {
                                    isAnyAcceptedDriver = true;
                                    String lat = mChildObject.getString("lat");
                                    String lng = mChildObject.getString("lng");
                                    String vtid = mChildObject.getString("vtype");

                                    String fname = mChildObject.getString("fname");
                                    String lname = mChildObject.getString("lname");
                                    String driver_noplate = mChildObject.getString("driver_noplate");
                                    String description = "";
                                    if (mChildObject.has("modelno"))
                                        description = mChildObject.getString("modelno");
                                    String eta = "";
                                    if (mChildObject.has("duration_from_driver_to_passenger"))
                                        eta = mChildObject.getString("duration_from_driver_to_passenger");

                                    String driverName = fname + " " + lname;
                                    mDriverNameTextView.setText(driverName);
                                    mVehicleDescriptionTextView.setText(description);
                                    mRegoTextView.setText(driver_noplate);
                                    mETATextView.setText(eta);
                                    mDriverInfoLayout.setVisibility(View.VISIBLE);


                                    double latitude = Double.parseDouble(lat);
                                    double longitude = Double.parseDouble(lng);
                                    LatLng TAXI_LOCATION = new LatLng(latitude, longitude);

                                    // Default vehicle is taxi so don't check in if else
                                    int bookedTaxiDrawable = R.drawable.ic_booked_taxi;
                                    if (vtid.equals("Premium")) {
                                        bookedTaxiDrawable = R.drawable.ic_booked_premium;
                                    } else if (vtid.equals("Private")) {
                                        bookedTaxiDrawable = R.drawable.ic_booked_private;
                                    }
                                    Marker marker = googlemap
                                            .addMarker(new MarkerOptions()
                                                    .position(TAXI_LOCATION)
                                                    .icon(BitmapDescriptorFactory
//                                                        .fromResource(R.drawable.ic_taxi)));
//                                                            .fromResource(R.drawable.ic_taxi_red_medium)));
                                                            .fromResource(bookedTaxiDrawable)));
                                } else {
                                    counter++;

                                    String fname = mChildObject.getString("fname");
                                    String lname = mChildObject.getString("lname");
                                    String phone_no = mChildObject.getString("phone_no");
                                    String numberPlate = mChildObject.getString("driver_noplate");
                                    String model = mChildObject.getString("modelno");
                                    String make = mChildObject.getString("made");

                                    String lat = mChildObject.getString("lat");
                                    String lng = mChildObject.getString("lng");
                                    String distance = mChildObject.getString("distance");
                                    dist = Double.parseDouble(distance);
                                    String did = mChildObject.getString("id");
                                    String vtid = mChildObject.getString("vtype");

                                    double pricePerKm = mChildObject.getDouble("price_per_km");
                                    double pricePerMin = mChildObject.getDouble("price_per_min");
                                    double minPrice = mChildObject.getDouble("min_price");
                                    double distFromPickupLoc = mChildObject.getDouble("distance");

                                    String rating = mChildObject.getString("rating");

//                                mTaxiObj = new NearestTaxi(fname, phone_no, lname, lng, distance,
//                                        did, lat, vtid, numberPlate);
//                                    mTaxiObj = new NearestTaxi(fname, phone_no, lname, lng, distance,
//                                            did, lat, vtid, numberPlate, pricePerKm, pricePerMin,
//                                            minPrice, distFromPickupLoc);
                                    mTaxiObj = new NearestTaxi(fname, phone_no, lname, lng, distance,
                                            did, lat, vtid, numberPlate, pricePerKm, pricePerMin,
                                            minPrice, distFromPickupLoc, rating);

                                    mNearestTaxiList.add(mTaxiObj);

                                    double latitude = Double.parseDouble(lat);
                                    double longitude = Double.parseDouble(lng);
                                    LatLng TAXI_LOCATION = new LatLng(latitude, longitude);

                                    // Default vehicle is taxi so don't check in if else
                                    int availableTaxiDrawable = R.drawable.ic_available_taxi;
                                    if (vtid.equals("Premium")) {
                                        availableTaxiDrawable = R.drawable.ic_available_premium;
                                    } else if (vtid.equals("Private")) {
                                        availableTaxiDrawable = R.drawable.ic_available_private;
                                    }

                                    Marker marker = googlemap
                                            .addMarker(new MarkerOptions()
                                                    .position(TAXI_LOCATION)
                                                    .icon(BitmapDescriptorFactory
//                                                        .fromResource(R.drawable.ic_taxi)));
//                                                            .fromResource(R.drawable.ic_taxi_medium)));
                                                            .fromResource(availableTaxiDrawable)));
                                }
                            }

                            if (!isAnyAcceptedDriver)
                                mDriverInfoLayout.setVisibility(View.GONE);

                            if (counter > 0) {
                                isTaxiAvailable = true;

                                imgSquareLeft.setVisibility(View.VISIBLE);
                                imgSqureRight.setVisibility(View.VISIBLE);
                                mTxtDistance.setVisibility(View.VISIBLE);
                                txtSelectLocation.setText("Set pickup location");
                                mTxtDistance.setText("" + ((int) dist) + " m");

                            } else {
                                isTaxiAvailable = false;

                                imgSquareLeft.setVisibility(View.INVISIBLE);
                                imgSqureRight.setVisibility(View.INVISIBLE);
                                mTxtDistance.setVisibility(View.INVISIBLE);
                                txtSelectLocation.setText("No nearby vehicle available !");
                            }

                        }

                    } else {
                        if (mParentObject.has("logout"))
                            if (mParentObject.getString("logout").equalsIgnoreCase("1")) {
                                // TODO: 1/24/2017 Show dialog

                                if (!debtAccountDialogShowing) {
                                    String msg = "Passanger account is Debt";
                                    if (mParentObject.has("items"))
                                        msg = mParentObject.getString("items");
                                    // TODO: 1/25/2017 Uncomment this
                                    debtAccountDialog(msg);
                                }
                            }
                        imgSquareLeft.setVisibility(View.INVISIBLE);
                        imgSqureRight.setVisibility(View.INVISIBLE);
                        mTxtDistance.setVisibility(View.INVISIBLE);
                        txtSelectLocation.setText("No nearby vehicle available !");
                        //Toast.makeText(HomeActivity.this, "No nearby vehicle available !", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }
            } else {

            }
        }
    }

    private void debtAccountDialog(String msg) {
        Button btnYes, btnNo;
        final Dialog exitDialog = new Dialog(HomeActivity.this);
        exitDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        exitDialog.setContentView(R.layout.layout_debt_account);

        ((TextView) exitDialog.findViewById(R.id.txt_alert_dialog_message)).setText(msg);

        btnYes = (Button) exitDialog.findViewById(R.id.btnYes);
        btnNo = (Button) exitDialog.findViewById(R.id.btnNo);

        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exitDialog.dismiss();
                debtAccountDialogShowing = true;
                finish();
            }
        });

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                debtAccountDialogShowing = true;
                exitDialog.dismiss();
            }
        });

        exitDialog.show();
        debtAccountDialogShowing = true;
    }

    private void ChangeSourceLocation() {

    }

    private class GetAddressFromLatLngAsyncTask extends AsyncTask<String, List<String>, String> {
        private LatLng latLng = null;
        private TextView et;

        GetAddressFromLatLngAsyncTask(LatLng latlng, TextView et) {
            this.latLng = latlng;
            this.et = et;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            mLoadingBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... params) {
            strAddress = "";
            String apiKey = getResources().getString(R.string.mapapikey);
            try {
                strAddress = mWebMapUtils.getAddressFromLatLng(apiKey, "" + latLng.latitude,
                        "" + latLng.longitude);
            } catch (JSONException | IOException e) {
                e.printStackTrace();
            }
            return strAddress;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (mLoadingBar != null)
                mLoadingBar.setVisibility(View.INVISIBLE);
            if (s != null && !s.isEmpty()) { // changed
                strAddress = s;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!TextUtils.isEmpty(strAddress)) {
                            et.setFocusable(false);
                            et.setFocusableInTouchMode(false);
                            et.setText(strAddress);
                            et.setTextColor(getResources().getColor(android.R.color.black));
                            et.setFocusable(true);
                            et.setFocusableInTouchMode(true);

                            mAddressLoadingBar.setVisibility(View.INVISIBLE);
                        } else {
                            mAddressLoadingBar.setVisibility(View.INVISIBLE);
                            et.setText("");
                            et.setTextColor(getResources().getColor(android.R.color.black));
                        }
                        //etSource.setEnabled(true);
                        if (mAsyncTaskGetTaxiList != null) {
                            mAsyncTaskGetTaxiList.cancel(true);
                        }

//                            restrictAsyncTaskCalls();
                        mAsyncTaskGetTaxiList = new GetNearestTaxi();
                        mAsyncTaskGetTaxiList.execute("" + LocationUtils.USER_CURRENT_LATITUDE,
                                "" + LocationUtils.USER_CURRENT_LONGITUDE,
                                LocationUtils.CURRENT_VEHICLE_TYPE);
                    }
                });
//                mLoadingBar.setVisibility(View.INVISIBLE);
            } else {
                /*
                 * Toast.makeText(context, "Suggestion Error",
				 * Toast.LENGTH_SHORT).show();
				 */
            }
        }
    }

    private class GetAddressSuggestionAsyncTask extends AsyncTask<String, List<String>, List<String>> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mLoadingBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected List<String> doInBackground(String... params) {
            mAddressList = new ArrayList<>();
            String apiKey = getResources().getString(R.string.mapapikey);
            try {
                mAddressList = mWebMapUtils.getAddressSuggestions(
//                        Constant.PLACES_AUTOCOMPLETE_API_KEY,
                        apiKey,
                        params[0], ""
                                + LocationUtils.USER_CURRENT_LATITUDE, ""
                                + LocationUtils.USER_CURRENT_LONGITUDE);
            } catch (JSONException | IOException e) {
                e.printStackTrace();
            }
            return mAddressList;
        }

        @Override
        protected void onPostExecute(List<String> s) {
            super.onPostExecute(s);
            mLoadingBar.setVisibility(View.INVISIBLE);
            if (!s.isEmpty()) { // changed
                mSourceAddressListAdapter = new ArrayAdapter<>(getApplicationContext(),
                        R.layout.layout_autocompletelist, s);
                mLstLocationList.setAdapter(mSourceAddressListAdapter);

                mLstLocationList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        LocationUtils.CURRENT_SOURCE_ADDRESS = parent.getItemAtPosition(position).toString();
                        dialog.dismiss();

                        new GetAddressOnMap().execute();
                        //startActivity(new Intent(HomeActivity.this, MapsActivity.class));
                    }
                });
                mLoadingBar.setVisibility(View.INVISIBLE);
                isSourceSelected = true;
            } else {
                /*
                 * Toast.makeText(context, "Suggestion Error",
				 * Toast.LENGTH_SHORT).show();
				 */
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        if (requestCode == PERMISSIONS_REQUEST) {
            // TODO: 7/12/2016 DO NOTHING
        }

        if (requestCode == REQUEST_LOCATION) {
            // BEGIN_INCLUDE(permission_result)
            // Received permission result for camera permission.

            // Check if the only required permission has been granted
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Camera permission has been granted, preview can be displayed
                Toast.makeText(HomeActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();
                gps = new GPSTracker(HomeActivity.this);
            } else {
                Toast.makeText(HomeActivity.this, "Permission Not Granted", Toast.LENGTH_SHORT).show();
            }
            // END_INCLUDE(permission_result)

        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    private class GetAddressOnMap extends AsyncTask<String, String, String> {
        private ProgressDialog mDlg;
        Exception ex;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(HomeActivity.this);
            mDlg.setMessage("Please wait...");
            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            String loc;

            try {
//                loc = mWebMapUtils.getLatLongFromAddress(LocationUtils.CURRENT_SOURCE_ADDRESS);
                String mapKey = getResources().getString(R.string.mapapikey);
                loc = mWebMapUtils.getLatLongFromAddress(LocationUtils.CURRENT_SOURCE_ADDRESS, mapKey);
                String loc1[] = loc.split(",");
                LocationUtils.USER_CURRENT_LATITUDE = Double.parseDouble(loc1[0]);
                LocationUtils.USER_CURRENT_LONGITUDE = Double.parseDouble(loc1[1]);

                LocationUtils.USER_CURRENT_LATITUDE = Double.valueOf(decimalFormat
                        .format(LocationUtils.USER_CURRENT_LATITUDE));
                LocationUtils.USER_CURRENT_LONGITUDE = Double.valueOf(decimalFormat
                        .format(LocationUtils.USER_CURRENT_LONGITUDE));

                addressFromMap = false;
                addressFromText = true;
                addressFromGPS = false;

            } catch (IOException | JSONException e) {
                e.printStackTrace();
                ex = e;
            }

            return "";
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mDlg.dismiss();
            if (ex == null) {
                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(new LatLng(LocationUtils.USER_CURRENT_LATITUDE, LocationUtils.USER_CURRENT_LONGITUDE)).zoom(14.5f).build();
                //map.setMyLocationEnabled(true);
                googlemap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
            } else {

            }
        }
    }

    public void setPickuOnClickMethod(View v) {
        LocationUtils.CURRENT_SOURCE_ADDRESS = btnLocation.getText().toString().trim();
        String s = "Waiting for address";
        if (s.equals(LocationUtils.CURRENT_SOURCE_ADDRESS)) {
            Toast.makeText(HomeActivity.this, "Could not get Starting Location! " +
                    "Please be patient and try again later.", Toast.LENGTH_SHORT).show();
        } else {
            if (txtSelectLocation.getText().toString().trim().equals("Set pickup location"))
                if (isTaxiAvailable) {
//                    startActivity(new Intent(HomeActivity.this, MapsActivity.class));
//                    if (getVehicleType != null) {
//                        if (getVehicleType.getStatus() != AsyncTask.Status.FINISHED) {
                    // My AsyncTask is done and onPostExecute was called
                    getVehicleType = null;
                    startActivity(new Intent(HomeActivity.this, NewMapsActivity.class));
//                        }
//                    } else {
//                        startActivity(new Intent(HomeActivity.this, NewMapsActivity.class));
//                    }
                } else
                    Toast.makeText(HomeActivity.this, "No nearby vehicle available !", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(HomeActivity.this, "No nearby vehicle available !", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * @param marker
     * @return
     */
    @Override
    public boolean onMarkerClick(Marker marker) {

//        if (marker != null) {
//            marker.hideInfoWindow();
//            String mId = marker.getId();
//            final String did = driverId.get(mId);
//            NearestTaxi selectedTaxi = destarnyRateDetails.get(mId);
////                Toast.makeText(this, "" + marker.getPosition() + " id " + marker.getId(), Toast.LENGTH_SHORT).show();
//            if (did != null) {
//                marker.showInfoWindow();
////                Toast.makeText(this, "" + marker.getPosition()
////                        + " id " + marker.getId(), Toast.LENGTH_SHORT).show();
//            }
//        }
        return true;
//        return infoWindowAsDialog(marker);
    }

    private Dialog customInfoWindowDialog = null;
    private Marker selectedMarker = null;

    private boolean infoWindowAsDialog(final Marker marker) {
        if (customInfoWindowDialog != null && customInfoWindowDialog.isShowing())
            customInfoWindowDialog.dismiss();

        selectedMarker = marker;
        if (marker != null) {
            marker.hideInfoWindow();
            String mId = marker.getId();
//            final String did = driverId.get(mId);
//            NearestTaxi selectedTaxi = destarnyRateDetails.get(mId);
//                Toast.makeText(this, "" + marker.getPosition() + " id " + marker.getId(), Toast.LENGTH_SHORT).show();
//            if (did != null) {
            customInfoWindowDialog = new Dialog(HomeActivity.this);
            customInfoWindowDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            //d.setTitle("Select");
            customInfoWindowDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
            customInfoWindowDialog.setContentView(R.layout.custom_info_contents);

            String markerId = marker.getId();
//                Log.e(TAG, markerId);

            ImageView ivInfoWindowImage = (ImageView) customInfoWindowDialog.findViewById(R.id.iv_info_window_image);
            String vehicleType = NewMapsActivity.vehicleTypeId.get(markerId);
            if (vehicleType.equals("Premium"))
                ivInfoWindowImage.setImageDrawable(this.getResources().getDrawable(R.drawable.premium_vehicle));
            else if (vehicleType.equals("Private"))
                ivInfoWindowImage.setImageDrawable(this.getResources().getDrawable(R.drawable.private_vehicle));
            else if (vehicleType.equals("Taxi"))
                ivInfoWindowImage.setImageDrawable(this.getResources().getDrawable(R.drawable.taxi_vehicle));

            TextView tvTitle = ((TextView) customInfoWindowDialog.findViewById(R.id.tv_title));
            tvTitle.setText(marker.getTitle());
            TextView tvSnippet = ((TextView) customInfoWindowDialog.findViewById(R.id.tv_snippet));
            tvSnippet.setText(marker.getSnippet());
            Button bookTaxi = (Button) customInfoWindowDialog.findViewById(R.id.btn_book_taxi);

            customInfoWindowDialog.show();
//            }
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        Button btnYes, btnNo;

        final Dialog exitDialog = new Dialog(HomeActivity.this);
        exitDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        exitDialog.setContentView(R.layout.exit_dialog_box);

        btnYes = (Button) exitDialog.findViewById(R.id.btnYes);
        btnNo = (Button) exitDialog.findViewById(R.id.btnNo);

        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exitDialog.dismiss();
            }
        });

        exitDialog.show();
    }
}
