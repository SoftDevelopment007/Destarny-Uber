/**
 * Copyright 2015 Google Inc. All Rights Reserved.
 * <p/>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p/>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p/>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.destarny.passenger.gcm;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.destarny.passenger.R;
import com.destarny.passenger.SplashActivity;
import com.google.android.gms.gcm.GcmListenerService;

import java.util.Calendar;

public class MyGcmListenerService extends GcmListenerService {

    private static final String TAG = "MyGcmListenerService";
    private String title = null;

    /**
     * Called when message is received.
     *
     * @param from SenderID of the sender.
     * @param data Data bundle containing message data as key/value pairs.
     *             For Set of keys use data.keySet().
     */
    // [START receive_message]
    @Override
    public void onMessageReceived(String from, Bundle data) {
        String message = data.getString("message");
        title = data.getString("title");
        Log.d(TAG, "From: " + from);
        Log.d(TAG, "title: " + title);
        Log.d(TAG, "Message: " + message);

        if (from.startsWith("/topics/")) {
            // message received from some topic.
        } else {
            // normal downstream message.
        }

        // [START_EXCLUDE]
        /**
         * Production applications would usually process the message here.
         * Eg: - Syncing with server.
         *     - Store message in local database.
         *     - Update UI.
         */

        /**
         * In some cases it may be useful to show a notification indicating to the user
         * that a message was received.
         */
        sendNotification(message);
        // [END_EXCLUDE]
    }
    // [END receive_message]

    /**
     * Create and show a simple notification containing the received GCM message.
     *
     * @param message GCM message received.
     */
    private void sendNotification(String message) {
        Intent intent = new Intent(this, SplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code */, intent,
                PendingIntent.FLAG_ONE_SHOT);

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//        int notificationId = (int) Calendar.getInstance().getTimeInMillis();
//        NotificationCompat.Builder builder = new NotificationCompat.Builder(
//                this);
//        Notification notification = builder.setContentIntent(pendingIntent)
////                .setSmallIcon(R.mipmap.ic_launcher)
//                .setSmallIcon(R.drawable.notification)
//                .setLargeIcon(getBitmapIcon())
//                .setTicker(getResources().getString(R.string.app_name))
//                .setWhen(0)
//                .setAutoCancel(true).setContentTitle(title)
//                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
//                .setContentText(message)
//                .setSound(defaultSoundUri)
//                .build();
//
//        NotificationManager notificationManager =
//                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//
//        notificationManager.notify(notificationId, notification);

//        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
//            Notification.Builder build = new Notification.Builder(this)
//                    .setTicker(message)
//                    .setSmallIcon(R.mipmap.ic_launcher)
////                .setWhen(when)
//                    .setContentTitle("GCM Message")
//                    .setContentText(message)
////                    .setNumber(4)
////                .addLine("First Message")
////                .addLine("Second Message")
////                .addLine("Third Message")
////                .addLine("Fourth Message")
////                .setBigContentTitle("Here Your Messages")
////                .setSummaryText("+3 more")
//                    .setContentIntent(pendingIntent);
//
//            Notification notification = new Notification.InboxStyle(build)
//                    .build();
//
//            NotificationManager notificationManager =
//                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//
////            notificationManager.notify(0 /* ID of notification */, notification);
//            notificationManager.notify(notificationId /* ID of notification */, notification);
//        } else {

        NotificationCompat.Builder builder = new NotificationCompat.Builder(
                this);
        Notification notification = builder.setContentIntent(pendingIntent)
//                .setSmallIcon(R.mipmap.ic_launcher)
//                .setColor(Color.RED)
                .setSmallIcon(R.drawable.ic_notification)
                .setLargeIcon(getBitmapIcon())
                .setTicker(getResources().getString(R.string.app_name))
                .setWhen(0)
                .setAutoCancel(true).setContentTitle(title)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setContentText(message)
                .setSound(defaultSoundUri)
                .build();
        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        int notificationId = (int) Calendar.getInstance().getTimeInMillis();
        notificationManager.notify(notificationId, notification);
    }

//    private int getNotificationIcon() {
//        boolean useWhiteIcon = (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP);
//        return useWhiteIcon ? R.drawable.destarny_notification_icon : R.mipmap.ic_launcher;
//    }

    private Bitmap getBitmapIcon() {
        return BitmapFactory.decodeResource(getResources(),
                R.drawable.notification_black);
    }
}
