package com.destarny.passenger.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import com.destarny.passenger.R;
import com.destarny.passenger.utils.Constant;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.Web;

public class EmergencyActivity extends AppCompatActivity {
    private Utils mUtils;
    private Web mWeb;
    private ShardPrefClass mPref;


    private TextView txtTitle, mTxtAdminNo, mTxtEmeNo;

    private ImageView imgBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency);
        getSupportActionBar().hide();
        mWeb = new Web();
        mPref = new ShardPrefClass(EmergencyActivity.this);
        mUtils = new Utils(EmergencyActivity.this);
        mTxtAdminNo = (TextView) findViewById(R.id.adminNo);
        mTxtEmeNo = (TextView) findViewById(R.id.emerNo);
        txtTitle = (TextView) findViewById(R.id.toolbar_title);
        imgBack = (ImageView) findViewById(R.id.toolbar_left);
        imgBack.setVisibility(View.VISIBLE);
        imgBack.setImageResource(R.drawable.ic_action_back);
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        txtTitle.setVisibility(View.VISIBLE);
        txtTitle.setText("Emergency Contact");
        if (mUtils.isInterentConnection()) {
            new GetEmergencyContact().execute();
        } else {
            Toast.makeText(EmergencyActivity.this, Constant.INTERNET_CONNECTION, Toast.LENGTH_SHORT).show();
        }
    }

    private class GetEmergencyContact extends AsyncTask<String, String, String> {
        private ProgressDialog mDlg;
        private String strResponse = "";
        private JSONObject mObject;
        private JSONArray mArray;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(EmergencyActivity.this);
            mDlg.setMessage("Please wait..");
            mDlg.show();

        }

        @Override
        protected String doInBackground(String... params) {
             try {
                String url = Constant.GET_EMERGENCY_NO;
                strResponse = mWeb.mWebMethod(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return strResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mDlg.dismiss();


            try {
                mObject = new JSONObject(s);

                if (mObject.getBoolean("status")) {

                    mArray = mObject.getJSONArray("items");
                    mTxtAdminNo.setText(mArray.getJSONObject(0).getString("admin_no"));
                    mTxtEmeNo.setText(mArray.getJSONObject(0).getString("emergency_no"));

                } else {
                    Toast.makeText(EmergencyActivity.this, "Record Not Found !", Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }

    public void emeOnClickMethod(View v) {
        if (v.getId() == R.id.imgAdminCall) {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + mTxtAdminNo.getText().toString().trim()));
            startActivity(intent);
        } else if (v.getId() == R.id.imgEmeCall) {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + mTxtEmeNo.getText().toString().trim()));
            startActivity(intent);
        }

    }
}
