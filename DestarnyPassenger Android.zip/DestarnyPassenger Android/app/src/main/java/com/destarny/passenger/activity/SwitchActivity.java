package com.destarny.passenger.activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.destarny.passenger.R;

/**
 * Created by ApkDev3 on 11/25/2015.
 */
public class SwitchActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(getResources().getColor(R.color.main_bg));
        }
        setContentView(R.layout.activity_switch);
        getSupportActionBar().hide();

    }

    public void switchOnClickMethod(View v) {
        if (v.getId() == R.id.btnSwitchRegister) {

            startActivity(new Intent(getApplicationContext(), PassengerRegisterActivity.class));

        } else if (v.getId() == R.id.btnSwitchLogin) {

            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
            finish();
        }
    }
}
