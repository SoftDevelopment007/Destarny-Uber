package com.destarny.passenger.activity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.destarny.passenger.R;
import com.destarny.passenger.adapter.PlacesAutoCompleteAdapter;
import com.destarny.passenger.utils.Constant;
import com.destarny.passenger.utils.LocationUtils;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.Web;
import com.destarny.passenger.web.WebHandler;
import com.destarny.passenger.web.WebMapUtils;

public class PreBookingActivity extends AppCompatActivity implements View.OnClickListener {
    private RadioGroup mGrup;
    private RadioButton btnStandard, btnSUV, btnPremium;
    private ImageView imgBack;
    private TextView txtTitle;

    private AutoCompleteTextView sourceACTV;
    private AutoCompleteTextView destinationACTV;
    private EditText noOfPassengersEditText;
    //    private Spinner spnrMyFare;
//    private CheckBox meteredTaxiCheckBox;
    private RadioGroup dateGroup;
    private RadioButton todayRadioButton, tomorrowRadioButton, calendarRadioButton;
    private Button selectDate;
    private TimePicker timePicker;
    private Button bookTaxiNowButton;


    ArrayList<SetFare> setFares = null;

    private WebMapUtils mWebMapUtils = null;
    private Web mWeb = null;
    private WebHandler mWebHandler = null;

    //    private SetFare selectedSetFare;
    private boolean isSource = true;
    private String noOfPassengers = "";

    private ShardPrefClass mPref = null;
    private String setfareUnfulfilled = "0";
    //    private String fareType = "DestarnyRate";
    private String fareType = "Destarnyrate";
    private String booking_date = "";
    private String booking_time = "";

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

    private Calendar myCalendar = null;
    //    private int calendarPressedCount = 0;
    private DatePickerDialog.OnDateSetListener date = null;
    private String approxCalfare = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre_booking);

        hideSoftKeyboard();
        bindViews();
        initObjects();
        sourceAddress();
        destinationAddress();
//        mySetFare();

        mGrup = (RadioGroup) findViewById(R.id.radioGrup);
        btnStandard = (RadioButton) findViewById(R.id.btnStandardRadio);
        btnSUV = (RadioButton) findViewById(R.id.btnSUVRadio);
        btnPremium = (RadioButton) findViewById(R.id.btnPremiumRadio);

        getSupportActionBar().hide();
        imgBack = (ImageView) findViewById(R.id.toolbar_left);
        txtTitle = (TextView) findViewById(R.id.toolbar_title);
        txtTitle.setVisibility(View.VISIBLE);
        txtTitle.setText("Pre Booking Details");
        imgBack.setVisibility(View.VISIBLE);
        imgBack.setImageResource(R.drawable.ic_action_back);
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        mGrup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {


                if (checkedId == R.id.btnStandardRadio) {
                    LocationUtils.CURRENT_VEHICLE_TYPE = "2";

                    btnStandard.setTextColor(Color.WHITE);
                    btnSUV.setTextColor(Color.parseColor("#FFCB07"));
                    btnPremium.setTextColor(Color.parseColor("#FFCB07"));

                } else if (checkedId == R.id.btnSUVRadio) {
                    LocationUtils.CURRENT_VEHICLE_TYPE = "3";

                    btnStandard.setTextColor(Color.parseColor("#FFCB07"));
                    btnSUV.setTextColor(Color.WHITE);
                    btnPremium.setTextColor(Color.parseColor("#FFCB07"));

                } else if (checkedId == R.id.btnPremiumRadio) {
                    LocationUtils.CURRENT_VEHICLE_TYPE = "1";

                    btnStandard.setTextColor(Color.parseColor("#FFCB07"));
                    btnSUV.setTextColor(Color.parseColor("#FFCB07"));
                    btnPremium.setTextColor(Color.WHITE);
                }

            }
        });

        dateGroup = (RadioGroup) findViewById(R.id.rg_date);
        todayRadioButton = (RadioButton) findViewById(R.id.radio_today);
        tomorrowRadioButton = (RadioButton) findViewById(R.id.radio_tomorrow);
        calendarRadioButton = (RadioButton) findViewById(R.id.radio_calendar);

        dateGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {


                if (checkedId == R.id.radio_today) {
//                    calendarPressedCount = 0;
                    // converting it to desired format
                    booking_date = dateFormat.format(new Date());

                    todayRadioButton.setTextColor(Color.WHITE);
                    tomorrowRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    calendarRadioButton.setTextColor(Color.parseColor("#FFCB07"));

                } else if (checkedId == R.id.radio_tomorrow) {
//                    calendarPressedCount = 0;
                    Calendar calendar = Calendar.getInstance();
                    Date today = calendar.getTime();

                    calendar.add(Calendar.DAY_OF_YEAR, 1);
                    Date tomorrow = calendar.getTime();

                    // converting it to desired format
                    booking_date = dateFormat.format(tomorrow);

                    todayRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    tomorrowRadioButton.setTextColor(Color.WHITE);
                    calendarRadioButton.setTextColor(Color.parseColor("#FFCB07"));

                } else if (checkedId == R.id.radio_calendar) {
//                    calendarPressedCount++;

//                    new DatePickerDialog(PreBookingActivity.this, date, myCalendar
//                            .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
//                            myCalendar.get(Calendar.DAY_OF_MONTH)).show();

                    todayRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    tomorrowRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    calendarRadioButton.setTextColor(Color.WHITE);
                }

            }
        });

        calendarRadioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (calendarRadioButton.isChecked()) {
                    new DatePickerDialog(PreBookingActivity.this, date, myCalendar
                            .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                            myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                }
            }
        });

        myCalendar = Calendar.getInstance();
        date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                // converting it to desired format
                booking_date = dateFormat.format(myCalendar.getTime());
                selectDate.setText(booking_date);
            }

        };

    }

    /**
     * Hides the soft keyboard
     */
    public void hideSoftKeyboard() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    private void bindViews() {
        sourceACTV = (AutoCompleteTextView) findViewById(R.id.edtSource);
        destinationACTV = (AutoCompleteTextView) findViewById(R.id.edtDestination);
        noOfPassengersEditText = (EditText) findViewById(R.id.edtNoOfPassenger);
//        spnrMyFare = (Spinner) findViewById(R.id.spnrMyFare);
//        meteredTaxiCheckBox = (CheckBox) findViewById(R.id.chk_metered_taxi);
        selectDate = (Button) findViewById(R.id.btn_date_pre_booking);
        selectDate.setOnClickListener(this);
        timePicker = (TimePicker) findViewById(R.id.timePicker_pre_booking);
        bookTaxiNowButton = (Button) findViewById(R.id.btn_book_taxi_now);
        bookTaxiNowButton.setOnClickListener(this);
    }

    private void initObjects() {
        mWebMapUtils = new WebMapUtils();
        mWeb = new Web();
        mWebHandler = new WebHandler();
        mPref = new ShardPrefClass(getApplicationContext());
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_date_pre_booking:
                DatePickerDialog datePickerDialog = new DatePickerDialog(PreBookingActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.getDatePicker()
                        .setMinDate(System.currentTimeMillis() - 1000);
                datePickerDialog.show();
                break;

            case R.id.btn_book_taxi_now:
                noOfPassengers = noOfPassengersEditText.getText().toString();
//                if (spnrMyFare.getSelectedItemPosition() == 0) {
//                    fareType = "Taximeter";
//                } else {
//                    fareType = "SetFare";
//                }
//                selectedSetFare = (SetFare) spnrMyFare.getSelectedItem();
//                if (meteredTaxiCheckBox.isChecked())
//                    setfareUnfulfilled = "1";
//                else
                setfareUnfulfilled = "0";

                timePicker.setIs24HourView(true);
                int hour = timePicker.getCurrentHour();
                int minute = timePicker.getCurrentMinute();

                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.HOUR_OF_DAY, hour);
                calendar.set(Calendar.MINUTE, minute);
                calendar.clear(Calendar.SECOND); //reset seconds to zero

                booking_time = timeFormat.format(calendar.getTime());

                if (validate()) {
                    new PreBookTaxiNowTask().execute();
                }
                break;
        }
    }

    private boolean validate() {
        String source = sourceACTV.getText().toString();
        String dest = destinationACTV.getText().toString();
        if (!source.equals(LocationUtils.CURRENT_SOURCE_ADDRESS)) {
            Toast.makeText(PreBookingActivity.this,
                    "Please select Starting Address!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!dest.equals(LocationUtils.CURRENT_DESTINATION_ADDRESS)) {
            Toast.makeText(PreBookingActivity.this,
                    "Please select Destination Address!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (mGrup.getCheckedRadioButtonId() == -1) {
            Toast.makeText(PreBookingActivity.this,
                    "Please select Car Type!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!Utils.isNotNull(noOfPassengers)) {
            Toast.makeText(PreBookingActivity.this,
                    "Please enter Number of Passengers!", Toast.LENGTH_SHORT).show();
            return false;
//        }else if (!spnrMyFare.isSelected()) {
//            Toast.makeText(PreBookingActivity.this,
//                    "Please select Fare!", Toast.LENGTH_SHORT).show();
//            return false;
//        }else if (!meteredTaxiCheckBox.isSelected()) {
//            Toast.makeText(PreBookingActivity.this,
//                    "Please select Car Type!", Toast.LENGTH_SHORT).show();
//            return false;
//        }else if (!mGrup.isSelected()) {
//            Toast.makeText(PreBookingActivity.this,
//                    "Please select Car Type!", Toast.LENGTH_SHORT).show();
//            return false;
        }
        return true;
    }

    private void sourceAddress() {

        sourceACTV.setAdapter(new PlacesAutoCompleteAdapter(this, android.R.layout.simple_list_item_1));
        sourceACTV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                isSource = true;
                String str = (String) parent.getItemAtPosition(position);
                Toast.makeText(PreBookingActivity.this, str, Toast.LENGTH_SHORT).show();
                LocationUtils.CURRENT_SOURCE_ADDRESS = str;
                new GetLatLngFromAddress(str).execute();
            }
        });

//        sourceACTV.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                isSource = true;
//                String str = (String) parent.getItemAtPosition(position);
//                Toast.makeText(PreBookingActivity.this, str, Toast.LENGTH_SHORT).show();
//                LocationUtils.CURRENT_SOURCE_ADDRESS = str;
//                new GetLatLngFromAddress(str).execute();
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });
    }

    private void destinationAddress() {

        destinationACTV.setAdapter(new PlacesAutoCompleteAdapter(this, android.R.layout.simple_list_item_1));
        destinationACTV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                isSource = false;
                String str = (String) parent.getItemAtPosition(position);
                Toast.makeText(PreBookingActivity.this, str, Toast.LENGTH_SHORT).show();
                LocationUtils.CURRENT_DESTINATION_ADDRESS = str;
                new GetLatLngFromAddress(str).execute();

            }
        });
    }

    private class GetLatLngFromAddress extends AsyncTask<String, String, String> {
        private String address = null;
        private ProgressDialog mDlg;
        Exception ex;

        public GetLatLngFromAddress(String sourceAddress) {
            this.address = sourceAddress;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(PreBookingActivity.this);
            mDlg.setMessage("Please wait...");
            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            String loc = null;

            try {
//                loc = mWebMapUtils.getLatLongFromAddress(address);
                String mapKey = getResources().getString(R.string.mapapikey);
                loc = mWebMapUtils.getLatLongFromAddress(address, mapKey);
            } catch (IOException | JSONException e) {
                e.printStackTrace();
                ex = e;
            }

            return loc;
        }

        @Override
        protected void onPostExecute(String location) {
            super.onPostExecute(location);
            mDlg.dismiss();

            if (location != null && !location.isEmpty()) {
                if (isSource) {
                    String loc1[] = location.split(",");
                    LocationUtils.USER_CURRENT_LATITUDE = Double.parseDouble(loc1[0]);
                    LocationUtils.USER_CURRENT_LONGITUDE = Double.parseDouble(loc1[1]);

                    Log.e("", LocationUtils.CURRENT_SOURCE_ADDRESS + " " + LocationUtils.USER_CURRENT_LATITUDE + " "
                            + LocationUtils.USER_CURRENT_LONGITUDE);
                } else {
                    String loc1[] = location.split(",");
                    LocationUtils.USER_DEST_LATITUDE = Double.parseDouble(loc1[0]);
                    LocationUtils.USER_DEST_LONGITUDE = Double.parseDouble(loc1[1]);

                    Log.e("", LocationUtils.CURRENT_DESTINATION_ADDRESS + " " + LocationUtils.USER_DEST_LATITUDE + " "
                            + LocationUtils.USER_DEST_LONGITUDE);
                }
            } else {
                if (isSource)
                    sourceACTV.setText("");
                else
                    destinationACTV.setText("");

                Toast.makeText(PreBookingActivity.this, "Something went wrong!", Toast.LENGTH_SHORT).show();
            }
        }
    }


    private void mySetFare() {

        if (Utils.isNetworkAvailable(PreBookingActivity.this))
            new GetAllSetFare().execute();
        else {
            Toast.makeText(PreBookingActivity.this,
                    "Please check the Internet Connection!", Toast.LENGTH_SHORT).show();
            finish();
        }

    }

    private class GetAllSetFare extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(PreBookingActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String response = null;
            try {
                String url = Constant.GET_SET_FARES;
                response = mWeb.mWebMethod(url);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (progressDialog.isShowing())
                progressDialog.hide();

            try {
                if (s != null) {
                    JSONObject mParentObject = new JSONObject(s);
                    if (mParentObject.getBoolean("status")) {
                        // Initialize ArrayList of SetFares
                        setFares = new ArrayList<>();

                        // Adding Default First Item to Spinner
                        SetFare setFareObj = new SetFare();
                        setFareObj.setId("0");
                        setFareObj.setFare("Taximeter");
                        setFares.add(setFareObj);

                        JSONArray itemsJsonArray = mParentObject.getJSONArray("items");
                        int size = itemsJsonArray.length();

                        for (int i = 0; i < size; i++) {
                            JSONObject obj = itemsJsonArray.getJSONObject(i);
                            String id = obj.getString("id");
                            String fare = obj.getString("fare");

                            SetFare setFare = new SetFare();
                            setFare.setId(id);
                            setFare.setFare(fare);

                            setFares.add(setFare);
                        }

                        // Creating adapter for spinner
//                    ArrayAdapter<SetFare> dataAdapter = new ArrayAdapter<SetFare>(PreBookingActivity.this, android.R.layout.simple_spinner_item, airportAddresses);
//                        ArrayAdapter<SetFare> dataAdapter = new ArrayAdapter<SetFare>(PreBookingActivity.this, R.layout.spinner_item, setFares);

//                    // Drop down layout style
//                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                        // attaching data adapter to spinner
//                        spnrMyFare.setAdapter(dataAdapter);
                    } else {
                        Toast.makeText(getApplicationContext(), "Something went wrong! Please try again!", Toast.LENGTH_LONG).show();
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class SetFare {
        private String id;
        private String fare;

        public SetFare() {
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getFare() {
            return fare;
        }

        public void setFare(String fare) {
            this.fare = fare;
        }

        @Override
        public String toString() {
            return "" + fare;
        }
    }

    private class PreBookTaxiNowTask extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(PreBookingActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String cid = mPref.getPassengerId();
            String vtid = LocationUtils.CURRENT_VEHICLE_TYPE;
            String booking_type = "Advance";
            String fare_type = fareType;
            String setfare_unfullfilled = setfareUnfulfilled;
            String booking_from_lat = String.valueOf(LocationUtils.USER_CURRENT_LATITUDE);
            String booking_from_lng = String.valueOf(LocationUtils.USER_CURRENT_LONGITUDE);
            String booking_from = LocationUtils.CURRENT_SOURCE_ADDRESS;
            String booking_to_lat = String.valueOf(LocationUtils.USER_DEST_LATITUDE);
            String booking_to_lng = String.valueOf(LocationUtils.USER_DEST_LONGITUDE);
            String booking_to = LocationUtils.CURRENT_DESTINATION_ADDRESS;
            String noofpass = noOfPassengers;
//            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
//            String booking_time = timeFormat.format(new Date());
//            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//            String booking_date = dateFormat.format(new Date());
            String notes = "";
            String fareid = "0";
//            if (selectedSetFare != null)
//                fareid = selectedSetFare.getId();

            String response = null;
            try {
                response = mWebHandler.bookNearestTaxi(cid, booking_type, fare_type, setfare_unfullfilled, booking_from_lat,
                        booking_from_lng, booking_from, booking_to_lat, booking_to_lng, booking_to, noofpass,
                        booking_time, booking_date, notes, fareid, "", "", "");
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (progressDialog.isShowing())
                progressDialog.hide();
            try {
                JSONObject mParentObject = new JSONObject(s);
                if (mParentObject.getBoolean("status")) {
                    JSONObject items = mParentObject.getJSONObject("items");
                    Toast.makeText(getApplicationContext(), "Your Pre-Order Request is sent!", Toast.LENGTH_LONG).show();

                    PreBookingActivity.this.finish();
                } else {
                    String msg = mParentObject.getString("items");
                    if (msg == null)
                        Toast.makeText(getApplicationContext(), "Something went wrong! Please try again!", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
