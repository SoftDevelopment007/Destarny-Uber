package com.destarny.passenger.utils;

/**
 * Created by sachi on 3/10/2016.
 */
public class LocationUtils {

    public static String CURRENT_VEHICLE_TYPE = "1";

    public static double USER_CURRENT_LATITUDE;
    public static double USER_CURRENT_LONGITUDE;
    public static double USER_CURRENT_ACCURACY;

    public static double USER_DEST_LATITUDE;
    public static double USER_DEST_LONGITUDE;

    public static double USER_SOURCE_LATITUDE;
    public static double USER_SOURCE_LONGITUDE;
    public static String CURRENT_SOURCE_ADDRESS;
    public static String CURRENT_DESTINATION_ADDRESS;

    public static String SOURCE_DESTINATION_DISTANCE;
    public static String SOURCE_DESTINATION_TIME;

    public static String SOURCE_DESTINATION_DISTANCE_METERS;
    public static String SOURCE_DESTINATION_TIME_SECONDS;

    public static String DISTANCE_UNIT;
    public static String NEAREST_CAR_LOCATION;

    public static String NEAREST_CAR_LATITUDE;
    public static String NEAREST_CAR_LONGITUDE;

}
