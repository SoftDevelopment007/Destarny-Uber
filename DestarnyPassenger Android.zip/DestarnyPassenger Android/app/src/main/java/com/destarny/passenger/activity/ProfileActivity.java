package com.destarny.passenger.activity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import com.destarny.passenger.R;
import com.destarny.passenger.utils.Constant;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.WebHandler;

public class ProfileActivity extends AppCompatActivity {

    private ImageView imgBack;
    private ShardPrefClass mPref;
    private TextView mTxtTitle;
    private EditText mEdtFirstName, mEdtSecondName, mEdtUserName, mEdtEmailAddress, mEdtMobileNo;
    private Utils mUtils;
    private WebHandler mWeb;

    private String firstNameString, lastNameString, usernameString, emailString, phoneNumberString, passwordString,
            deviceIdString, deviceTypeString, payMethodString;
    private String custId = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        getSupportActionBar().hide();

        mUtils = new Utils(getApplicationContext());
        mEdtFirstName = (EditText) findViewById(R.id.edtFirstName);
        mEdtSecondName = (EditText) findViewById(R.id.edtLastName);
        mEdtUserName = (EditText) findViewById(R.id.edtUserName);
        mEdtEmailAddress = (EditText) findViewById(R.id.edtEmail);
        mEdtMobileNo = (EditText) findViewById(R.id.edtContactNumber);
        mWeb = new WebHandler();
        mTxtTitle = (TextView) findViewById(R.id.toolbar_title);
        mTxtTitle.setVisibility(View.VISIBLE);
        mTxtTitle.setText("User Profile");
        imgBack = (ImageView) findViewById(R.id.toolbar_left);
        imgBack.setImageResource(R.drawable.ic_action_back);
        imgBack.setVisibility(View.VISIBLE);

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        mPref = new ShardPrefClass(getApplicationContext());

        try {
            String passId = getPassengerId(mPref.getPassengerDetails());
            new GetProfile().execute(passId);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            addDataToFields(mPref.getPassengerDetails());
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private String getPassengerId(String passengerDetails) throws JSONException {
        JSONObject mObject;
        JSONArray itemsJsonArray = null;

        mObject = new JSONObject(passengerDetails);

        itemsJsonArray = mObject.getJSONArray("items");
        JSONObject itemObject = itemsJsonArray.getJSONObject(0);
        String id = itemObject.getString("id");
        return id;
    }

    private void addDataToFields(String passengerDetails) throws JSONException {

        JSONObject mObject, mChildObject;
        JSONArray itemsJsonArray = null;

        mObject = new JSONObject(passengerDetails);

//        mChildObject = mObject.getJSONObject("Response");
        itemsJsonArray = mObject.getJSONArray("items");
        JSONObject itemObject = itemsJsonArray.getJSONObject(0);

        custId = itemObject.getString("id");

        mEdtFirstName.setText(itemObject.getString("fname"));
        mEdtSecondName.setText(itemObject.getString("lname"));
        mEdtUserName.setText(itemObject.getString("username"));
        mEdtUserName.setEnabled(false);
        mEdtEmailAddress.setText(itemObject.getString("emailid"));
        mEdtMobileNo.setText(itemObject.getString("phone_no"));

//        mChildObject = mObject.getJSONObject("Response");
//
//        mEdtFirstName.setText(mChildObject.getString("fname").toString());
//        mEdtSecondName.setText(mChildObject.getString("lname").toString());
//        mEdtUserName.setText(mChildObject.getString("fname").toString());
//        mEdtUserName.setEnabled(false);
//        mEdtEmailAddress.setText(mChildObject.getString("emailid").toString());
//        mEdtMobileNo.setText(mChildObject.getString("phone_no").toString());
    }

    public void updateOnClickMethod(View v) {

        if (v.getId() == R.id.btnUpdate) {
            if (mUtils.isInterentConnection()) {
                firstNameString = mEdtFirstName.getText().toString().trim();
                lastNameString = mEdtSecondName.getText().toString().trim();
                emailString = mEdtEmailAddress.getText().toString().trim();
                phoneNumberString = mEdtMobileNo.getText().toString().trim();

                if (validate())
                    new UpdateProfile().execute(custId, firstNameString, lastNameString, emailString,
                            phoneNumberString, usernameString, passwordString, deviceIdString, deviceTypeString,
                            payMethodString);

            } else {
                Toast.makeText(ProfileActivity.this, Constant.INTERNET_CONNECTION, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean validate() {
        if (firstNameString.isEmpty()) {
            Toast.makeText(ProfileActivity.this, "Please enter appropriate First Name!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (lastNameString.isEmpty()) {
            Toast.makeText(ProfileActivity.this, "Please enter appropriate Last Name!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!isValidEmail(emailString)) {
            Toast.makeText(ProfileActivity.this, "Please enter appropriate Email!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (phoneNumberString.isEmpty()) {
            Toast.makeText(ProfileActivity.this, "Please enter appropriate Phone Number!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    public static boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }

    private class GetProfile extends AsyncTask<String, String, String> {
        private ProgressDialog mDlg;
        private JSONObject mObject;
        private String strResponse;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(ProfileActivity.this);
            mDlg.setMessage("Please wait...");
            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            try {
//                strResponse=mWeb.updateUserProfile(params[0],params[1],params[2],params[3],params[4]);
                strResponse = mWeb.getUserProfile(params[0]);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return strResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                setValuesToView(s);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            mDlg.dismiss();

        }
    }

    private void setValuesToView(String s) throws JSONException {
        JSONObject mObject;
        JSONArray itemsJsonArray = null;

        if (s != null) {
            mObject = new JSONObject(s);

//        mChildObject = mObject.getJSONObject("Response");
            itemsJsonArray = mObject.getJSONArray("items");
            JSONObject itemObject = itemsJsonArray.getJSONObject(0);

            custId = itemObject.getString("id");
            firstNameString = itemObject.getString("fname");
            lastNameString = itemObject.getString("lname");
            usernameString = itemObject.getString("username");
            emailString = itemObject.getString("emailid");
            phoneNumberString = itemObject.getString("phone_no");
            passwordString = itemObject.getString("password");
            deviceIdString = itemObject.getString("deviceid");
            deviceTypeString = itemObject.getString("device_type");
            payMethodString = itemObject.getString("pay_method");

            mEdtFirstName.setText(firstNameString);
            mEdtSecondName.setText(lastNameString);
            mEdtUserName.setText(usernameString);
            mEdtUserName.setEnabled(false);
            mEdtEmailAddress.setText(emailString);
            mEdtMobileNo.setText(phoneNumberString);
        }

    }

    private class UpdateProfile extends AsyncTask<String, String, String> {
        private ProgressDialog mDlg;
        private String strResponse;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(ProfileActivity.this);
            mDlg.setMessage("Please wait...");
            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            try {
//                strResponse=mWeb.updateUserProfile(params[0],params[1],params[2],params[3],params[4]);
                strResponse = mWeb.editUserProfile(params[0], params[1], params[2], params[3], params[4],
                        params[5], params[6], params[7], params[8], params[9]);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return strResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mDlg.dismiss();
            try {
                updateResponse(s);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void updateResponse(String s) throws JSONException {
        JSONObject mObject = new JSONObject(s);

        boolean status = mObject.getBoolean("status");
        if (status)
            Toast.makeText(ProfileActivity.this, "Profile Updated Successfully!",
                    Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(ProfileActivity.this, "Profile was not updated!",
                    Toast.LENGTH_LONG).show();
    }

}
