package com.destarny.passenger.utils;

import android.content.Context;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by Aniket on 6/15/2016.
 */
public class ContentLogger {
    private static final String LOG_TAG = ContentLogger.class.getSimpleName();

    public static void addLog(String TAG, String s, Context context) {
        Log.e(TAG, s);
        appendLog(s);
    }

    public static void appendLog(String text) {
        File logFile = new File("sdcard/destarnypassengerlog.txt");
        if (!logFile.exists()) {
            try {
                logFile.createNewFile();

                //BufferedWriter for performance, true to set append to file flag
                BufferedWriter buf = new BufferedWriter(new FileWriter(logFile, true));
                buf.append(text);
                buf.newLine();
                buf.close();
                Log.e(LOG_TAG, "Added to the Log!");
            } catch (IOException e) {
                e.printStackTrace();
                Log.e(LOG_TAG, "Error while adding to the Log!");
            }
        }
    }
}
