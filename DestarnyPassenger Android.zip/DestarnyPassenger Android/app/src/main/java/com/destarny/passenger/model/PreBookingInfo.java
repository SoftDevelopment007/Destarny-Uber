package com.destarny.passenger.model;

/**
 * Created by hr on 5/10/2016.
 */
public class PreBookingInfo {
    private String bookingFrom;
    private String bookingTo;
    private String vtid;
    private String noofpass;
    private String fareType;
    private String bookingDate;
    private String bookingTime;

    public PreBookingInfo() {
    }

    public String getBookingFrom() {
        return bookingFrom;
    }

    public void setBookingFrom(String bookingFrom) {
        this.bookingFrom = bookingFrom;
    }

    public String getBookingTo() {
        return bookingTo;
    }

    public void setBookingTo(String bookingTo) {
        this.bookingTo = bookingTo;
    }

    public String getVtid() {
        return vtid;
    }

    public void setVtid(String vtid) {
        this.vtid = vtid;
    }

    public String getNoofpass() {
        return noofpass;
    }

    public void setNoofpass(String noofpass) {
        this.noofpass = noofpass;
    }

    public String getFareType() {
        return fareType;
    }

    public void setFareType(String fareType) {
        this.fareType = fareType;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getBookingTime() {
        return bookingTime;
    }

    public void setBookingTime(String bookingTime) {
        this.bookingTime = bookingTime;
    }

    @Override
    public String toString() {
        return "PreBookingInfo{" +
                "bookingFrom='" + bookingFrom + '\'' +
                ", bookingTo='" + bookingTo + '\'' +
                ", vtid='" + vtid + '\'' +
                ", noofpass='" + noofpass + '\'' +
                ", fareType='" + fareType + '\'' +
                ", bookingDate='" + bookingDate + '\'' +
                ", bookingTime='" + bookingTime + '\'' +
                '}';
    }
}
