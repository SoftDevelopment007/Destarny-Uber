package com.destarny.passenger.location;

/**
 * Created by ApkDev3 on 12/18/2015.
 */
public class LocationTracker {


}
