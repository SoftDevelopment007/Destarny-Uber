package com.destarny.passenger.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import com.destarny.passenger.model.DrawerClass;
import com.destarny.passenger.R;

/**
 * Created by ApkDev3 on 12/1/2015.
 */
public class DrawerAdapter extends BaseAdapter {

    private Context mContext;

    public DrawerAdapter(Context mContext, ArrayList<DrawerClass> mArrayList) {
        this.mContext = mContext;
        this.mArrayList = mArrayList;
    }

    private ArrayList<DrawerClass> mArrayList = new ArrayList<DrawerClass>();
    private LayoutInflater mInflater;

    @Override
    public int getCount() {
        return mArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return mArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return mArrayList.indexOf(mArrayList.get(position));
    }

    @Override
    public View getView(int position, View v, ViewGroup parent) {

        ViewHolder mHolder;

        if (mInflater == null) {

            mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        }

        if (v == null) {
            v = mInflater.inflate(R.layout.layout_drawer_list, null);
            mHolder = new ViewHolder();

            mHolder.imgIcon = (ImageView) v.findViewById(R.id.drawer_icon);
            mHolder.txtName = (TextView) v.findViewById(R.id.drawer_itemName);


            v.setTag(mHolder);

        } else {
            mHolder = (ViewHolder) v.getTag();
        }


        mHolder.imgIcon.setImageResource(mArrayList.get(position).getId());
        mHolder.txtName.setText(mArrayList.get(position).getText());

        return v;
    }

    private class ViewHolder {

        private ImageView imgIcon;
        private TextView txtName;

    }
}
