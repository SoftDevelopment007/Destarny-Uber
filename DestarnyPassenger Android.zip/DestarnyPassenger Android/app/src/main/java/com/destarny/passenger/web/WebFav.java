package com.destarny.passenger.web;

import android.net.Uri;

import java.io.IOException;
import java.util.HashMap;

import com.destarny.passenger.utils.Constant;

/**
 * Created by sachi on 5/11/2016.
 */
public class WebFav {

    Web mWeb;
    String strUrl = "";

    public WebFav() {
        mWeb = new Web();
    }

    public String mPassengerGetFavList(String strID) throws IOException {

        strUrl = Constant.GET_FAV_BOOKING;
//        Uri.Builder builder = new Uri.Builder()
//                .appendQueryParameter("cid", strID);
//
//        String query = builder.build().getEncodedQuery();
//        return mWeb.mWebMethod(strUrl, query);

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", strID).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", strID);
        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String mPassengerGetAllPastBookings(String strID) throws IOException {
        strUrl = Constant.GET_ALL_BOOKING;
//        Uri.Builder builder = new Uri.Builder()
//                .appendQueryParameter("cid", strID);
//
//        String query = builder.build().getEncodedQuery();
//        return mWeb.mWebMethod(strUrl, query);

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("cid", strID).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("cid", strID);
        return mWeb.mWebMethod(strUrl, postDataParams);
    }

    public String mPassengerSetFav(String bid) throws IOException {

        strUrl = Constant.SET_FAV_BOOKING;
//        Uri.Builder builder = new Uri.Builder()
//                .appendQueryParameter("bid", bid);
//
//        String query = builder.build().getEncodedQuery();
//        return mWeb.mWebMethod(strUrl, query);

//        String uri = Uri.parse(strUrl).buildUpon()
//                .appendQueryParameter("bid", bid).build().toString();
//        return mWeb.mWebMethod(uri);

        HashMap<String, String> postDataParams = new HashMap<>();
        postDataParams.put("bid", bid);
        return mWeb.mWebMethod(strUrl, postDataParams);
    }
}
