package com.destarny.passenger.interfaces;

/**
 * Created by hr on 5/14/2016.
 */
public interface ViewClickListener {
    void onButtonClicked(int position);
}
