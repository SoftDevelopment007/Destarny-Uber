package com.destarny.passenger.utils;

import android.content.Context;
import android.content.Intent;

import com.google.android.gms.maps.model.LatLng;

/**
 * Created by ApkDev3 on 07-11-2015.
 */
public class Constant {
    public static final String PUBLISHABLE_KEY = "pk_test_w7N1BuPLAxbshRsaEzYcJmUa";

    public static final String BASE_URL, LOGIN_URL, REGISTER_URL, GET_TERMS_CONDITION, GET_NEAREST_TAXI_LIST, UPDATE_PROFILE, CHECK_USERNAME,
            BOOK_NEAREST_TAXI, BOOK_SELECTED_TAXI, FORGOT_PASSWORD, GET_SET_FARES, GET_USER_PROFILE, EDIT_PROFILE,
            GET_PAYMENT_METHOD, ADD_PAYMENT_METHOD, SET_PAYMENT_METHOD, PRE_BOOKING_INFO, GET_AIRPORTS,
            GET_FAV_BOOKING, GET_ALL_BOOKING, SET_FAV_BOOKING, CURRENT_BOOKING_STATUS, CANCEL_BOOKING,
            DELETE_CREDIT_CARD_DETAILS, GET_EMERGENCY_NO, GET_VEHICLE_TYPE;

    public static final String USERNAME, PASSWORD, FIRSTNAME, LASTNAME, EMAIL, CONTACTNO, UDID, DEVICETYPE, LATITUDE, LONGITUDE, VTID, PAY_METHOD, TCID,
            BOOKING_FROM_LNG, BOOKING_FROM_LAT, BOOKING_TYPE, FARE_TYPE, SET_FARE_UNFULFILLED, BOOKING_FROM, BOOKING_TO_LAT, BOOKING_TO_LNG,
            BOOKING_TO, NO_OF_PASS, BOOKING_TIME, BOOKING_DATE, NOTES, FARE_ID, DID, CNO, CVN, EXP_DATE, PAY_ID, ATID,
            BID, CANCEL_REASON, DISTANCE, DURATION, APPX_FARE;


    static {

        //BASE_URL = "http://dev12.edreamz3.com/api/passenger.php/";
//        BASE_URL = "http://destarny.com/api/passenger.php/";
//        BASE_URL = "http://destarny.com/api/passenger.php/";
//        BASE_URL = "http://mysetfare.com/au/sydney/api/passenger.php/";
        BASE_URL = "https://mysetfare.com/au/sydney/api/passenger.php/";

        LOGIN_URL = BASE_URL + "login/?";
        REGISTER_URL = BASE_URL + "signup/?";
        GET_TERMS_CONDITION = BASE_URL + "getptc";
        GET_NEAREST_TAXI_LIST = BASE_URL + "getnearbydriversbtvtype/?";
        UPDATE_PROFILE = BASE_URL + "passenger_update_registration.php";
        CHECK_USERNAME = BASE_URL + "passenger_username_check.php";
        BOOK_NEAREST_TAXI = BASE_URL + "addbooking/?";
        BOOK_SELECTED_TAXI = BASE_URL + "addbookingfordriver/?";
        FORGOT_PASSWORD = BASE_URL + "forgetPassword/?";
        GET_SET_FARES = BASE_URL + "getsetfares";

        GET_USER_PROFILE = BASE_URL + "getuserprofile/?";
        EDIT_PROFILE = BASE_URL + "editprofile/?";
        GET_PAYMENT_METHOD = BASE_URL + "getpaymentmethod/?";
        ADD_PAYMENT_METHOD = BASE_URL + "addpaymethodmethod/?";
        SET_PAYMENT_METHOD = BASE_URL + "setpaymethodmethod/?";
        PRE_BOOKING_INFO = BASE_URL + "openbooking/?";
        GET_AIRPORTS = BASE_URL + "getairporttolist";

        GET_FAV_BOOKING = BASE_URL + "getfavoritesbooking/?";
        GET_ALL_BOOKING = BASE_URL + "completedbookingforpass/?";
        SET_FAV_BOOKING = BASE_URL + "setfavoritesbooking/?";

        CURRENT_BOOKING_STATUS = BASE_URL + "acceptedbooking/?";
        CANCEL_BOOKING = BASE_URL + "cancelbooking/?";
        DELETE_CREDIT_CARD_DETAILS = BASE_URL + "deletepaymethodmethod/?";
        GET_EMERGENCY_NO = BASE_URL + "getemergencynos";

        GET_VEHICLE_TYPE = BASE_URL + "getvehicletype";
    }

    static {
        BOOKING_FROM_LNG = "booking_from_lng";
        BOOKING_FROM_LAT = "booking_from_lat";
        USERNAME = "username";
        PASSWORD = "password";
        FIRSTNAME = "fname";
        LASTNAME = "lname";
        EMAIL = "emailid";
        CONTACTNO = "phone_no";
        UDID = "deviceid";
        DEVICETYPE = "device_type";
        LATITUDE = "lat";
        LONGITUDE = "lng";
        VTID = "vtid";
        PAY_METHOD = "pay_method";
        TCID = "tcid";

        BOOKING_TYPE = "booking_type";
        FARE_TYPE = "fare_type";
        SET_FARE_UNFULFILLED = "setfare_unfullfilled";
        BOOKING_FROM = "booking_from";
        BOOKING_TO_LAT = "booking_to_lat";
        BOOKING_TO_LNG = "booking_to_lng";
        BOOKING_TO = "booking_to";
        NO_OF_PASS = "noofpass";
        BOOKING_TIME = "booking_time";
        BOOKING_DATE = "booking_date";
        NOTES = "notes";
        FARE_ID = "fareid";
        DID = "did";
        CNO = "cno";
        CVN = "cvn";
        EXP_DATE = "expdate";
        PAY_ID = "payid";
        ATID = "atid";

        BID = "bid";
        CANCEL_REASON = "cancel_reason";

        DISTANCE = "distance";
        DURATION = "duration";
        APPX_FARE = "calfare";
    }


    public static final String LOCATION_BROADCAST = "locatioin_broadcast";
    public static final String INTERNET_CONNECTION = "You don't have internet connection.";

    public static void updateLocation(Context context) {
        Intent intent = new Intent(LOCATION_BROADCAST);
        context.sendBroadcast(intent);
    }


    public static final String PLACES_AUTOCOMPLETE_API_KEY = "AIzaSyBx1zPjeF3anUuCtL_UJ1kqZ1z-RBWDXe8";
    public static final String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";
    public static final String TYPE_AUTOCOMPLETE = "/autocomplete";
    public static final String TYPE_NEAR_BY = "/nearbysearch";
    public static final String OUT_JSON = "/json";


    public static LatLng mapLatLong = null;


}
