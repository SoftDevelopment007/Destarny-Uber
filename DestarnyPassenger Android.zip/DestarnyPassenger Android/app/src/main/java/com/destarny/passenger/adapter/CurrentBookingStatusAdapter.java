package com.destarny.passenger.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import com.destarny.passenger.R;
import com.destarny.passenger.activity.CurrentBookingStatusActivity;
import com.destarny.passenger.model.CurrentBookingStatus;

/**
 * Created by hr on 5/14/2016.
 */
public class CurrentBookingStatusAdapter extends ArrayAdapter<CurrentBookingStatus> {
    private CurrentBookingStatusActivity mActivity = null;
    private ArrayList<CurrentBookingStatus> objects;
    int layoutResourceId;
//    private ViewClickListener mViewClickListener;

    public CurrentBookingStatusAdapter(Activity activty, int layoutResourceId, ArrayList<CurrentBookingStatus> objects) {
        super(activty, layoutResourceId, objects);
        this.mActivity = (CurrentBookingStatusActivity) activty;
        this.layoutResourceId = layoutResourceId;
        this.objects = objects;

    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View rootView = convertView;
        CurrentBookingStatusViewHolder statusViewHolder = null;


        // first check to see if the view is null. if so, we have to inflate it.
        // to inflate it basically means to render, or show, the view.
        if (rootView == null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rootView = inflater.inflate(layoutResourceId, null);

            statusViewHolder = new CurrentBookingStatusViewHolder();
            statusViewHolder.sourceTextView = (TextView) rootView.findViewById(R.id.tv_from);
            statusViewHolder.destTextView = (TextView) rootView.findViewById(R.id.tv_to);
            statusViewHolder.bookingTimeTextView = (TextView) rootView.findViewById(R.id.tv_time);
            statusViewHolder.typeOfVehicleTextView = (TextView) rootView.findViewById(R.id.tv_vehicle_type);
            statusViewHolder.noOfPassengersTextView = (TextView) rootView.findViewById(R.id.tv_no_of_pass);
            statusViewHolder.setFareTextView = (TextView) rootView.findViewById(R.id.tv_fare_type);
            statusViewHolder.driverNameTextView = (TextView) rootView.findViewById(R.id.tv_driver_name);
            statusViewHolder.driverContactNoTextView = (TextView) rootView.findViewById(R.id.tv_contact_no);
            statusViewHolder.modelTextView = (TextView) rootView.findViewById(R.id.tv_model);
            statusViewHolder.vehicleNoTextView = (TextView) rootView.findViewById(R.id.tv_vehicle_no);
            statusViewHolder.vehicleRegoTextView = (TextView) rootView.findViewById(R.id.tv_vehicle_rego);
            statusViewHolder.driverTaglineTextView = (TextView) rootView.findViewById(R.id.tv_driver_tagline);

            statusViewHolder.distanceFromDriverTextView = (TextView) rootView.findViewById(R.id.tv_distance);
            statusViewHolder.durationFromDriverTextView = (TextView) rootView.findViewById(R.id.tv_duration);
            statusViewHolder.durationFromDriverInTrafficTextView = (TextView) rootView.findViewById(R.id.tv_duration_in_traffic);


            statusViewHolder.callDriver = (Button) rootView.findViewById(R.id.btn_call_driver);
            statusViewHolder.cancelButton = (Button) rootView.findViewById(R.id.btn_cancel);

            statusViewHolder.driverDetailsLinearLayout = (LinearLayout)
                    rootView.findViewById(R.id.ll_driver_details);
            statusViewHolder.distanceFromDriverLinearLayout = (LinearLayout)
                    rootView.findViewById(R.id.ll_distance);
            statusViewHolder.durationFromDriverLinearLayout = (LinearLayout)
                    rootView.findViewById(R.id.ll_ETA);
            statusViewHolder.durationFromDriverInTrafficLinearLayout = (LinearLayout)
                    rootView.findViewById(R.id.ll_duration_in_traffic);

            rootView.setTag(statusViewHolder);
        } else {
            statusViewHolder = (CurrentBookingStatusViewHolder) rootView.getTag();
        }

        CurrentBookingStatus bookingStatus = objects.get(position);
        statusViewHolder.sourceTextView.setText(bookingStatus.getSource());
        statusViewHolder.destTextView.setText(bookingStatus.getDestination());
        statusViewHolder.bookingTimeTextView.setText(bookingStatus.getBookingTime());
        statusViewHolder.typeOfVehicleTextView.setText(bookingStatus.getVehicleType());
        statusViewHolder.noOfPassengersTextView.setText(bookingStatus.getNoOfPass());
        statusViewHolder.setFareTextView.setText(bookingStatus.getSetFare());

        String driverNameString = bookingStatus.getDriverName();
        String driverContactString = bookingStatus.getDriverContact();
        String modelString = bookingStatus.getModel();
        String vehicleNoString = bookingStatus.getVehicleNo();
        String vehicleRegoString = bookingStatus.getVehicleRego();
        String madeString = bookingStatus.getMade();

        if (driverNameString.trim().isEmpty() && driverContactString.isEmpty()
                && modelString.isEmpty()&& vehicleNoString.isEmpty()&& madeString.isEmpty()) {
            statusViewHolder.driverDetailsLinearLayout.setVisibility(View.GONE);
            statusViewHolder.callDriver.setVisibility(View.INVISIBLE);
//            statusViewHolder.durationFromDriverLinearLayout.setVisibility(View.GONE);
//            statusViewHolder.durationFromDriverInTrafficLinearLayout.setVisibility(View.GONE);
        } else {
            statusViewHolder.driverDetailsLinearLayout.setVisibility(View.VISIBLE);
            statusViewHolder.callDriver.setVisibility(View.VISIBLE);

            statusViewHolder.driverNameTextView.setText(driverNameString);
            statusViewHolder.driverContactNoTextView.setText(driverContactString);
            statusViewHolder.modelTextView.setText(modelString);
            statusViewHolder.vehicleNoTextView.setText(vehicleNoString);
            statusViewHolder.vehicleRegoTextView.setText(vehicleRegoString);
            statusViewHolder.driverTaglineTextView.setText(madeString);
        }

        String distanceFromDriver = bookingStatus.getDistanceFromDriver();
        String durationFromDriver = bookingStatus.getDurationFromDriver();
        String durationFromDriverInTraffic = bookingStatus.getDurationFromDriverInTraffic();

        if (distanceFromDriver.isEmpty() && durationFromDriver.isEmpty()
                && durationFromDriverInTraffic.isEmpty()) {
            statusViewHolder.distanceFromDriverLinearLayout.setVisibility(View.GONE);
            statusViewHolder.durationFromDriverLinearLayout.setVisibility(View.GONE);
            statusViewHolder.durationFromDriverInTrafficLinearLayout.setVisibility(View.GONE);
        } else {
            statusViewHolder.durationFromDriverLinearLayout.setVisibility(View.VISIBLE);
            statusViewHolder.durationFromDriverLinearLayout.setVisibility(View.VISIBLE);
            statusViewHolder.durationFromDriverInTrafficLinearLayout.setVisibility(View.VISIBLE);

            statusViewHolder.distanceFromDriverTextView.setText(distanceFromDriver);
            statusViewHolder.durationFromDriverTextView.setText(durationFromDriver);
            statusViewHolder.durationFromDriverInTrafficTextView.setText(durationFromDriverInTraffic);
        }

        final String contact = bookingStatus.getDriverContact();
        statusViewHolder.callDriver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mActivity.onCallButtonClicked(contact);
            }
        });
        statusViewHolder.cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mActivity.onButtonClicked(position);
            }
        });

        // the view must be returned to our activity
        return rootView;
    }

    static class CurrentBookingStatusViewHolder {
        TextView sourceTextView;
        TextView destTextView;
        TextView bookingTimeTextView;
        TextView typeOfVehicleTextView;
        TextView noOfPassengersTextView;
        TextView setFareTextView;
        TextView driverNameTextView;
        TextView driverContactNoTextView;
        TextView modelTextView;
        TextView vehicleNoTextView;
        TextView vehicleRegoTextView;
        TextView driverTaglineTextView;

        TextView distanceFromDriverTextView;
        TextView durationFromDriverTextView;
        TextView durationFromDriverInTrafficTextView;

        Button callDriver;
        Button cancelButton;

        LinearLayout driverDetailsLinearLayout;
        LinearLayout distanceFromDriverLinearLayout;
        LinearLayout durationFromDriverLinearLayout;
        LinearLayout durationFromDriverInTrafficLinearLayout;
    }

//    public void setViewClickListener(ViewClickListener viewClickListener) {
//        mViewClickListener = viewClickListener;
//    }
}
