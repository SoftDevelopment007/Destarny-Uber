package com.destarny.passenger.activity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import com.destarny.passenger.R;
import com.destarny.passenger.adapter.PlacesAutoCompleteAdapter;
import com.destarny.passenger.utils.Constant;
import com.destarny.passenger.utils.LocationUtils;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.Web;
import com.destarny.passenger.web.WebHandler;
import com.destarny.passenger.web.WebMapUtils;

public class TaxiToAirportActivity extends AppCompatActivity implements View.OnClickListener {

    private RadioGroup mGrup;
    private RadioButton btnStandard, btnSUV, btnPremium;
    private ImageView imgBack;
    private TextView txtTitle;
    private AutoCompleteTextView sourceACTV;
    private Spinner destinationSpinner;
    private Button selectDate;
    private TimePicker timePicker;
    private EditText notesEditText, noOfPassengersEditText;
    private Button orderTaxiButton;

    ArrayList<AirportAddress> airportAddresses = null;
    private AirportAddress selectedAirport;

    private String bookingTime = "";
    private String noOfPassengers = null;

    private ShardPrefClass mPref = null;
    private WebMapUtils mWebMapUtils = null;
    private Web mWeb = null;
    private WebHandler mWebHandler = null;

    private Calendar myCalendar = null;
    private DatePickerDialog.OnDateSetListener date = null;

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
    private String booking_date = null;
    private String notes = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_taxi_to_airport);

        hideSoftKeyboard();
        bindViews();
        initObjects();
        sourceAddress();
        if (Utils.isNetworkAvailable(TaxiToAirportActivity.this))
            new GetAirportAddress().execute();
        else
            finish();

        mGrup = (RadioGroup) findViewById(R.id.radioGrup);
        btnStandard = (RadioButton) findViewById(R.id.btnStandardRadio);
        btnSUV = (RadioButton) findViewById(R.id.btnSUVRadio);
        btnPremium = (RadioButton) findViewById(R.id.btnPremiumRadio);
        getSupportActionBar().hide();
        imgBack = (ImageView) findViewById(R.id.toolbar_left);
        txtTitle = (TextView) findViewById(R.id.toolbar_title);
        txtTitle.setVisibility(View.VISIBLE);
        txtTitle.setText("Fixed Fare To Airport");
        imgBack.setVisibility(View.VISIBLE);
        imgBack.setImageResource(R.drawable.ic_action_back);
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        mGrup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.btnStandardRadio) {
                    LocationUtils.CURRENT_VEHICLE_TYPE = "2";

                    btnStandard.setTextColor(Color.WHITE);
                    btnSUV.setTextColor(Color.parseColor("#FFCB07"));
                    btnPremium.setTextColor(Color.parseColor("#FFCB07"));
                } else if (checkedId == R.id.btnSUVRadio) {
                    LocationUtils.CURRENT_VEHICLE_TYPE = "3";

                    btnStandard.setTextColor(Color.parseColor("#FFCB07"));
                    btnSUV.setTextColor(Color.WHITE);
                    btnPremium.setTextColor(Color.parseColor("#FFCB07"));
                } else if (checkedId == R.id.btnPremiumRadio) {
                    LocationUtils.CURRENT_VEHICLE_TYPE = "1";

                    btnStandard.setTextColor(Color.parseColor("#FFCB07"));
                    btnSUV.setTextColor(Color.parseColor("#FFCB07"));
                    btnPremium.setTextColor(Color.WHITE);
                }

            }
        });

        myCalendar = Calendar.getInstance();
        date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                // converting it to desired format
                booking_date = dateFormat.format(myCalendar.getTime());

                selectDate.setText(booking_date);
            }

        };

    }

    /**
     * Hides the soft keyboard
     */
    public void hideSoftKeyboard() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    private void bindViews() {
        sourceACTV = (AutoCompleteTextView) findViewById(R.id.actvSource);
        destinationSpinner = (Spinner) findViewById(R.id.spnrDestination);
        selectDate = (Button) findViewById(R.id.btn_date_taxi_to_airport);
        selectDate.setOnClickListener(this);
        timePicker = (TimePicker) findViewById(R.id.timePicker_taxi_to_airport);
        notesEditText = (EditText) findViewById(R.id.edtNotes);
        noOfPassengersEditText = (EditText) findViewById(R.id.edtNoPassenger);
        orderTaxiButton = (Button) findViewById(R.id.btn_order_taxi);
        orderTaxiButton.setOnClickListener(this);
    }

    private void initObjects() {
        mWebMapUtils = new WebMapUtils();
        mWeb = new Web();
        mWebHandler = new WebHandler();
        mPref = new ShardPrefClass(getApplicationContext());
    }

    private void sourceAddress() {
        sourceACTV.setAdapter(new PlacesAutoCompleteAdapter(this, android.R.layout.simple_list_item_1));
        sourceACTV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String str = (String) parent.getItemAtPosition(position);
                Toast.makeText(TaxiToAirportActivity.this, str, Toast.LENGTH_SHORT).show();
                LocationUtils.CURRENT_SOURCE_ADDRESS = str;
                new GetLatLngFromAddress(str).execute();
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_date_taxi_to_airport:
                new DatePickerDialog(TaxiToAirportActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                break;

            case R.id.btn_order_taxi:
                noOfPassengers = noOfPassengersEditText.getText().toString();
                timePicker.setIs24HourView(true);
                int hour = timePicker.getCurrentHour();
                int minute = timePicker.getCurrentMinute();

                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.HOUR_OF_DAY, hour);
                calendar.set(Calendar.MINUTE, minute);
                calendar.clear(Calendar.SECOND); //reset seconds to zero

                bookingTime = timeFormat.format(calendar.getTime());
                selectedAirport = (AirportAddress) destinationSpinner.getSelectedItem();
                notes = notesEditText.getText().toString();
                if (validate()) {
                    if (Utils.isNetworkAvailable(TaxiToAirportActivity.this))
                        new BookTaxiToAirportTask().execute();
                    else
                        Toast.makeText(TaxiToAirportActivity.this,
                                "Please check Internet Connection!", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    private boolean validate() {
        String source = sourceACTV.getText().toString();
        if (!source.equals(LocationUtils.CURRENT_SOURCE_ADDRESS)) {
            Toast.makeText(TaxiToAirportActivity.this,
                    "Please select Starting Address!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (destinationSpinner.getSelectedItemPosition() == 0) {
            Toast.makeText(TaxiToAirportActivity.this,
                    "Please select Airport!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (mGrup.getCheckedRadioButtonId() == -1) {
            Toast.makeText(TaxiToAirportActivity.this,
                    "Please select Car Type!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!Utils.isNotNull(noOfPassengers)) {
            Toast.makeText(TaxiToAirportActivity.this,
                    "Please enter Number of Passengers!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private class GetAirportAddress extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(TaxiToAirportActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String response = null;
            try {
                String url = Constant.GET_AIRPORTS;
                response = mWeb.mWebMethod(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (progressDialog.isShowing())
                progressDialog.hide();

            try {
                JSONObject mParentObject = new JSONObject(s);
                if (mParentObject.getBoolean("status")) {
                    // Initialize ArrayList of SetFares
                    airportAddresses = new ArrayList<>();

                    // Adding Default First Item to Spinner
                    AirportAddress airportAddressObj = new AirportAddress();
                    airportAddressObj.setId("0");
                    airportAddressObj.setAirportName("Select Destination");
                    airportAddressObj.setFixedFare("0");
                    airportAddresses.add(airportAddressObj);

                    JSONArray itemsJsonArray = mParentObject.getJSONArray("items");
                    int size = itemsJsonArray.length();

                    for (int i = 0; i < size; i++) {
                        JSONObject obj = itemsJsonArray.getJSONObject(i);
                        String id = obj.getString("atid");
                        String airportName = obj.getString("airport_name");
                        String fixedFare = obj.getString("fixed_fare");


                        AirportAddress airportAddress = new AirportAddress();
                        airportAddress.setId(id);
                        airportAddress.setAirportName(airportName);
                        airportAddress.setFixedFare(fixedFare);

                        airportAddresses.add(airportAddress);
                    }

                    // Creating adapter for spinner
                    ArrayAdapter<AirportAddress> dataAdapter = new ArrayAdapter<>(TaxiToAirportActivity.this, R.layout.spinner_item, airportAddresses);

                    // attaching data adapter to spinner
                    destinationSpinner.setAdapter(dataAdapter);
                } else {
                    Toast.makeText(getApplicationContext(), "Something went wrong! Please try again!", Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class AirportAddress {
        private String id;
        private String airportName;
        private String fixedFare;

        public AirportAddress() {
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getAirportName() {
            return airportName;
        }

        public void setAirportName(String airportName) {
            this.airportName = airportName;
        }

        public String getFixedFare() {
            return fixedFare;
        }

        public void setFixedFare(String fixedFare) {
            this.fixedFare = fixedFare;
        }

        @Override
        public String toString() {
            return airportName;
        }
    }

    private class GetLatLngFromAddress extends AsyncTask<String, String, String> {
        private String address = null;
        private ProgressDialog mDlg;
        Exception ex;

        public GetLatLngFromAddress(String sourceAddress) {
            this.address = sourceAddress;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(TaxiToAirportActivity.this);
            mDlg.setMessage("Please wait...");
            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            String loc = null;

            try {
//                loc = mWebMapUtils.getLatLongFromAddress(address);
                String mapKey = getResources().getString(R.string.mapapikey);
                loc = mWebMapUtils.getLatLongFromAddress(address, mapKey);
            } catch (IOException | JSONException e) {
                e.printStackTrace();
                ex = e;
            }

            return loc;
        }

        @Override
        protected void onPostExecute(String location) {
            super.onPostExecute(location);
            mDlg.dismiss();

            if (location != null) {
                String loc1[] = location.split(",");
                LocationUtils.USER_CURRENT_LATITUDE = Double.parseDouble(loc1[0]);
                LocationUtils.USER_CURRENT_LONGITUDE = Double.parseDouble(loc1[1]);

                Log.e("", LocationUtils.CURRENT_SOURCE_ADDRESS + " " + LocationUtils.USER_CURRENT_LATITUDE + " "
                        + LocationUtils.USER_CURRENT_LONGITUDE);
            } else {
                Toast.makeText(TaxiToAirportActivity.this, "Something went wrong!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class BookTaxiToAirportTask extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(TaxiToAirportActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String cid = mPref.getPassengerId();
            String vtid = LocationUtils.CURRENT_VEHICLE_TYPE;
            String booking_type = "AirportTo";
            String fare_type = "FixedFare";
            String booking_from_lat = String.valueOf(LocationUtils.USER_CURRENT_LATITUDE);
            String booking_from_lng = String.valueOf(LocationUtils.USER_CURRENT_LONGITUDE);
            String booking_from = LocationUtils.CURRENT_SOURCE_ADDRESS;
            String noofpass = noOfPassengers;
            String atid = selectedAirport.getId();

            String response = null;
            try {
                response = mWebHandler.bookTaxiToAirport(cid, vtid, booking_type, fare_type, booking_from_lat,
                        booking_from_lng, booking_from, noofpass,
                        bookingTime, booking_date, notes, atid);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (progressDialog.isShowing())
                progressDialog.hide();
            try {
                JSONObject mParentObject = new JSONObject(s);
                if (mParentObject.getBoolean("status")) {
                    JSONObject items = mParentObject.getJSONObject("items");
                    Toast.makeText(getApplicationContext(), "Your Pre-Order Request is sent!", Toast.LENGTH_LONG).show();

                    TaxiToAirportActivity.this.finish();
                } else {
                    String msg = mParentObject.getString("items");
                    if (msg == null)
                        Toast.makeText(getApplicationContext(), "Something went wrong! Please try again!", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
