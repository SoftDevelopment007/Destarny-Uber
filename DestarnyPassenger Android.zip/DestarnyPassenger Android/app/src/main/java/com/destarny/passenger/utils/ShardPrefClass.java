package com.destarny.passenger.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Aniket on 2/23/2016.
 */
public class ShardPrefClass {
    private Context mContext;
    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;

    private static final String MY_PREFERENCES = "my_passenger_pref";
    private static final String PASSENGER_ID = "pid";
    private static final String IS_PASSNEEGER_LOGIN = "isPassengerLogin";
    private static final String PASSENGER_DETAILS = "passenger_details";
    private static final String TOKEN = "token";

    private static final String DEFAULT_PAYMENT_METHOD = "paymentMethod";
    private static final String DEFAULT_CARD_ID = "defaultCardId";
    private static final String DEFAULT_CARD_POSITION = "defaultCardPosition";

    private static final String VEHICLE_TYPE = "vehicleType";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";

    public ShardPrefClass(Context mContext) {
        this.mContext = mContext;
        mPreferences = mContext.getSharedPreferences(MY_PREFERENCES, Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();
    }


    /* save and get driver id */

    public String getPassengerId() {
        return mPreferences.getString(PASSENGER_ID, "0");
    }

    public void setPassengerId(String strPassengerId) {

        mEditor.putString(PASSENGER_ID, strPassengerId);
        mEditor.commit();
    }


    /* check driver is login or not */

    public boolean isPassengerLogin() {
        return mPreferences.getBoolean(IS_PASSNEEGER_LOGIN, false);
    }

    public void setPassengerLogin(boolean isPassengerLogin) {

        mEditor.putBoolean(IS_PASSNEEGER_LOGIN, isPassengerLogin);
        mEditor.commit();
    }


     /* save and get gcm token */

    public String getToken() {
        return mPreferences.getString(TOKEN, "");
    }

    public void setToken(String strToken) {

        mEditor.putString(TOKEN, strToken);
        mEditor.commit();
    }

    public String getPassengerDetails() {
        return mPreferences.getString(PASSENGER_DETAILS, "");
    }

    public void setPassengerDetails(String strPassDetails) {
        mEditor.putString(PASSENGER_DETAILS, strPassDetails);
        mEditor.commit();
    }

    public String getPaymentMethod() {
        return mPreferences.getString(DEFAULT_PAYMENT_METHOD, "Cash");
    }

    public void setPaymentMethod(String paymentMethod) {

        mEditor.putString(DEFAULT_PAYMENT_METHOD, paymentMethod);
        mEditor.commit();
    }

    public String getDefaultCardId() {
        return mPreferences.getString(DEFAULT_CARD_ID, "0");
    }

    public void setDefaultCardId(String defaultCardId) {

        mEditor.putString(DEFAULT_CARD_ID, defaultCardId);
        mEditor.commit();
    }

    public int getDefaultCardPosition() {
        return mPreferences.getInt(DEFAULT_CARD_POSITION, -1);
    }

    public void setDefaultCardPosition(int defaultCardPosition) {
        mEditor.putInt(DEFAULT_CARD_POSITION, defaultCardPosition);
        mEditor.commit();
    }

    public String getVehicleTypes() {
        return mPreferences.getString(VEHICLE_TYPE, null);
    }

    public void setVehicleTypes(String vehicleTypes) {
        mEditor.putString(VEHICLE_TYPE, vehicleTypes);
        mEditor.commit();
    }

    public String getUsername() {
        return mPreferences.getString(USERNAME, null);
    }

    public void setUsername(String username) {
        mEditor.putString(USERNAME, username);
        mEditor.commit();
    }

    public String getPassword() {
        return mPreferences.getString(PASSWORD, null);
    }

    public void setPassword(String password) {
        mEditor.putString(PASSWORD, password);
        mEditor.commit();
    }


}
