package com.destarny.passenger.web;

import android.util.Log;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.destarny.passenger.utils.LocationUtils;

/**
 * Created by sachi on 3/21/2016.
 */
public class WebMapUtils {

    Web mWeb;
    String strUrl = "";

    public WebMapUtils() {

        mWeb = new Web();
    }

    public String getAddressFromLatLng(String api_key, String strLatitude,
                                       String strLongitude) throws JSONException, IOException {

        String addressString = "";
        HttpURLConnection conn = null;
//        api_key = "AIzaSyDMSVwjY-Ml_OeJpzDKQEM-8fNZWJnHXY8";
        strUrl = "https://maps.googleapis.com/maps/api/geocode/json?"
                + "&latlng="
                + strLatitude
                + ","
                + strLongitude
                + "&radius=49000"
                + "&sensor=true&key=" + api_key;


        List<String> list = new ArrayList<String>();
//        StringBuilder jsonResults = new StringBuilder();

        Web mWeb = new Web();
        String jsonResults = mWeb.mWebMethod(strUrl);

        try {
            JSONObject successJsonObject = new JSONObject(jsonResults);
            if (successJsonObject.has("status")) {
                String status = successJsonObject.getString("status");
                if (status.equalsIgnoreCase("OK")) {
                    if (successJsonObject.has("results")) {
                        JSONArray resultsJsonArray = successJsonObject.getJSONArray("results");
                        int size = resultsJsonArray.length();
                        if (size > 0) {
                            JSONObject resultJsonObject = resultsJsonArray.getJSONObject(0);
                            if (resultJsonObject.has("formatted_address")) {
                                addressString = resultJsonObject.getString("formatted_address");

//                                if (currentAddress == null || currentAddress.equals(null) || currentAddress.equals("null")) {
//                                    mAddressEditText.setHint("Can't get address");
//                                    manuallyEnteredAddress = true;
//                                } else {
//                                    manuallyEnteredAddress = false;
//                                    mAddressEditText.setText(currentAddress);
//                                }
                            }

                        }
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return addressString;
    }

    public List<String> getAddressSuggestions(String api_key, String strText, String strLatitude, String strLongitude) throws JSONException, IOException {

        HttpURLConnection conn = null;
        strText = strText.replace(" ", "+");

        strUrl = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input="
                + strText
                + "&location="
                + strLatitude
                + ","
                + strLongitude
                + "&radius=49000"
                + "&sensor=true&key=" + api_key;


        List<String> list = new ArrayList<String>();
//        StringBuilder jsonResults = new StringBuilder();

        Web mWeb = new Web();
        String jsonResults = mWeb.mWebMethod(strUrl);

        URL urlNew = new URL(strUrl);

//        conn = (HttpURLConnection) urlNew.openConnection();
//
//        InputStreamReader in = new InputStreamReader(conn.getInputStream());
//
//        // Load the results into a StringBuilder
//
//        int read;
//
//        char[] buff = new char[1024];
//
//        while ((read = in.read(buff)) != -1) {
//
//            jsonResults.append(buff, 0, read);
//
//        }

        // String res = HttpService.httpPostService(url);
        JSONObject json = new JSONObject(jsonResults.toString());
        Log.e("Response", jsonResults.toString());
        if (json != null && json.has("predictions")) {

            JSONArray contacts = json.getJSONArray("predictions");

            for (int i = 0; i < contacts.length(); i++) {
                JSONObject c = contacts.getJSONObject(i);
                if (c.has("description")) {
                    String description = c.getString("description");
                    list.add(description);
                }
            }
        }
        return list;
    }

    public String getLatLongFromAddress(String address)
            throws IOException,
            JSONException {

        String uri = "http://maps.google.com/maps/api/geocode/json?address="
                + address.replace(" ", "+") + "&sensor=false";

        String res = mWeb.mWebMethod(uri);
        String location = "";

        JSONObject jsonObject = new JSONObject(res);
        if (jsonObject != null && jsonObject.has("results") && jsonObject.has("status")) {
            String status = jsonObject.getString("status");
            if (status.equals("OK")) {
                JSONArray jarray = jsonObject.getJSONArray("results");
                if (jarray != null && jarray.length() > 0) {
                    JSONObject json = jarray.getJSONObject(0);
                    if (json != null && json.has("geometry")) {
                        JSONObject loca = json.getJSONObject("geometry");
                        if (loca != null && loca.has("location")) {
                            JSONObject loc = loca.getJSONObject("location");
                            if (loc.has("lat")) {
                                location += loc.getDouble("lat");
                            }
                            location += ",";
                            if (loc.has("lng")) {
                                location += loc.getDouble("lng");
                            }
                        }
                    }

                }
            } else {
                location = "";
            }
        }

        return location;
    }

    public String getLatLongFromAddress(String address, String mapKey)
            throws IOException,
            JSONException {

//        String uri = "http://maps.google.com/maps/api/geocode/json?address="
//                + address.replace(" ", "+") + "&sensor=false";
//        mapKey = "AIzaSyDu9qemBClJUtGHq_E0Ye1HE-jIMtcwh1o";

        String uri = "https://maps.googleapis.com/maps/api/place/textsearch/json?query="
                + address.replace(" ", "+") + "&key=" + mapKey;

        String res = mWeb.mWebMethod(uri);
        String location = "";

        JSONObject jsonObject = new JSONObject(res);
        if (jsonObject != null && jsonObject.has("results") && jsonObject.has("status")) {
            String status = jsonObject.getString("status");
            if (status.equals("OK")) {
                JSONArray jarray = jsonObject.getJSONArray("results");
                if (jarray != null && jarray.length() > 0) {
                    JSONObject json = jarray.getJSONObject(0);
                    if (json != null && json.has("geometry")) {
                        JSONObject loca = json.getJSONObject("geometry");
                        if (loca != null && loca.has("location")) {
                            JSONObject loc = loca.getJSONObject("location");
                            if (loc.has("lat")) {
                                location += loc.getDouble("lat");
                            }
                            location += ",";
                            if (loc.has("lng")) {
                                location += loc.getDouble("lng");
                            }
                        }
                    }

                }
            } else {
                location = "";
            }
        }

        return location;
    }

    public HashMap<String, String> getTimeDistanceBetweenMapPoints(
            String source_lat, String source_long, String dest_lat,
            String dest_long, String units, boolean isETA) throws
            IOException,
            JSONException {
        HashMap<String, String> response = new HashMap<String, String>();

        String url = "https://maps.googleapis.com/maps/api/directions/"
                + "json" + "?" + "&origin=" + source_lat + "," + source_long
                + "&destination=" + dest_lat + "," + dest_long + "&"
                + "sensor=false&" + "units=" + units;
        Log.e("Url Request", url);
        //
        // String
        // url="http://maps.googleapis.com/maps/api/directions/json?origin=28.675861870844997,77.32144810259342&destination=28.6805906,77.3747908&sensor=true&mode=driving";
        String res = "";
        res = mWeb.mWebMethod(url);
        response.put("response", res);
        JSONObject jsonobj = new JSONObject(res);
        if (jsonobj != null && jsonobj.has("routes")) {
            JSONArray jsonarray = jsonobj.getJSONArray("routes");

            if (jsonarray != null && jsonarray.length() > 0) {
                JSONObject jsonobj2 = jsonarray.getJSONObject(0);
                if (jsonobj2 != null && jsonobj2.has("legs")) {
                    JSONArray jsonArray2 = jsonobj2.getJSONArray("legs");
                    if (jsonArray2 != null && jsonArray2.length() > 0) {

                        JSONObject jsonobj3 = jsonArray2.getJSONObject(0);
                        if (jsonobj3 != null && jsonobj3.has("distance")) {
                            JSONObject jsonobj4 = jsonobj3
                                    .getJSONObject("distance");
                            if (jsonobj4 != null && jsonobj4.has("text")) {
                                String dist = jsonobj4.getString("text");
                                response.put("distance", dist);

                                String distInMtr = jsonobj4.getString("value");
                                response.put("distance_meters", distInMtr);

                                if (!isETA) {
                                    LocationUtils.SOURCE_DESTINATION_DISTANCE = dist;
                                    LocationUtils.SOURCE_DESTINATION_DISTANCE_METERS = distInMtr;
                                }
                            }
                        }
                        if (jsonobj3 != null && jsonobj3.has("duration")) {
                            JSONObject jsonobj4 = jsonobj3
                                    .getJSONObject("duration");
                            if (jsonobj4 != null && jsonobj4.has("text")) {
                                String dur = jsonobj4.getString("text");
                                response.put("duration", dur);

                                String durSec = jsonobj4.getString("value");
                                response.put("duration_seconds", durSec);

                                if (!isETA) {
                                    LocationUtils.SOURCE_DESTINATION_TIME = dur;
                                    LocationUtils.SOURCE_DESTINATION_TIME_SECONDS = durSec;
                                }
                            }
                        }

                    }

                }

            }

        }

        return response;
    }


    public List<List<HashMap<String, String>>> getRoutesBetweenMapPoints(
            String res) throws JSONException {
        List<List<HashMap<String, String>>> routes = new ArrayList<List<HashMap<String, String>>>();

        JSONArray jLegs;
        JSONObject jsonobj = new JSONObject(res);
        if (jsonobj != null && jsonobj.has("routes")) {
            JSONArray jsonarray = jsonobj.getJSONArray("routes");

            if (jsonarray != null && jsonarray.length() > 0) {

                for (int i = 0; i < jsonarray.length(); i++) {
                    jLegs = ((JSONObject) jsonarray.get(i))
                            .getJSONArray("legs");
                    List<HashMap<String, String>> path = new ArrayList<HashMap<String, String>>();

                    /** Traversing all legs */
                    for (int j = 0; j < jLegs.length(); j++) {
                        JSONArray jSteps = ((JSONObject) jLegs.get(j))
                                .getJSONArray("steps");

                        /** Traversing all steps */
                        for (int k = 0; k < jSteps.length(); k++) {
                            String polyline = "";
                            polyline = (String) ((JSONObject) ((JSONObject) jSteps
                                    .get(k)).get("polyline")).get("points");
                            List<LatLng> list = decodePoly(polyline);

                            /** Traversing all points */
                            for (int l = 0; l < list.size(); l++) {
                                HashMap<String, String> hm = new HashMap<String, String>();
                                hm.put("lat", Double.toString(((LatLng) list
                                        .get(l)).latitude));
                                hm.put("lng", Double.toString(((LatLng) list
                                        .get(l)).longitude));
                                path.add(hm);
                            }
                        }
                        routes.add(path);
                    }

                }
            }
        }
        return routes;
    }

    private List<LatLng> decodePoly(String encoded) {

        List<LatLng> poly = new ArrayList<LatLng>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng((((double) lat / 1E5)),
                    (((double) lng / 1E5)));
            poly.add(p);
        }
        return poly;
    }

}
