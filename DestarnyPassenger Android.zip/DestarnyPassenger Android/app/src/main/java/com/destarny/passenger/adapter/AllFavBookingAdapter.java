package com.destarny.passenger.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import com.destarny.passenger.R;
import com.destarny.passenger.model.AllPastBookingModel;

/**
 * Created by sachi on 5/11/2016.
 */
public class AllFavBookingAdapter extends BaseAdapter {
    private ArrayList<AllPastBookingModel> mArrayList = new ArrayList<AllPastBookingModel>();
    private Context mContext;


    public AllFavBookingAdapter(ArrayList<AllPastBookingModel> mArrayList, Context mContext) {
        this.mArrayList = mArrayList;
        this.mContext = mContext;

    }

    private LayoutInflater mInflator;

    @Override
    public int getCount() {
        return mArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return mArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return mArrayList.indexOf(mArrayList.get(position));
    }

    @Override
    public View getView(final int position, View v, ViewGroup parent) {

        ViewHolder mHolder;


        if (mInflator == null) {
            mInflator = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (v == null) {
            v = mInflator.inflate(R.layout.layout_past_booking_item, null);

            mHolder = new ViewHolder();

            mHolder.bookingFromTextView = (TextView) v.findViewById(R.id.tv_booking_from);
            mHolder.bookingToTextView = (TextView) v.findViewById(R.id.tv_booking_to);
            mHolder.distanceTextView = (TextView) v.findViewById(R.id.tv_booking_distance);
            mHolder.durationTextView = (TextView) v.findViewById(R.id.tv_booking_duration);
            mHolder.costTextView = (TextView) v.findViewById(R.id.tv_booking_cost);
            mHolder.imageView = (ImageView) v.findViewById(R.id.ImgFav);


            v.setTag(mHolder);
        } else {
            mHolder = (ViewHolder) v.getTag();
        }
        mHolder.imageView.setVisibility(View.VISIBLE);
        mHolder.bookingFromTextView.setText(mArrayList.get(position).getBooking_from());
        mHolder.bookingToTextView.setText(mArrayList.get(position).getBooking_to());
        mHolder.distanceTextView.setText(mArrayList.get(position).getTotalDistance() + " Km");
        mHolder.durationTextView.setText(mArrayList.get(position).getTotalDuration() + " Hours");
        mHolder.costTextView.setText("$" + mArrayList.get(position).getTotalCost());

        return v;
    }

    private class ViewHolder {
        TextView bookingFromTextView;
        TextView bookingToTextView;
        TextView distanceTextView;
        TextView durationTextView;
        TextView costTextView;
        ImageView imageView;
    }
}