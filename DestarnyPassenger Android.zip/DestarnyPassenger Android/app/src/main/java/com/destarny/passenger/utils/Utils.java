package com.destarny.passenger.utils;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by ApkDev3 on 12/17/2015.
 */
public class Utils {

    private static ProgressDialog mDlg;
    public static final String EMAIL_PATTERN = "[a-zA-Z0-9._-]+@[a-z-]+\\.+[a-z]+";
    public static void mCustomProgressDialog(Context mContext) {

        if (mDlg != null && mDlg.isShowing())
            return;
        mDlg = new ProgressDialog(mContext);
        mDlg.setMessage("Please wait...");
        mDlg.show();
    }

    public static void mDismissCustomDialog() {
        if (mDlg == null)
            return;
        mDlg.dismiss();
    }

    private Context mContext;

    public Utils(Context mContext) {
        this.mContext = mContext;
    }

    public boolean isInterentConnection() {

        ConnectivityManager manager = (ConnectivityManager) mContext
                .getSystemService(Context.CONNECTIVITY_SERVICE);

        if (manager != null) {

            NetworkInfo info[] = manager.getAllNetworkInfo();
            if (info != null) {

                for (int i = 0; i < info.length; i++) {
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
                }
            }

        }

        return false;
    }


    private static Pattern pattern;
    private static Matcher matcher;
    //Email Pattern
    private static final String NEW_EMAIL_PATTERN =
            "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                    + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

    /**
     * Validate Email with regular expression
     *
     * @param email
     * @return true for Valid Email and false for Invalid Email
     */
    public static boolean validateEmail(String email) {
        pattern = Pattern.compile(NEW_EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();

    }

    /**
     * Checks for Null String object
     *
     * @param txt
     * @return true for not null and false for null String object
     */
    public static boolean isNotNull(String txt) {
        return txt != null && txt.trim().length() > 0 ? true : false;
    }


    public static boolean isNetworkAvailable(Context context) {

        ConnectivityManager cm = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        if (ni == null) {
            // There are no active networks.
            return false;
        } else
            return true;

    }

}
