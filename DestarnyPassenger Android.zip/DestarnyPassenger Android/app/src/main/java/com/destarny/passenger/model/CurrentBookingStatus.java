package com.destarny.passenger.model;

/**
 * Created by hr on 5/14/2016.
 */
public class CurrentBookingStatus {
    private String bid;
    private String source;
    private String destination;
    private String bookingTime;
    private String vehicleType;
    private String noOfPass;
    private String setFare;
    //        private String bookingString;
    private String driverName;
    private String driverContact;
    private String model;
    private String vehicleNo;
    private String vehicleRego;
    private String made;

    private String distanceFromDriver;
    private String durationFromDriver;
    private String durationFromDriverInTraffic;

    public CurrentBookingStatus() {
    }

    public String getBid() {
        return bid;
    }

    public void setBid(String bid) {
        this.bid = bid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getBookingTime() {
        return bookingTime;
    }

    public void setBookingTime(String bookingTime) {
        this.bookingTime = bookingTime;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getNoOfPass() {
        return noOfPass;
    }

    public void setNoOfPass(String noOfPass) {
        this.noOfPass = noOfPass;
    }

    public String getSetFare() {
        return setFare;
    }

    public void setSetFare(String setFare) {
        this.setFare = setFare;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getDriverContact() {
        return driverContact;
    }

    public void setDriverContact(String driverContact) {
        this.driverContact = driverContact;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getVehicleRego() {
        return vehicleRego;
    }

    public void setVehicleRego(String vehicleRego) {
        this.vehicleRego = vehicleRego;
    }

    public String getMade() {
        return made;
    }

    public void setMade(String made) {
        this.made = made;
    }

    public String getDistanceFromDriver() {
        return distanceFromDriver;
    }

    public void setDistanceFromDriver(String distanceFromDriver) {
        this.distanceFromDriver = distanceFromDriver;
    }

    public String getDurationFromDriver() {
        return durationFromDriver;
    }

    public void setDurationFromDriver(String durationFromDriver) {
        this.durationFromDriver = durationFromDriver;
    }

    public String getDurationFromDriverInTraffic() {
        return durationFromDriverInTraffic;
    }

    public void setDurationFromDriverInTraffic(String durationFromDriverInTraffic) {
        this.durationFromDriverInTraffic = durationFromDriverInTraffic;
    }

    @Override
    public String toString() {
        return "CurrentBookingStatus{" +
                "bid='" + bid + '\'' +
                ", source='" + source + '\'' +
                ", destination='" + destination + '\'' +
                ", bookingTime='" + bookingTime + '\'' +
                ", vehicleType='" + vehicleType + '\'' +
                ", noOfPass='" + noOfPass + '\'' +
                ", setFare='" + setFare + '\'' +
                ", driverName='" + driverName + '\'' +
                ", driverContact='" + driverContact + '\'' +
                ", model='" + model + '\'' +
                ", vehicleNo='" + vehicleNo + '\'' +
                ", made='" + made + '\'' +
                '}';
    }
}