package com.destarny.passenger.model;

/**
 * Created by hr on 5/12/2016.
 */
public class CreditCardClass {
    private String id;
    private String cid;
    private String cnolastdigits;
    private String cardNo;
    private String month;
    private String year;
    private String cvv;
    private boolean isChecked;

    public boolean isChecked() {
        return isChecked;
    }

    public void setIsChecked(boolean isChecked) {
        this.isChecked = isChecked;
    }

    public CreditCardClass() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getCnolastdigits() {
        return cnolastdigits;
    }

    public void setCnolastdigits(String cnolastdigits) {
        this.cnolastdigits = cnolastdigits;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    @Override
    public String toString() {
        return "creditCard{" +
                "id='" + id + '\'' +
                ", cid='" + cid + '\'' +
                ", cnolastdigits='" + cnolastdigits + '\'' +
                ", cardNo='" + cardNo + '\'' +
                ", month='" + month + '\'' +
                ", year='" + year + '\'' +
                ", cvv='" + cvv + '\'' +
                '}';
    }

}
