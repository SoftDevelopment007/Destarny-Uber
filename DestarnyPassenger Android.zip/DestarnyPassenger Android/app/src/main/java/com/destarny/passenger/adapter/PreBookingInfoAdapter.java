package com.destarny.passenger.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import com.destarny.passenger.R;
import com.destarny.passenger.model.PreBookingInfo;

/**
 * Created by hr on 5/10/2016.
 */
public class PreBookingInfoAdapter extends ArrayAdapter<PreBookingInfo> {
    private ArrayList<PreBookingInfo> objects;
    int layoutResourceId;

    public PreBookingInfoAdapter(Context context, int layoutResourceId, ArrayList<PreBookingInfo> objects) {
        super(context, layoutResourceId, objects);
        this.layoutResourceId = layoutResourceId;
        this.objects = objects;

    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View rootView = convertView;
        PreBookingInfoViewHolder preBookingInfoViewHolder = null;


        // first check to see if the view is null. if so, we have to inflate it.
        // to inflate it basically means to render, or show, the view.
        if (rootView == null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rootView = inflater.inflate(layoutResourceId, null);

            preBookingInfoViewHolder = new PreBookingInfoViewHolder();
            preBookingInfoViewHolder.serialTextView = (TextView) rootView.findViewById(R.id.tv_serial_number);
            preBookingInfoViewHolder.sourceTextView = (TextView) rootView.findViewById(R.id.tv_source);
            preBookingInfoViewHolder.destTextView = (TextView) rootView.findViewById(R.id.tv_destination);
            preBookingInfoViewHolder.typeOfVehicleTextView = (TextView) rootView.findViewById(R.id.tv_type_of_vehicle);
            preBookingInfoViewHolder.noOfPassengersTextView = (TextView) rootView.findViewById(R.id.tv_no_of_passengers);
            preBookingInfoViewHolder.setFareTextView = (TextView) rootView.findViewById(R.id.tv_set_fare);
            preBookingInfoViewHolder.dateTextView = (TextView) rootView.findViewById(R.id.tv_date);
            preBookingInfoViewHolder.timeTextView = (TextView) rootView.findViewById(R.id.tv_time);

            rootView.setTag(preBookingInfoViewHolder);
        } else {
            preBookingInfoViewHolder = (PreBookingInfoViewHolder) rootView.getTag();
        }

        PreBookingInfo preBookingInfo = objects.get(position);
        preBookingInfoViewHolder.serialTextView.setText((position + 1) + ") ");
        preBookingInfoViewHolder.sourceTextView.setText(preBookingInfo.getBookingFrom());
        preBookingInfoViewHolder.destTextView.setText(preBookingInfo.getBookingTo());
        switch (preBookingInfo.getVtid()) {
            case "1":
                preBookingInfoViewHolder.typeOfVehicleTextView.setText("Premium");
                break;
            case "2":
                preBookingInfoViewHolder.typeOfVehicleTextView.setText("Standard");
                break;
            case "3":
                preBookingInfoViewHolder.typeOfVehicleTextView.setText("SUV");
                break;
        }
        preBookingInfoViewHolder.noOfPassengersTextView.setText(preBookingInfo.getNoofpass());
        preBookingInfoViewHolder.setFareTextView.setText(preBookingInfo.getFareType());
        preBookingInfoViewHolder.dateTextView.setText(preBookingInfo.getBookingDate());
        preBookingInfoViewHolder.timeTextView.setText(preBookingInfo.getBookingTime());

		/*
         * Recall that the variable position is sent in as an argument to this method.
		 * The variable simply refers to the position of the current object in the list. (The ArrayAdapter
		 * iterates through the list we sent it)
		 *
		 * Therefore, i refers to the current PreBookingInfo object.
		 */
//        PreBookingInfo i = objects.get(position);
//
//        if (i != null) {
//            TextView sourceTextView = (TextView) rootView.findViewById(R.id.tv_source);
//            TextView destTextView = (TextView) rootView.findViewById(R.id.tv_destination);
//            TextView typeOfVehicleTextView = (TextView) rootView.findViewById(R.id.tv_type_of_vehicle);
//            TextView noOfPassengersTextView = (TextView) rootView.findViewById(R.id.tv_no_of_passengers);
//            TextView setFareTextView = (TextView) rootView.findViewById(R.id.tv_set_fare);
//            TextView dateTextView = (TextView) rootView.findViewById(R.id.tv_date);
//            TextView timeTextView = (TextView) rootView.findViewById(R.id.tv_time);
//
//            sourceTextView.setText("From: " + i.getBookingFrom());
//            destTextView.setText("To: " + i.getBookingTo());
//            typeOfVehicleTextView.setText("Type of Vehicle: " + i.getvType());
//            noOfPassengersTextView.setText("No. of Passengers: " + i.getNoofpass());
//            setFareTextView.setText("Fare Type: " + i.getFareType());
//            dateTextView.setText("Booking Time: " + i.getBookingDate());
//            timeTextView.setText(i.getBookingTime());
//        }

        // the view must be returned to our activity
        return rootView;
    }

    static class PreBookingInfoViewHolder {
        TextView serialTextView;
        TextView sourceTextView;
        TextView destTextView;
        TextView typeOfVehicleTextView;
        TextView noOfPassengersTextView;
        TextView setFareTextView;
        TextView dateTextView;
        TextView timeTextView;
    }
}
