package com.destarny.passenger.map;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.destarny.passenger.R;
import com.destarny.passenger.activity.BillingInfoActivity;
import com.destarny.passenger.adapter.CustomInfoWindowAdapter;
import com.destarny.passenger.model.NearestTaxi;
import com.destarny.passenger.utils.Constant;
import com.destarny.passenger.utils.LocationUtils;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.Web;
import com.destarny.passenger.web.WebHandler;
import com.destarny.passenger.web.WebMapUtils;

public class NewMapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleMap.OnMarkerClickListener, View.OnClickListener,
        GoogleMap.OnInfoWindowClickListener {

    private Dialog dialog;
    private GoogleMap mMap;
    private Polyline polylineFinal = null;
    Marker destMarker = null;
    private ProgressBar mLoadingBar;
    private ImageView imgToolBarLeft;
    private ListView mLstLocationList;
    private TextView mTxtSourceLocation;
    private AutoCompleteTextView mAutoPlace;
    private TextView mTxtDestinationLocation;


    private List<String> mAddressList;
    private ArrayAdapter<String> mSourceAddressListAdapter;
    private ArrayList<NearestTaxi> mNearestTaxiList = new ArrayList<>();

    private AsyncTask<String, List<String>, List<String>> mAddressSuggestionAsyncTask;

    private Utils mUtils;
    private WebMapUtils mWebMapUtils;
    private Button etaButton;

    private WebHandler mWebHandler = null;
    private ShardPrefClass mPref = null;
    private Button bookNearestTaxi;
    private HashMap<String, String> driverId = new HashMap<>();
    public static HashMap<String, String> vehicleTypeId = new HashMap<>();
    private HashMap<String, NearestTaxi> destarnyRateDetails = new HashMap<>();
    private boolean isRecieverRegistered = false, isNetDialogShowing = false, isGpsDialogShowing = false;
    private android.support.v7.app.AlertDialog internetDialog, gpsAlertDialog, locationAlertDialog;
    private CustomInfoWindowAdapter infoWindowAdapter = null;
    private String fareType = null;
    private String fareString = "0";
//    private Marker selectedTaxiMarker = null;

    private RadioGroup paymentTypeGroup = null;
    private RadioButton cashRadioButton, cardRadioButton;
    private String payMethod = null;
    private String payId = "0";
    private boolean isDestinationSelected = false;

    DecimalFormat df = new DecimalFormat("#.##");
    //    DecimalFormat twoDecimalf = new DecimalFormat("#.##");
    DecimalFormat decimalFormat = new DecimalFormat("#.######");
    private NearestTaxi selectedTaxi = null;
    private NearestTaxi premiumForAll = null;
    private boolean isPremumAvailable = false;
    private boolean isTaxiAvailable = false;
    private boolean isPrivateAvailable = false;

    private Web mWeb = null;
    private ShardPrefClass mShardPrefClass = null;
    private VehicleTypeDetails premiumVehicle;
    private VehicleTypeDetails privateVehicle;
    private VehicleTypeDetails taxiVehicle;

    private String destarnyEstimation = "";
    private String taxiEstimation = "";
    private String premiumEstimation = "";

    private String specificTaxiFareType = "";
    private String approxCalfare = "";
    private ProgressBar mProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_maps);
        setUpToolBar();
        init();

        mWebMapUtils = new WebMapUtils();
        mUtils = new Utils(NewMapsActivity.this);
        mWebHandler = new WebHandler();
        mPref = new ShardPrefClass(getApplicationContext());
        mWeb = new Web();
        mShardPrefClass = new ShardPrefClass(NewMapsActivity.this);

        setPaymentMethod();
        String items = mShardPrefClass.getVehicleTypes();
        if (items != null) {
            try {
                JSONArray vehicleType = new JSONArray(items);
                getVehicleType(vehicleType);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
//        GetVehicleType getVehicleType = new GetVehicleType();
//        getVehicleType.execute();

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    private void setPaymentMethod() {
        String paymentMethod = mPref.getPaymentMethod();

        if (paymentMethod.equals("Cash")) {
            payMethod = paymentMethod;
            cashRadioButton.setChecked(true);
//                cardRadioButton.setChecked(false);
            cashRadioButton.setTextColor(Color.parseColor("#FFCB07"));
            cardRadioButton.setTextColor(Color.BLACK);
        } else if (paymentMethod.equals("CreditCard")) {
            if (mPref.getDefaultCardPosition() != -1) {
                payMethod = paymentMethod;
//            cashRadioButton.setChecked(false);
                cardRadioButton.setChecked(true);
                cashRadioButton.setTextColor(Color.BLACK);
                cardRadioButton.setTextColor(Color.parseColor("#FFCB07"));
            } else {
                cashRadioButton.setChecked(true);
            }
        }

        paymentTypeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio_cash) {
                    cashRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    cardRadioButton.setTextColor(Color.BLACK);

                    // TODO: Call API to set method
                } else if (checkedId == R.id.radio_credit_card) {
                    cashRadioButton.setTextColor(Color.BLACK);
                    cardRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                }
            }
        });

        cashRadioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                payMethod = "Cash";
                mPref.setPaymentMethod(payMethod);
                payId = "0";
                new SetPaymentMethodTask().execute();
            }
        });

        cardRadioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mPref.getDefaultCardPosition() != -1) {
                    payMethod = "CreditCard";
                    mPref.setPaymentMethod(payMethod);
                    payId = mPref.getDefaultCardId();
                    new SetPaymentMethodTask().execute();
                } else {
//                    startActivity(new Intent(NewMapsActivity.this, BillingInfoActivity.class), 1);
//                    Intent i = new Intent(this, SecondActivity.class);
//                    startActivityForResult(i, 1);

                    startActivityForResult(new Intent(NewMapsActivity.this, BillingInfoActivity.class), 1);
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                payMethod = "CreditCard";
                mPref.setPaymentMethod(payMethod);
                payId = data.getStringExtra("cardId");

                new SetPaymentMethodTask().execute();
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                //code if there's no result
                Toast.makeText(NewMapsActivity.this,
                        "No Card selected, setting Payment Method to Cash!", Toast.LENGTH_LONG).show();
                cashRadioButton.setChecked(true);
//                payMethod = "Cash";
//                mPref.setPaymentMethod(payMethod);
//                payId = "0";
//                new SetPaymentMethodTask().execute();
            }
        }
    }

    private void init() {
        mTxtSourceLocation = (TextView) findViewById(R.id.txtSourceLocation);
        mTxtSourceLocation.setVisibility(View.VISIBLE);
        mTxtDestinationLocation = (TextView) findViewById(R.id.txtDestinationLocation);

        paymentTypeGroup = (RadioGroup) findViewById(R.id.rg_payment_type);
        cashRadioButton = (RadioButton) findViewById(R.id.radio_cash);
        cardRadioButton = (RadioButton) findViewById(R.id.radio_credit_card);

        initButtons();
    }

    private void setUpToolBar() {
        imgToolBarLeft = (ImageView) findViewById(R.id.toolbar_left);
        imgToolBarLeft.setImageResource(R.drawable.ic_action_back);
        imgToolBarLeft.setVisibility(View.VISIBLE);
        imgToolBarLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng loc = new LatLng(LocationUtils.USER_CURRENT_LATITUDE, LocationUtils.USER_CURRENT_LONGITUDE);
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(loc).zoom(15.5f).build();
        //map.setMyLocationEnabled(true);
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
        mTxtSourceLocation.setText(LocationUtils.CURRENT_SOURCE_ADDRESS);

        sourceMarker(loc);
        nearestTaxiLocation();

        mMap.setOnMarkerClickListener(this);
        mMap.setOnInfoWindowClickListener(this);
        infoWindowAdapter = new CustomInfoWindowAdapter(NewMapsActivity.this);
        mMap.setInfoWindowAdapter(infoWindowAdapter);
    }

    private void nearestTaxiLocation() {
        JSONArray mArray;
        JSONObject mParentObject, mChildObject;
        String s = LocationUtils.NEAREST_CAR_LOCATION;

        double minDistance = 0;
        try {

            mParentObject = new JSONObject(s);
            if (mParentObject.getBoolean("status")) {
                mArray = mParentObject.getJSONArray("items");

                double dist = 0.0;
                if (mArray.length() > 0) {
                    for (int i = 0; i < mArray.length(); i++) {

                        NearestTaxi mTaxiObj;
                        mChildObject = mArray.getJSONObject(i);

                        String fname = mChildObject.getString("fname");
                        String lname = mChildObject.getString("lname");
                        String model = mChildObject.getString("modelno");

                        String make = mChildObject.getString("made");
                        if (make != null)
                            make = "\n" + make;
                        String phone_no = mChildObject.getString("phone_no");
                        String noofseats = mChildObject.getString("noofseats");

                        String hiddenPhoneNo = null;
                        char[] chars = phone_no.toCharArray();
                        int length = phone_no.length();
                        for (int j = 4; j < length; j++) {
                            chars[j] = 'X';
                        }
                        hiddenPhoneNo = new String(chars);
                        String numberPlate = mChildObject.getString("driver_noplate");

                        String rating = mChildObject.getString("rating");

//                        String driverDetails =
//                                "Name: " + fname + " " + lname +
//                                "Model: " + model
//                                        + "\nMake: " + make
//                                        + "\nContact No.: " + hiddenPhoneNo;
//                                        + "\nNumber Plate: " + numberPlate;


                        String driverDetails =
                                fname + " " + lname
                                        + "\n" + model
                                        + make
                                        + "\n" + rating + ", No. of Seats: " + noofseats;

                        String lng = mChildObject.getString("lng");
                        String distance = mChildObject.getString("distance");
                        dist = Double.parseDouble(distance);
                        String did = mChildObject.getString("id");
                        String lat = mChildObject.getString("lat");
                        String vtid = mChildObject.getString("vtype");

                        String title = vtid + " (" + numberPlate + ")";

                        double pricePerKm = mChildObject.getDouble("price_per_km");
                        double pricePerMin = mChildObject.getDouble("price_per_min");
                        double minPrice = mChildObject.getDouble("min_price");
                        double distFromPickupLoc = mChildObject.getDouble("distance");

//                        mTaxiObj = new NearestTaxi(fname, phone_no, lname, lng, distance, did, lat,
//                                vtid, numberPlate);
//                        mTaxiObj = new NearestTaxi(fname, phone_no, lname, lng, distance, did, lat,
//                                vtid, numberPlate, pricePerKm, pricePerMin, minPrice, distFromPickupLoc);
                        mTaxiObj = new NearestTaxi(fname, phone_no, lname, lng, distance, did, lat,
                                vtid, numberPlate, pricePerKm, pricePerMin, minPrice, distFromPickupLoc, rating);
                        mNearestTaxiList.add(mTaxiObj);
                        double latitude = Double.parseDouble(lat);
                        double longitude = Double.parseDouble(lng);
                        LatLng TAXI_LOCATION = new LatLng(latitude, longitude);


                        int availableTaxiDrawable = R.drawable.ic_available_taxi;
                        if (vtid.equals("Premium")) {
                            availableTaxiDrawable = R.drawable.ic_available_premium;
                        } else if (vtid.equals("Private")) {
                            availableTaxiDrawable = R.drawable.ic_available_private;
                        }

                        Marker marker = mMap
                                .addMarker(new MarkerOptions()
                                        .position(TAXI_LOCATION)
                                        .icon(BitmapDescriptorFactory
//                                                .fromResource(R.drawable.ic_taxi))
//                                                .fromResource(R.drawable.ic_taxi_medium))
                                                .fromResource(availableTaxiDrawable))
                                        .snippet(driverDetails)
//                                        .title("Driver Details")
//                                        .title(fname + " " + lname));
                                        .title(title));
                        // Put Driver Id againsts Marker Id in Hashmap for Marker Click Taxi Booking
                        driverId.put(marker.getId(), did);
                        vehicleTypeId.put(marker.getId(), vtid);
                        destarnyRateDetails.put(marker.getId(), mTaxiObj);
                        // We will use Max Value for Destarny Rate Calculations for Vehicle Type 'All'
                        // on Book Nearest Vehicle
                        if (vtid.equals("Premium")) {
                            isPremumAvailable = true;
                            premiumForAll = mTaxiObj;
                        } else if (vtid.equals("Taxi")) {
                            isTaxiAvailable = true;
                        } else if (vtid.equals("Private")) {
                            isPrivateAvailable = true;
                        }


                        if (minDistance == 0) {
                            minDistance = dist;
                            LocationUtils.NEAREST_CAR_LATITUDE = lat;
                            LocationUtils.NEAREST_CAR_LONGITUDE = lng;
                        } else if (minDistance > dist) {
                            minDistance = dist;
                            LocationUtils.NEAREST_CAR_LATITUDE = lat;
                            LocationUtils.NEAREST_CAR_LONGITUDE = lng;
                        }
                    }


                }

            } else {
                //Toast.makeText(HomeActivity.this, "No nearby vehicle available !", Toast.LENGTH_SHORT).show();

            }

        } catch (JSONException e1) {
            e1.printStackTrace();
        }
    }

    private void selectDestinationAddress() {
        dialog = new Dialog(NewMapsActivity.this,
                android.R.style.Theme_Black_NoTitleBar);
        dialog.setContentView(R.layout.layout_select_source_address);
        mAutoPlace = (AutoCompleteTextView) dialog
                .findViewById(R.id.select_place);
        mLoadingBar = (ProgressBar) dialog
                .findViewById(R.id.progressBarLoading);
        mLstLocationList = (ListView) dialog.findViewById(R.id.lst_locations);
        dialog.show();

        mAutoPlace.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                if (mAddressSuggestionAsyncTask != null) {
                    mAddressSuggestionAsyncTask.cancel(true);
                }
                if (s.length() >= 1) {
                    new mAddressSuggestionAsyncTask()
                            .execute(s.toString());
                } else {

                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                // getSuggestonAsyncTask.execute(s.toString());

            }
        });


    }

    private class mAddressSuggestionAsyncTask extends AsyncTask<String, List<String>, List<String>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mLoadingBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected List<String> doInBackground(String... params) {
            mAddressList = new ArrayList<>();
            String apiKey = getResources().getString(R.string.mapapikey);

            try {
                mAddressList = mWebMapUtils.getAddressSuggestions(
//                        Constant.PLACES_AUTOCOMPLETE_API_KEY,
                        apiKey,
                        params[0], ""
                                + LocationUtils.USER_CURRENT_LATITUDE, ""
                                + LocationUtils.USER_CURRENT_LONGITUDE);
            } catch (JSONException | IOException e) {
                e.printStackTrace();
            }
            return mAddressList;
        }

        @Override
        protected void onPostExecute(List<String> s) {
            super.onPostExecute(s);
            mLoadingBar.setVisibility(View.INVISIBLE);
            if (!s.isEmpty()) { // changed
                mSourceAddressListAdapter = new ArrayAdapter<>(getApplicationContext(),
                        R.layout.layout_autocompletelist, s);
                mLstLocationList.setAdapter(mSourceAddressListAdapter);

                mLstLocationList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        LocationUtils.CURRENT_DESTINATION_ADDRESS = parent.getItemAtPosition(position).toString();
                        mTxtDestinationLocation.setText(LocationUtils.CURRENT_DESTINATION_ADDRESS);
                        mTxtDestinationLocation.setTextColor(Color.parseColor("#9f9d9d"));
                        dialog.dismiss();

                        new GetAddressOnMap().execute();
                        //startActivity(new Intent(HomeActivity.this, NewMapsActivity.class));
                    }
                });
                mLoadingBar.setVisibility(View.INVISIBLE);
            } else {
                /*
                 * Toast.makeText(context, "Suggestion Error",
				 * Toast.LENGTH_SHORT).show();
				 */
            }
        }
    }

    private class GetAddressOnMap extends AsyncTask<String, String, List<List<HashMap<String, String>>>> {

        private ProgressDialog mDlg;
        Exception ex;
        HashMap<String, String> response = new HashMap<String, String>();
        List<List<HashMap<String, String>>> routes = new ArrayList<List<HashMap<String, String>>>();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(NewMapsActivity.this);
            mDlg.setMessage("Please wait...");
            mDlg.show();
        }

        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... params) {

            String loc;
            String res = "";
            try {
//                loc = mWebMapUtils.getLatLongFromAddress(LocationUtils.CURRENT_DESTINATION_ADDRESS);
                String mapKey = getResources().getString(R.string.mapapikey);
                loc = mWebMapUtils.getLatLongFromAddress(LocationUtils.CURRENT_DESTINATION_ADDRESS, mapKey);
                if (!(loc.trim().isEmpty())) {
                    String loc1[] = loc.split(",");
                    LocationUtils.USER_DEST_LATITUDE = Double.parseDouble(loc1[0]);
                    LocationUtils.USER_DEST_LONGITUDE = Double.parseDouble(loc1[1]);

                    LocationUtils.USER_DEST_LATITUDE = Double.valueOf(decimalFormat
                            .format(LocationUtils.USER_DEST_LATITUDE));
                    LocationUtils.USER_DEST_LONGITUDE = Double.valueOf(decimalFormat
                            .format(LocationUtils.USER_DEST_LONGITUDE));

                    response = mWebMapUtils.getTimeDistanceBetweenMapPoints("" + LocationUtils.USER_CURRENT_LATITUDE,
                            "" + LocationUtils.USER_CURRENT_LONGITUDE, "" + LocationUtils.USER_DEST_LATITUDE,
                            "" + LocationUtils.USER_DEST_LONGITUDE, LocationUtils.DISTANCE_UNIT, false);

                    LocationUtils.SOURCE_DESTINATION_DISTANCE = response.get("distance");
                    LocationUtils.SOURCE_DESTINATION_TIME = response.get("duration");

                    LocationUtils.SOURCE_DESTINATION_DISTANCE_METERS = response.get("distance_meters");
                    LocationUtils.SOURCE_DESTINATION_TIME_SECONDS = response.get("duration_seconds");
                    res = response.get("response");
                    routes = mWebMapUtils.getRoutesBetweenMapPoints(res);
                } else {
                    routes = null;
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
                ex = e;
            }
            return routes;
        }

        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {
            super.onPostExecute(result);
            mDlg.dismiss();
            if (ex == null) {

                if (result != null) {

                    if (result.size() == 0) {
                        Toast.makeText(NewMapsActivity.this, "No Route Found",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        ArrayList<LatLng> points = null;
                        PolylineOptions polyLineOptions = null;
                        if (polylineFinal != null) {
                            polylineFinal.remove();
                        }

                        if (destMarker != null)
                            destMarker.remove();

                        // traversing through routes
                        for (int i = 0; i < result.size(); i++) {
                            points = new ArrayList<LatLng>();
                            polyLineOptions = new PolylineOptions();
                            List<HashMap<String, String>> path = result.get(i);

                            for (int j = 0; j < path.size(); j++) {
                                HashMap<String, String> point = path.get(j);

                                double lat = Double.parseDouble(point.get("lat"));
                                double lng = Double.parseDouble(point.get("lng"));
                                LatLng position = new LatLng(lat, lng);

                                points.add(position);
                            }

                            polyLineOptions.addAll(points);

                            polyLineOptions.width(10);
                            polyLineOptions.color(Color.BLUE);
                        }

                        polylineFinal = mMap.addPolyline(polyLineOptions);

                        //animateCameraToUserLocation("yes");
                        Log.e("DISTANCE", LocationUtils.SOURCE_DESTINATION_DISTANCE);
                        Log.e("TIME", LocationUtils.SOURCE_DESTINATION_TIME);

                        Log.e("DISTANCE METERS", LocationUtils.SOURCE_DESTINATION_DISTANCE_METERS);
                        Log.e("TIME SECONDS", LocationUtils.SOURCE_DESTINATION_TIME_SECONDS);
                    }

                    LatLng loc = new LatLng(LocationUtils.USER_DEST_LATITUDE, LocationUtils.USER_DEST_LONGITUDE);
                    destinationMarker(loc);

                    isDestinationSelected = true;
                } else {
                    mTxtDestinationLocation.setText("Select Destination Address");
//                    mTxtDestinationLocation.setText("Suburb: Select Destination Address");
                    Toast.makeText(NewMapsActivity.this, "No Route Found",
                            Toast.LENGTH_SHORT).show();
                }
            } else {

            }
        }
    }

    private void destinationMarker(LatLng locDestination) {
        MarkerOptions markerOptions = new MarkerOptions()
                .position(locDestination)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.red));
        destMarker = mMap.addMarker(markerOptions);
    }

    private void sourceMarker(LatLng locSource) {
        mMap.addMarker(new MarkerOptions()
                .position(locSource)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.green)));
    }

    public void btnSelectDestinationAddress(View v) {
        selectDestinationAddress();
    }

    public void btnSelectNearestTaxi(View v) {


    }


    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(internetConnectionReciever, new IntentFilter(
                "android.net.conn.CONNECTIVITY_CHANGE"));
//        registerReceiver(GpsChangeReceiver, new IntentFilter(
//                LocationManager.PROVIDERS_CHANGED_ACTION));
        isRecieverRegistered = true;
        mProgressBar.setVisibility(View.VISIBLE);
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run()
            {
                mProgressBar.setVisibility(View.INVISIBLE);

            }
        }, 5000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isRecieverRegistered) {
            unregisterReceiver(internetConnectionReciever);
//            unregisterReceiver(GpsChangeReceiver);
        }
    }

    public BroadcastReceiver internetConnectionReciever = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            ConnectivityManager connectivityManager = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetInfo = connectivityManager
                    .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            NetworkInfo activeWIFIInfo = connectivityManager
                    .getNetworkInfo(connectivityManager.TYPE_WIFI);

            if (activeWIFIInfo.isConnected() || activeNetInfo.isConnected()) {
                removeInternetDialog();
            } else {
                if (isNetDialogShowing) {
                    return;
                }
                showInternetDialog();
            }
        }
    };

    private void removeInternetDialog() {
        if (internetDialog != null && internetDialog.isShowing()) {
            internetDialog.dismiss();
            isNetDialogShowing = false;
            internetDialog = null;

        }
    }

    private void showInternetDialog() {
        //AndyUtils.removeCustomProgressDialog();
        isNetDialogShowing = true;
        android.support.v7.app.AlertDialog.Builder internetBuilder = new android.support.v7.app.AlertDialog.Builder(
                NewMapsActivity.this);
        internetBuilder.setCancelable(false);
        internetBuilder
                .setTitle(getString(R.string.dialog_no_internet))
                .setMessage(getString(R.string.dialog_no_inter_message))
                .setPositiveButton(getString(R.string.dialog_enable_3g),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // continue with delete
                                Intent intent = new Intent(
                                        android.provider.Settings.ACTION_SETTINGS);
                                startActivity(intent);
                                removeInternetDialog();
                            }
                        })
                .setNeutralButton(getString(R.string.dialog_enable_wifi),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // User pressed Cancel button. Write
                                // Logic Here
                                startActivity(new Intent(
                                        Settings.ACTION_WIFI_SETTINGS));
                                removeInternetDialog();
                            }
                        })
                .setNegativeButton(getString(R.string.dialog_exit),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // do nothing
                                removeInternetDialog();
                                finish();
                            }
                        });
        internetDialog = internetBuilder.create();
        internetDialog.show();
    }

    private void initButtons() {
        etaButton = (Button) findViewById(R.id.btnETA);
        etaButton.setOnClickListener(this);
        bookNearestTaxi = (Button) findViewById(R.id.btnBookNearestTaxi);
        bookNearestTaxi.setOnClickListener(this);
        mProgressBar = (ProgressBar)findViewById(R.id.progressBar_center_new_map);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnETA:

                double lat = Double.parseDouble(LocationUtils.NEAREST_CAR_LATITUDE);
                double lng = Double.parseDouble(LocationUtils.NEAREST_CAR_LONGITUDE);
                LatLng nearestCarLatLng = new LatLng(lat, lng);
                new GetETAAsyncTask(nearestCarLatLng).execute();
                break;

            case R.id.btnBookNearestTaxi:
                if (isDestinationSelected) {
                    // TODO: TO calculate Destarny Rate picked up Random Taxi please check with client
                    // TODO: 9/19/2016 Client rejected above approach.
                    // Destarny by Private Rate
                    // Taxi by Taxi Rate
                    // Premium by Premium Rate
                    // Set Fare

//                    if (isPrivateAvailable)
//                    String destarnyXValue = calculateValue();
//                    if (isTaxiAvailable)
//                    String taxiValue = calculateValue();
//                    if (isPremumAvailable)
//                    String Premium = calculateValue();

                    // TODO: 9/19/2016 Pass above values to newBookTaxiCustomDialog

                    /******************************************************************************/
                    String dId = "";
                    String msg = "To Book Nearest Vehicle Now Please Select Taximeter Option?";
                    if (isPremumAvailable) {
                        selectedTaxi = premiumForAll;
                    } else {
                        selectedTaxi = mNearestTaxiList.get(0);
                    }

//                    String destarnyRate = calculateDestarnyValue();
                    // Get Estimated Values
                    premiumEstimation = calculateEstimationValue(premiumVehicle);
                    destarnyEstimation = calculateEstimationValue(privateVehicle);
                    taxiEstimation = calculateEstimationValue(taxiVehicle);

//                    bookTaxiCustomDialog(dId, msg, destarnyRate);
                    newBookTaxiCustomDialog(dId, msg);
//                    new BookNearestTaxiTask().execute();
                } else {
//                if (mLstLocationList == null || mLstLocationList.isSelected()) {
//                if (LocationUtils.CURRENT_DESTINATION_ADDRESS == null ||
//                        LocationUtils.CURRENT_DESTINATION_ADDRESS.isEmpty()) {
                    customAlertDialog();
//                    Toast.makeText(getApplicationContext(), "Please select destination!", Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.btn_book_taxi:
                if (customInfoWindowDialog != null && customInfoWindowDialog.isShowing())
                    customInfoWindowDialog.dismiss();

                if (isDestinationSelected) {
                    if (selectedMarker != null) {
                        selectedMarker.hideInfoWindow();
                        String mId = selectedMarker.getId();
                        final String did = driverId.get(mId);
//                Toast.makeText(this, "" + selectedMarker.getPosition() + " id " + selectedMarker.getId(), Toast.LENGTH_SHORT).show();

                        if (did != null) {
//                    callCustomDialog(did);
                            String msg = "To Book Vehicle Now Please Select Taximeter Option?";
                            selectedTaxi = destarnyRateDetails.get(mId);

                            specificTaxiFareType = selectedTaxi.getvType();

//                    String destarnyRate = calculateDestarnyValue();
                            // Get Estimated Values
                            premiumEstimation = calculateEstimationValue(premiumVehicle);
                            destarnyEstimation = calculateEstimationValue(privateVehicle);
                            taxiEstimation = calculateEstimationValue(taxiVehicle);

//                    bookTaxiCustomDialog(did, msg, destarnyRate);
                            newBookTaxiCustomDialog(did, msg);
                        } else {
                            Toast.makeText(NewMapsActivity.this, "Your Journey will Start here!", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
//        if (mLstLocationList == null || mLstLocationList.isSelected()) {
                    customAlertDialog();
//            Toast.makeText(getApplicationContext(), "Please select destination!", Toast.LENGTH_LONG).show();
                }

                break;
        }
    }

    private class BookNearestTaxiTask extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(NewMapsActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String cid = mPref.getPassengerId();
            String vtid = LocationUtils.CURRENT_VEHICLE_TYPE;
            String booking_type = "Current";
            String fare_type = fareType;
            String setfare_unfullfilled = "0";
            String booking_from_lat = String.valueOf(LocationUtils.USER_CURRENT_LATITUDE);
            String booking_from_lng = String.valueOf(LocationUtils.USER_CURRENT_LONGITUDE);
            String booking_from = LocationUtils.CURRENT_SOURCE_ADDRESS;
            String booking_to_lat = String.valueOf(LocationUtils.USER_DEST_LATITUDE);
            String booking_to_lng = String.valueOf(LocationUtils.USER_DEST_LONGITUDE);
            String booking_to = LocationUtils.CURRENT_DESTINATION_ADDRESS;
            String noofpass = "0";
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            String booking_time = sdf.format(new Date());
            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
            String booking_date = sdf1.format(new Date());
            String notes = "";
            String fareid = fareString;

            String response = null;
            try {
//                response = mWebHandler.bookNearestTaxi(cid, vtid, booking_type, fare_type, setfare_unfullfilled, booking_from_lat,
//                        booking_from_lng, booking_from, booking_to_lat, booking_to_lng, booking_to, noofpass,
//                        booking_time, booking_date, notes, fareid);
                response = mWebHandler.bookNearestTaxi(cid, booking_type, fare_type, setfare_unfullfilled, booking_from_lat,
                        booking_from_lng, booking_from, booking_to_lat, booking_to_lng, booking_to, noofpass,
                        booking_time, booking_date, notes, fareid,
                        LocationUtils.SOURCE_DESTINATION_DISTANCE, LocationUtils.SOURCE_DESTINATION_TIME,
                        approxCalfare);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (progressDialog.isShowing())
                progressDialog.dismiss();
            try {
                if (s != null) {
                    JSONObject mParentObject = new JSONObject(s);
                    if (mParentObject.getBoolean("status")) {
                        JSONObject items = mParentObject.getJSONObject("items");
                        Toast.makeText(getApplicationContext(), "Your Order Request is sent!", Toast.LENGTH_LONG).show();

                        NewMapsActivity.this.finish();
                    } else {
                        String msg = mParentObject.getString("items");
                        Toast.makeText(getApplicationContext(),
                                "Something went wrong! Please try again!" + msg, Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(),
                            "Something went wrong! Please try again!", Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param marker
     * @return
     */
    @Override
    public boolean onMarkerClick(Marker marker) {

//        if (marker != null) {
//            marker.hideInfoWindow();
//            String mId = marker.getId();
//            final String did = driverId.get(mId);
//            NearestTaxi selectedTaxi = destarnyRateDetails.get(mId);
////                Toast.makeText(this, "" + marker.getPosition() + " id " + marker.getId(), Toast.LENGTH_SHORT).show();
//            if (did != null) {
//                marker.showInfoWindow();
////                Toast.makeText(this, "" + marker.getPosition()
////                        + " id " + marker.getId(), Toast.LENGTH_SHORT).show();
//            }
//        }
//        return true;
        return infoWindowAsDialog(marker);
    }

    private Dialog customInfoWindowDialog = null;
    private Marker selectedMarker = null;

    private boolean infoWindowAsDialog(final Marker marker) {
        if (customInfoWindowDialog != null && customInfoWindowDialog.isShowing())
            customInfoWindowDialog.dismiss();

        selectedMarker = marker;
        if (marker != null) {
            marker.hideInfoWindow();
            String mId = marker.getId();
            final String did = driverId.get(mId);
            NearestTaxi selectedTaxi = destarnyRateDetails.get(mId);
//                Toast.makeText(this, "" + marker.getPosition() + " id " + marker.getId(), Toast.LENGTH_SHORT).show();
            if (did != null) {
                customInfoWindowDialog = new Dialog(NewMapsActivity.this);
                customInfoWindowDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                //d.setTitle("Select");
                customInfoWindowDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                customInfoWindowDialog.setContentView(R.layout.custom_info_contents);

                String markerId = marker.getId();
//                Log.e(TAG, markerId);

                ImageView ivInfoWindowImage = (ImageView) customInfoWindowDialog.findViewById(R.id.iv_info_window_image);
                String vehicleType = NewMapsActivity.vehicleTypeId.get(markerId);
                if (vehicleType.equals("Premium"))
                    ivInfoWindowImage.setImageDrawable(this.getResources().getDrawable(R.drawable.premium_vehicle));
                else if (vehicleType.equals("Private"))
                    ivInfoWindowImage.setImageDrawable(this.getResources().getDrawable(R.drawable.private_vehicle));
                else if (vehicleType.equals("Taxi"))
                    ivInfoWindowImage.setImageDrawable(this.getResources().getDrawable(R.drawable.taxi_vehicle));

                TextView tvTitle = ((TextView) customInfoWindowDialog.findViewById(R.id.tv_title));
                tvTitle.setText(marker.getTitle());
                TextView tvSnippet = ((TextView) customInfoWindowDialog.findViewById(R.id.tv_snippet));
                tvSnippet.setText(marker.getSnippet());
                Button bookTaxi = (Button) customInfoWindowDialog.findViewById(R.id.btn_book_taxi);
                bookTaxi.setOnClickListener(this);

                customInfoWindowDialog.show();
            }
        }

//        //arg0.showInfoWindow();
//        final DataClass data = myMapData.get(arg0);
//
//
//        ivPhoto = (ImageView)d.findViewById(R.id.infocontent_iv_image);
//        AddImageOnWindow executeDownload = new AddImageOnWindow();
//        final LatLng l = arg0.getPosition();
//        executeDownload.execute(l);
//        TextView tvName = (TextView)d.findViewById(R.id.infocontent_tv_name);
//        tvName.setText(data.getPlaceName());
//
//        TextView tvType = (TextView)d.findViewById(R.id.infocontent_tv_type);
//        tvType.setText("("+data.getPlaceType()+")");
//
//        TextView tvDesc = (TextView)d.findViewById(R.id.infocontent_tv_desc);
//        tvDesc.setText(data.getPlaceDesc());
//
//        TextView tvAddr = (TextView)d.findViewById(R.id.infocontent_tv_addr);
//        tvAddr.setText(Html.fromHtml(data.getPlaceAddr()));


        return true;
    }

    @Override
    public void onInfoWindowClick(Marker marker) {
        if (isDestinationSelected) {
            if (marker != null) {
                marker.hideInfoWindow();
                String mId = marker.getId();
                final String did = driverId.get(mId);
//                Toast.makeText(this, "" + marker.getPosition() + " id " + marker.getId(), Toast.LENGTH_SHORT).show();

                if (did != null) {
//                    callCustomDialog(did);
                    String msg = "To Book Vehicle Now Please Select Taximeter Option?";
                    selectedTaxi = destarnyRateDetails.get(mId);

                    specificTaxiFareType = selectedTaxi.getvType();

//                    String destarnyRate = calculateDestarnyValue();
                    // Get Estimated Values
                    premiumEstimation = calculateEstimationValue(premiumVehicle);
                    destarnyEstimation = calculateEstimationValue(privateVehicle);
                    taxiEstimation = calculateEstimationValue(taxiVehicle);

//                    bookTaxiCustomDialog(did, msg, destarnyRate);
                    newBookTaxiCustomDialog(did, msg);
                } else {
                    Toast.makeText(this, "Your Journey will Start here!", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
//        if (mLstLocationList == null || mLstLocationList.isSelected()) {
            customAlertDialog();
//            Toast.makeText(getApplicationContext(), "Please select destination!", Toast.LENGTH_LONG).show();
        }
    }

    private String calculateDestarnyValue() {
        String finalValue = "";
        double pricePerKm = selectedTaxi.getPricePerKm();
        double pricePerMin = selectedTaxi.getPricePerMin();
        double minPrice = selectedTaxi.getMinPrice();
        double distFromPickupLoc = selectedTaxi.getDistFromPickupLoc();

        double dist = 0.0, tim = 0.0, res = 0.0, resDist = 0.0, resTime = 0.0;
//        String[] splitDistance = LocationUtils.SOURCE_DESTINATION_DISTANCE.split("\\s+");
//        String[] splitTime = LocationUtils.SOURCE_DESTINATION_TIME.split("\\s+");
//
//        Log.e("DISTANCE", LocationUtils.SOURCE_DESTINATION_DISTANCE);
//        Log.e("TIME", LocationUtils.SOURCE_DESTINATION_TIME);
//
////        dist = Double.parseDouble(splitDistance[0]);
////        tim = Double.parseDouble(splitTime[0]);
//
//        dist = Double.parseDouble(splitDistance[0].replaceAll(",", ""));
//        tim = Double.parseDouble(splitTime[0].replaceAll(",", ""));
//
//        if (splitDistance[1].equals("km")) {
//            resDist = (dist * pricePerKm);
//        } else if (splitDistance[1].equals("m")) {
//            resDist = ((dist * 1000) * pricePerKm);
//        } else {
//            resDist = 0.0;
//        }
//
//        if (splitTime[1].equals("mins")) {
//            resTime = (tim * pricePerMin);
//        } else if (splitTime[1].equals("hours")) {
//            resTime = ((tim * 60) * pricePerMin);
//        } else if (splitTime[1].equals("day")) {
//            resTime = (((tim * 24) * 60) * pricePerMin);
//        } else {
//            resTime = 0.0;
//        }

        String distMeters = LocationUtils.SOURCE_DESTINATION_DISTANCE_METERS;
        String timeSeconds = LocationUtils.SOURCE_DESTINATION_TIME_SECONDS;

        resDist = ((Double.parseDouble(distMeters)) * pricePerKm) / 1000;
        resTime = ((Double.parseDouble(timeSeconds)) * pricePerMin) / 60;

        res = resDist + resTime;
        finalValue = df.format(res);

        return finalValue;
    }

    private void callCustomDialog(final String did) {
        // Create custom dialog object
        final Dialog dialog = new Dialog(NewMapsActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // Include dialog.xml file
        dialog.setContentView(R.layout.custom_dialog);

        // set values for custom dialog components - text, image and button
        TextView text = (TextView) dialog.findViewById(R.id.txt_dialog_message);
        text.setText("Book this Taxi Now?");

        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
//        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.90);
        dialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.show();

        Button acceptButton = (Button) dialog.findViewById(R.id.btn_yes);
        // if Yes button is clicked
        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                new BookSelectedTaxiTask(did).execute();
            }
        });

        Button declineButton = (Button) dialog.findViewById(R.id.btn_no);
        // if decline button is clicked, close the custom dialog
        declineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close dialog
                dialog.dismiss();
            }
        });
    }

    private void customAlertDialog() {
        // Create custom dialog object
        final Dialog dialog = new Dialog(NewMapsActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // Include dialog.xml file
        dialog.setContentView(R.layout.custom_alert_dialog);

        // set values for custom dialog components - text, image and button
        TextView titleText = (TextView) dialog.findViewById(R.id.txt_alert_dialog_title);
        titleText.setText("Set Destination");

        TextView text = (TextView) dialog.findViewById(R.id.txt_alert_dialog_message);
        text.setText("To book this vehicle directly please set destination");

        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
//        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.90);
        dialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.show();

        Button acceptButton = (Button) dialog.findViewById(R.id.btn_ok);
        // if Yes button is clicked
        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

    }

    private void bookTaxiCustomDialog(final String did, String msg, String destarnyRateValue) {
        // Create custom dialog object
        final Dialog dialog = new Dialog(NewMapsActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // Include dialog.xml file
//        dialog.setContentView(R.layout.test);
        dialog.setContentView(R.layout.dialog_book_vehicle);
        final ViewFlipper viewFlipper = (ViewFlipper) dialog.findViewById(R.id.ViewFlipper01);

        // set values for custom dialog components - text, image and button
        TextView text = (TextView) dialog.findViewById(R.id.txt_dialog_message);
        text.setText(msg);

        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
//        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.90);
        dialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.show();

        RadioGroup bookingTypeGroup = (RadioGroup) dialog.findViewById(R.id.rg_booking_type);
        final RadioButton destarnyRateRadioButton =
                (RadioButton) dialog.findViewById(R.id.radio_destarny_rate);
        final RadioButton taximeterRadioButton =
                (RadioButton) dialog.findViewById(R.id.radio_taximeter);
        final RadioButton setFareRadioButton =
                (RadioButton) dialog.findViewById(R.id.radio_set_fare);
        final EditText fareEditText = (EditText) dialog.findViewById(R.id.et_set_fare);
//        fareEditText.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(10, 2)});

        // Setting Calculated Destarny Rate
        String destarnyValueString = "Destarny Rate (Est. $" + destarnyRateValue + ")";
        destarnyRateRadioButton.setText(destarnyValueString);

        bookingTypeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio_destarny_rate) {
                    // TODO: Define type for Destarny Rate
//                    fareType = "DestarnyRate";
                    fareType = "Destarnyrate";
                    fareString = "0";

                    destarnyRateRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    taximeterRadioButton.setTextColor(Color.BLACK);
                    setFareRadioButton.setTextColor(Color.BLACK);

                } else if (checkedId == R.id.radio_taximeter) {
                    fareType = "Taximeter";
                    fareString = "0";

                    destarnyRateRadioButton.setTextColor(Color.BLACK);
                    taximeterRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    setFareRadioButton.setTextColor(Color.BLACK);

                } else if (checkedId == R.id.radio_set_fare) {
//                    fareType = "SetFare";
                    fareType = "Setfare";

                    destarnyRateRadioButton.setTextColor(Color.BLACK);
                    taximeterRadioButton.setTextColor(Color.BLACK);
                    setFareRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                }

            }
        });

        setFareRadioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewFlipper.showNext();
            }
        });

        Button backSetFareButton = (Button) dialog.findViewById(R.id.btn_dialog_back);
        // if Yes button is clicked
        backSetFareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (Utils.isNotNull(fareString))
                fareString = "";
                viewFlipper.showPrevious();

            }
        });

        Button setFareButton = (Button) dialog.findViewById(R.id.btn_set_fare);
        // if Yes button is clicked
        setFareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fareString = fareEditText.getText().toString();
                if (Utils.isNotNull(fareString)) {
                    String setFareTemp = "Set Fare (My Offer: $"
                            + fareString + ")";
                    setFareRadioButton.setText(setFareTemp);
                    viewFlipper.showPrevious();
                } else
                    Toast.makeText(NewMapsActivity.this,
                            "Please enter appropriate fare!", Toast.LENGTH_SHORT).show();

            }
        });

        Button bookButton = (Button) dialog.findViewById(R.id.btn_book_yes);
        // if Yes button is clicked
        bookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isNotNull(fareType)) {
                    if (Utils.isNotNull(fareString)) {
                        if (Utils.isNetworkAvailable(NewMapsActivity.this)) {
                            dialog.dismiss();
                            if (Utils.isNotNull(did)) {
                                if (selectedTaxi.getvType().equals("Premium"))
                                    LocationUtils.CURRENT_VEHICLE_TYPE = "1";
//                                else if (selectedTaxi.getvType().equals("Standard")) {
                                else if (selectedTaxi.getvType().equals("Taxi")) {
                                    LocationUtils.CURRENT_VEHICLE_TYPE = "2";
//                                else if (selectedTaxi.getvType().equals("Van")) {
                                } else if (selectedTaxi.getvType().equals("Private")) {
                                    LocationUtils.CURRENT_VEHICLE_TYPE = "3";
                                }

                                new BookSelectedTaxiTask(did).execute();
                            } else
                                new BookNearestTaxiTask().execute();
                        } else {
                            Toast.makeText(NewMapsActivity.this,
                                    "Please check Internet Connection!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(NewMapsActivity.this,
                                "Please enter Fare while selecting Set Fare!",
                                Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(NewMapsActivity.this,
                            "Please select Fare Type!",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button declineButton = (Button) dialog.findViewById(R.id.btn_book_no);
        // if decline button is clicked, close the custom dialog
        declineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close dialog
                dialog.dismiss();
            }
        });
    }

    private void newBookTaxiCustomDialog(final String did, String msg) {
        // Create custom dialog object
        final Dialog dialog = new Dialog(NewMapsActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // Include dialog.xml file
//        dialog.setContentView(R.layout.test);
        dialog.setContentView(R.layout.dialog_new_book_vehicle);
        final ViewFlipper viewFlipper = (ViewFlipper) dialog.findViewById(R.id.ViewFlipper01);

        // set values for custom dialog components - text, image and button
        TextView text = (TextView) dialog.findViewById(R.id.txt_dialog_message);
        text.setText(msg);

        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
//        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.90);
        dialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.show();

        RadioGroup bookingTypeGroup = (RadioGroup) dialog.findViewById(R.id.rg_booking_type);
        final RadioButton destarnyRateRadioButton =
                (RadioButton) dialog.findViewById(R.id.radio_destarny_rate);
        final RadioButton taximeterRadioButton =
                (RadioButton) dialog.findViewById(R.id.radio_taximeter);
        final RadioButton premiumRadioButton =
                (RadioButton) dialog.findViewById(R.id.radio_premium);
        final RadioButton setFareRadioButton =
                (RadioButton) dialog.findViewById(R.id.radio_set_fare);
        final EditText fareEditText = (EditText) dialog.findViewById(R.id.et_set_fare);
//        fareEditText.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(10, 2)});

//        // Setting Calculated Destarny Rate
//        String destarnyValueString = "Destarny Rate (Est. $" + destarnyRateValue + ")";
//        destarnyRateRadioButton.setText(destarnyValueString);

        // Setting Estimated Rates
//        final String destarnyValueString = "DestarnyX (Est. Private Vehicle: $" + destarnyEstimation + " to $" + addTolerance(destarnyEstimation) + ")";
        final String destarnyValueString = "Destarny x1.0 (Est. $" + destarnyEstimation + " to $" + addTolerance(destarnyEstimation) + ")";
        destarnyRateRadioButton.setText(destarnyValueString);

//        final String taxiValueString = "Taxi (Est. Taxi: $" + taxiEstimation + " to $" + addTolerance(taxiEstimation) + ")";
        final String taxiValueString = "Taxi (Est. $" + taxiEstimation + " to $" + addTolerance(taxiEstimation) + ")";
        taximeterRadioButton.setText(taxiValueString);

//        final String premiumValueString = "Premium (Est. Premium: $" + premiumEstimation + " to $" + addTolerance(premiumEstimation) + ")";
        final String premiumValueString = "Premium (Est. $" + premiumEstimation + " to $" + addTolerance(premiumEstimation) + ")";
        premiumRadioButton.setText(premiumValueString);

        if (!did.isEmpty()) {
            if (selectedTaxi.getvType().equals("Premium")) {
                taximeterRadioButton.setVisibility(View.GONE);
                premiumRadioButton.setVisibility(View.VISIBLE);
            } else if (selectedTaxi.getvType().equals("Taxi")) {
                taximeterRadioButton.setVisibility(View.VISIBLE);
                premiumRadioButton.setVisibility(View.GONE);
            } else if (selectedTaxi.getvType().equals("Private")) {
                taximeterRadioButton.setVisibility(View.GONE);
                premiumRadioButton.setVisibility(View.GONE);
            } else {
                premiumRadioButton.setVisibility(View.VISIBLE);
                taximeterRadioButton.setVisibility(View.VISIBLE);
            }
        } else {
            premiumRadioButton.setVisibility(View.VISIBLE);
            taximeterRadioButton.setVisibility(View.VISIBLE);
        }

        bookingTypeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio_destarny_rate) {
                    // TODO: Define type for Destarny Rate
//                    fareType = "DestarnyRate";
                    fareType = "Destarnyrate";
                    fareString = "0";
                    approxCalfare = destarnyEstimation;

                    destarnyRateRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    taximeterRadioButton.setTextColor(Color.BLACK);
                    premiumRadioButton.setTextColor(Color.BLACK);
                    setFareRadioButton.setTextColor(Color.BLACK);

                } else if (checkedId == R.id.radio_taximeter) {
                    fareType = "Taximeter";
                    fareString = "0";
                    approxCalfare = taxiEstimation;

                    destarnyRateRadioButton.setTextColor(Color.BLACK);
                    taximeterRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    premiumRadioButton.setTextColor(Color.BLACK);
                    setFareRadioButton.setTextColor(Color.BLACK);

                } else if (checkedId == R.id.radio_premium) {
                    fareType = "Premium";
                    fareString = "0";
                    approxCalfare = premiumEstimation;

                    destarnyRateRadioButton.setTextColor(Color.BLACK);
                    taximeterRadioButton.setTextColor(Color.BLACK);
                    premiumRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    setFareRadioButton.setTextColor(Color.BLACK);

                } else if (checkedId == R.id.radio_set_fare) {
//                    fareType = "SetFare";
                    fareType = "Setfare";
                    approxCalfare = destarnyEstimation;

                    destarnyRateRadioButton.setTextColor(Color.BLACK);
                    taximeterRadioButton.setTextColor(Color.BLACK);
                    premiumRadioButton.setTextColor(Color.BLACK);
                    setFareRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                }

            }
        });

        setFareRadioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewFlipper.showNext();
            }
        });

        Button backSetFareButton = (Button) dialog.findViewById(R.id.btn_dialog_back);
        // if Yes button is clicked
        backSetFareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (Utils.isNotNull(fareString))
                fareString = "";
                viewFlipper.showPrevious();

            }
        });

        Button setFareButton = (Button) dialog.findViewById(R.id.btn_set_fare);
        // if Yes button is clicked
        setFareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fareString = fareEditText.getText().toString();
                if (Utils.isNotNull(fareString)) {
                    String setFareTemp = "Set Fare (My Offer: $"
                            + fareString + ")";
                    setFareRadioButton.setText(setFareTemp);
                    viewFlipper.showPrevious();
                } else
                    Toast.makeText(NewMapsActivity.this,
                            "Please enter appropriate fare!", Toast.LENGTH_SHORT).show();

            }
        });

        Button bookButton = (Button) dialog.findViewById(R.id.btn_book_yes);
        // if Yes button is clicked
        bookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isNotNull(fareType)) {
//                    if (!specificTaxiFareType.equals("") && !fareType.equals("Destarnyrate")
//                            && !fareType.equals("Setfare") && !specificTaxiFareType.equals(fareType)) {
                    if (Utils.isNotNull(fareString)) {
                        if (Utils.isNetworkAvailable(NewMapsActivity.this)) {
                            dialog.dismiss();
                            if (Utils.isNotNull(did)) {
                                if (selectedTaxi.getvType().equals("Premium"))
                                    LocationUtils.CURRENT_VEHICLE_TYPE = "1";
//                                else if (selectedTaxi.getvType().equals("Standard")) {
                                else if (selectedTaxi.getvType().equals("Taxi")) {
                                    LocationUtils.CURRENT_VEHICLE_TYPE = "2";
//                                else if (selectedTaxi.getvType().equals("Van")) {
                                } else if (selectedTaxi.getvType().equals("Private")) {
                                    LocationUtils.CURRENT_VEHICLE_TYPE = "3";
                                }

                                new BookSelectedTaxiTask(did).execute();
                            } else
                                new BookNearestTaxiTask().execute();
                        } else {
                            Toast.makeText(NewMapsActivity.this,
                                    "Please check Internet Connection!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(NewMapsActivity.this,
                                "Please enter Fare while selecting Set Fare!",
                                Toast.LENGTH_SHORT).show();
                    }
//                    } else {
//                        Toast.makeText(NewMapsActivity.this, "Selected vehicle type does not offer Booking of this type!",
//                                Toast.LENGTH_LONG).show();
//                    }
                } else {
                    Toast.makeText(NewMapsActivity.this,
                            "Please select Fare Type!",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button declineButton = (Button) dialog.findViewById(R.id.btn_book_no);
        // if decline button is clicked, close the custom dialog
        declineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close dialog
                dialog.dismiss();
            }
        });
    }

    private String addTolerance(String value) {
        double valueDouble = Double.parseDouble(value);
        double valueAfterTolerance = valueDouble + (valueDouble * 0.2);

        return df.format(valueAfterTolerance);
    }

    private class BookSelectedTaxiTask extends AsyncTask<Void, Void, String> {

        private String did;
        private ProgressDialog progressDialog;

        public BookSelectedTaxiTask(String did) {
            this.did = did;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(NewMapsActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String cid = mPref.getPassengerId();
            String vtid = LocationUtils.CURRENT_VEHICLE_TYPE;
            String booking_type = "Current";
            String fare_type = fareType;

            String setfare_unfullfilled = "0";
            String booking_from_lat = String.valueOf(LocationUtils.USER_CURRENT_LATITUDE);
            String booking_from_lng = String.valueOf(LocationUtils.USER_CURRENT_LONGITUDE);
            String booking_from = LocationUtils.CURRENT_SOURCE_ADDRESS;
            String booking_to_lat = String.valueOf(LocationUtils.USER_DEST_LATITUDE);
            String booking_to_lng = String.valueOf(LocationUtils.USER_DEST_LONGITUDE);
            String booking_to = LocationUtils.CURRENT_DESTINATION_ADDRESS;
            String noofpass = "0";
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            String booking_time = sdf.format(new Date());
            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
            String booking_date = sdf1.format(new Date());
            String notes = "";
            String fareid = fareString;

            String response = null;
            try {
//                response = mWebHandler.bookSelectedTaxi(cid, vtid, booking_type, fare_type, setfare_unfullfilled, booking_from_lat,
//                        booking_from_lng, booking_from, booking_to_lat, booking_to_lng, booking_to, noofpass,
//                        booking_time, booking_date, notes, fareid, did);

//                response = mWebHandler.bookSelectedTaxi(cid, booking_type, fare_type, setfare_unfullfilled, booking_from_lat,
//                        booking_from_lng, booking_from, booking_to_lat, booking_to_lng, booking_to, noofpass,
//                        booking_time, booking_date, notes, fareid, did);

                response = mWebHandler.bookSelectedTaxi(cid, booking_type, fare_type, setfare_unfullfilled, booking_from_lat,
                        booking_from_lng, booking_from, booking_to_lat, booking_to_lng, booking_to, noofpass,
                        booking_time, booking_date, notes, fareid, did,
                        LocationUtils.SOURCE_DESTINATION_DISTANCE, LocationUtils.SOURCE_DESTINATION_TIME,
                        approxCalfare);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (progressDialog.isShowing())
                progressDialog.hide();

            try {
                if (s != null) {
                    JSONObject mParentObject = new JSONObject(s);
                    if (mParentObject.getBoolean("status")) {
                        JSONObject items = mParentObject.getJSONObject("items");
                        Toast.makeText(getApplicationContext(), "Your Order Request is sent!", Toast.LENGTH_LONG).show();

                        NewMapsActivity.this.finish();
                    } else {
                        String items = mParentObject.getString("items");
                        if (items != null) {
                            Toast.makeText(getApplicationContext(),
                                    items, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(getApplicationContext(),
                                    "Something went wrong! Please try again!", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


    private class GetETAAsyncTask extends AsyncTask<String, Void, HashMap<String, String>> {
        private LatLng carLatLng;
        private ProgressDialog progressDialog;

        GetETAAsyncTask(LatLng carLatLng) {
            this.carLatLng = carLatLng;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(NewMapsActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected HashMap<String, String> doInBackground(String... params) {
            HashMap<String, String> response = null;
            try {
//                String loc = mWebMapUtils.getLatLongFromAddress(LocationUtils.CURRENT_SOURCE_ADDRESS);
                String mapKey = getResources().getString(R.string.mapapikey);
                String loc = mWebMapUtils.getLatLongFromAddress(LocationUtils.CURRENT_SOURCE_ADDRESS, mapKey);
                if (!loc.isEmpty()) {
                    // Get Latlng of Source Address
                    String loc1[] = loc.split(",");
                    double sourceLat = Double.parseDouble(loc1[0]);
                    double sourceLongi = Double.parseDouble(loc1[1]);

                    // Get Latlng of Nearest Car by Distance
                    double carLat = carLatLng.latitude;
                    double carLongi = carLatLng.longitude;

                    // Calculate Duration between Source and Nearest Car
                    response = mWebMapUtils.getTimeDistanceBetweenMapPoints("" + sourceLat,
                            "" + sourceLongi, "" + carLat,
                            "" + carLongi, LocationUtils.DISTANCE_UNIT, true);

                    String carToSourceDistance = response.get("distance");
                    String carToSourceDuration = response.get("duration");
//                res = response.get("response");
//                routes = mWebMapUtils.getRoutesBetweenMapPoints(res);
                }
            } catch (JSONException | IOException e) {
                e.printStackTrace();
            }

            return response;
        }

        @Override
        protected void onPostExecute(HashMap<String, String> s) {
            super.onPostExecute(s);
            if (progressDialog.isShowing())
                progressDialog.hide();
            if (s != null) {
                String carToSourceDistance = s.get("distance");
                String carToSourceDuration = s.get("duration");

                Toast.makeText(getApplicationContext(), "ETA: " + carToSourceDuration, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "Somethings went wrong!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private class SetPaymentMethodTask extends AsyncTask<Void, Void, String> {

        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(NewMapsActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String passId = mPref.getPassengerId();

            String response = null;

            try {
                response = mWebHandler.setPaymentMethod(passId, payMethod, payId);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (progressDialog.isShowing())
                progressDialog.hide();

            try {
                if (s != null) {
                    JSONObject mParentObject = new JSONObject(s);
                    if (mParentObject.getBoolean("status")) {
                        JSONArray items = mParentObject.getJSONArray("items");
                        Toast.makeText(getApplicationContext(),
                                "Your Payment Method is set!", Toast.LENGTH_LONG).show();

                    } else {
                        Toast.makeText(getApplicationContext(),
                                "Something went wrong! Please try again!", Toast.LENGTH_LONG).show();
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class GetVehicleType extends AsyncTask<String, String, String> {
        //        private ProgressDialog mDlg;
        private String strResponse = "";
        private JSONObject mObject;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            mDlg = new ProgressDialog(NewMapsActivity.this);
//            mDlg.setMessage("Please wait..");
//            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                String url = Constant.GET_VEHICLE_TYPE;
                strResponse = mWeb.mWebMethod(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return strResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
//            mDlg.dismiss();
            try {
                mObject = new JSONObject(s);
                if (mObject.getBoolean("status")) {
                    JSONArray itemsJsonArray = mObject.getJSONArray("items");

                    mShardPrefClass.setVehicleTypes(itemsJsonArray.toString());
                    getVehicleType(itemsJsonArray);
                } else {
                    String items = mShardPrefClass.getVehicleTypes();
                    if (items != null) {
                        JSONArray itemsJsonArray = new JSONArray(items);
                        getVehicleType(itemsJsonArray);
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }

    private void getVehicleType(JSONArray itemsJsonArray) {
        int itemSize = itemsJsonArray.length();
        for (int i = 0; i < itemSize; i++) {
            JSONObject itemJsonObject = null;
            try {
                itemJsonObject = itemsJsonArray.getJSONObject(i);
                if (itemJsonObject.has("vtype")) {
                    if (itemJsonObject.getString("vtype").equals("Premium")) {
                        String id = itemJsonObject.getString("id");
                        String vtype = itemJsonObject.getString("vtype");
                        String noofseats = itemJsonObject.getString("noofseats");
                        String price_per_km = itemJsonObject.getString("price_per_km");
                        String price_per_min = itemJsonObject.getString("price_per_min");
                        String min_price = itemJsonObject.getString("min_price");

                        premiumVehicle = new VehicleTypeDetails();
                        premiumVehicle.setId(id);
                        premiumVehicle.setVtype(vtype);
                        premiumVehicle.setPrice_per_km(price_per_km);
                        premiumVehicle.setPrice_per_min(price_per_min);
                        premiumVehicle.setMin_price(min_price);

//                        calculateDestarnyValue();
//                        premiumEstimation = calculateEstimationValue(premiumVehicle);
                    } else if (itemJsonObject.getString("vtype").equals("Private")) {
                        String id = itemJsonObject.getString("id");
                        String vtype = itemJsonObject.getString("vtype");
                        String noofseats = itemJsonObject.getString("noofseats");
                        String price_per_km = itemJsonObject.getString("price_per_km");
                        String price_per_min = itemJsonObject.getString("price_per_min");
                        String min_price = itemJsonObject.getString("min_price");

                        privateVehicle = new VehicleTypeDetails();
                        privateVehicle.setId(id);
                        privateVehicle.setVtype(vtype);
                        privateVehicle.setPrice_per_km(price_per_km);
                        privateVehicle.setPrice_per_min(price_per_min);
                        privateVehicle.setMin_price(min_price);

//                        destarnyEstimation = calculateEstimationValue(privateVehicle);
                    } else if (itemJsonObject.getString("vtype").equals("Taxi")) {
                        String id = itemJsonObject.getString("id");
                        String vtype = itemJsonObject.getString("vtype");
                        String noofseats = itemJsonObject.getString("noofseats");
                        String price_per_km = itemJsonObject.getString("price_per_km");
                        String price_per_min = itemJsonObject.getString("price_per_min");
                        String min_price = itemJsonObject.getString("min_price");

                        taxiVehicle = new VehicleTypeDetails();
                        taxiVehicle.setId(id);
                        taxiVehicle.setVtype(vtype);
                        taxiVehicle.setPrice_per_km(price_per_km);
                        taxiVehicle.setPrice_per_min(price_per_min);
                        taxiVehicle.setMin_price(min_price);

//                        taxiEstimation= calculateEstimationValue(taxiVehicle);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private String calculateEstimationValue(VehicleTypeDetails vehicleTypeDetails) {
        String finalValue = "";
        double pricePerKm = Double.parseDouble(vehicleTypeDetails.getPrice_per_km());
        double pricePerMin = Double.parseDouble(vehicleTypeDetails.getPrice_per_min());
        double minPrice = Double.parseDouble(vehicleTypeDetails.getMin_price());
//        double distFromPickupLoc = vehicleTypeDetails.getDistFromPickupLoc();

        double dist = 0.0, tim = 0.0, res = 0.0, resDist = 0.0, resTime = 0.0;

        String distMeters = LocationUtils.SOURCE_DESTINATION_DISTANCE_METERS;
        String timeSeconds = LocationUtils.SOURCE_DESTINATION_TIME_SECONDS;

        resDist = ((Double.parseDouble(distMeters)) * pricePerKm) / 1000;
        resTime = ((Double.parseDouble(timeSeconds)) * pricePerMin) / 60;

        res = minPrice + (resDist + resTime);
        finalValue = df.format(res);

        return finalValue;
    }


    class VehicleTypeDetails {

        /**
         * id : 1
         * vtype : Premium
         * noofseats : 4
         * price_per_km : 2.50
         * price_per_min : 0.55
         * min_price : 3.00
         */

        private String id;
        private String vtype;
        private String noofseats;
        private String price_per_km;
        private String price_per_min;
        private String min_price;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getVtype() {
            return vtype;
        }

        public void setVtype(String vtype) {
            this.vtype = vtype;
        }

        public String getNoofseats() {
            return noofseats;
        }

        public void setNoofseats(String noofseats) {
            this.noofseats = noofseats;
        }

        public String getPrice_per_km() {
            return price_per_km;
        }

        public void setPrice_per_km(String price_per_km) {
            this.price_per_km = price_per_km;
        }

        public String getPrice_per_min() {
            return price_per_min;
        }

        public void setPrice_per_min(String price_per_min) {
            this.price_per_min = price_per_min;
        }

        public String getMin_price() {
            return min_price;
        }

        public void setMin_price(String min_price) {
            this.min_price = min_price;
        }
    }

}