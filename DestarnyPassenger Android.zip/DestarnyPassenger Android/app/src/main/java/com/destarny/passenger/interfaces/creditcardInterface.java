package com.destarny.passenger.interfaces;

/**
 * Created by hr on 5/20/2016.
 */
public interface creditcardInterface {
    public void selectCreditCard();
    public void deselectCreditCard();
}
