package com.destarny.passenger.utils;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.SeekBar;

public class Utils_SliderLayout extends SeekBar {


    private Drawable thumb;
    private SlideButtonListener listener;

    public Utils_SliderLayout(Context context, AttributeSet attrs) {
        super(context, attrs);

    }

    @Override
    public void setThumb(Drawable thumb) {
        super.setThumb(thumb);
        this.thumb = thumb;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (thumb.getBounds().contains((int) event.getX(),
                    (int) event.getY())) {
                super.onTouchEvent(event);
            } else
                return false;
        } else if (event.getAction() == MotionEvent.ACTION_UP) {
            if (getProgress() >= 25 && getProgress() < 50) {
                setProgress(50);
                handleSlide("3");
            } else if (getProgress() >= 51 && getProgress() <= 75) {
                setProgress(50);
                handleSlide("3");

            } else if (getProgress() > 75) {
                setProgress(100);
                handleSlide("1");

            } else {
                setProgress(0);
                handleSlide("2");

            }

        } else
            super.onTouchEvent(event);

        return true;
    }

    private void handleSlide(String s) {
        listener.handleSlid(s);
    }

    public void setSlideButtonListener(SlideButtonListener listener) {
        this.listener = listener;
    }

    public interface SlideButtonListener {
        public void handleSlid(String s);
    }

    @Override
    public synchronized void setProgress(int progress) {
        super.setProgress(progress);
    }
}
