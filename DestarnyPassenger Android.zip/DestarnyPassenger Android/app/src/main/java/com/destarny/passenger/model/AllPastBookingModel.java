package com.destarny.passenger.model;

/**
 * Created by sachi on 5/11/2016.
 */
public class AllPastBookingModel {


    String bid;
    String booking_from;
    String booking_to;
    String totalDistance;
    String totalDuration;
    String totalCost;
    boolean isFav;

    public boolean isFav() {
        return isFav;
    }

    public AllPastBookingModel(String bid, String booking_from, String booking_to, boolean isFav) {
        this.bid = bid;
        this.booking_from = booking_from;
        this.booking_to = booking_to;
        this.isFav = isFav;
    }

    public AllPastBookingModel(String bid, String booking_from, String booking_to, String totalDistance, String totalDuration, String totalCost, boolean isFav) {
        this.bid = bid;
        this.booking_from = booking_from;
        this.booking_to = booking_to;
        this.totalDistance = totalDistance;
        this.totalDuration = totalDuration;
        this.totalCost = totalCost;
        this.isFav = isFav;
    }

    public String getBid() {
        return bid;
    }

    public void setBid(String bid) {
        this.bid = bid;
    }

    public String getBooking_from() {
        return booking_from;
    }

    public void setBooking_from(String booking_from) {
        this.booking_from = booking_from;
    }

    public String getBooking_to() {
        return booking_to;
    }

    public void setBooking_to(String booking_to) {
        this.booking_to = booking_to;
    }

    public String getTotalDistance() {
        return totalDistance;
    }

    public void setTotalDistance(String totalDistance) {
        this.totalDistance = totalDistance;
    }

    public String getTotalDuration() {
        return totalDuration;
    }

    public void setTotalDuration(String totalDuration) {
        this.totalDuration = totalDuration;
    }

    public String getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(String totalCost) {
        this.totalCost = totalCost;
    }

    public void setIsFav(boolean isFav) {
        this.isFav = isFav;
    }
}
