package com.destarny.passenger.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

import com.destarny.passenger.R;
import com.destarny.passenger.map.NewMapsActivity;

/**
 * Created by hr on 5/11/2016.
 */
public class CustomInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {

    private static final String TAG = CustomInfoWindowAdapter.class.getSimpleName();
    private final View myContentsView;
    private Context mContext = null;

    public CustomInfoWindowAdapter(Context context) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        myContentsView = inflater.inflate(R.layout.custom_info_contents, null);
        mContext = context;
    }

    public void setData() {
        notify();
    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    @Override
    public View getInfoContents(Marker marker) {
        String markerId = marker.getId();
        Log.e(TAG, markerId);

        ImageView ivInfoWindowImage = (ImageView) myContentsView.findViewById(R.id.iv_info_window_image);
        String vehicleType = NewMapsActivity.vehicleTypeId.get(markerId);
        if (vehicleType.equals("Premium"))
            ivInfoWindowImage.setImageDrawable(mContext.getResources().getDrawable(R.drawable.premium_vehicle));
        else if (vehicleType.equals("Private"))
            ivInfoWindowImage.setImageDrawable(mContext.getResources().getDrawable(R.drawable.private_vehicle));
        else if (vehicleType.equals("Taxi"))
            ivInfoWindowImage.setImageDrawable(mContext.getResources().getDrawable(R.drawable.taxi_vehicle));

        TextView tvTitle = ((TextView) myContentsView.findViewById(R.id.tv_title));
        tvTitle.setText(marker.getTitle());
        TextView tvSnippet = ((TextView) myContentsView.findViewById(R.id.tv_snippet));
        tvSnippet.setText(marker.getSnippet());
        Button bookTaxi = (Button) myContentsView.findViewById(R.id.btn_book_taxi);

        return myContentsView;
    }

}
