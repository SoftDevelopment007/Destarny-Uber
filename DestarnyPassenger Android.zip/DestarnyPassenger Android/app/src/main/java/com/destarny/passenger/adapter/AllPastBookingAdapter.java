package com.destarny.passenger.adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import com.destarny.passenger.R;

import com.destarny.passenger.activity.FavouriteActivity;
import com.destarny.passenger.interfaces.PastBookingAllInteface;
import com.destarny.passenger.model.AllPastBookingModel;
import com.destarny.passenger.utils.Constant;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.WebFav;

/**
 * Created by sachi on 5/11/2016.
 */
public class AllPastBookingAdapter extends BaseAdapter {
    private ArrayList<AllPastBookingModel> mArrayList = new ArrayList<AllPastBookingModel>();
    private Context mContext;
    private PastBookingAllInteface mBookingInterface;
    private WebFav mWeb;
    int pos = 0;
    private Utils mUtils;


    public AllPastBookingAdapter(ArrayList<AllPastBookingModel> mArrayList, Context mContext, FavouriteActivity mActivity) {
        this.mArrayList = mArrayList;
        this.mContext = mContext;
        mBookingInterface = mActivity;
        mWeb = new WebFav();

        mUtils = new Utils(mContext);
    }

    private LayoutInflater mInflator;

    @Override
    public int getCount() {
        return mArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return mArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return mArrayList.indexOf(mArrayList.get(position));
    }

    @Override
    public View getView(final int position, View v, ViewGroup parent) {

        ViewHolder mHolder;


        if (mInflator == null) {
            mInflator = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (v == null) {
            v = mInflator.inflate(R.layout.layout_past_booking_item, null);

            mHolder = new ViewHolder();

            mHolder.bookingFromTextView = (TextView) v.findViewById(R.id.tv_booking_from);
            mHolder.bookingToTextView = (TextView) v.findViewById(R.id.tv_booking_to);
            mHolder.distanceTextView = (TextView) v.findViewById(R.id.tv_booking_distance);
            mHolder.durationTextView = (TextView) v.findViewById(R.id.tv_booking_duration);
            mHolder.costTextView = (TextView) v.findViewById(R.id.tv_booking_cost);
            mHolder.imageView = (ImageView) v.findViewById(R.id.ImgFav);

            v.setTag(mHolder);
        } else {
            mHolder = (ViewHolder) v.getTag();
        }

        mHolder.bookingFromTextView.setText(mArrayList.get(position).getBooking_from());
        mHolder.bookingToTextView.setText(mArrayList.get(position).getBooking_to());
        mHolder.distanceTextView.setText(mArrayList.get(position).getTotalDistance()+" Km");
        mHolder.durationTextView.setText(mArrayList.get(position).getTotalDuration()+" Hours");
        mHolder.costTextView.setText("$"+mArrayList.get(position).getTotalCost());

        if (!mArrayList.get(position).isFav()) {
            mHolder.imageView.setImageResource(R.drawable.ic_action_empty_star);
        } else {
            mHolder.imageView.setImageResource(R.drawable.ic_action_fill_star);
        }
        mHolder.imageView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                pos = position;

                if (mUtils.isInterentConnection()) {

                    new AddToFavBooking().execute(mArrayList.get(position).getBid());
                } else {
                    Toast.makeText(mContext, Constant.INTERNET_CONNECTION, Toast.LENGTH_SHORT).show();
                }
            }
        });
        return v;
    }

    private class ViewHolder {
        TextView bookingFromTextView;
        TextView bookingToTextView;
        TextView distanceTextView;
        TextView durationTextView;
        TextView costTextView;
        ImageView imageView;
    }


    private class AddToFavBooking extends AsyncTask<String, String, String> {

        private String strResponse = "";
        private JSONArray mArray;
        private JSONObject mObject;
        private ProgressDialog mDlg;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(mContext);
            mDlg.setMessage("Please wait..");
            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {

            try {
                strResponse = mWeb.mPassengerSetFav(params[0]);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return strResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mDlg.dismiss();


            try {
                mObject = new JSONObject(s);
                if (mObject.getBoolean("status")) {

                    mArrayList.remove(pos);
                    notifyDataSetChanged();
                    mBookingInterface.AddFavBook(pos);
                } else {
                    if (mObject.has("items")){
                    String items = mObject.getString("items");
                    Toast.makeText(mContext, items, Toast.LENGTH_SHORT).show();
                    }
                    //mBookingInterface.AddFavBook(pos);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }

    }
}