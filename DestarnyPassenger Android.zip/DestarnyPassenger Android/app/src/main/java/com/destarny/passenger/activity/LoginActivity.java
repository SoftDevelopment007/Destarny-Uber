package com.destarny.passenger.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import com.destarny.passenger.R;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.WebHandler;

public class LoginActivity extends AppCompatActivity {

    private EditText mEdtUsername, mEdtPassword;
    private CheckBox rememberMeCheckBox;
    private ShardPrefClass mPrefClass;
    private Dialog mDlg;
    private WebHandler mWebHandler;
    private AlertDialog.Builder alertDialogBuilder = null;
    private AlertDialog alertDialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(getResources().getColor(R.color.main_bg));
        }
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();

        mPrefClass = new ShardPrefClass(getApplicationContext());
        //Instance
        mWebHandler = new WebHandler();
        mEdtUsername = (EditText) findViewById(R.id.edtUserName);
        mEdtPassword = (EditText) findViewById(R.id.edtPwd);
        rememberMeCheckBox = (CheckBox) findViewById(R.id.chk_remember_me);

        if (mPrefClass.getUsername() != null)
            mEdtUsername.setText(mPrefClass.getUsername());
        if (mPrefClass.getPassword() != null)
            mEdtPassword.setText(mPrefClass.getPassword());
    }

    public void LoginOnClickMethod(View v) {
        if (v.getId() == R.id.btnLogin) {
            if (isValidate()) {
                if (Utils.isNetworkAvailable(getApplicationContext()))
                    new PassengerLoginAsyncTask()
                            .execute(mEdtUsername.getText().toString().trim(), mEdtPassword.getText().toString().trim(), mPrefClass.getToken());
                else
                    Toast.makeText(LoginActivity.this, "Please check Internet Connection!", Toast.LENGTH_LONG).show();
                //new LoginAsyncTask().execute(mEdtUsername.getText().toString().trim(), mEdtPassword.getText().toString().trim());
            }

        } else if (v.getId() == R.id.btnForgotPassword) {
            forgotPasswordCustomDialog();
//            createDialog();
        }
    }

    private void forgotPasswordCustomDialog() {
        // Create custom dialog object
        final Dialog dialog = new Dialog(LoginActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // Include dialog.xml file
        dialog.setContentView(R.layout.dialog_forgot_password);

        // set values for custom dialog components - text, image and button
//        TextView text = (TextView) dialog.findViewById(R.id.txt_dialog_message);
//        text.setText("Book this Taxi Now?");

        final EditText edittext = (EditText) dialog.findViewById(R.id.edtUserName);

        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
//        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.90);
        dialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.show();

        Button acceptButton = (Button) dialog.findViewById(R.id.btnSubmit);
        // if Yes button is clicked
        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = edittext.getText().toString();
                if (!Utils.isNotNull(email) || !Utils.validateEmail(email))
                    Toast.makeText(getApplicationContext(),
                            "Please Enter Appropriate Email!", Toast.LENGTH_SHORT).show();
                else {
                    if (Utils.isNetworkAvailable(getApplicationContext())) {
                        dialog.dismiss();
                        new ForgotPasswordTask(email).execute();
                    } else
                        Toast.makeText(LoginActivity.this, "Please check Internet Connection!", Toast.LENGTH_LONG).show();
                }
            }
        });

        Button declineButton = (Button) dialog.findViewById(R.id.btnCancel);
        // if decline button is clicked, close the custom dialog
        declineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close dialog
                dialog.dismiss();
            }
        });
    }

    private void createDialog() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
//        new AlertDialog.Builder(mContext, R.style.MyCustomDialogTheme);
        final EditText edittext = new EditText(LoginActivity.this);
        edittext.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        edittext.setImeOptions(EditorInfo.IME_ACTION_DONE);
        alert.setMessage("Forgot Password?");
//            alert.setTitle("Weather");

        alert.setView(edittext);

        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                String email = edittext.getText().toString();
                if (!Utils.isNotNull(email) || !Utils.validateEmail(email))
                    Toast.makeText(getApplicationContext(),
                            "Please Enter Appropriate Email!", Toast.LENGTH_SHORT).show();
                else {
                    if (Utils.isNetworkAvailable(getApplicationContext()))
                        new ForgotPasswordTask(email).execute();
                    else
                        Toast.makeText(LoginActivity.this, "Please check Internet Connection!", Toast.LENGTH_LONG).show();
                }
            }
        });

        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

            }
        });

        alert.show();
    }

    private boolean isValidate() {
        if (isEmpty(mEdtUsername, "Enter username")) {
            return false;
        } else if (isEmpty(mEdtUsername, "Enter Password")) {
            return false;
        }
        return true;
    }

    private boolean isEmpty(EditText mEdt, String mErrorMsg) {
        if (mEdt.getText().toString().trim().length() == 0) {
            mEdt.requestFocus();
            mEdt.setError(mErrorMsg);
            return true;
        } else {
            return false;
        }
    }


    private class PassengerLoginAsyncTask extends AsyncTask<String, String, String> {
        private ProgressDialog mDlg;
        private String strResponse;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(LoginActivity.this);
            mDlg.setMessage("Please wait..");
            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                strResponse = mWebHandler.mPassengerLogin(params[0], params[1], params[2]);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return strResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mDlg.dismiss();
            try {
                if (s != null) {
                    JSONObject mObject = new JSONObject(s);

                    if (mObject.getBoolean("status")) {
                        Toast.makeText(getApplicationContext(), "Login Successfully!", Toast.LENGTH_SHORT).show();
                        mPrefClass.setPassengerLogin(true);
                        mPrefClass.setPassengerDetails(s);
                        mPrefClass.setPassengerId(mObject.getJSONArray("items").getJSONObject(0).getString("id"));
                        mPrefClass.setPaymentMethod(mObject.getJSONArray("items").getJSONObject(0).getString("pay_method"));
                        mPrefClass.setDefaultCardId(mObject.getJSONArray("items").getJSONObject(0).getString("payid"));
                        mPrefClass.setDefaultCardPosition(-1);

                        if (rememberMeCheckBox.isChecked()) {
                            mPrefClass.setUsername(mEdtUsername.getText().toString().trim());
                            mPrefClass.setPassword(mEdtPassword.getText().toString().trim());
                        } else {
                            mPrefClass.setUsername("");
                            mPrefClass.setPassword("");
                        }

                        startActivity(new Intent(LoginActivity.this, HomeActivity.class));

                        finish();
                    } else {
                        String msg = mObject.getString("message");
                        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class ForgotPasswordTask extends AsyncTask<Void, Void, String> {
        private String email;
        private ProgressDialog progressDialog;

        ForgotPasswordTask(String email) {
            this.email = email;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(LoginActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String response = null;
            try {
                response = mWebHandler.forgotPassword(email);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (progressDialog.isShowing())
                progressDialog.hide();

            try {
                JSONObject mParentObject = new JSONObject(s);
                if (mParentObject.getBoolean("status")) {
                    String msg = mParentObject.getString("message");

                    Toast.makeText(getApplicationContext(), "" + msg, Toast.LENGTH_LONG).show();
//                    JSONObject items = mParentObject.getJSONObject("items");
//                    LoginActivity.this.finish();
                } else {
                    Toast.makeText(getApplicationContext(), "Something went wrong! Please try again!", Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(LoginActivity.this, SwitchActivity.class));
        finish();
    }
}
