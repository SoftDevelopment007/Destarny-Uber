package com.destarny.passenger.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import com.destarny.passenger.R;
import com.destarny.passenger.utils.Constant;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.WebHandler;

public class PassengerRegisterActivity extends AppCompatActivity {

    private EditText mEdtEmail, mEdtUsername, mEdtPassword, mEdtFirstName, mEdtLastName, mEdtContact;

    private CheckBox mChkTermsCondition;
    private TextView mtxtTermsConditionDialogBox;
    private ProgressBar mPrgTermsAndcondition;

    private WebHandler mWebHandler;
    private ShardPrefClass mPref;
    private Utils mUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(getResources().getColor(R.color.main_bg));
        }

        setContentView(R.layout.activity_passenger_register);
        getSupportActionBar().hide();
        mWebHandler = new WebHandler();
        mEdtFirstName = (EditText) findViewById(R.id.edtFirstName);
        mEdtLastName = (EditText) findViewById(R.id.edtLastName);
        mEdtPassword = (EditText) findViewById(R.id.edtPwd);
        mEdtUsername = (EditText) findViewById(R.id.edtUserName);
        mEdtEmail = (EditText) findViewById(R.id.edtEmail);
        mEdtContact = (EditText) findViewById(R.id.edtContactNumber);
        mChkTermsCondition = (CheckBox) findViewById(R.id.chkTermsCondition);
        mPref = new ShardPrefClass(getApplicationContext());
        mUtils = new Utils(getApplicationContext());
    }

    public void registerOnClick(View v) {

        if (v.getId() == R.id.btnRegister) {
            if (isValidate()) {
                if (mUtils.isInterentConnection()) {

                    new PassengerRegisterAsyncTask().execute(mEdtFirstName.getText().toString().trim(),
                            mEdtLastName.getText().toString().trim(), mEdtUsername.getText().toString().trim(),
                            mEdtEmail.getText().toString().trim(), mEdtPassword.getText().toString().trim(),
                            mEdtContact.getText().toString().trim(), mPref.getToken());
                } else {
                    Toast.makeText(PassengerRegisterActivity.this, "" + Constant.INTERNET_CONNECTION, Toast.LENGTH_SHORT).show();
                }
            }
        } else if (v.getId() == R.id.termsandcond) {
            showTermsAndConditionDialog();
        }
    }

    private void showTermsAndConditionDialog() {
        final Dialog mDlg = new Dialog(PassengerRegisterActivity.this);
        mDlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mDlg.setContentView(R.layout.layout_terms_condition);

        Button btnClose = (Button) mDlg.findViewById(R.id.btnCloseDialog);
        mtxtTermsConditionDialogBox = (TextView) mDlg.findViewById(R.id.txtTermsCondition);
        mPrgTermsAndcondition = (ProgressBar) mDlg.findViewById(R.id.prgTermsCondition);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDlg.dismiss();
            }
        });

        mDlg.show();

        if (Utils.isNetworkAvailable(PassengerRegisterActivity.this)) {
            new GetTermsAndCondition().execute();
        }
    }

    private boolean isValidate() {
        if (isEmpty(mEdtFirstName, "Enter First Name")) {
            return false;
        } else if (isEmpty(mEdtLastName, "Enter Last Name")) {
            return false;
        } else if (isEmpty(mEdtUsername, "Enter Username")) {
            return false;
        } else if (!isValidEmail(mEdtEmail.getText().toString().trim())) {
            mEdtEmail.setError("Invalid email");
            return false;
        } else if (isEmpty(mEdtPassword, "Enter Password")) {
            return false;
        } else if (isEmpty(mEdtContact, "Enter Contact Number")) {
            return false;
        } else if (!mChkTermsCondition.isChecked()) {
            Toast.makeText(PassengerRegisterActivity.this, "Please select terms and condition",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    public static boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }

    private boolean isEmpty(EditText mEdt, String mErrorMsg) {
        if (mEdt.getText().toString().trim().length() == 0) {
            mEdt.requestFocus();
            mEdt.setError(mErrorMsg);
            return true;
        } else {
            return false;
        }
    }

    private class PassengerRegisterAsyncTask extends AsyncTask<String, String, String> {
        private String strResp = "";
        private ProgressDialog mDlg;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(PassengerRegisterActivity.this);
            mDlg.setMessage("please wait..");
            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                strResp = mWebHandler.mPassengerRegister(params[0],
                        params[1], params[2],
                        params[3], params[4],
                        params[5], params[6], "Cash", "2");
            } catch (IOException e) {
                e.printStackTrace();
            }
            return strResp;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mDlg.dismiss();
            try {
                if (s != null) {
                    JSONObject mObject = new JSONObject(s);

                    if (mObject.getBoolean("status")) {
                        Toast.makeText(getApplicationContext(), "Successfully Registered! " +
                                        "Please check your inbox to Activate your account!",
                                Toast.LENGTH_LONG).show();
                        //startActivity(new Intent(PassengerRegisterActivity.this, HomeActivity.class));
                        finish();
                    } else {
                        JSONObject items = mObject.getJSONObject("items");
                        String msg = items.getString("items");
                        Toast.makeText(getApplicationContext(), "Failed to Register!"
                                + msg, Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class GetTermsAndCondition extends AsyncTask<String, String, String> {
        private JSONObject mObject;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mPrgTermsAndcondition.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... params) {
            String strJson = null;

            try {
                strJson = mWebHandler.mPassengerGetTermsCondition();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return strJson;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mPrgTermsAndcondition.setVisibility(View.GONE);

            if (s != null) {
                try {
                    mObject = new JSONObject(s);

                    if (mObject.getBoolean("status")) {
                        JSONArray itemsJsonArray = mObject.getJSONArray("items");
                        JSONObject cmsJsonObject = itemsJsonArray.getJSONObject(0);
                        String termsString = cmsJsonObject.getString("cms");

                        mtxtTermsConditionDialogBox.setText(Html.fromHtml(termsString));
                        mtxtTermsConditionDialogBox.setMovementMethod(new ScrollingMovementMethod());
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(PassengerRegisterActivity.this, "Something went wrong!",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
}
