package com.destarny.passenger.activity;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import com.destarny.passenger.R;
import com.destarny.passenger.adapter.AllFavBookingAdapter;
import com.destarny.passenger.adapter.AllPastBookingAdapter;
import com.destarny.passenger.interfaces.PastBookingAllInteface;
import com.destarny.passenger.model.AllPastBookingModel;
import com.destarny.passenger.utils.Constant;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.WebFav;

public class FavouriteActivity extends Activity implements PastBookingAllInteface {

    private static String TAG = "Fav Class";

    private ImageView imgBack, imgRightAdd;
    private TextView txtTitle;
    private TabLayout tabLayout;
    private Utils mUtils;
    private ShardPrefClass mPref;
    private ProgressBar mLoadingBar;
    private ListView mLstFavBooking, mLstAllBooking;
    private WebFav mWeb;
    private AllPastBookingAdapter mPastBookingAdapter;
    private AllFavBookingAdapter mFavBookingAdapter;

    private ArrayList<AllPastBookingModel> mAllPastBookingListView = new ArrayList<AllPastBookingModel>();
    private ArrayList<AllPastBookingModel> mAllFavBookingListView = new ArrayList<AllPastBookingModel>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);

        mUtils = new Utils(FavouriteActivity.this);

        imgBack = (ImageView) findViewById(R.id.toolbar_left);
        imgRightAdd = (ImageView) findViewById(R.id.toolbar_right);
        txtTitle = (TextView) findViewById(R.id.toolbar_title);
        txtTitle.setVisibility(View.VISIBLE);
        txtTitle.setText("Favourite");
        mPref = new ShardPrefClass(getApplicationContext());
        imgBack.setImageResource(R.drawable.ic_action_back);
        imgBack.setVisibility(View.VISIBLE);

        tabLayout = (TabLayout) findViewById(R.id.sliding_tabs);
        mLoadingBar = (ProgressBar) findViewById(R.id.loadingBar);
        mLstFavBooking = (ListView) findViewById(R.id.lstFavList);
        mLstAllBooking = (ListView) findViewById(R.id.lstAllBooking);
        tabLayout.addTab(tabLayout.newTab().setText("Past Bookings"));
        tabLayout.addTab(tabLayout.newTab().setText("Favourite Booking"));

        mWeb = new WebFav();
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();

            }
        });
        if (mUtils.isInterentConnection()) {
            //new GetAllPastBooking().execute("1");
            mLstAllBooking.setVisibility(View.VISIBLE);
            mLstFavBooking.setVisibility(View.INVISIBLE);
            new GetAllPastBooking().execute(mPref.getPassengerId());
        } else {
            Toast.makeText(FavouriteActivity.this, Constant.INTERNET_CONNECTION, Toast.LENGTH_SHORT).show();
        }

        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                if (tab.getPosition() == 0) {
                    if (mUtils.isInterentConnection()) {
                        mLstAllBooking.setVisibility(View.VISIBLE);
                        mLstFavBooking.setVisibility(View.INVISIBLE);
                        //new GetAllPastBooking().execute("1");
                        new GetAllPastBooking().execute(mPref.getPassengerId());
                    } else {
                        Toast.makeText(FavouriteActivity.this, Constant.INTERNET_CONNECTION, Toast.LENGTH_SHORT).show();
                    }
                } else if (tab.getPosition() == 1) {
                    if (mUtils.isInterentConnection()) {
                        //new GetFavBooking().execute("1");
                        mLstAllBooking.setVisibility(View.INVISIBLE);
                        mLstFavBooking.setVisibility(View.VISIBLE);
                        new GetFavBooking().execute(mPref.getPassengerId());
                    } else {
                        Toast.makeText(FavouriteActivity.this, Constant.INTERNET_CONNECTION, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

    private class GetFavBooking extends AsyncTask<String, String, String> {

        private String strResponse = "";
        private JSONArray mArray;
        private JSONObject mObject;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mLoadingBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... params) {

            try {
                strResponse = mWeb.mPassengerGetFavList(params[0]);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return strResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mLoadingBar.setVisibility(View.INVISIBLE);
            Log.e(TAG, "onPostExecute: " + s);
            try {
                mObject = new JSONObject(s);
                if (mObject.getBoolean("status")) {

                    mArray = mObject.getJSONArray("items");
                    mAllFavBookingListView.clear();
                    for (int i = 0; i < mArray.length(); i++) {

                        AllPastBookingModel mObj;
                        String bid = mArray.getJSONObject(i).getString("id");
                        String booking_from = mArray.getJSONObject(i).getString("booking_from");
                        String booking_to = mArray.getJSONObject(i).getString("booking_to");
                        String totalDistance = mArray.getJSONObject(i).getString("tot_distance");
                        String totalDuration = mArray.getJSONObject(i).getString("tot_duration");
                        String totalCost = mArray.getJSONObject(i).getString("tot_fare");

//                        mObj = new AllPastBookingModel(bid, booking_from, booking_to, true);
                        mObj = new AllPastBookingModel(bid, booking_from, booking_to, totalDistance,
                                totalDuration, totalCost, true);

                        mAllFavBookingListView.add(mObj);

                        AddDataToFavAdapter();
                    }
                } else {
                    Toast.makeText(FavouriteActivity.this, "Record not Available", Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void AddDataToFavAdapter() {
        mFavBookingAdapter = new AllFavBookingAdapter(mAllFavBookingListView, FavouriteActivity.this);
        mLstFavBooking.setAdapter(mFavBookingAdapter);
        mFavBookingAdapter.notifyDataSetChanged();
    }

    private class GetAllPastBooking extends AsyncTask<String, String, String> {

        private String strResponse = "";
        private JSONArray mArray;
        private JSONObject mObject;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mLoadingBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... params) {

            try {
                strResponse = mWeb.mPassengerGetAllPastBookings(params[0]);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return strResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mLoadingBar.setVisibility(View.INVISIBLE);
            Log.e(TAG, "onPostExecute: " + s);

            try {
                mObject = new JSONObject(s);
                if (mObject.getBoolean("status")) {

                    mArray = mObject.getJSONArray("items");
                    mAllPastBookingListView.clear();
                    for (int i = 0; i < mArray.length(); i++) {

                        AllPastBookingModel mObj;
                        String bid = mArray.getJSONObject(i).getString("id");
                        String booking_from = mArray.getJSONObject(i).getString("booking_from");
                        String booking_to = mArray.getJSONObject(i).getString("booking_to");
//                        String status  = mArray.getJSONObject(i).getString("booking_to");
                        String totalDistance = mArray.getJSONObject(i).getString("tot_distance");
                        String totalDuration = mArray.getJSONObject(i).getString("tot_duration");
                        String totalCost = mArray.getJSONObject(i).getString("tot_fare");
                        String isFav = mArray.getJSONObject(i).getString("favorites_booking");
                        boolean isFavv;
                        if (isFav.equals("1")) {
                            isFavv = true;
                        } else {
                            isFavv = false;
                        }

                        mObj = new AllPastBookingModel(bid, booking_from, booking_to, totalDistance,
                                totalDuration, totalCost, isFavv);
                        mAllPastBookingListView.add(mObj);

                        AddDataToAdapter();
                    }
                } else {
                    Toast.makeText(FavouriteActivity.this, "Record not Available", Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }

    private void AddDataToAdapter() {
        mPastBookingAdapter = new AllPastBookingAdapter(mAllPastBookingListView, FavouriteActivity.this, FavouriteActivity.this);
        mLstAllBooking.setAdapter(mPastBookingAdapter);
        mPastBookingAdapter.notifyDataSetChanged();
    }

    @Override
    public void AddFavBook(int position) {
        Toast.makeText(FavouriteActivity.this, "Added Booking to Favourite Successfully!",
                Toast.LENGTH_SHORT).show();
        tabLayout.getTabAt(1).select();

    }


}
