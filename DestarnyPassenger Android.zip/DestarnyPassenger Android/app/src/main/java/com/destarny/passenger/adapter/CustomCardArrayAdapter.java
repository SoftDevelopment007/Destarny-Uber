package com.destarny.passenger.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

import com.destarny.passenger.R;
import com.destarny.passenger.activity.BillingInfoActivity;
import com.destarny.passenger.interfaces.creditcardInterface;
import com.destarny.passenger.model.CreditCardClass;
import com.destarny.passenger.utils.ShardPrefClass;

/**
 * Created by hr on 5/12/2016.
 */
public class CustomCardArrayAdapter extends ArrayAdapter<CreditCardClass> {
    private ArrayList<CreditCardClass> objects;
    int layoutResourceId;
    int selected_position = -1;
    private ShardPrefClass mShardPrefClass = null;
    private creditcardInterface mInterface;

    public CustomCardArrayAdapter(Context context, int layoutResourceId, ArrayList<CreditCardClass> objects, BillingInfoActivity con) {
        super(context, layoutResourceId, objects);
        this.layoutResourceId = layoutResourceId;
        this.objects = objects;
        mInterface = con;
        mShardPrefClass = new ShardPrefClass(context);
        selected_position = mShardPrefClass.getDefaultCardPosition();
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View rootView = convertView;
        CreditCardViewHolder cardViewHolder = null;


        // first check to see if the view is null. if so, we have to inflate it.
        // to inflate it basically means to render, or show, the view.
        if (rootView == null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rootView = inflater.inflate(layoutResourceId, null);

            cardViewHolder = new CreditCardViewHolder();
            cardViewHolder.serialTextView = (TextView) rootView.findViewById(R.id.tv_card_no);
            cardViewHolder.cardNoTextView = (TextView) rootView.findViewById(R.id.tv_card_no);
            cardViewHolder.expiryDateTextView = (TextView) rootView.findViewById(R.id.tv_card_expiry_date);
            cardViewHolder.defaultCardCheckBox = (CheckBox) rootView.findViewById(R.id.chk_default_card);

            rootView.setTag(cardViewHolder);
        } else {
            cardViewHolder = (CreditCardViewHolder) rootView.getTag();
        }

        final CreditCardClass creditCardClass = objects.get(position);
        cardViewHolder.serialTextView.setText(" ");
        cardViewHolder.cardNoTextView.setText(creditCardClass.getCnolastdigits());
        String expiryDate = creditCardClass.getYear();
        cardViewHolder.expiryDateTextView.setText(expiryDate);
        cardViewHolder.defaultCardCheckBox.setTag(position);

        if (position == selected_position) {
            cardViewHolder.defaultCardCheckBox.setChecked(true);
        } else {
            cardViewHolder.defaultCardCheckBox.setChecked(false);
        }

        cardViewHolder.defaultCardCheckBox.
                setOnClickListener(onStateChangedListener(cardViewHolder.defaultCardCheckBox
                        , position));

        // the view must be returned to our activity
        return rootView;
    }

    private View.OnClickListener onStateChangedListener(final CheckBox checkBox, final int position) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox.isChecked()) {
                    String defaultCardId = objects.get(position).getId();
                    mShardPrefClass.setDefaultCardId(defaultCardId);
                    mShardPrefClass.setDefaultCardPosition(position);
                    selected_position = position;
                    mInterface.selectCreditCard();
                } else {
                    mInterface.deselectCreditCard();
                    selected_position = -1;
                    mShardPrefClass.setDefaultCardId("-1");
                    mShardPrefClass.setDefaultCardPosition(selected_position);
                }
                notifyDataSetChanged();
            }
        };
    }

    static class CreditCardViewHolder {
        TextView serialTextView;
        TextView cardNoTextView;
        TextView expiryDateTextView;
        CheckBox defaultCardCheckBox;
    }
}
