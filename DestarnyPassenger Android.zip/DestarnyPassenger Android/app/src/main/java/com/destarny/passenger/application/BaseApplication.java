package com.destarny.passenger.application;

import android.app.Application;


import org.acra.ACRA;
import org.acra.ReportField;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

import com.destarny.passenger.R;

/**
 * Created by Aniket on 6/22/2016.
 */

@ReportsCrashes(mailTo = "aniket.h@edreamz.in", customReportContent = {
        ReportField.APP_VERSION_CODE, ReportField.APP_VERSION_NAME,
        ReportField.ANDROID_VERSION, ReportField.PHONE_MODEL,
        ReportField.CUSTOM_DATA, ReportField.STACK_TRACE, ReportField.LOGCAT},
        mode = ReportingInteractionMode.DIALOG, resDialogText = R.string.crash_toast_text,
        resDialogIcon = android.R.drawable.ic_dialog_info, resDialogTitle = R.string.crash_title)

public class BaseApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        ACRA.init(this);
    }
}
