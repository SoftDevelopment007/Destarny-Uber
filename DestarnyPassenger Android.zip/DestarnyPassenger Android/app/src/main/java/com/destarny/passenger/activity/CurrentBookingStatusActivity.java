package com.destarny.passenger.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import com.destarny.passenger.R;
import com.destarny.passenger.adapter.CurrentBookingStatusAdapter;
import com.destarny.passenger.model.CurrentBookingStatus;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.WebHandler;

public class CurrentBookingStatusActivity extends AppCompatActivity {

    private ImageView imgBack;
    private ImageView imgRefresh;
    //    private ProgressBar mToolBarRightProgressBar;
    private TextView txtTitle;

    private ListView currentBookingLV;
    ArrayList<CurrentBookingStatus> currentBookingStatuses = null;
    private CurrentBookingStatusAdapter statusAdapter;

    private WebHandler mWebHandler = null;
    private ShardPrefClass mPrefClass = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_booking_status);
        getSupportActionBar().hide();
        imgBack = (ImageView) findViewById(R.id.toolbar_left);
        imgRefresh = (ImageView) findViewById(R.id.toolbar_refresh);
        imgRefresh.setVisibility(View.VISIBLE);
//        mToolBarRightProgressBar = (ProgressBar) findViewById(R.id.progress_right);
        txtTitle = (TextView) findViewById(R.id.toolbar_title);
        txtTitle.setVisibility(View.VISIBLE);
        txtTitle.setText("Current Booking Status");
        imgBack.setVisibility(View.VISIBLE);
        imgBack.setImageResource(R.drawable.ic_action_back);
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        bindViews();
        initObjects();
        currentBookingStatuses = new ArrayList<>();

        if (Utils.isNetworkAvailable(CurrentBookingStatusActivity.this)) {
            new GetCurrentBookingStatusTask().execute();
        }

        imgRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isNetworkAvailable(CurrentBookingStatusActivity.this)) {
                    currentBookingStatuses = new ArrayList<>();
                    new GetCurrentBookingStatusTask().execute();
                }
            }
        });

    }

    private void bindViews() {
        currentBookingLV = (ListView) findViewById(R.id.lv_current_booking);
    }

    private void initObjects() {
        mWebHandler = new WebHandler();
        mPrefClass = new ShardPrefClass(CurrentBookingStatusActivity.this);
    }

//    @Override
//    public void onButtonClicked(int position) {
//        callCustomDialog(position);
//    }

    public void onButtonClicked(int position) {
        callCustomDialog(position);
    }

    public void onCallButtonClicked(String contact) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + contact.trim()));
        startActivity(intent);
    }

    private void callCustomDialog(final int position) {
        // Create custom dialog object
        final Dialog dialog = new Dialog(CurrentBookingStatusActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // Include dialog.xml file
        dialog.setContentView(R.layout.dialog_cancel_booking);

        // set values for custom dialog components - text, image and button
        TextView textTitle = (TextView) dialog.findViewById(R.id.txt_dia_title);
        textTitle.setText("Cancel Booking");
        TextView textMsg = (TextView) dialog.findViewById(R.id.txt_dia_message);
        textMsg.setText("Cancel this booking?");
        final EditText reasonEditText = (EditText) dialog.findViewById(R.id.et_cancel_reason);

        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
//        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.90);
        dialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.show();

        Button acceptButton = (Button) dialog.findViewById(R.id.btn_yes);
        // if Yes button is clicked
        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String reason = reasonEditText.getText().toString();
                if (Utils.isNotNull(reason)) {
                    if (Utils.isNetworkAvailable(CurrentBookingStatusActivity.this)) {
                        dialog.dismiss();
                        new CancelBookingTask(position, reason).execute();
                    } else {
                        Toast.makeText(CurrentBookingStatusActivity.this, "Please check Internet Connection!",
                                Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(CurrentBookingStatusActivity.this, "Please Enter The Reason!",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button declineButton = (Button) dialog.findViewById(R.id.btn_no);
        // if decline button is clicked, close the custom dialog
        declineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close dialog
                dialog.dismiss();
            }
        });
    }

    private class GetCurrentBookingStatusTask extends AsyncTask<Void, Void, String> {

        private ProgressDialog mProgressDialog = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mProgressDialog = new ProgressDialog(CurrentBookingStatusActivity.this);
            mProgressDialog.setMessage("Please wait...");
            mProgressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String passId = mPrefClass.getPassengerId();
            String response = null;

            try {
                response = mWebHandler.getCurrentBookingStatus(passId);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (mProgressDialog.isShowing())
                mProgressDialog.dismiss();

            if (s != null) {
                try {
                    JSONObject responseObject = new JSONObject(s);
                    if (responseObject.getBoolean("status")) {

                        JSONArray itemsJsonArray = responseObject.getJSONArray("items");

                        int size = itemsJsonArray.length();
                        for (int i = 0; i < size; i++) {
                            JSONObject object = itemsJsonArray.getJSONObject(i);
                            String bidString = object.getString("id");
                            String sourceString = object.getString("booking_from");
                            String destString = object.getString("booking_to");
                            String bookingTimeString = object.getString("booking_date")
                                    + "   " + object.getString("booking_time");
                            String vehicleTypeString = object.getString("vtype");
                            String noOfPassString = object.getString("noofpass");
                            String setFareString = object.getString("fare_type");
                            String fname = "";
                            if (object.has("fname"))
                                fname = object.getString("fname");
                            String lname = "";
                            if (object.has("lname"))
                                lname = object.getString("lname");

                            String driverNameString = fname + " " + lname;

                            String driverContactString = "";
                            if (object.has("phone_no"))
                                driverContactString = object.getString("phone_no");

                            String modelString = "";
                            if (object.has("modelno"))
                                modelString = object.getString("modelno");

                            String vehicleNoString = "";
                            if (object.has("veh_no"))
                                vehicleNoString = object.getString("veh_no");

                            String vehicleRegoString = "";
                            if (object.has("driver_noplate"))
                                vehicleRegoString = object.getString("driver_noplate");

                            String madeString = "";
                            if (object.has("made"))
                                madeString = object.getString("made");

                            String distanceFromDriver = "";
                            if (object.has("distance_from_driver_to_bookingfrom"))
                                distanceFromDriver = object.getString("distance_from_driver_to_bookingfrom");

                            String durationFromDriver = "";
                            if (object.has("duration_from_driver_to_bookingfrom"))
                                durationFromDriver = object.getString("duration_from_driver_to_bookingfrom");

                            String durationFromDriverInTraffic = "";
                            if (object.has("duration_in_traffic_from_driver_to_bookingfrom"))
                                durationFromDriverInTraffic = object.getString("duration_in_traffic_from_driver_to_bookingfrom");

                            CurrentBookingStatus bookingStatus = new CurrentBookingStatus();
                            bookingStatus.setBid(bidString);
                            bookingStatus.setSource(sourceString);
                            bookingStatus.setDestination(destString);
                            bookingStatus.setBookingTime(bookingTimeString);
                            bookingStatus.setVehicleType(vehicleTypeString);
                            bookingStatus.setNoOfPass(noOfPassString);
                            bookingStatus.setSetFare(setFareString);
                            bookingStatus.setDriverName(driverNameString);
                            bookingStatus.setDriverContact(driverContactString);
                            bookingStatus.setModel(modelString);
                            bookingStatus.setVehicleNo(vehicleNoString);
                            bookingStatus.setVehicleRego(vehicleRegoString);
                            bookingStatus.setMade(madeString);
                            bookingStatus.setDistanceFromDriver(distanceFromDriver);
                            bookingStatus.setDurationFromDriver(durationFromDriver);
                            bookingStatus.setDurationFromDriverInTraffic(durationFromDriverInTraffic);

                            currentBookingStatuses.add(bookingStatus);
                        }

                        statusAdapter =
                                new CurrentBookingStatusAdapter(CurrentBookingStatusActivity.this,
                                        R.layout.current_booking_status_item, currentBookingStatuses);

                        currentBookingLV.setAdapter(statusAdapter);
                    } else {
                        Toast.makeText(CurrentBookingStatusActivity.this,
                                "Record Not Found!", Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class CancelBookingTask extends AsyncTask<Void, Void, String> {

        private ProgressDialog mProgressDialog = null;
        private int position;
        private String reason;

        public CancelBookingTask(int position, String reason) {
            this.position = position;
            this.reason = reason;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mProgressDialog = new ProgressDialog(CurrentBookingStatusActivity.this);
            mProgressDialog.setMessage("Please wait...");
            mProgressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            CurrentBookingStatus bookingStatus = currentBookingStatuses.get(position);
            String bid = bookingStatus.getBid();
            String passId = mPrefClass.getPassengerId();
            String response = null;

            try {
                response = mWebHandler.cancelBooking(bid, passId, reason);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (mProgressDialog.isShowing())
                mProgressDialog.dismiss();

            if (s != null) {
                try {
                    JSONObject responseObject = new JSONObject(s);
                    if (responseObject.getBoolean("status")) {
                        String msg = responseObject.getString("items");
                        currentBookingStatuses.remove(position);
                        statusAdapter.notifyDataSetChanged();

                        Toast.makeText(CurrentBookingStatusActivity.this,
                                "Order is successfully canceled!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(CurrentBookingStatusActivity.this,
                                "Unable to cancel Order!", Toast.LENGTH_LONG).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }


}
