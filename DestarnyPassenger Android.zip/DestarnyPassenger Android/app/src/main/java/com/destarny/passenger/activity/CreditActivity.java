package com.destarny.passenger.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.destarny.passenger.R;
import com.destarny.passenger.adapter.CustomCardArrayAdapter;
import com.destarny.passenger.interfaces.creditcardInterface;
import com.destarny.passenger.model.CreditCardClass;
import com.destarny.passenger.utils.Constant;
import com.destarny.passenger.utils.InputFilterMinMax;
import com.destarny.passenger.utils.ShardPrefClass;
import com.destarny.passenger.utils.Utils;
import com.destarny.passenger.web.WebHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

public class CreditActivity extends AppCompatActivity implements creditcardInterface {

    private ImageView imgBack, imgRightAdd;
    private TextView txtTitle;

//    private ListView mLstCards;
    private TextView emptyTextView;

    private EditText cardNoEditText, monthEditText, yearEditText, cvvEditText;
    private String cardNo, month, year, cvv;
    private String passId;

    private ShardPrefClass mPref;

    private WebHandler mWebHandler = null;
    private String getPaymentResponse = "";
    private String response = "";
    int index = 0;
    private ArrayList<CreditCardClass> creditCardClasses = new ArrayList<CreditCardClass>();

    private Utils mUtils;
    private Button btnDone;

    private RadioGroup paymentTypeGroup = null;
    private RadioButton cashRadioButton, cardRadioButton;
    private String payMethod = null;
    private String payId = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit);
        getSupportActionBar().hide();
        imgBack = (ImageView) findViewById(R.id.toolbar_left);
        txtTitle = (TextView) findViewById(R.id.toolbar_title);
        emptyTextView = (TextView) findViewById(R.id.tv_empty_view);

        txtTitle.setVisibility(View.VISIBLE);
        txtTitle.setText("Credit");
        imgBack.setVisibility(View.VISIBLE);
        imgBack.setImageResource(R.drawable.ic_action_back);
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        paymentTypeGroup = (RadioGroup) findViewById(R.id.rg_payment_type_bi);
        cashRadioButton = (RadioButton) findViewById(R.id.radio_cash_bi);
        cardRadioButton = (RadioButton) findViewById(R.id.radio_credit_card_bi);

        mPref = new ShardPrefClass(CreditActivity.this);
        mWebHandler = new WebHandler();

        passId = mPref.getPassengerId();

        if (Utils.isNetworkAvailable(CreditActivity.this)) {
            new CreditActivity.GetPaymentMethodTask().execute();
        } else {
            Toast.makeText(CreditActivity.this, "Please check Internet Connection!", Toast.LENGTH_SHORT).show();
            finish();
        }

        imgRightAdd.setImageResource(R.drawable.ic_action_add);
        imgRightAdd.setVisibility(View.VISIBLE);
        imgRightAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Dialog mDlg = new Dialog(CreditActivity.this);

                mDlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
                mDlg.setContentView(R.layout.layout_payment_type);
                mDlg.show();

                Button btnCancel = (Button) mDlg.findViewById(R.id.btnCancel);
                Button btnSubmit = (Button) mDlg.findViewById(R.id.btnSubmit);

                cardNoEditText = (EditText) mDlg.findViewById(R.id.edtCardNumber);
                monthEditText = (EditText) mDlg.findViewById(R.id.edtMonth);
                yearEditText = (EditText) mDlg.findViewById(R.id.edtYear);
                cvvEditText = (EditText) mDlg.findViewById(R.id.edtCVV);

                monthEditText.setFilters(new InputFilter[]{new InputFilterMinMax(1, 12)});
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDlg.dismiss();

                    }
                });

                btnSubmit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        cardNo = cardNoEditText.getText().toString();
                        month = monthEditText.getText().toString();
                        year = yearEditText.getText().toString();
                        cvv = cvvEditText.getText().toString();

                        if (validate()) {
                            mDlg.dismiss();
                            if (Utils.isNetworkAvailable(CreditActivity.this)) {
                                new CreditActivity.AddPaymentMethodTask().execute();
                            } else {
                                Toast.makeText(CreditActivity.this,
                                        "Please check Internet Connection!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });


            }
        });
        imgBack.setImageResource(R.drawable.ic_action_back);
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataBackToMaps();
//                finish();
            }
        });


//        registerForContextMenu(mLstCards);

        setPaymentMethod();
    }

    private void setPaymentMethod() {
        String paymentMethod = mPref.getPaymentMethod();

        if (paymentMethod.equals("Cash")) {
            payMethod = paymentMethod;
            cashRadioButton.setChecked(true);
//                cardRadioButton.setChecked(false);
            cashRadioButton.setTextColor(Color.parseColor("#FFCB07"));
            cardRadioButton.setTextColor(Color.WHITE);
        } else if (paymentMethod.equals("CreditCard")) {
            if (mPref.getDefaultCardPosition() != -1) {
                payMethod = paymentMethod;
//            cashRadioButton.setChecked(false);
                cardRadioButton.setChecked(true);
                cashRadioButton.setTextColor(Color.WHITE);
                cardRadioButton.setTextColor(Color.parseColor("#FFCB07"));
            } else {
                cashRadioButton.setChecked(true);
            }
        }

        paymentTypeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio_cash_bi) {
                    cashRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                    cardRadioButton.setTextColor(Color.WHITE);

                    // TODO: Call API to set method
                } else if (checkedId == R.id.radio_credit_card_bi) {
                    cashRadioButton.setTextColor(Color.WHITE);
                    cardRadioButton.setTextColor(Color.parseColor("#FFCB07"));
                }
            }
        });

        cashRadioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                payMethod = "Cash";
                mPref.setPaymentMethod(payMethod);
                payId = "0";
                new CreditActivity.SetPaymentMethodTask().execute();
            }
        });

        cardRadioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mPref.getDefaultCardPosition() != -1) {
                    payMethod = "CreditCard";
                    mPref.setPaymentMethod(payMethod);
                    payId = mPref.getDefaultCardId();
                    new CreditActivity.SetPaymentMethodTask().execute();
                }
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Select The Action");
        menu.add(0, v.getId(), 0, "Delete");//groupId, itemId, order, title
        menu.add(0, v.getId(), 0, "Cancel");
    }


    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        index = info.position;
        if (item.getTitle() == "Delete") {

            //Toast.makeText(CreditActivity.this, "" + index, Toast.LENGTH_SHORT).show();
            if (Utils.isNetworkAvailable(CreditActivity.this)) {


                CreditCardClass mObj = creditCardClasses.get(index);

                new CreditActivity.DeleteCreditCard().execute("" + mObj.getId(), mPref.getPassengerId());
            } else {
                Toast.makeText(CreditActivity.this, Constant.INTERNET_CONNECTION, Toast.LENGTH_SHORT).show();
            }
        } else if (item.getTitle() == "Cancel") {

        } else {
            return false;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent returnIntent = new Intent();
        setResult(Activity.RESULT_CANCELED, returnIntent);
        finish();
    }

    private void sendDataBackToMaps() {
        if (mPref.getDefaultCardPosition() != -1) {
            Intent returnIntent = new Intent();
            returnIntent.putExtra("cardId", mPref.getDefaultCardId());
            setResult(Activity.RESULT_OK, returnIntent);
            finish();
        } else {
            Intent returnIntent = new Intent();
            setResult(Activity.RESULT_CANCELED, returnIntent);
            finish();
        }
    }

    private boolean validate() {
        if (!Utils.isNotNull(cardNo)) {
            Toast.makeText(CreditActivity.this, "Please enter valid Card Number!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!Utils.isNotNull(month)) {
            Toast.makeText(CreditActivity.this, "Please enter valid Month!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!Utils.isNotNull(year)) {
            Toast.makeText(CreditActivity.this, "Please enter valid Year!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!Utils.isNotNull(cvv)) {
            Toast.makeText(CreditActivity.this, "Please enter valid CVV!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    @Override
    public void selectCreditCard() {
        btnDone.setVisibility(View.VISIBLE);
    }

    @Override
    public void deselectCreditCard() {
        btnDone.setVisibility(View.GONE);
    }

    private class GetPaymentMethodTask extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressDialog = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(CreditActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            try {
                getPaymentResponse = mWebHandler.getPaymentMethod(passId);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return getPaymentResponse;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            try {
                if (s != null) {
                    JSONObject responseObject = new JSONObject(s);
                    if (responseObject.getBoolean("status")) {
                        JSONArray itemsJsonArray = responseObject.getJSONArray("items");
                        creditCardClasses = new ArrayList<>();
                        int size = itemsJsonArray.length();
                        for (int i = 0; i < size; i++) {
                            JSONObject itemObject = itemsJsonArray.getJSONObject(i);
                            String id = itemObject.getString("id");
                            String cid = itemObject.getString("cid");
                            String cnolastdigits = itemObject.getString("cnolastdigits");
                            String cardNo = itemObject.getString("cno");
                            String expdate = itemObject.getString("expdate");


                            String cvv = itemObject.getString("cvn");

                            CreditCardClass creditCardClass = new CreditCardClass();
                            creditCardClass.setId(id);
                            creditCardClass.setCid(cid);
                            creditCardClass.setCardNo(cardNo);
                            creditCardClass.setCnolastdigits("XXXX XXXX XXXX " + cnolastdigits);
                            creditCardClass.setMonth(expdate);
                            creditCardClass.setYear(expdate);
                            creditCardClass.setCvv(cvv);

                            if (mPref.getDefaultCardPosition() == i) {
                                creditCardClass.setIsChecked(true);
                            } else {
                                creditCardClass.setIsChecked(false);
                            }

                            creditCardClasses.add(creditCardClass);
                        }

//                    ArrayAdapter<CreditCardClass> cardArrayAdapter
//                            = new ArrayAdapter<>(CreditActivity.this, android.R.layout.simple_list_item_1,
//                            creditCardClasses);
//                        CustomCardArrayAdapter cardArrayAdapter
//                                = new CustomCardArrayAdapter(CreditActivity.this, R.layout.credit_card_item,
//                                creditCardClasses, CreditActivity.this);
//                        mLstCards.setAdapter(cardArrayAdapter);
//                        mLstCards.setVisibility(View.VISIBLE);
                        emptyTextView.setVisibility(View.GONE);
                    } else {
                        Toast.makeText(CreditActivity.this, "Getting Card List Unsuccessful!", Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private class AddPaymentMethodTask extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressDialog = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(CreditActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            try {
                response = mWebHandler.addPaymentMethod(passId, cardNo, cvv, " 20" + year + "/" + month + "/" + "01");
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            try {
                JSONObject responseObject = new JSONObject(s);

                if (responseObject.getBoolean("status")) {
                    Toast.makeText(CreditActivity.this, "Card Added Successfully!", Toast.LENGTH_SHORT).show();

                    JSONArray itemsJsonArray = responseObject.getJSONArray("items");
                    creditCardClasses = new ArrayList<>();
                    int size = itemsJsonArray.length();
                    for (int i = 0; i < size; i++) {
                        JSONObject itemObject = itemsJsonArray.getJSONObject(i);
                        String id = itemObject.getString("id");
                        String cid = itemObject.getString("cid");
                        String cnolastdigits = itemObject.getString("cnolastdigits");
                        String cardNo = itemObject.getString("cno");
                        String expdate = itemObject.getString("expdate");
                       /* String[] date = expdate.split(" ");*/

                       /* String month = date[0];
                        String year = date[1];*/
//                        String month = itemObject.getString("id");
//                        String year = itemObject.getString("id");
                        String cvv = itemObject.getString("cvn");

                        CreditCardClass creditCardClass = new CreditCardClass();
                        creditCardClass.setId(id);
                        creditCardClass.setCid(cid);
                        creditCardClass.setCardNo(cardNo);
                        creditCardClass.setCnolastdigits("XXXX XXXX XXXX " + cnolastdigits);
                        creditCardClass.setMonth(expdate);
                        creditCardClass.setYear(expdate);
                        creditCardClass.setCvv(cvv);

                        creditCardClasses.add(creditCardClass);
                    }

//                    ArrayAdapter<CreditCardClass> cardArrayAdapter
//                            = new ArrayAdapter<>(CreditActivity.this, android.R.layout.simple_list_item_1,
//                            creditCardClasses);
//                    CustomCardArrayAdapter cardArrayAdapter
//                            = new CustomCardArrayAdapter(CreditActivity.this, R.layout.credit_card_item,
//                            creditCardClasses, CreditActivity.this);
//                    mLstCards.setAdapter(cardArrayAdapter);
//                    mLstCards.setVisibility(View.VISIBLE);
                    emptyTextView.setVisibility(View.GONE);
                } else {
                    Toast.makeText(CreditActivity.this, "Add Card Unsuccessful!", Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    public void btnDoneBillingOnClick(View v) {
        sendDataBackToMaps();
    }


    private class DeleteCreditCard extends AsyncTask<String, String, String> {

        private ProgressDialog mDlg;
        private JSONObject mObject;
        private String strRes = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(CreditActivity.this);
            mDlg.setMessage("Please wait..");
            mDlg.show();
        }

        @Override
        protected String doInBackground(String... params) {

            try {
                strRes = mWebHandler.mDeleteCreditCard(params[0], params[1]);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return strRes;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mDlg.dismiss();
            try {
                mObject = new JSONObject(s);

                if (mObject.getBoolean("status")) {
                    Toast.makeText(CreditActivity.this, "" + mObject.getString("items"), Toast.LENGTH_SHORT).show();

                    creditCardClasses.remove(index);
//                    CustomCardArrayAdapter cardArrayAdapter
//                            = new CustomCardArrayAdapter(CreditActivity.this, R.layout.credit_card_item,
//                            creditCardClasses, CreditActivity.this);
//                    mLstCards.setAdapter(cardArrayAdapter);
//                    cardArrayAdapter.notifyDataSetChanged();


                } else {
                    Toast.makeText(CreditActivity.this, "" + mObject.getString("items"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class SetPaymentMethodTask extends AsyncTask<Void, Void, String> {

        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(CreditActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            String passId = mPref.getPassengerId();
            String response = null;
            try {
                response = mWebHandler.setPaymentMethod(passId, payMethod, payId);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (progressDialog.isShowing())
                progressDialog.hide();

            try {
                if (s != null) {
                    JSONObject mParentObject = new JSONObject(s);
                    if (mParentObject.getBoolean("status")) {
                        JSONArray items = mParentObject.getJSONArray("items");
                        Toast.makeText(getApplicationContext(),
                                "Your Payment Method is set!", Toast.LENGTH_LONG).show();

                    } else {
                        Toast.makeText(getApplicationContext(),
                                "Something went wrong! Please try again!", Toast.LENGTH_LONG).show();
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
